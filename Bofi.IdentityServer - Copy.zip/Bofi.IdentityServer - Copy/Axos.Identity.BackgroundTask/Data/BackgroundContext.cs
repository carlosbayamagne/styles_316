﻿using Axos.Identity.BackgroundTasks.Data.Entities;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Options;

namespace Axos.Identity.BackgroundTasks.Data
{
    public class BackgroundContext : DbContext
    {
        protected readonly IOptions<BackgroundConfigOptions> _configOptions;

        public DbSet<BackgroundJob> BackgroundJobs { get; set; }

        public BackgroundContext(IOptions<BackgroundConfigOptions> configOptions)
        {
            _configOptions = configOptions;
        }

        public BackgroundContext(IOptions<BackgroundConfigOptions> configOptions,
            DbContextOptions<BackgroundContext> options) : base(options)
        {
            _configOptions = configOptions;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        /// <summary>
        /// Override to set the connection string to the datbase
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            if (!optionsBuilder.IsConfigured && _configOptions?.Value?.DbConnection != null)
            {
                optionsBuilder.UseSqlServer(_configOptions.Value.DbConnection);
            }
        }
    }

    /// <summary>
    /// This is used in the migration generation.
    /// </summary>
    public class BackgroundContextFactory : IDesignTimeDbContextFactory<BackgroundContext>
    {
        protected readonly IOptions<BackgroundConfigOptions> _configOptions;

        public BackgroundContextFactory(IOptions<BackgroundConfigOptions> configOptions)
        {
            _configOptions = configOptions;
        }

        public BackgroundContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<BackgroundContext>();
            optionsBuilder.UseSqlServer(_configOptions?.Value?.DbConnection);

            return new BackgroundContext(_configOptions, optionsBuilder.Options);
        }
    }
}
