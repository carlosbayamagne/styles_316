﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace Axos.Identity.BackgroundTasks.Data.Repositories.Base
{
    public interface IBackgroundRepository<TEntity> where TEntity : class
    {
        /// <summary>
        /// Find an entity by its primary key.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<TEntity> GetAsync(int id);

        /// <summary>
        /// Get the Single or Default entity that match the criteria async.
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        Task<TEntity> GetSingleAsync(Expression<Func<TEntity, bool>> predicate);

        /// <summary>
        /// Get all the entities that match the criteria async.
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        Task<IEnumerable<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate);

        /// <summary>
        /// Get all the entities that match the criteria asynchronously.
        /// </summary>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="predicate"></param>
        /// <param name="include">Navigation property path</param>
        /// <returns></returns>
        Task<IEnumerable<TEntity>> GetAsync<TProperty>(Expression<Func<TEntity, bool>> predicate,
            Expression<Func<TEntity, TProperty>> include);

        /// <summary>
        /// Gets all the entities async.
        /// </summary>        
        /// <returns>List</returns>
        Task<IList<TEntity>> GetAllAsync();

        /// <summary>
        /// Creates a new registry on database async
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="saveChanges">Whether to save changes after the operation. Defaults to true.</param>
        Task AddAsync(TEntity entity, bool saveChanges = true);

        /// <summary>
        /// Updates a row in database async.
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="saveChanges">Whether to save changes after the operation. Defaults to true.</param>
        Task<int> UpdateAsync(TEntity entity, bool saveChanges = true);

        /// <summary>
        /// Deletes a registry in database async.
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="saveChanges">Whether to save changes after the operation. Defaults to true.</param>
        Task DeleteAsync(TEntity entity, bool saveChanges = true);

        /// <summary>
        /// Commit the changes async to the database.
        /// </summary>
        Task<int> SaveChangesAsync();
        Task<int> ExecuteSqlRawAsync(string sql, CancellationToken cancellationToken = default);
    }
}
