﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;

namespace Axos.Identity.BackgroundTasks.Data.Repositories.Base
{
    public class BackgroundRepository<TEntity> : IBackgroundRepository<TEntity> where TEntity : class
    {
        public readonly BackgroundContext Context;

        public BackgroundRepository(BackgroundContext dbContext)
        {
            Context = dbContext;
        }

        public virtual async Task AddAsync(TEntity entity, bool saveChanges = true)
        {
            Context.Set<TEntity>().Add(entity);
            if (saveChanges) await SaveChangesAsync();
        }

        public virtual async Task DeleteAsync(TEntity entity, bool saveChanges = true)
        {
            Context.Set<TEntity>().Remove(entity);
            if (saveChanges) await SaveChangesAsync();
        }

        public virtual async Task<IEnumerable<TEntity>> GetAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await Context.Set<TEntity>().Where(predicate).ToListAsync();
        }

        public virtual async Task<IEnumerable<TEntity>> GetAsync<TProperty>(Expression<Func<TEntity, bool>> predicate,
            Expression<Func<TEntity, TProperty>> include)
        {
            return await Context.Set<TEntity>().Include(include).Where(predicate).ToListAsync();
        }

        public async Task<TEntity> GetAsync(int id)
        {
            return await Context.Set<TEntity>().FindAsync(id);
        }

        public virtual async Task<IList<TEntity>> GetAllAsync()
        {
            return await Context.Set<TEntity>().ToListAsync();
        }

        public virtual async Task<TEntity> GetSingleAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await Context.Set<TEntity>().FirstOrDefaultAsync(predicate);
        }

        public virtual async Task<int> UpdateAsync(TEntity entity, bool saveChanges = true)
        {
            Context.Set<TEntity>().Update(entity);
            if (saveChanges)
                return await SaveChangesAsync();
            return 1;
        }

        public async Task<int> SaveChangesAsync()
        {
            return await Context.SaveChangesAsync();
        }

        public async Task<int> ExecuteSqlRawAsync(string sql, CancellationToken cancellationToken = default)
        {
            return await Context.Database.ExecuteSqlRawAsync(sql, cancellationToken);
        }
    }
}
