﻿using System.Threading.Tasks;

using Axos.Identity.BackgroundTasks.Data.Entities;
using Axos.Identity.BackgroundTasks.Data.Repositories.Base;

namespace Axos.Identity.BackgroundTasks.Data.Repositories
{
    public interface IBackgroundJobRepository : IBackgroundRepository<BackgroundJob>
    {
        Task<int> AddIfNotExistsAsync(BackgroundJob entity);
    }
}
