﻿using System.Threading.Tasks;

using Axos.Identity.BackgroundTasks.Data.Entities;
using Axos.Identity.BackgroundTasks.Data.Extensions;
using Axos.Identity.BackgroundTasks.Data.Repositories.Base;

namespace Axos.Identity.BackgroundTasks.Data.Repositories
{
    public class BackgroundJobRepository : BackgroundRepository<BackgroundJob>, IBackgroundJobRepository
    {
        public BackgroundJobRepository(BackgroundContext dbContext)
            : base(dbContext)
        {

        }

        public virtual async Task<int> AddIfNotExistsAsync(BackgroundJob entity)
        {
            Context.Set<BackgroundJob>().AddIfNotExists(entity, x => x.Name == entity.Name);

            return await SaveChangesAsync();
        }
    }
}
