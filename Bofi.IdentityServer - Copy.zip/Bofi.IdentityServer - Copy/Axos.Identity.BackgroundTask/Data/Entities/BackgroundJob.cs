﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.BackgroundTasks.Data.Entities
{
    public class BackgroundJob
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// The unique name of the Job. Used as main identifier.
        /// </summary>
        [Required]
        [MaxLength(64)]
        public string Name { get; set; }

        /// <summary>
        /// A brief description of what this job does.
        /// </summary>
        [MaxLength(256)]
        public string Description { get; set; }

        /// <summary>
        /// Whether the job is currently running.
        /// </summary>
        public bool IsRunning { get; set; }

        /// <summary>
        /// The datetime when the last run job started.
        /// </summary>
        public DateTime? LastRunStart { get; set; }

        /// <summary>
        /// The datetime when the last run job finished.
        /// </summary>
        public DateTime? LastRunFinish { get; set; }

        /// <summary>
        /// A brief text summary of the output of the last job. This
        /// can be the number of records updated or something similar.
        /// This can also include an error message.
        /// </summary>
        [MaxLength(512)]
        public string LastRunSummary { get; set; }

        /// <summary>
        /// Whether the job is active or not meaning if this job can be run.
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Cron expression
        /// https://cronexpressiontogo.com/
        /// </summary>
        [Required]
        [MaxLength(20)]
        public string ScheduleCron { get; set; }

        /// <summary>
        /// TimeZone Id https://learn.microsoft.com/en-us/previous-versions/windows/embedded/ms912391(v=winembedded.11)
        /// </summary>        
        [MaxLength(20)]
        public string TimeZone { get; set; }

        /// <summary>
        /// Row version column used to avoid concurrency issues at database level
        /// (avoid the job to be picked up by more than one server).
        /// </summary>
        [Timestamp]
        public byte[] Timestamp { get; set; }
    }
}
