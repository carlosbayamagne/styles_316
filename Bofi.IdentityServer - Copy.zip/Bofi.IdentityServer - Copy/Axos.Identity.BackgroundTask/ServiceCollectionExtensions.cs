﻿using System;

using Axos.Identity.BackgroundTasks.Data;
using Axos.Identity.BackgroundTasks.Data.Repositories;

using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

using Serilog;

namespace Axos.Identity.BackgroundTasks
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddBackgroundServices(this IServiceCollection services,
            System.Collections.Specialized.NameValueCollection settings)
        {

            services.AddOptions<BackgroundConfigOptions>().Configure(opt =>
            {
                opt.DbConnection = settings["DbConnection"];
                opt.Inactive = settings["BackgroundServices_Inactive"]?.Equals("true", StringComparison.InvariantCultureIgnoreCase) ?? false;
                opt.MaxHoursRunning = int.Parse(settings["BackgroundServices_MaxHoursRunning"] ?? "12");
            });

            services.AddDbContext<BackgroundContext>(option => option.UseSqlServer(settings["DbConnection"]));

            services.AddScoped<IBackgroundJobRepository, BackgroundJobRepository>();

            return services;
        }
    }

    public static class ApplicationExtensions
    {
        public static void AddBackgroundApplications(this IApplicationBuilder app)
        {
            try
            {
                using var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope();

                BackgroundContext backgroundContext = serviceScope.ServiceProvider.GetService<BackgroundContext>();
                if (backgroundContext?.Database != null && backgroundContext.Database.IsSqlServer())
                {
                    backgroundContext.Database.MigrateAsync().Wait();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, $"Exception caught during migration processing: {ex.Message}");
                throw;
            }
        }
    }
}