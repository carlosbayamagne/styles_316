﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.BackgroundTasks
{
    public class BackgroundConfigOptions
    {
        public string DbConnection { get; set; }
        public bool Inactive { get; set; }
        public int MaxHoursRunning { get; set; }
    }
}
