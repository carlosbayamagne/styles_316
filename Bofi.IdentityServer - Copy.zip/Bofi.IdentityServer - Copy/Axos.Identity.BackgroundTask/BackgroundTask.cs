﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Axos.Identity.BackgroundTasks.Data.Entities;
using Axos.Identity.BackgroundTasks.Data.Repositories;

using Cronos;
using System.Linq;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Axos.Identity.BackgroundTasks
{
    /// <summary>
    /// Background Service Base
    /// </summary>
    public abstract class BackgroundTask : BackgroundService
    {
        protected readonly ILogger<BackgroundTask> _logger;
        protected readonly IServiceScopeFactory _serviceScopeFactory;
        protected readonly IOptions<BackgroundConfigOptions> _options;

        private CronExpression _expression;
        private TimeZoneInfo _timeZoneInfo;
        private int _millisecondsDelay = 60000; // one minute by default.        

        protected abstract string Name { get; set; }
        protected abstract string Description { get; set; }
        /// <summary>
        ///  https://cronexpressiontogo.com/
        /// </summary>
        protected abstract string ScheduleCron { get; set; }
        protected abstract bool IsActive { get; set; }

        /// <summary>
        /// Method to run.
        /// </summary>
        /// <param name="stoppingToken"></param>
        /// <returns></returns>
        protected abstract Task<string> ScheduleJobAsync(CancellationToken stoppingToken);

        public BackgroundTask(
            IServiceScopeFactory serviceScopeFactory,
            ILogger<BackgroundTask> logger,
            IOptions<BackgroundConfigOptions> options)
        {
            _serviceScopeFactory = serviceScopeFactory;
            _logger = logger;
            _options = options;

            _logger.LogInformation("Job {jobName} was loaded!", Name);
        }

        protected virtual async Task Initialize()
        {
            using var scope = _serviceScopeFactory.CreateAsyncScope();
            var repository = scope.ServiceProvider.GetRequiredService<IBackgroundJobRepository>();
            var backgroundJob = await repository.GetSingleAsync(x => x.Name == Name);

            if (backgroundJob is null)
            {
                var newBackgroundJob = new BackgroundJob
                {
                    Name = Name,
                    Description = Description,
                    ScheduleCron = ScheduleCron,
                    IsRunning = false,
                    IsActive = IsActive
                };

                await repository.AddIfNotExistsAsync(newBackgroundJob);

                backgroundJob = await repository.GetSingleAsync(x => x.Name == Name);
                if (backgroundJob is null)
                {
                    _logger.LogError("Job {jobName} is not created in db", Name);
                    return;
                }
            }

            if (backgroundJob.IsRunning)
            {
                if (backgroundJob.LastRunStart.HasValue)
                {
                    await CheckTimeRunning(backgroundJob);
                }
                else
                {
                    _logger.LogInformation("Job {jobName} is running from another thread");
                }
            }

            CalculateDelay(backgroundJob);
        }

        private async Task CheckTimeRunning(BackgroundJob backgroundJob)
        {
            var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(backgroundJob.TimeZone ?? TimeZoneInfo.Local.Id);
            DateTime currentTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            TimeSpan difference = currentTime - (backgroundJob.LastRunStart ?? currentTime.AddYears(-1));
            _logger.LogInformation("Job {jobName} has been running for {hours} hours, {minutes} minutes", Name, (difference.Days * 24) + difference.Hours, difference.Minutes);

            if (_options.Value.MaxHoursRunning <= (currentTime - backgroundJob.LastRunStart.Value).TotalHours)
            {
                _logger.LogInformation("Job {jobName} was reset the flag IsRunning", Name);
                await SetIsRunning(false);
            }
        }

        private void CalculateDelay(BackgroundJob backgroundJob)
        {
            _expression = CronExpression.Parse(backgroundJob.ScheduleCron);
            _timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(backgroundJob.TimeZone ?? TimeZoneInfo.Local.Id);
            var next = _expression.GetNextOccurrence(DateTimeOffset.Now, _timeZoneInfo);
            if (next.HasValue)
            {
                var delay = next.Value - DateTimeOffset.Now;
                _millisecondsDelay = (int)delay.TotalMilliseconds;
            }
        }

        protected async Task<bool> CanRunJobAsync()
        {
            using var scope = _serviceScopeFactory.CreateAsyncScope();
            var repository = scope.ServiceProvider.GetRequiredService<IBackgroundJobRepository>();
            var backgroundJob = await repository.GetSingleAsync(x => x.Name == Name);

            if (backgroundJob is null)
            {
                _logger.LogError("Job {jobName} is not created", Name);
                return false;
            }
            if (!backgroundJob.IsActive)
            {
                _logger.LogDebug("Job {jobName} is not active", Name);
                return false;
            }
            if (backgroundJob.IsRunning)
            {
                _logger.LogDebug("Job {jobName} is already running", Name);
                await CheckTimeRunning(backgroundJob);
                return false;
            }
            if (_expression != CronExpression.Parse(backgroundJob.ScheduleCron)
                || _timeZoneInfo != TimeZoneInfo.FindSystemTimeZoneById(backgroundJob.TimeZone ?? TimeZoneInfo.Local.Id))
            {
                CalculateDelay(backgroundJob);
            }

            return true;
        }

        protected async override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            if (_expression is null)
            {
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
                await Initialize();
            }

            _logger.LogInformation("Job {jobName} will run in {milliseconds} seconds.", Name, _millisecondsDelay / 1000);

            await InternalRunAsync(stoppingToken);
        }

        private async Task InternalRunAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                byte[] runningTimestamp = null;
                await Task.Delay(_millisecondsDelay, stoppingToken);
                try
                {
                    if (await CanRunJobAsync())
                    {
                        bool success = false;
                        (runningTimestamp, success) = await SetIsRunning(true);
                        if (!success)
                        {
                            throw new ApplicationException("Job could not be initialized");
                        };

                        string result = await ScheduleJobAsync(stoppingToken);
                        await SetIsRunning(false, true, runningTimestamp, result);
                    }
                }
                catch (ApplicationException exc)
                {
                    _logger.LogError(exc, "Job {jobName} threw an exception", Name);
                    var exception = exc.Message;

                    await SetIsRunning(false, true, runningTimestamp, exception[..512]);
                }
                catch (Exception exc)
                {
                    _logger.LogError(exc, "Job {jobName} threw an exception", Name);
                    var exception = exc.Message + Environment.NewLine + exc.StackTrace;

                    await SetIsRunning(false, true, runningTimestamp, exception[..512]);
                }

                _logger.LogInformation("Job {jobName} will be executed again in {milliseconds} seconds.", Name, _millisecondsDelay / 1000);
            }
        }

        private async Task<(byte[], bool)> SetIsRunning(bool isRunning, bool lastRunFinish = false, byte[] runningTimestamp = null, string lastRunSummary = null)
        {
            using var scope = _serviceScopeFactory.CreateAsyncScope();
            var repository = scope.ServiceProvider.GetRequiredService<IBackgroundJobRepository>();
            var backgroundJob = await repository.GetSingleAsync(x => x.Name == Name);

            backgroundJob.IsRunning = isRunning;

            var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(backgroundJob.TimeZone ?? TimeZoneInfo.Local.Id);
            DateTime currentTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            if (isRunning)
            {
                backgroundJob.LastRunStart = currentTime;
                backgroundJob.LastRunFinish = null;
            }
            if (!isRunning && lastRunFinish)
            {
                backgroundJob.LastRunFinish = currentTime;
                backgroundJob.LastRunSummary = lastRunSummary;

                if (runningTimestamp == null || !backgroundJob.Timestamp.SequenceEqual(runningTimestamp))
                {
                    return (null, false);
                }
            }

            var rowAffected = await repository.UpdateAsync(backgroundJob);

            // If start the process, return the timestamp.
            runningTimestamp = null;
            if (rowAffected == 1 && isRunning)
            {
                backgroundJob = await repository.GetSingleAsync(x => x.Name == Name);
                runningTimestamp = backgroundJob.Timestamp;
            }

            return (runningTimestamp, rowAffected == 1);
        }

    }
}
