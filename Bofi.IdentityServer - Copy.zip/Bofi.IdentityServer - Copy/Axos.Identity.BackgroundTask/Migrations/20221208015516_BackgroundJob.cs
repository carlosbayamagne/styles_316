﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Axos.Identity.BackgroundTasks.Migrations
{
    public partial class BackgroundJob : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BackgroundJobs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 64, nullable: false),
                    Description = table.Column<string>(maxLength: 256, nullable: true),
                    IsRunning = table.Column<bool>(nullable: false),
                    LastRunStart = table.Column<DateTime>(nullable: true),
                    LastRunFinish = table.Column<DateTime>(nullable: true),
                    LastRunSummary = table.Column<string>(maxLength: 512, nullable: true),
                    IsActive = table.Column<bool>(nullable: false),
                    ScheduleCron = table.Column<string>(maxLength: 20, nullable: false),
                    TimeZone = table.Column<string>(maxLength: 20, nullable: true),
                    Timestamp = table.Column<byte[]>(rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BackgroundJobs", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BackgroundJobs");
        }
    }
}
