# This PowerShell script is intended to read the .csproj file, and read the Package version from it.
# You must set the Working folder setting on your build step, pointing to the project folder
# in order for this script to work.
# e.g. $(build.sourcesDirectory)\src\{Project}

[xml]$project = Get-Content -Raw -Path '*.csproj' -ErrorAction Ignore
if($project){
	if ([string]::IsNullOrWhitespace($project.Project.PropertyGroup.Version)) {
		$projectVersion = $project.Project.PropertyGroup.VersionPrefix
	}
	else {
		$projectVersion = $project.Project.PropertyGroup.Version
	}
	$projectVersion = ($projectVersion | Out-String) -replace "\s$"
	Write-Host $projectVersion
}
else{
	throw ("There was a problem getting content from the .csproj file.")
}

Write-Host "##vso[build.updatebuildnumber]$projectVersion-b$($env:Build_BuildNumber)"