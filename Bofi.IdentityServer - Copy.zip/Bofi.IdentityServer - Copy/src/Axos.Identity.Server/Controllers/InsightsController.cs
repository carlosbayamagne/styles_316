﻿using System;
using System.Threading.Tasks;

using Axos.Identity.Server.Infra.Exceptions;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for Customer identities
    /// </summary>
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    public class InsightsController : UdbBaseApiController
    {
        private readonly ILogger<InsightsController> _logger;
        private readonly IInsightsService _insightsService;

        public InsightsController(
            ILogger<InsightsController> logger,
            IInsightsService insightsService
             )
        {
            _logger = logger;
            _insightsService = insightsService;
        }

        #region Insights
        /// <summary>
        /// Get if the insights is enabled or not by user id.
        /// </summary>
        /// <param name="userId">User id</param>    
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/insights/insightsEnabled/userId/1
        ///
        /// </remarks>
        /// <returns>Is insights enabled</returns>
        /// <response code="200">Is insights enabled</response>
        /// <response code="400">Invalid userId.</response>              
        /// <response code="500">If an error occurred</response>         
        [HttpGet("insightsEnabled/userId/{userId:int}")]
        public async Task<ActionResult<bool>> InsightsEnabled(int userId)
        {
            try
            {
                if (userId == 0)
                    return BadRequest(userId, $"Invalid userId {User}");

                var response = await _insightsService.InsightsEnabled(userId);

                return Ok(response);
            }
            catch (UserNotFoundException ex)
            {
                _logger.LogDebug("Error in IsInsightsEnabled. User not found. {ex}", ex);
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error in IsInsightsEnabled");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Get if the insights is enabled or not by CIF.
        /// </summary>
        /// <param name="cif">CIF</param>    
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/insights/insightsEnabled/cif/1
        ///
        /// </remarks>
        /// <returns>Is insights enabled</returns>
        /// <response code="200">Is insights enabled</response>
        /// <response code="400">Invalid userId.</response>              
        /// <response code="500">If an error occurred</response>         
        [HttpGet("insightsEnabled/cif/{cif}")]
        public async Task<ActionResult<bool>> InsightsEnabled(string cif)
        {
            try
            {
                if (string.IsNullOrEmpty(cif))
                    return BadRequest(cif, $"Invalid userId {User}");

                var response = await _insightsService.InsightsEnabled(cif);

                return Ok(response);
            }
            catch (UserNotFoundException ex)
            {
                _logger.LogDebug("Error in IsInsightsEnabled. User not found. {ex}", ex);
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error in IsInsightsEnabled");
                return InternalError(ex.Message);
            }
        }
        #endregion
    }
}
