﻿using System;
using System.Net;

using Axos.Identity.Server.Infra.Helpers;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Utils.Exts;
using Axos.Identity.Server.Utils.Helpers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;

using Newtonsoft.Json;

namespace Axos.Identity.Server.Controllers.Base
{
    /// <summary>
    /// Base controller for UDB controllers
    /// </summary>
    [Authorize(Policy = "InternalServiceOnly")]
    public class UdbLoggingController : Controller
    {
        private readonly ILogger<UdbLoggingController> _logger;

        public UdbLoggingController() { }
        public UdbLoggingController(ILogger<UdbLoggingController> logger)
        {
            _logger = logger;
        }

        protected IActionResult JSendReplyOk<T>(T data, string message = "") where T : class
        {
            return Ok(data, message);
        }

        protected IActionResult JSendReplyInternalError(Exception exception, string errorMessage = null, object parameters = null)
        {
            Log(UdbStatusCode.InternalError, errorMessage ?? exception.Message, parameters, exception);
            return InternalError(exception, errorMessage);
        }

        #region Ok method
        /// <summary>
        /// Creates Bofi Response with status code 200 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>        
        protected ObjectResult Ok(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.OK, Status.Success, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 200 and parameters provided in the body
        /// </summary>
        /// <returns>ObjectResult</returns>        
        new protected ObjectResult Ok()
        {
            return Ok(null);
        }

        #endregion

        #region NotFound method
        /// <summary>
        /// Creates Bofi Response with status code 404 and parameters provided in the body
        /// </summary>
        /// <param name="message">Response message</param>
        /// <param name="parameters">The viewmodel / object for serialization during logging</param>
        /// <returns>ObjectResult</returns>         
        protected ObjectResult NotFound(string message = "", object parameters = null)
        {
            Log(UdbStatusCode.NotFound, message, parameters);
            return new ResponseWrapper(UdbStatusCode.NotFound, Status.Fail, message, null).CreateResponse();
        }
        #endregion

        #region BadRequest method
        /// <summary>
        /// Creates Bofi Response with status code 400 and parameters provided in the body
        /// </summary>
        /// <param name="modelState">ModelState Dictionary</param>
        /// <returns>ObjectResult</returns>       
        protected new ObjectResult BadRequest(ModelStateDictionary modelState)
        {
            var message = string.Join(", ", modelState.GetErrorMessages());
            Log(UdbStatusCode.BadRequest, null, modelState.GetErrorMessages());
            return new ResponseWrapper(UdbStatusCode.BadRequest, Status.Fail, message, null).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 400 and parameters provided in the body
        /// </summary>     
        /// <param name="message">Optional message to return</param>
        /// <returns>ObjectResult</returns>       
        protected ObjectResult BadRequest(string message = null)
        {
            Log(UdbStatusCode.BadRequest, message, null);
            return new ResponseWrapper(UdbStatusCode.BadRequest, Status.Fail, message, null).CreateResponse();
        }
        #endregion

        #region BadGateway method
        /// <summary>
        /// Creates Bofi Response with status code 502 and parameters provided in the body
        /// </summary>        
        /// <param name="message">Response message</param>
        /// <param name="parameters">The viewmodel / object for serialization during logging</param>
        /// <param name="exception">The exception to be logged (optional)</param>
        /// <returns>ObjectResult</returns>
        protected ObjectResult BadGateway(Exception exception, string message = "", object parameters = null)
        {
            Log(UdbStatusCode.BadGateway, message, parameters, exception);
            return new ResponseWrapper(UdbStatusCode.BadGateway, Status.Fail, message, null).CreateResponse();
        }
        #endregion

        #region Created method
        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>     
        protected ObjectResult Created(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.Created, Status.Success, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="uri">Location of the resource</param>
        /// <returns>ObjectResult</returns>       
        new protected ObjectResult Created(Uri uri, object value)
        {
            return Created(value, uri.ToString());
        }

        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="uri">Location of the resource</param>
        /// <returns>ObjectResult</returns>       
        new protected ObjectResult Created(string uri, object value)
        {
            return Created(value, uri);
        }
        #endregion


        #region InternalError method
        /// <summary>
        /// Creates Bofi Response with status code 500 and parameters provided in the body
        /// </summary>
        /// <param name="message">Response message</param>
        /// <param name="parameters">The viewmodel / object for serialization during logging</param>
        /// <param name="exception">The exception data to be added to the log</param>
        /// <returns>ObjectResult</returns>      
        protected ObjectResult InternalError(Exception exception, string message = null, object parameters = null)
        {
            Log(UdbStatusCode.InternalError, message ?? exception.Message, parameters, exception);
            return new ResponseWrapper(UdbStatusCode.InternalError, Status.Error, message, null).CreateResponse();
        }
        #endregion

        #region Unauthorized method
        /// <summary>
        /// Creates Bofi Response with status code 401 and parameters provided in the body
        /// </summary>        
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>       
        protected ObjectResult Unauthorized(string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.Unauthorized, Status.Fail, message, null).CreateResponse();
        }
        #endregion

        #region Forbidden method
        /// <summary>
        /// Creates Response with status code 403
        /// </summary>        
        /// <returns>ObjectResult</returns>       
        protected IActionResult Forbidden()
        {
            return StatusCode((int)HttpStatusCode.Forbidden);
        }
        #endregion

        #region Logging
        /// <summary>
        /// Serializes an object removing sensitive information for Logging
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        internal static string SerializeObject(object model)
        {
            if (model == null) return null;

            var serializerSettings = new JsonSerializerSettings
            {
                ContractResolver = new RemovePropertiesContractResolver()
            };

            return JsonConvert.SerializeObject(model, serializerSettings);
        }


        internal LogData GetLogData(UdbStatusCode statusCode, string message, object parameters)
        {
            string serializedParams = SerializeObject(parameters);
            bool hasParameters = !string.IsNullOrEmpty(serializedParams);
            var descriptor = ControllerContext.ActionDescriptor;

            var data = new LogData(statusCode)
            {
                Message = message ?? (descriptor == null ? $"{statusCode}" : $"{statusCode} at {descriptor.ControllerName}.{descriptor.ActionName}")
            };

            if (!hasParameters && string.IsNullOrEmpty(message))
            {
                data.Template = descriptor == null ? $"{statusCode}" : $"{statusCode} at {descriptor.ControllerName}.{descriptor.ActionName}";
            }
            else if (hasParameters)
            {
                data.Template = $"{statusCode} with message: '{message}', and parameters: {parameters}";
                data.Parameters = serializedParams;
            }
            else
            {
                data.Template = $"{statusCode} with message: '{message}'";
            }

            return data;
        }

        private void Log(UdbStatusCode statusCode, string message, object parameters, Exception exception = null)
        {
            if (_logger != null)
            {
                var data = GetLogData(statusCode, message, parameters);

                if (data.StatusCode == UdbStatusCode.InternalError)
                {
                    _logger.LogError(exception, data.Message, data.Parameters);
                }
                else if ((int)data.StatusCode > 500)
                {
                    _logger.LogCritical(exception, data.Message, data.Parameters);
                }
                else
                {
                    _logger.LogInformation(data.Message, data.Parameters);
                }
            }
        }

        #endregion
    }
}