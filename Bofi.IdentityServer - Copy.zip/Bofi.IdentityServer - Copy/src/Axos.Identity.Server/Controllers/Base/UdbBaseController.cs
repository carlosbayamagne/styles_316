﻿using System;
using System.Net;

using Axos.Identity.Server.Utils.Helpers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Axos.Identity.Server.Controllers
{

    /// <summary>
    /// Base controller for UDB controllers
    /// </summary>   
    [Authorize(Policy = "InternalServiceOnly")]
    public class UdbBaseController : Controller
    {
        protected IActionResult JSendReplyOk<T>(T data, string message = "") where T : class
        {
            return Ok(data, message);
        }

        protected IActionResult JSendReplyInternalError(string errorMessage = "")
        {
            return InternalError(errorMessage);
        }

        #region Ok method
        /// <summary>
        /// Creates Bofi Response with status code 200 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>        
        protected ObjectResult Ok(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.OK, Status.Success, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 200 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <returns>ObjectResult</returns>        
        new protected ObjectResult Ok(object value)
        {
            return Ok(value, "");
        }

        /// <summary>
        /// Creates Bofi Response with status code 200 and parameters provided in the body
        /// </summary>
        /// <returns>ObjectResult</returns>        
        new protected ObjectResult Ok()
        {
            return Ok(null, "");
        }

        #endregion

        #region NotFound method
        /// <summary>
        /// Creates Bofi Response with status code 404 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>        
        protected ObjectResult NotFound(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.NotFound, Status.Fail, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 404 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <returns>ObjectResult</returns>        
        new protected ObjectResult NotFound(object value)
        {
            return this.NotFound(value, "");
        }

        /// <summary>
        /// Creates Bofi Response with status code 404 and parameters provided in the body
        /// </summary>
        /// <returns>ObjectResult</returns>        
        new protected ObjectResult NotFound()
        {
            return NotFound(null, "");
        }
        #endregion

        #region BadRequest method
        /// <summary>
        /// Creates Bofi Response with status code 400 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>       
        protected ObjectResult BadRequest(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.BadRequest, Status.Fail, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 400 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <returns>ObjectResult</returns>       
        new protected ObjectResult BadRequest(object value)
        {
            return BadRequest(value, "");
        }

        /// <summary>
        /// Creates Bofi Response with status code 400 and parameters provided in the body
        /// </summary>
        /// <returns>ObjectResult</returns>      
        new protected ObjectResult BadRequest()
        {
            return BadRequest(null, "");
        }
        #endregion

        #region BadGateway method
        /// <summary>
        /// Creates Bofi Response with status code 502 and parameters provided in the body
        /// </summary>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>
        protected ObjectResult BadGateway(string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.BadGateway, Status.Fail, message, null).CreateResponse();
        }
        #endregion

        #region Created method
        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="uri">Location of the resource</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>     
        protected ObjectResult Created(object value, string uri, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.Created, Status.Success, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="uri">Location of the resource</param>
        /// <returns>ObjectResult</returns>       
        new protected ObjectResult Created(Uri uri, object value)
        {
            return Created(value, uri.ToString(), "");
        }

        /// <summary>
        /// Creates Bofi Response with status code 201 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="uri">Location of the resource</param>
        /// <returns>ObjectResult</returns>       
        new protected ObjectResult Created(string uri, object value)
        {
            return Created(value, uri, "");
        }
        #endregion

        #region NotImplemented method
        /// <summary>
        /// Creates Bofi Response with status code 405 and parameters provided in the body
        /// </summary>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>     
        protected ObjectResult NotImplemented(string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.MethodNotAllowed, Status.Error, message, null).CreateResponse();
        }
        #endregion

        #region InternalError method
        /// <summary>
        /// Creates Bofi Response with status code 500 and parameters provided in the body
        /// </summary>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>      
        protected ObjectResult InternalError(string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.InternalError, Status.Error, message, null).CreateResponse();
        }
        #endregion

        #region Forbidden method
        /// <summary>
        /// Creates Response with status code 403
        /// </summary>        
        /// <returns>ObjectResult</returns>       
        protected IActionResult Forbidden()
        {
            return StatusCode((int)HttpStatusCode.Forbidden);
        }
        #endregion

        #region Unauthorized method
        /// <summary>
        /// Creates Bofi Response with status code 401 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <param name="message">Response message</param>
        /// <returns>ObjectResult</returns>       
        protected ObjectResult Unauthorized(object value, string message = "")
        {
            return new ResponseWrapper(UdbStatusCode.Unauthorized, Status.Fail, message, value).CreateResponse();
        }

        /// <summary>
        /// Creates Bofi Response with status code 401 and parameters provided in the body
        /// </summary>
        /// <param name="value">Response data</param>
        /// <returns>ObjectResult</returns>      
        protected new ObjectResult Unauthorized(object value)
        {
            return Unauthorized(value, "");
        }

        /// <summary>
        /// Creates Bofi Response with status code 401 and parameters provided in the body
        /// </summary>
        /// <returns>ObjectResult</returns>

        new protected ObjectResult Unauthorized()
        {
            return Unauthorized(null, "");
        }
        #endregion
    }
}