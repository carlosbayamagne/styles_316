﻿using System;
using System.Linq;
using System.Threading.Tasks;

using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.Server.Utils.Exts;
using Axos.Identity.Server.Utils.Filters;
using Axos.Integration.Common.Models;
using Axos.Integration.FraudLinks.Models;
using Axos.Integration.FraudLinks.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary> 
    /// Controller for Fraud links
    /// </summary>
    [Route("api/Identity")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    [ServiceFilter(typeof(APIExceptionFilter))]
    public class FraudLinksController : UdbBaseController
    {
        private readonly IFraudLinksService _fraudLinksRuleService;
        private readonly ILogger<FraudLinksController> _logger;

        public FraudLinksController(IFraudLinksService fraudLinksRuleService, ILogger<FraudLinksController> logger)
        {
            _fraudLinksRuleService = fraudLinksRuleService;
            _logger = logger;
        }

        /// <summary>
        /// Verify match applicant
        /// </summary>
        /// <param name="request">Applicant data</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /fraudlinks
        ///     {
        ///     	"ssn": "974149493",
        ///     	"cellPhone": null,
        ///     	"homePhone": null,
        ///     	"workPhone": null,
        ///     	"email": null,
        ///     	"ipAddress": null,
        ///     	"firstName": "PETER",
        ///     	"lastName": "MAYER",
        ///     	"city": "",
        ///     	"street": "",
        ///     	"unit": null,
        ///     	"state": "",
        ///     	"zip": "",
        ///     	"mailingStreet": "",
        ///     	"mailingUnit": "",
        ///     	"mailingCity": "",
        ///     	"mailingState": "",
        ///     	"mailingZip": "",
        ///     	"secondaryEmail": ""
        ///     }
        ///     
        /// </remarks>
        /// <returns>A ServiceResult response object</returns>
        /// <response code="200">A ServiceResult response object</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("fraudlinks")]
        [ProducesResponseType(typeof(ServiceResult<OverAllVerificationResultDto>), 200)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> FraudLinks([FromBody] Applicant request)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in Applicant. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }
            try
            {
                var result = await _fraudLinksRuleService.Match(request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest(ex.Message);
            }
        }

    }
}
