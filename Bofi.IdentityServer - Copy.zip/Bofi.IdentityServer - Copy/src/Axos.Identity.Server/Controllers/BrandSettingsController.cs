﻿using System.Threading.Tasks;

using Axos.Identity.Server.Models;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class BrandSettingsController : UdbBaseApiController
    {
        private readonly IBrandSettingService _brandSettingService;


        public BrandSettingsController(IBrandSettingService brandSettingService)
        {
            _brandSettingService = brandSettingService;
        }

        /// <summary>
        /// Get brand setting by Id
        /// </summary>
        /// <param name="settingId">Brand Setting Id</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandsettings/1
        ///    
        /// </remarks>
        /// <returns>A Brands setting response object</returns>
        /// <response code="200">A Brands setting response object</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("{settingId}")]
        public async Task<ActionResult<BrandSettingDto>> Get(int settingId)
        {
            var result = await _brandSettingService.GetBrandSetting(settingId);

            return Ok(result.Value);
        }

        /// <summary>
        /// Create brand settings.
        /// </summary>
        /// <param name="data">Brand Settings</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/brandsettings
        ///     {
        /// 	    "name": "Test",
        /// 	    "displayName": "Test",
        /// 	    "Value": "Value",
        /// 	    "brandId": 1
        ///     }
        ///    
        /// </remarks>
        /// <returns>A brand setting response object</returns>
        /// <response code="200">A brand setting response object</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost]
        public async Task<ActionResult> CreateBrandSetting(BrandSettingDto data)
        {
            var result = await _brandSettingService.CreateBrandSetting(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Update brand settings.
        /// </summary>
        /// <param name="data">Brand Settings</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /api/brandsettings
        ///     {
        ///         "Id": 1,
        /// 	    "name": "Test",
        /// 	    "displayName": "Test",
        /// 	    "Value": "Value",
        /// 	    "brandId": 2
        ///     }
        ///    
        /// </remarks>
        /// <returns>A brand setting response object</returns>
        /// <response code="200">A brand setting response object</response>      
        /// <response code="500">If an error occurred</response>   
        [HttpPut]
        public async Task<ActionResult> UpdateBrandSetting(BrandSettingDto data)
        {
            var result = await _brandSettingService.UpdateBrandSetting(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Delete brand settings.
        /// </summary>
        /// <param name="settingId">Brand Settings Id</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/brandsettings/1
        ///    
        /// </remarks>
        /// <returns>A brand setting response object</returns>
        /// <response code="200">A brand setting response object</response>      
        /// <response code="500">If an error occurred</response>  
        [HttpDelete("{settingId}")]
        public async Task<ActionResult> DeleteBrandSetting(int settingId)
        {
            var result = await _brandSettingService.DeleteBrandSetting(settingId);

            return Ok(result.Value);
        }
    }
}
