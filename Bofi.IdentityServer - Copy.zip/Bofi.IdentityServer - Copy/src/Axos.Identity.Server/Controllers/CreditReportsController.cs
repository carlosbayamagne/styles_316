﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Axos.Identity.Server.Utils.Filters;
using Axos.Integration.Common.Exceptions;
using Axos.Integration.Common.Models;
using Axos.Integration.CreditReport.Models;
using Axos.Integration.CreditReport.Models.Response;
using Axos.Integration.CreditReport.Services.Interfaces;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for Addresses
    /// </summary>
    [Route("api/Identity")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    [ServiceFilter(typeof(APIExceptionFilter))]
    public class CreditReportsController : UdbBaseController
    {
        private readonly ICreditReportService _creditReportService;
        private ITokenService _tokenService;
        private readonly ILogger<CreditReportsController> _logger;

        public CreditReportsController(ICreditReportService creditReportService, ITokenService tokenService, ILogger<CreditReportsController> logger)
        {
            _tokenService = tokenService;
            _creditReportService = creditReportService;
            _logger = logger;
        }

        /// <summary>
        /// Adds a credit report
        /// </summary>
        /// <param name="request">Address data data</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /creditreports
        ///     {
        ///     	"FirstName" : "NANCY",
        ///     	"LastName" : "BIRKHEAD",
        ///     	"MiddleName" : "L",
        ///         "SSN" : "666701451",
        ///         "Line1" : "378 East St",
        ///         "City" : "Bloomsburg",
        ///         "State" : "PA",
        ///         "ZipCode" : "178151847",
        ///         "PhoneNumber" : "5704414264",
        ///         "DateOfBirth" : "1938-10-14"
        ///     }
        ///     
        /// </remarks>
        /// <returns>A rule result object</returns>
        /// <response code="200">A rule result object</response>
        /// <response code="400">If an rules engine error occurred</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("creditreports")]
        [ProducesResponseType(typeof(IEnumerable<ServiceResult<CreditReportResponse>>), 200)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> RequestReport([FromBody] PersonalInformation request)
        {
            try
            {
                var token = await _tokenService.GetToken();

                var result = await _creditReportService.RequestScores(request, token.Value.access_token);
                return Ok(result);
            }
            catch (RulesEngineException rex)
            {
                _logger.LogCritical(rex, "Rules engine error");
                return BadRequest(null, rex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest(null, ex.Message);
            }
        }
    }
}
