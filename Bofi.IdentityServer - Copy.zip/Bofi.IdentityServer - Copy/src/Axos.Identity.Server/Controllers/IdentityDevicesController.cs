﻿namespace Axos.Identity.Server.Controllers
{
    using System;
    using System.Threading.Tasks;

    using Axos.Identity.Server.Models.Biometrics;
    using Axos.Identity.Server.Services;
    using Axos.Identity.Server.Utils.Filters;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Controller for Customer devices
    /// </summary>
    [Route("api/identity/{userId}/devices")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class IdentityDevicesController : UdbBaseApiController
    {
        private readonly IUserDevicesService _userDevicesService;
        private readonly ILogger<IdentityDevicesController> _logger;

        public IdentityDevicesController(IUserDevicesService userDevicesService, ILogger<IdentityDevicesController> logger)
        {
            _userDevicesService = userDevicesService;
            _logger = logger;
        }

        /// <summary>
        /// Add user device and register the user if no devices have been registered
        /// </summary>
        /// <param name="userId">The userId</param>
        /// <param name="model">The user device Object</param>
        /// <returns>201 Created when user device is registered</returns>
        /// <response code="201">Created</response>
        /// <response code="400">Bad request</response>
        /// <response code="404">If user was not found</response>
        /// <response code="500">Internal server error</response>
        [HttpPost, ValidateModelFilter]
        public ActionResult AddUserDevice([FromRoute]int userId, [FromBody]BiometricDeviceDetails model)
        {
            try
            {
                if (_userDevicesService.AddUserDevice(userId, model))
                {
                    return Created($"api/identity/{userId}/devices", model);
                }

                _logger.LogInformation("Device already exists");
                return BadRequest(null, "Device already exists");
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "User not found");

                return NotFound(null, "User not found.");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error occurred when adding user {0}", userId);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Disable a specific device for the user, if the user only has 1 device registered it will internally also disable the user
        /// </summary>
        /// /// <param name="userId">The userId</param>
        /// <param name="model">UserDevice information</param>
        /// <returns>200 OK when succesful</returns>
        /// <response code="204">No content</response>       
        /// <response code="404">If user was not found</response>
        /// <response code="500">Internal server error</response>
        [HttpDelete, ValidateModelFilter]
        public async Task<ActionResult> DeleteDevice([FromRoute]int userId, [FromBody]DeleteBiometricDeviceRequest model)
        {
            try
            {
                if (await _userDevicesService.DeleteDevice(userId, model))
                {
                    return NoContent();
                }

                _logger.LogDebug("Device does not exist");
                return NotFound(null, "Device does not exist");
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Null reference error");

                return NotFound(null, "User not found.");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error occurred when deleting device {0} for user {1}", model.DeviceId, userId);
                return InternalError(ex.Message);
            }
        }


        /// <summary>
        /// Returns a list of registered deviceIds for the user
        /// </summary>
        /// <param name="userId">The userId</param>        
        /// <returns>The list of deviceIds</returns>
        /// <response code="200">The list of deviceIds</response>       
        /// <response code="404">If user was not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet]
        public async Task<ActionResult> GetUserDevices([FromRoute]int userId)
        {
            try
            {
                var results = await _userDevicesService.GetUserDevices(userId);

                return Ok(results);
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(null, "User not found.");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error occurred when requesting devices for user {0}", userId);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// This will delete all the user devices and remove the user from the biometric access
        /// </summary> 
        /// <param name="userId">The user id</param>        
        /// <response code="200">Success</response>       
        /// <response code="404">If user was not found</response>
        /// <response code="500">Internal server error</response>
        [HttpDelete("deleteuser"), ValidateModelFilter]
        public async Task<ActionResult> DeleteUser([FromRoute]int userId)
        {
            try
            {
                await _userDevicesService.DeleteUser(userId);
                return Ok(userId, "User has been deleted and all devices removed");
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Null reference exception");


                return NotFound(null, "User not found.");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Error occurred deleting user {0}", userId);
                return InternalError(ex.Message);
            }
        }

    }
}
