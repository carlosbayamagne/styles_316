﻿using System.Threading.Tasks;

using Axos.Identity.Server.Models;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class BrandingSettingsController : UdbBaseApiController
    {
        private readonly IBrandingSettingService _brandingSettingService;


        public BrandingSettingsController(IBrandingSettingService brandingSettingService)
        {
            _brandingSettingService = brandingSettingService;
        }

        /// <summary>
        /// Get branding setting by Id
        /// </summary>
        /// <param name="settingId">Branding setting Id</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandingsettings/1
        ///    
        /// </remarks>
        /// <returns>A Brandings setting response object</returns>
        /// <response code="200">A Brandings setting response object</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("{settingId}")]
        public async Task<ActionResult<BrandingSettingDto>> Get(int settingId)
        {
            var result = await _brandingSettingService.GetBrandingSetting(settingId);

            return Ok(result.Value);
        }

        /// <summary>
        /// Create branding settings.
        /// </summary>
        /// <param name="data">Branding Settings</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/brandingsettings
        ///     {
        /// 	    "name": "Test",
        /// 	    "displayName": "Test",
        /// 	    "Value": "Value",
        /// 	    "brandingId": 1
        ///     }
        ///    
        /// </remarks>
        /// <returns>A branding setting response object</returns>
        /// <response code="200">A branding setting response object</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost]
        public async Task<ActionResult> CreateBrandingSetting(BrandingSettingDto data)
        {
            var result = await _brandingSettingService.CreateBrandingSetting(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Update branding settings.
        /// </summary>
        /// <param name="data">Branding Settings</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /api/brandingsettings
        ///     {
        ///         "Id": 1,
        /// 	    "name": "Test",
        /// 	    "displayName": "Test",
        /// 	    "Value": "Value",
        /// 	    "brandingId": 2
        ///     }
        ///    
        /// </remarks>
        /// <returns>A branding setting response object</returns>
        /// <response code="200">A branding setting response object</response>      
        /// <response code="500">If an error occurred</response>   
        [HttpPut]
        public async Task<ActionResult> UpdateBrandingSetting(BrandingSettingDto data)
        {
            var result = await _brandingSettingService.UpdateBrandingSetting(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Delete branding settings.
        /// </summary>
        /// <param name="settingId">Branding Settings Id</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/brandingsettings/1
        ///    
        /// </remarks>
        /// <returns>A branding setting response object</returns>
        /// <response code="200">A branding setting response object</response>      
        /// <response code="500">If an error occurred</response>  
        [HttpDelete("{settingId}")]
        public async Task<ActionResult> DeleteBrandingSetting(int settingId)
        {
            var result = await _brandingSettingService.DeleteBrandingSetting(settingId);

            return Ok(result.Value);
        }
    }
}
