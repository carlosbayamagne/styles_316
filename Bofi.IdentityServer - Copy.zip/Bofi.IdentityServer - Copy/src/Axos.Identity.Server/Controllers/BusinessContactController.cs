﻿namespace Axos.Identity.Server.Controllers
{
    using System.Linq;
    using System.Threading.Tasks;

    using Axos.Identity.Server.Controllers.Base;
    using Axos.Identity.Server.Models;
    using Axos.Identity.Server.Services;
    using Axos.Identity.Server.Utils.Exts;
    using Axos.Identity.Server.Utils.Filters;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Controller for Business Contact
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json"), ServiceFilter(typeof(APIExceptionFilter))]
    public class BusinessContactController : UdbLoggingController
    {
        private readonly ILogger<BusinessContactController> _logger;
        private readonly IUserBusinessContactService _userBusinessContactService;

        public BusinessContactController(IUserBusinessContactService userBusinessContactService,
            ILogger<BusinessContactController> logger)
        {
            _logger = logger;
            _userBusinessContactService = userBusinessContactService;
        }

        /// <summary>
        /// Adds a business contact to an user
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="request">User Business Contacts Request</param>        
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /businesscontact/12345
        ///     {
		///         "organizationId": 173040,
		///         "phone": "2222222222",
		///         "cellPhone": "9999999999",
		///         "email": "test@gmail.com",
		///         "street1": "P.O. Box 1234",
		///         "street2": "",
		///         "city": "Schenectady",
		///         "state": "New York (NY)",
		///         "postalCode": "12345",
		///         "extension": "6666"
        ///     }
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the given Business Contacts were added</returns>
        /// <response code="200">Boolean that indicates if the given Business Contacts were added</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">The request is not valid</response>           
        [HttpPost("{userId}"), ValidateModelFilter]
        public async Task<ActionResult> AddBusinessContact(int userId, UserBusinessContactsDto request)
        {

            var result = await _userBusinessContactService.AddBusinessContact(userId, request);
            if (result.IsFailed)
            {
                if (result.IsNotFoundError())
                {
                    return NotFound($"Business Contact error: {result.Errors.FirstOrDefault().Message}", new { userId });
                }
                _logger.LogError("Business Contact error", result.Errors);
                return BadRequest($"Business Contact error: {result.Errors.FirstOrDefault().Message}");
            }
            return Ok(result.Value);
        }

        /// <summary>
        /// Deletes a business contact 
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="organizationId">Organization Id</param>        
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     DELETE /businesscontact/12345/1
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the business contact was deleted.</returns>
        /// <response code="200">Boolean that indicates if the business contact was deleted.</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>                 
        [HttpDelete("{userId}/{organizationId}"), ValidateModelFilter]
        public async Task<ActionResult> DeleteBusinessContact(int userId, int organizationId)
        {
            var result = await _userBusinessContactService.DeleteBusinessContact(userId, organizationId);
            if (result.IsFailed)
            {
                if (result.IsNotFoundError())
                {
                    return NotFound($"Business Contact error: {result.Errors.FirstOrDefault().Message}", new { userId });
                }
            }
            return Ok(result.Value);
        }

        /// <summary>
        /// Updates the business contact of an user
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="request">User Business Contacts Request</param>        
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /businesscontact/12345
        ///     {
        ///         "id":"2873",
		///         "organizationId": 173040,
		///         "phone": "2222222222",
		///         "cellPhone": "9999999999",
		///         "email": "test@gmail.com",
		///         "street1": "P.O. Box 1234",
		///         "street2": "",
		///         "city": "Schenectady",
		///         "state": "New York (NY)",
		///         "postalCode": "12345",
		///         "extension": "6666"
        ///     }
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the given Business Contacts were updated</returns>
        /// <response code="200">Boolean that indicates if the given Business Contacts were updated</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">The request is not valid</response>           
        [HttpPut("{userId}"), ValidateModelFilter]
        public async Task<ActionResult> UpdateBusinessContact(int userId, UserBusinessContactsDto request)
        {
            var result = await _userBusinessContactService.UpdateBusinessContact(userId, request);
            if (result.IsFailed)
            {
                if (result.IsNotFoundError())
                {
                    return NotFound($"Business Contact error: {result.Errors.FirstOrDefault().Message}", new { userId });
                }
                _logger.LogError("Business Contact error", result.Errors);
                return BadRequest($"Business Contact error: {result.Errors.FirstOrDefault().Message}");
            }
            return Ok(result.Value);
        }

        /// <summary>
        /// Gets a Bussiness Contacts list by user id
        /// </summary>
        /// <param name="userId">User Id</param>        
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /businesscontact/12345
        ///
        /// </remarks>
        /// <returns>Business contacts list of the given user.</returns>
        /// <response code="200">Business contacts list of the given user.</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>                        
        [HttpGet("{userId}")]
        public async Task<ActionResult> GetBusinessContacts(int userId)
        {
            var result = await _userBusinessContactService.GetBusinessContacts(userId);
            if (result.IsFailed)
            {
                if(result.IsNotFoundError())
                {
                    return NotFound($"Business Contact error: {result.Errors.FirstOrDefault().Message}", new { userId });
                }
                _logger.LogError("Business Contact error", result.Errors);
                return BadRequest($"Business Contact error: {result.Errors.FirstOrDefault().Message}");
            }
            return Ok(result.Value);         
        }

        /// <summary>
        /// Gets an user business contact 
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="businessContactId">Organization Id</param>        
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /businesscontact/12345/1
        ///
        /// </remarks>
        /// <returns>Business contacts of the given user.</returns>
        /// <response code="200">Business contacts of the given user.</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>                 
        [HttpGet("{userId}/{businessContactId}")]
        public async Task<ActionResult> GetBusinessContact(int userId, int businessContactId)
        {
            var result = await _userBusinessContactService.GetBusinessContact(userId, businessContactId);
            if (result.IsFailed)
            {
                if (result.IsNotFoundError())
                {
                    return NotFound($"Business Contact error: {result.Errors.FirstOrDefault().Message}", new { userId });
                }
            }
            return Ok(result.Value);
        }

    }
}
