﻿namespace Axos.Identity.Server.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using IdentityServer4.EntityFramework.DbContexts;
    using IdentityServer4.EntityFramework.Entities;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Controller for Customer devices
    /// </summary>
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    public class IdentityConfigurationController : UdbBaseApiController
    {
        private readonly ConfigurationDbContext _configurationDbContext;        

        public IdentityConfigurationController(
            ConfigurationDbContext configurationDbContext
            )
        {
            _configurationDbContext = configurationDbContext;            
        }

        /// <summary>
        /// Gets clients list.
        /// </summary>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identityConfiguration/clients
        ///
        /// </remarks>
        /// <returns>List of Clients</returns>
        /// <response code="200">list of clients</response>
        /// <response code="500">If an error occurred</response>   
        [HttpGet("Clients")]
        public async Task<ActionResult<List<Client>>> GetClients()
        {
            var results = await _configurationDbContext.Clients
                .Include(_ => _.Claims)
                .Include(_ => _.IdentityProviderRestrictions)
                .Include(_ => _.AllowedCorsOrigins)
                .Include(_ => _.Properties)
                .Include(_ => _.AllowedScopes)
                .Include(_ => _.ClientSecrets)
                .Include(_ => _.AllowedGrantTypes)
                .Include(_ => _.RedirectUris)
                .Include(_ => _.PostLogoutRedirectUris)
                .ToListAsync();
            return Ok(results);
        }

        /// <summary>
        /// Gets ApiScope list.
        /// </summary>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identityConfiguration/apiscopes
        ///
        /// </remarks>
        /// <returns>List of ApiScope</returns>
        /// <response code="200">list of ApiScope</response>
        /// <response code="500">If an error occurred</response>   
        [HttpGet("ApiScopes")]
        public async Task<ActionResult<List<ApiScope>>> GetApiScopes()
        {
            var results = await _configurationDbContext.ApiScopes
                .Include(_ => _.UserClaims)
                .Include(_ => _.Properties)
                .ToListAsync();
            return Ok(results);
        }

        /// <summary>
        /// Gets ApiResource list.
        /// </summary>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identityConfiguration/apiresources
        ///
        /// </remarks>
        /// <returns>List of apiresources</returns>
        /// <response code="200">list of apiresources</response>
        /// <response code="500">If an error occurred</response>   
        [HttpGet("ApiResources")]
        public async Task<ActionResult<List<ApiResource>>> GetApiResources()
        {
            var results = await _configurationDbContext.ApiResources
                .Include(_ => _.Secrets)
                .Include(_ => _.Scopes)
                .Include(_ => _.UserClaims)
                .Include(_ => _.Properties)
                .ToListAsync();
            return Ok(results);
        }
    }
}
