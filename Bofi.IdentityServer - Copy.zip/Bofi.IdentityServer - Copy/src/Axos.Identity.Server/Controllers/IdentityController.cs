﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

using Axos.BankingCore.Client.Exceptions;
using Axos.Identity.Server.Controllers.Base;
using Axos.Identity.Server.Data.Enums;
using Axos.Identity.Server.Infra;
using Axos.Identity.Server.Infra.Exceptions;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Models.Catalog;
using Axos.Identity.Server.Models.Extensions;
using Axos.Identity.Server.Models.Request;
using Axos.Identity.Server.Models.Response;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Exceptions;
using Axos.Identity.Server.Utils.Exts;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for Customer identities
    /// </summary>
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    public class IdentityController : UdbLoggingController
    {
        private readonly IUserService _userService;
        private readonly IEnrollService _enrollService;
        private readonly ISyncManager _syncManager;
        private readonly ILogger<IdentityController> _logger;

        public IdentityController(
            IUserService userService,
            IEnrollService enrollService,
            ILogger<IdentityController> logger,
            ISyncManager syncManager,
            ScopedProperties scopedProperties
        ) : base(logger)
        {
            _userService = userService;
            _enrollService = enrollService;
            _logger = logger;
            _syncManager = syncManager;
            _userService.FacingBrandId = scopedProperties.FacingBrand;
        }

        /// <summary>
        /// Associate users in a parent child relationship
        /// </summary>
        /// <param name="au">Parent and Child id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /api/identity/users/associate
        ///     {
        ///         "parentId": 0,
        ///         "childId": 0
        ///     }
        ///
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("users/associate")]
        public IActionResult AssociateUsers([FromBody] AssociateUserRequest au)
        {
            try
            {
                _userService.AssociateUsers(au.ParentId, au.ChildId);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Internal server error");

                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(new Exception("Internal error"));
            }

            return Ok();
        }

        /// <summary>
        /// Gets the user which has the given child
        /// </summary>
        /// <param name="childId">Child id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/123/parent
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{childId}/parent")]
        public IActionResult FindUserByChildID(int childId)
        {
            UserTree result = null;
            try
            {
                result = _userService.FindUserByChildID(childId);
            }
            catch (Exception ex)
            {
                return InternalError(ex, "Internal server error");
            }
            return Ok(result);
        }

        /// <summary>
        /// Gets the complete tree/subtree for the given node
        /// </summary>
        /// <param name="nodeId">Child id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/123/tree
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{nodeId}/tree")]
        public IActionResult GetUserTree(int nodeId)
        {
            UserTree result = null;
            try
            {
                result = _userService.GetTree(nodeId);
            }
            catch (Exception ex)
            {
                return InternalError(ex, "Internal server error");
            }
            return Ok(result);
        }

        /// <summary>
        /// Gets the complete tree/subtree for the given node
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/123/relationships
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{userId}/relationships")]
        public IActionResult GetRelationshipsTree(int userId)
        {
            UserTree result = null;
            try
            {
                result = _userService.GetTree(userId);
            }
            catch (Exception ex)
            {
                return InternalError(ex, "Internal server error");
            }
            return Ok(result);
        }

        /// <summary>
        /// Gets the set of users which has a given parent
        /// </summary>
        /// <param name="parentId">Parent id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/123/children
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{parentId}/children")]
        public IActionResult FindUsersByParentID(int parentId)
        {
            IEnumerable<UserTree> result = null;
            try
            {
                result = _userService.FindUsersByParentID(parentId);
            }
            catch (Exception ex)
            {
                return InternalError(ex, "Internal server error");
            }
            return Ok(result);
        }

        /// <summary>
        /// Dissociate user in parent child relationship
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /api/identity/dissociate
        ///     {
        ///         "userId":123
        ///     }
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("users/dissociate/")]
        public IActionResult DissociateUser([FromBody] int userId)
        {
            try
            {
                _userService.DissociateUser(userId);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogInformation(ex, "User doesnt have a parent");

                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(new Exception("Internal error"));
            }

            return Ok();
        }

        /// <summary>
        /// Adds username and password to an user that doesn't have them
        /// </summary>
        /// <param name="request">User id, Name and password</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /api/identity/credentials
        ///     {
        ///         "userId": 123,
        ///         "userName": "Test",
        ///         "password": "pass123"
        ///     }
        ///
        /// </remarks>
        /// <returns>List of Users</returns>
        /// <response code="200">List of Users</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPut("credentials")]
        public IActionResult AddUserCredentials([FromBody] AddUserCredentialsRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = _userService.AddUserCredentials(request);
                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Invalid Operation: ");
                return BadRequest(ex.Message);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found");
                return NotFound(ex.Message, new { request.UserId });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal Error: ");
                return InternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// Registers a new user
        /// </summary>
        /// <remarks>
        /// Note that if the request lacks both username and password, it would be an incomplete registration
        /// Sample request:
        ///
        ///     POST /register/generic/true
        ///     {
        ///        "FirstName":"John",
        ///        "LastName":"Doe",
        ///        "Email":"johndoe@mail.com",
        ///        "UserType":1,
        ///        "UserName":"johndoe",
        ///        "Password":"password",
        ///        "SSN":"258120316",
        ///        "BrandId":10
        ///     }
        ///
        /// </remarks>
        /// <param name="user"></param>
        /// <param name="waitForSync">If set to true it waits for the synchronization process to finish</param>
        /// <returns>A newly created user</returns>
        /// <response code="200">Returns the new user's id</response>
        /// <response code="400">If model is invalid</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("register/generic/{waitForSync=true}")]
        [ProducesResponseType(typeof(EnrollmentResult), 200)]
        public async Task<IActionResult> RegisterUser([FromBody] GenericCreateUserRequest user, [FromRoute] bool waitForSync)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (user.RegistrationOrigin == "IdentityServiceAcct")
            {
                user.RegistrationOrigin = null;
            }
            if (string.IsNullOrEmpty(user.RegistrationOrigin))
            {
                if (HttpContext?.User?.Identity != null)
                {
                    string origin = null;
                    origin = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                    if (origin != "IdentityServiceAcct")
                    {
                        user.RegistrationOrigin = origin;
                    }
                }
            }

            if (!user.Email.IsValidEmailAddress(false))
            {
                return BadRequest("Invalid Email Address");
            }
            try
            {
                user.Email = user.Email?.ToLower();
                var result = await _userService.CreateUser(user, waitForSync);
                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Invalid operation");
                return BadRequest(ex.Message);
            }
            catch (BadRequestException ex)
            {
                _logger.LogError(ex, "Bad request");
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal Error");
                return InternalError(ex, parameters: user);
            }
        }

        /// <summary>
        /// Completes a user regisration with a username and a password
        /// </summary>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /register/complete
        ///     {
        ///        "id":123,
        ///        "UserName":"johndoe",
        ///        "Password":"password"
        ///     }
        ///
        /// </remarks>
        /// <param name="user"></param>
        /// <returns>The result preload status of the user</returns>
        /// <response code="200">Returns the user's preload status</response>
        /// <response code="500">If an error ocurred</response>
        [HttpPost("register/complete")]
        [ProducesResponseType(typeof(PreloadUserStatus), 200)]
        [ProducesResponseType(typeof(PreloadUserStatus), 500)]
        public IActionResult CompleteRegistration([FromBody] CompleteRegistrationRequest user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = _userService.CompleteRegistration(user);
                return Ok(result);
            }
            catch (ObjectDisposedException ode)
            {
                _logger.LogError(ode, "Object disposed exception");
                return BadGateway(ode, $"{ode.Message} Status : {PreloadUserStatus.AddInCAFailed}", user);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex, $"{ex.Message} Status : {PreloadUserStatus.AddInCAFailed}", user);
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpDelete("hardDeleteUser/{id}")]
        public IActionResult HardDeleteUser(int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                string deletedBy = null;
                if (HttpContext?.User?.Identity != null)
                {
                    deletedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                }

                if (_userService.DeleteUser(id, deletedBy))
                {
                    return Ok("");
                }
                else
                {
                    return NotFound();
                }
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Invalid operation");
                return BadRequest(ex.Message);
            }
            catch (BadRequestException ex)
            {
                _logger.LogError(ex, "Bad request");
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal Error");
                return InternalError(ex, parameters: id);
            }
        }

        /// <summary>
        /// Test the connection
        /// </summary>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /register/test
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="500">If an error ocurred</response>
        [AllowAnonymous]
        [HttpGet("test")]
        public IActionResult Test()
        {
            try
            {
                return Ok("Success");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Gets a specified user
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/2
        ///
        /// </remarks>
        /// <param name="id">The user id</param>
        /// <param name="includeStatus">If true it includes its CA status</param>
        /// <returns>A user</returns>
        /// <response code="200">Returns the user with the specified id</response>
        /// <response code="404">If the user was not found</response>
        [HttpGet("users/{id}")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetUser(int id, [FromQuery] bool includeStatus = false)
        {
            try
            {
                var user = _userService.GetUser(id, includeStatus);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found");
                return NotFound(ex.Message, new { id });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Gets a user by SSN
        /// </summary>
        /// <param name="includeStatus">If true it includes its CA status</param>
        /// <param name="ssn">The user's SSN</param>
        /// <param name="shouldSendException">If true it returns 404 if no user was found</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/ssn/223154
        ///
        /// </remarks>
        /// <returns>A user</returns>
        /// <response code="200">Returns the user with the specified SSN</response>
        /// <response code="404">If the user was not found</response>
        [HttpGet("users/ssn/{ssn}")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetUserbySsn(string ssn, [FromQuery] bool includeStatus = false,
            [FromQuery] bool shouldSendException = true)
        {
            try
            {
                var user = _userService.GetUserBySsn(ssn, includeStatus, shouldSendException);

                if (user == null)
                {
                    // Security: See https://bofaz.visualstudio.com/Axos%20Core%20Services/_workitems/edit/511499 for why we wait 10 seconds here.
                    System.Threading.Thread.Sleep(10000);
                }

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                // Security: See https://bofaz.visualstudio.com/Axos%20Core%20Services/_workitems/edit/511499 for why we wait 10 seconds here.
                System.Threading.Thread.Sleep(10000);

                _logger.LogDebug(ex, "Not found");
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Gets a user by CIF
        /// </summary>
        /// <param name="cif">The user's CIF</param>
        /// <param name="includeStatus">If true it includes its CA status</param>
        /// <param name="shouldSendException">If true it returns 404 if no user was found</param>
        ///  <remarks>
        /// Sample request:
        ///
        ///     GET /users/cif/FAA2073
        ///
        /// </remarks>
        /// <returns>Returns the user with the specified CIF</returns>
        /// <response code="200">Returns the user with the specified CIF</response>
        /// <response code="404">If the user was not found</response>
        [HttpGet("users/cif/{cif}")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetUserbyCif(string cif, [FromQuery] bool includeStatus = false,
            [FromQuery] bool shouldSendException = true)
        {
            try
            {
                var user = _userService.GetUserByCif(cif, includeStatus, shouldSendException);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");
                return NotFound(ex.Message, new { cif });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Gets users by phone number
        /// </summary>
        /// <param name="includeStatus">If true it includes its CA status</param>
        /// <param name="shouldSendException">If true it returns 500 if no user was found</param>
        /// <param name="phoneNumber">The phone number</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/phoneNumber/0000000000
        ///
        /// </remarks>
        /// <returns>Returns a list of users</returns>
        /// <response code="200">Returns a list of users with the specified phone number</response>
        /// <response code="500">If an error ocurred</response>
        [HttpGet("users/phoneNumber/{phoneNumber}")]
        [ProducesResponseType(typeof(IEnumerable<User>), 200)]
        [ProducesResponseType(500)]
        public IActionResult GetUserbyPhoneNumber(string phoneNumber, [FromQuery] bool includeStatus = false, [FromQuery] bool shouldSendException = true)
        {
            try
            {
                var user = _userService.GetUsersByPhoneNumber(phoneNumber, includeStatus, shouldSendException);

                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Gets user detail
        /// </summary>
        /// <param name="id">User id</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/1/detail
        ///
        /// </remarks>
        /// <returns>Returns a user detail</returns>
        /// <response code="200">Returns user details</response>
        /// <response code="404">If user was not found</response>
        /// <response code="502">If an error with JHA ocurred</response>
        [HttpGet("users/{id}/detail")]
        [ProducesResponseType(typeof(UserDetail), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(502)]
        public IActionResult GetUserDetail(int id)
        {
            try
            {
                var user = _userService.GetUserDetail(id);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found error");
                return NotFound(ex.Message, new { id });
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { id });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Gets user by username
        /// </summary>
        /// <param name="userName">Username</param>
        /// <param name="includeStatus">If true it includes its CA status</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/username/johndoe/
        ///
        /// </remarks>
        /// <returns>Returns a user</returns>
        /// <response code="200">Returns a user with the specified username</response>
        /// <response code="404">If user was not found</response>
        [HttpGet("users/userName/{userName}/")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetUser(string userName, [FromQuery] bool includeStatus = false)
        {
            try
            {
                var user = _userService.GetUser(userName, includeStatus);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found");

                return NotFound($"Username {userName} not found", null);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        /// <summary>
        ///  Gets user with CA details
        /// </summary>
        /// <param name="userName">Username</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /users/userName/johndoe/cadetails
        ///
        /// </remarks>
        /// <returns>Returns a user with CA details</returns>
        /// <response code="200">Returns a user with CA details</response>
        /// <response code="404">If user was not found</response>
        [HttpGet("users/userName/{userName}/cadetails")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetUserwithCADetails(string userName)
        {
            try
            {
                var user = _userService.GetUser(userName, false);
                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, new { userName });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        [HttpGet("users")]
        [Obsolete("This API is obsolete.  Use Search")]
        public IActionResult GetUsers(int pageNum, int pageSize, string cif, int[] ids, string[] userNames,
            bool enrollmentCompleted, UsersTypeFilter usersFilter, bool includeCredentialsInfo = true, bool includeSSN = true)
        {
            bool getAllUsers = true;
            bool getFilteredUsers = false;
            const int maxPageSizeForCA = 500;
            int maxPageSize = includeCredentialsInfo ? maxPageSizeForCA : 5000;

            if (pageNum < 0 || pageSize > maxPageSize)
            {
                return BadRequest($"Pagination data is invalid (Max page size is {maxPageSize})");
            }

            var userSearchRequest = new UserSearchRequest
            {
                EnrollmentCompleted = enrollmentCompleted,
                IncludeCredentialsInfo = includeCredentialsInfo,
                IncludeSSN = includeSSN
            };

            try
            {
                if (!string.IsNullOrEmpty(cif))
                {
                    userSearchRequest.CIF = cif;
                }
                else if (ids.Length > 0)
                {
                    userSearchRequest.UserIds = ids;
                }
                else if (userNames.Length > 0 && !(userNames.Length == 1 && userNames[0] == null))
                {
                    userSearchRequest.UserNames = userNames;
                }
                else
                {
                    userSearchRequest.GetAll = getAllUsers;
                }

                if (usersFilter == UsersTypeFilter.OnlyCifUsers)
                {
                    userSearchRequest.UserType = UserType.Consumer;
                    userSearchRequest.UserState = UserState.Customer;
                    userSearchRequest.GetAll = getFilteredUsers;
                }
                else if (usersFilter == UsersTypeFilter.OnlyNonCifUsers)
                {
                    userSearchRequest.UserType = UserType.Advisor;
                    userSearchRequest.UserSubType = UserSubType.RealEstate;
                    userSearchRequest.GetAll = getFilteredUsers;
                }

                var users = SearchUsersService(userSearchRequest, pageSize, pageNum);

                return Ok(users);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Internal server error");

                return BadRequest(ex.Message);
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Null reference error");

                return NotFound(ex.Message, new { pageSize, pageNum });
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, new { cif });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        /// <summary>
        /// Update a user profile
        /// </summary>
        /// <param name="user">User profile</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     PUT /users/profile
        ///     {
        ///       "maskedCellPhone": null,
        ///       "maskedEmail": null,
        ///       "addressAssociations": null,
        ///       "groupPrimaryAddress": null,
        ///       "primaryAddress": null,
        ///       "mailingAddress": null,
        ///       "primaryEmail": "user@mail.com",
        ///       "homePhone": null,
        ///       "cellPhone1": null,
        ///       "cellPhone2": null,
        ///       "workPhone": null,
        ///       "primaryPhone": null,
        ///       "userId": 117237,
        ///       "userName": "johndoe",
        ///       "firstName": "John",
        ///       "lastName": "Doe",
        ///       "status": null,
        ///       "cif": null,
        ///       "email": "user@mail.com",
        ///       "phoneNumber": null,
        ///       "ssn": "258120316",
        ///       "address": null,
        ///       "birthdate": "0001-01-01T00:00:00",
        ///       "brandId": 1,
        ///       "registrationDate": "2019-10-02T15:45:35.7604087",
        ///       "registries": [],
        ///       "lastContactDate": null,
        ///       "enrollmentCompleted": false,
        ///       "preloadedUser": 0,
        ///       "caCreationDate": null,
        ///       "insightsEnabled": false,
        ///       "userType": 1,
        ///       "userState": 1,
        ///       "userSubType": null,
        ///       "hasSecurityQuestions": false,
        ///       "secretWord": null,
        ///       "secretWordHint": null,
        ///       "segmentCode": null,
        ///       "occupation": null,
        ///       "employer": null,
        ///       "gender": null,
        ///       "maritalStatus": null,
        ///       "alternateEmail": null,
        ///       "smsOptIn": false,
        ///       "phones": [],
        ///       "addresses": [],
        ///       "sourceTypeCode": null
        ///     }
        ///
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="404">If user was not found</response>
        /// <response code="502">If a JHA error ocurred</response>
        [HttpPut("users/profile")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(502)]
        public IActionResult UpdateUserProfile([FromBody] UserProfileInfo user)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in UpdateUserProfile. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }

            try
            {
                string UpdatedBy = "";
                if (HttpContext?.User?.Identity != null)
                {
                    UpdatedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                }

                if (!user.Email.IsValidEmailAddress(false))
                {
                    return BadRequest("Invalid Email Address");
                }
                user.Email = user.Email?.ToLower();
                _userService.UpdateUserProfile(user, UpdatedBy);
                return Ok();
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { user.UserId });
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, $"Not found error: User {user.UserId}");
                return NotFound(ex.Message, new { user.UserId });
            }
            catch (BadRequestException ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
            catch (BankingCoreException ex)
            {
                _logger.LogError(ex, "BankingCore error");

                return BadGateway(ex, $"BankingCore error: {ex.Message}", new { user.UserId });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, ex.Message);

                string message = string.Empty;
                if (ex.InnerException?.Message?.Contains("IX_UdbUsers_CIF") ?? false)
                {
                    message = $"The CIF {user.CIF} is already registered.";
                }

                return InternalError(ex, message: message, parameters: user.UserId);
            }
        }

        /// <summary>
        /// Test interface that allows a CIF to be reset in an Identity -- not for use by services external to Identity tests
        /// </summary>
        /// <param name="UserId">id of user to clear</param>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpPost("clearcif/{UserId}")]
        public IActionResult ClearCif(int UserId)
        {
            _userService.ClearCif(UserId);
            return Ok();
        }

        /// <summary>
        /// Update CA status of multiple users
        /// </summary>
        /// <param name="request"></param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /users/statuses
        ///     {
        ///        "Status": 1,
        ///        "UserIds":[1,2,3]
        ///     }
        ///
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="404">If user was not found</response>
        [HttpPut("users/statuses")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        public IActionResult UpdateUserStatuses([FromBody] UpdateUserStatusRequest request)
        {
            if (request == null || request.UserIds.Length == 0)
            {
                return BadRequest("At least one userId is required");
            }

            try
            {
                _userService.UpdateUserStatuses(request);

                return Ok();
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Null reference error");

                return NotFound(ex.Message, new { request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Check if CIF was recently created
        /// </summary>
        /// <param name="cif">User CIF</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /user/cifdate/FAA2073
        ///
        /// </remarks>
        /// <returns>Boolean indicating whether or not the CIF was recently created</returns>
        /// <response code="200">Boolean indicating whether or not the CIF was recently created</response>
        /// <response code="500">If an error ocurred</response>
        [HttpGet("user/cifdate/{cif}")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(500)]
        public IActionResult CheckCifDate(string cif)
        {
            try
            {
                var isCifRecentlyCreated = int.TryParse(cif, out int userId)
                    ? _userService.IsCifRecentlyCreated(userId)
                    : _userService.IsCifRecentlyCreated(cif);

                return Ok(!isCifRecentlyCreated);
            }
            catch (BadRequestException ex)
            {
                _logger.LogError(ex, "Bad request exception");

                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Check if a username is available
        /// </summary>
        /// <param name="username">Username</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /user/johndoe/available
        ///
        /// </remarks>
        /// <returns>Boolean indicating whether or not the username is available</returns>
        /// <response code="200">Boolean indicating whether or not the username is available</response>
        /// <response code="500">If an error ocurred</response>
        [HttpGet("user/{username}/available")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(500)]
        public IActionResult IsUsernameAvailable(string username)
        {
            try
            {
                var isUsernameAvailable = _userService.IsUsernameAvailable(username);

                return Ok(isUsernameAvailable);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: username);
            }
        }

        /// <summary>
        /// Authenticate an internal service account
        /// </summary>
        /// <param name="request">Authentication request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /authenticate/serviceaccount
        ///     {
        ///         "Username": "InternalServiceAcct",
        ///         "Password": "InternalServicePassword"
        ///     }
        ///
        /// </remarks>
        /// <returns>Authentication response</returns>
        /// <response code="200">An authentication response</response>
        /// <response code="403">If credentials are invalid</response>
        [AllowAnonymous]
        [HttpPost("authenticate/serviceaccount")]
        [ProducesResponseType(typeof(AccessTokenResponse), 200)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> AuthenticateServiceAccountAsync([FromBody] InternalServiceAuthenticationRequest request)
        {
            try
            {
                var (authresponse, errorMessage) = await _userService.AuthenticateInternalServiceAccount(request);
                if (authresponse.Status != AuthenticationStatus.Allow)
                {
                    _logger.LogWarning("Login Error: {@info} ", new
                    {
                        Request = request,
                        Response = authresponse,
                        ErrorMessage = errorMessage
                    });
                    return Forbidden();
                }

                AccessTokenResponse response = _userService.GetToken(request.Username, null, null, null);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return JSendReplyInternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// Get token for a user
        /// </summary>
        /// <param name="atr">Access token request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /token/mint
        ///     {
        ///         "Username": "johndoe"
        ///     }
        ///
        /// </remarks>
        /// <returns>A token response</returns>
        /// <response code="200">An authentication response</response>
        /// <response code="403">If an error occurred</response>
        [HttpPost("token/mint")]
        [ProducesResponseType(typeof(AccessTokenResponse), 200)]
        [ProducesResponseType(403)]
        public IActionResult MintToken([FromBody] AccessTokenRequest atr)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Modelstate is invalid in MintToken. {atr}", atr);
                return BadRequest(ModelState.GetErrorMessages());
            }

            try
            {
                var response = _userService.GetToken(atr.Username, atr.Client, atr.Secret, atr.Scopes, atr.AccessTokenLifetime);
                return Ok(response);
            }
            catch (Exception)
            {
                // any error is Forbidden
                return Forbidden();
            }
        }

        /// <summary>
        /// Refresh user token
        /// </summary>
        /// <param name="atr"></param>
        /// <returns></returns>
        [HttpPost("token/refresh")]
        public IActionResult RefreshToken([FromBody] AccessTokenRequest atr)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Modelstate is invalid in RefreshToken. {atr}", atr);
                return BadRequest(ModelState.GetErrorMessages());
            }

            try
            {
                var response = _userService.RefreshToken(atr.Token, atr.Client, atr.Secret, atr.Scopes, atr.AccessTokenLifetime);

                // no response -- invalid, expired, or bad claims
                if (response == null) return Forbidden();

                // it's good...
                return Ok(response);
            }
            catch (Exception)
            {
                // any error is Forbidden
                return Forbidden();
            }
        }

        /// <summary>
        /// Authenticate a user
        /// </summary>
        /// <param name="request">Authentication request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /token/mint
        ///     {
        ///         "Username": "johndoe",
        ///         "Password": "password",
        ///         "BrandId" : 0,
        ///         "Device": { }
        ///     }
        ///
        /// </remarks>
        /// <returns>An authentication response</returns>
        /// <response code="200">An authentication response</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("authenticate/v2")]
        [ProducesResponseType(typeof(AuthenticateResponse), 200)]
        [ProducesResponseType(500)]
        public IActionResult Authenticate([FromBody] AuthenticateRequest request)
        {
            if (request.LoginOrigin == "IdentityServiceAcct")
            {
                request.LoginOrigin = null;
            }
            if (string.IsNullOrEmpty(request.LoginOrigin))
            {
                if (HttpContext?.User?.Identity != null)
                {
                    string origin = null;
                    origin = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                    if (origin != "IdentityServiceAcct")
                    {
                        request.LoginOrigin = origin;
                    }
                }
            }
            try
            {
                var response = _userService.Authenticate(request);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// Authenticate a user
        /// </summary>
        /// <param name="request">Authentication request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /token/mint
        ///     {
        ///         "Username": "johndoe",
        ///         "Password": "password",
        ///         "BrandId" : 0,
        ///         "Device": { }
        ///     }
        ///
        /// </remarks>
        /// <returns>An authentication response</returns>
        /// <response code="200">An authentication response</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("authenticate/aggregators")]
        [ProducesResponseType(typeof(AuthenticateResponse), 200)]
        [ProducesResponseType(500)]
        public IActionResult AuthenticateAggregators([FromBody] AuthenticateRequest request)
        {
            if (request.LoginOrigin == "IdentityServiceAcct")
            {
                request.LoginOrigin = null;
            }
            if (string.IsNullOrEmpty(request.LoginOrigin))
            {
                if (HttpContext?.User?.Identity != null)
                {
                    string origin = null;
                    origin = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                    if (origin != "IdentityServiceAcct")
                    {
                        request.LoginOrigin = origin;
                    }
                }
            }
            try
            {
                var response = _userService.Authenticate(request, true);

                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// User Logout
        /// </summary>
        [HttpPost("logout")]
        public IActionResult LogOut([FromBody] LogOutRequest request)
        {
            return Ok();
        }

        /// <summary>
        /// Gets the brand of the customer, and updates the User entity.
        /// </summary>
        /// <param name="userName">User Name</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/username/testing/brand
        ///
        /// </remarks>
        /// <returns>Brand</returns>
        /// <response code="200">Brand</response>
        /// <response code="404">Customer not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/userName/{userName}/brand")]
        public IActionResult GetCustomerBrand(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                return BadRequest(nameof(userName));
            }

            try
            {
                var response = _userService.GetCustomerBrand(userName);
                return Ok(response);
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Customer not found");

                return NotFound("Customer not found", new { userName });
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { userName });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: userName);
            }
        }

        //page is 0 based
        /// <summary>
        /// Search users
        /// </summary>
        /// <param name="vm">Search request</param>
        /// <param name="pageSize">Page size</param>
        /// <param name="pageNum">Page number</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /users/search
        ///     {
        ///         "Name": "John",
        ///         "UserType": 1
        ///     }
        ///
        /// </remarks>
        /// <returns>A list of users</returns>
        /// <response code="200">An authentication response</response>
        [HttpPost("users/search")]
        [ProducesResponseType(typeof(IEnumerable<User>), 200)]
        public IActionResult Search([FromBody] UserSearchRequest vm, int pageSize, int pageNum)
        {
            const int maxPageSizeForCA = 500;

            if (vm != null)
            {
                int maxPageSize = vm.IncludeCredentialsInfo ? maxPageSizeForCA : 99999;

                if (pageNum < 0 || pageSize > maxPageSize)
                {
                    return BadRequest($"Pagination data is invalid (Max page size is {maxPageSize})");
                }

                try
                {
                    var users = SearchUsersService(vm, pageSize, pageNum);

                    return Ok(users);
                }
                catch (InvalidOperationException ex)
                {
                    _logger.LogError(ex, "Internal server error");

                    return BadRequest(ex.Message);
                }
                catch (NullReferenceException ex)
                {
                    _logger.LogDebug(ex, "Null reference error");

                    return NotFound(ex.Message, new { vm, pageSize, pageNum });
                }
                catch (Exception ex)
                {
                    _logger.LogCritical(ex, "Internal server error");

                    return InternalError(ex, parameters: new { vm, pageSize, pageNum });
                }
            }
            else
            {
                return BadRequest("The UserSearchRequest object is null");
            }
        }

        private IEnumerable<User> SearchUsersService(UserSearchRequest vm, int pageSize, int pageNum)
        {
            return _userService.Search(vm, pageSize, pageNum);
        }

        /// <summary>
        /// Gets the user that match the request criteria.
        /// </summary>
        /// <param name="request">User Data</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /api/identity/users/match
        ///
        /// </remarks>
        /// <returns>User</returns>
        /// <response code="200">User</response>
        /// <response code="404">Request is not valid.</response>
        /// <response code="500">If an error occurred</response>
        [ProducesResponseType(typeof(User), 200)]
        [HttpPost("users/match")]
        public IActionResult MatchUser([FromBody] UserMatchRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Request is not valid.");
            }

            try
            {
                var user = _userService.UserMatch(request);
                return Ok(user);
            }
            catch (NullReferenceException ex)
            {
                _logger.LogDebug(ex, "Null reference error");

                return NotFound(ex.Message, new { request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { request });
            }
        }

        /// <summary>
        /// Get user profile
        /// </summary>
        /// <param name="id">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /users/1/profile
        ///
        /// </remarks>
        /// <returns>A user profile</returns>
        /// <response code="200">A user profile</response>
        /// <response code="404">If user was not found</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{id}/profile")]
        [ProducesResponseType(typeof(IEnumerable<UserProfileInfo>), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult GetUserProfileInfo(int id)
        {
            try
            {
                var userDetails = _userService.GetUserProfileInfo(id);
                return Ok(userDetails);
            }
            catch (NullReferenceException ex)
            {
                _logger.LogCritical(ex, "Null reference error");

                return InternalError(ex, parameters: id);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound($"Customer not found {id}");
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { id });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: id);
            }
        }

        /// <summary>
        /// Updates user's email info (profile)
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="request">Primary and alternate email values</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /api/identity/users/123/emails
        ///     {
        ///         "primaryEmail": "user@example.com",
        ///         "alternateEmail": "user@example.com"
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Request is not valid.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPut("users/{id}/emails")]
        public IActionResult UpdateEmailInfo([FromRoute] int id, [FromBody] UpdateEmailRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                if (!request.PrimaryEmail.IsValidEmailAddress())
                {
                    return BadRequest("Invalid Primary Email Address");
                }

                if (!request.AlternateEmail.IsValidEmailAddress(false))
                {
                    return BadRequest("Invalid Alternate Email Address");
                }
                request.PrimaryEmail = request.PrimaryEmail?.ToLower();
                request.AlternateEmail = request.AlternateEmail?.ToLower();
                _userService.UpdateEmailInfo(id, request);
                return Ok("Success");
            }
            catch (JxchangeServiceException jex)
            {
                _logger.LogError(jex, "JxService error");

                return BadGateway(jex, $"JxService error: {jex.Message}", new { id, request });
            }
            catch (NullReferenceException nex)
            {
                _logger.LogDebug(nex, "Null reference error");

                return NotFound(nex.Message, new { id, request });
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, new { id, request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { id, request });
            }
        }

        /// <summary>
        /// Update employment information
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="request">Employment information request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /users/1/employmentinfo
        ///     {
        ///         "Employer": "",
        ///         "Occupation": ""
        ///     }
        ///
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="404">If user was not found</response>
        /// <response code="502">If an error with JHA occurred</response>
        [HttpPut("users/{id}/employmentinfo")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(502)]
        public IActionResult UpdateEmploymentInfo([FromRoute] int id, [FromBody] UpdateEmploymentInfoRequest request)
        {
            try
            {
                _userService.UpdateEmploymentInfo(id, request);
                return Ok();
            }
            catch (NullReferenceException ex)
            {
                _logger.LogCritical(ex, "Null reference error");

                return InternalError(ex, parameters: id);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, new { id, request });
            }
            catch (JxchangeServiceException jex)
            {
                _logger.LogError(jex, "JxService error");

                return BadGateway(jex, $"JxService error: {jex.Message}", new { id, request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { id, request });
            }
        }

        /// <summary>
        /// Update user phones
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="request">Update phones request</param>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="404">If user was not found</response>
        /// <response code="502">If an error with JHA occurred</response>
        [HttpPut("users/{id}/phones")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(502)]
        public IActionResult UpdatesPhones([FromRoute] int id, [FromBody] UpdateUserPhonesRequest request)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Modelstate is invalid in UpdatesPhones. {request}", request);
                return BadRequest(ModelState.GetErrorMessages());
            }

            try
            {
                var profile = _userService.GetUserProfileInfo(id);

                profile.SetPhones(request);

                string UpdatedBy = "";
                if (HttpContext?.User?.Identity != null)
                {
                    UpdatedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                }
                _userService.UpdateUserProfile(profile, UpdatedBy);

                return Ok("Success");
            }
            catch (InvalidOperationException iex)
            {
                _logger.LogError(iex, "Invalid operation error");

                return BadRequest(iex.Message);
            }
            catch (NotFoundException nex)
            {
                _logger.LogDebug(nex, "Not found error");

                return NotFound(nex.Message, new { id, request });
            }
            catch (JxchangeServiceException jex)
            {
                _logger.LogError(jex, "JxService error");

                return BadGateway(jex, $"JxService error: {jex.Message}", new { id, request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        /// <summary>
        /// Get primary phone
        /// </summary>
        /// <param name="id">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /users/1/phones/primary
        ///
        /// </remarks>
        /// <returns>User primary phone</returns>
        /// <response code="200">User primary phone</response>
        /// <response code="404">If user was not found</response>
        [HttpGet("users/{id}/phones/primary")]
        [ProducesResponseType(typeof(UserPhoneDto), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetPrimaryPhone(int id)
        {
            try
            {
                var user = _userService.GetUser(id);
                var primaryPhone = user.Phones.FirstOrDefault(x => x.PhoneType == PhoneType.HomeCellPhone);

                if (primaryPhone == null)
                    return NotFound($"User ID {id} does not have a primary phone");

                return Ok(primaryPhone);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found");
                return NotFound(ex.Message, new { id });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Update primary phone
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="request">Update primary phone request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /users/1/phones/primary
        ///     {
        ///         "Number":"00000000",
        ///         "Extension": "",
        ///         "IsPrimary": true,
        ///         "PhoneType": 1
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="404">If user was not found</response>
        [HttpPut("users/{id:int}/phones/primary")]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(404)]
        public IActionResult UpdatePrimaryPhone([FromRoute] int id, [FromBody] UserPhoneDto request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                _userService.UpdatePrimaryPhone(id, request);

                return Ok("Success");
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found");
                return NotFound(ex.Message, new { id });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal error");
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Update primary address
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="primaryAddress">Primary address</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /users/1/addresses/primary
        ///     {
        ///         "StreetAddress1":"Address",
        ///         "StreetAddress2":"",
        ///         "City":"Los Angeles",
        ///         "State":"CA",
        ///         "StateCode":"California",
        ///         "Id": "",
        ///         "IsPrimary": true,
        ///         "AddressType": 1
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="404">If user was not found</response>
        /// <response code="400">If model is invalid</response>
        /// <response code="502">If an error with JHA occurred</response>
        [HttpPut("users/{id}/addresses/primary")]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(502)]
        public IActionResult UpdatePrimaryAddress([FromRoute] int id, [FromBody] Models.Address primaryAddress)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("Modelstate is invalid in UpdatePrimaryAddress. {primaryAddress}", primaryAddress);
                return BadRequest(ModelState.GetErrorMessages());
            }

            try
            {
                var profile = _userService.GetUserProfileInfo(id);
                if (profile.CellPhone1 != null
                    && profile.CellPhone1.Number != null
                    && !profile.CellPhone1.Equals(profile.PhoneNumber))
                {
                    profile.PhoneNumber = profile.CellPhone1.Number;
                }
                profile.SetPrimaryAddress(primaryAddress);

                string UpdatedBy = "";
                if (HttpContext?.User?.Identity != null)
                {
                    UpdatedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;
                }
                _userService.UpdateUserProfile(profile, UpdatedBy);

                return Ok("Success");
            }
            catch (InvalidOperationException iex)
            {
                _logger.LogError(iex, "Invalid operation error");

                return BadRequest(iex.Message);
            }
            catch (NotFoundException nex)
            {
                _logger.LogDebug(nex, "Not found error");

                return NotFound(nex.Message, new { id, primaryAddress });
            }
            catch (JxchangeServiceException jex)
            {
                _logger.LogError(jex, "JxService error");

                return BadGateway(jex, $"JxService error: {jex.Message}", new { id, primaryAddress });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Get all addresses of a user
        /// </summary>
        /// <param name="id">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /users/1/addresses
        ///
        /// </remarks>
        /// <returns>List of addresses</returns>
        /// <response code="404">If user was not found</response>
        /// <response code="200">User addresses</response>
        [HttpGet("users/{id}/addresses")]
        [ProducesResponseType(typeof(IEnumerable<Models.Address>), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetAllAddresses([FromRoute] int id)
        {
            try
            {
                var addresses = _userService.GetAllAddresses(id);
                return Ok(addresses);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, new { id });
            }
            catch (NullReferenceException ex)
            {
                _logger.LogCritical(ex, "Null reference error");

                return InternalError(ex);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        /// <summary>
        /// Deletes and address from account
        /// </summary>
        /// <param name="addressId">Address id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     DELETE /api/identity/users/addresses/12
        ///     {
        ///         "primaryEmail": "user@example.com",
        ///         "alternateEmail": "user@example.com"
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="502">JxService error.</response>
        /// <response code="500">If an error occurred</response>
        [HttpDelete("users/addresses/{addressId}")]
        public IActionResult DeleteAccountAddress([FromRoute] string addressId)
        {
            try
            {
                _userService.DeleteAccountAddress(addressId);
                return Ok("Success");
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { addressId });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { addressId });
            }
        }

        /// <summary>
        /// Updates address account associations
        /// </summary>
        /// <param name="request">Address data</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /api/identity/users/addresses/accountassociations
        ///     {
        ///         "accountNumber": "string",
        ///         "accountType": "DemandDeposit",
        ///         "addressType": "Mailing",
        ///         "city": "string",
        ///         "postalCode": "string",
        ///         "streetAddress1": "string",
        ///         "streetAddress2": "string",
        ///         "state": "string",
        ///         "stateCode": "string",
        ///         "id": "string",
        ///         "seasonalBeginDate": "2022-07-10T21:18:16.687Z",
        ///         "seasonalEndDate": "2022-07-10T21:18:16.687Z",
        ///         "seasonalRecurrence": true,
        ///         "confirmed": true
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="502">JxService error.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPut("users/addresses/accountassociations")]
        public IActionResult UpdateAccountAssociations([FromBody] Models.Address request)
        {
            try
            {
                _userService.UpdateAddressAccountAssociations(request);
                return Ok("Success");
            }
            catch (JxchangeServiceException ex)
            {
                _logger.LogError(ex, "JxService error");

                return BadGateway(ex, $"JxService error: {ex.Message}", new { request });
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { request });
            }
        }

        /// <summary>
        /// Enroll the User
        /// </summary>
        /// <param name="username">User Name</param>
        /// <param name="vendorName">Vendor Name</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /api/identity/testing/enroll/vendortest
        ///
        /// </remarks>
        /// <returns>Id generated</returns>
        /// <response code="200">Id generated</response>
        /// <response code="404">User not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPut("{username}/enroll/{vendorName}")]
        public IActionResult EnrollUser(string username, string vendorName)
        {
            try
            {
                var id = _enrollService.EnrollUserIn(vendorName, username);
                return Ok(id);
            }
            catch (NotFoundException notFoundEx)
            {
                _logger.LogError(notFoundEx, notFoundEx.Message);
                return NotFound(notFoundEx.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, parameters: new { username, vendorName });
            }
        }

        /// <summary>
        ///  Synchronize user information with JHA
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /sync/1
        ///
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        [HttpGet("sync/{userId:int}")]
        [ProducesResponseType(200)]
        public async Task<IActionResult> SyncUser(int userId)
        {
            try
            {
                await _syncManager.SyncAsync(userId);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex, ex.InnerException?.Message);
            }
        }

        /// <summary>
        /// Get user password information
        /// </summary>
        /// <param name="username">User Name</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/password/userTest/info
        ///
        /// </remarks>
        /// <returns>Credencial Information</returns>
        /// <response code="200">Credencial Information</response>
        /// <response code="404">User not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/password/{username}/info")]
        public IActionResult GetPasswordInformation([FromRoute] string username)
        {
            try
            {
                var response = _userService.GetPasswordInformation(username);
                return JSendReplyOk(response, response.Message);
            }
            catch (NotFoundException notFoundEx)
            {
                _logger.LogError(notFoundEx, notFoundEx.Message);
                return NotFound(notFoundEx.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex);
            }
        }

        /// <summary>
        /// Declines failed registration
        /// </summary>
        /// <param name="request">Data user entered</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /api/identity/declineRegistration
        ///     {
        ///       "firstName": "string",
        ///       "lastName": "string",
        ///       "email": "string",
        ///       "phoneNumber": "string",
        ///       "cif": "string"
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Invalid Email Address.</response>
        /// <response code="404">Not found error.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("declineRegistration")]
        public IActionResult DeclineRegistration([FromBody] DeclineRegistrationRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                if (!request.Email.IsValidEmailAddress())
                {
                    return BadRequest("Invalid Email Address");
                }
                request.Email = request.Email?.ToLower();
                _userService.DeclineRegistration(request);
                return Ok();
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, request);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(
                    $"Send Decline Registration email failed for {request.FirstName} {request.LastName} ex: {ex}");
                return JSendReplyInternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// Approves failed registration
        /// </summary>
        /// <param name="request">Data user entered</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /api/identity/approveregistration
        ///     {
        ///         "cif": "string",
        ///         "username": "string",
        ///         "applicationUrl": "string",
        ///         "registrationStatus": "0 = Complete",
        ///         "deliveryMethod": "0 = None"
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("approveregistration")]
        public IActionResult ApproveRegistration([FromBody] ApproveRegistrationRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                _userService.ApproveRegistration(request);
                return Ok();
            }
            catch (ArgumentException ex)
            {
                _logger.LogInformation(ex.Message);
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Invalid operation error");

                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex, parameters: request);
            }
        }

        /// <summary>
        /// Repairs Marketo LeadId when LeadId has been de-duplicated away
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/repairMarketo/1
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Bad request.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("repairMarketo/{userId}")]
        public IActionResult RepairMarketoLeadId(int userId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = _userService.RepairMarketoLeadId(userId);
                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Invalid operation");
                return BadRequest(ex.Message);
            }
            catch (BadRequestException ex)
            {
                _logger.LogError(ex, "Bad request");
                return BadRequest(ex.Message);
            }
            catch (NotFoundException notFoundEx)
            {
                _logger.LogError(notFoundEx, notFoundEx.Message);
                return NotFound(notFoundEx.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal Error");
                return InternalError(ex, parameters: userId);
            }
        }

        /// <summary>
        /// Check if user has security questions
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /users/hasSecurityQuestions/1
        ///
        /// </remarks>
        /// <returns>Boolean indicating whether or not a user has security questions</returns>
        /// <response code="200">Boolean indicating whether or not a user has security questions</response>
        /// <response code="404">If user was not found</response>
        [HttpGet("users/hasSecurityQuestions/{userId}")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(404)]
        public IActionResult GetHasSecurityQuestionsFlag(int userId)
        {
            try
            {
                bool? hasSecurityQuestions = _userService.SetHasSecurityQuestionsFlag(userId);
                string message = hasSecurityQuestions.HasValue && hasSecurityQuestions.Value ? string.Empty : "User does not have security questions";

                return Ok(hasSecurityQuestions ?? false, message);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message, "User ID: " + userId.ToString());
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return InternalError(ex);
            }
        }

        /// <summary>
        /// Assing to the User an default UserName value.
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/AssignDefaultUsernameForUser/1
        ///
        /// </remarks>
        /// <returns>User Name</returns>
        /// <response code="200">User Name</response>
        /// <response code="404">Not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/AssignDefaultUsernameForUser/{userId}")]
        public IActionResult AssignDefaultUsernameForUser(int userId)
        {
            try
            {
                var userName = _userService.AssignDefaultUsernameForUser(userId);
                return Ok(userName, $"Username:{userName}");
            }
            catch (NotFoundException nfe)
            {
                _logger.LogError(nfe, nfe.Message);
                return NotFound(nfe.Message, nfe);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return InternalError(ex, ex.Message);
            }
        }

        #region Confirmed Flag

        /// <summary>
        /// Confirm the User Address for the request Type <see cref="AddressType"/> enum.<br/>
        /// Update the Confirmed flag with true.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        /// <returns></returns>
        /// <response code="200">Message "Address Confirmed"</response>
        /// <response code="400">Missing or incorrect Address type on request</response>
        /// <response code="404">Address Type not found for User</response>
        [HttpPut("users/{userId}/confirmaddress")]
        public IActionResult ConfirmAddress([FromRoute] int userId, [FromBody] ConfirmAddressRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (!Enum.IsDefined(typeof(AddressType), request.AddressType))
            {
                _logger.LogInformation("Incorrect Address Type {addressType} userid {userId}", request.AddressType.ToString(), userId);
                return BadRequest("Incorrect Address Type");
            }

            try
            {
                _userService.ConfirmAddress(userId, request);
                return Ok("Address Confirmed");
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("Not found Address Type {userID, addressType}", userId, request.AddressType.ToString());
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in ConfirmAddress. {ex}", ex);
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Confirm the User Phone, only PhoneType == 1 (HomeCellPhone).<br/>
        /// Update the Confirmed flag with true.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        /// <returns></returns>
        /// <response code="200">Message "Phone Confirmed"</response>
        /// <response code="400">Missing or incorrect phone number on request</response>
        /// <response code="404">Phone number not found for User</response>
        [HttpPut("users/{userId}/confirmphone")]
        public IActionResult ConfirmPhone([FromRoute] int userId, [FromBody] ConfirmPhoneRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                _userService.ConfirmPhone(userId, request);
                return Ok("Phone Confirmed");
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("Not found Phone Number {userID, number}", userId, request.Number);
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in ConfirmPhone. {ex}", ex);
                return InternalError(ex);
            }
        }

        /// <summary>
        /// Confirm the User Email.<br/>
        /// Update the EmailConfirmed flag with true.
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <returns></returns>
        /// <response code="200">Message "Email Confirmed"</response>
        /// <response code="404">User Id not found</response>
        [HttpPut("users/{userId}/confirmemail")]
        public IActionResult ConfirmEmail([FromRoute] int userId)
        {
            try
            {
                _userService.ConfirmEmail(userId);
                return Ok("Email Confirmed");
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("User ID {userID} not found ", userId);
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in ConfirmEmail. {ex}", ex);
                return InternalError(ex);
            }
        }

        #endregion

        #region Privacy

        /// <summary>
        /// Get User Privacy Settings
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("privacy/{userid:int}")]
        public IActionResult GetUserPrivacySettings(int userid)
        {
            try
            {
                var results = _userService.GetPrivacySettings(userid);
                if (results != null)
                {
                    return Ok(results);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex, ex.Message, parameters: new { userid });
            }
        }

        /// <summary>
        /// Update User Privacy Settings
        /// </summary>
        /// <param name="request">Private Setting</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /api/identity/privacy
        ///     {
        ///       "cif": "string",
        ///       "shareCreditWorthinessOptOut": true,
        ///       "shareWithAffiliatesOptOut": true,
        ///       "shareWithNonAffiliatesOptOut": true
        ///     }
        ///
        /// </remarks>
        /// <returns>Success</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Update failed.</response>
        /// <response code="500">If an error occurred</response>
        [HttpPut]
        [Route("privacy")]
        public IActionResult UpdateCustomerPrivacy([FromBody] PrivacySettingsRequest request)
        {
            try
            {
                var response = _userService.UpdateCustomerPrivacy(request.Cif, request.ShareCreditWorthinessOptOut,
                    request.ShareWithAffiliatesOptOut, request.ShareWithNonAffiliatesOptOut);

                return !response ? BadRequest("Update Failed") : Ok($"Privacy updated correctly for {request.Cif}");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");

                return JSendReplyInternalError(ex, parameters: new { request });
            }
        }

        #endregion 


        /// <summary>
        /// Get date of last successful login..
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/dateoflastsuccessfullogin/1
        ///
        /// </remarks>
        /// <returns>DateTime</returns>
        /// <response code="200">DateTime</response>
        /// <response code="404">Not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/dateoflastsuccessfullogin/{userId}")]
        public IActionResult DateOfLastSuccessfulLogin(int userId)
        {
            try
            {
                DateTime date = _userService.DateOfLastSuccessfulLogin(userId);
                return Ok(date);
            }
            catch (NotFoundException nfe)
            {
                _logger.LogError(nfe, nfe.Message);
                return NotFound(nfe.Message, nfe);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Get date of last password change.
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/dateoflastpasswordchange/1
        ///
        /// </remarks>
        /// <returns>DateTime</returns>
        /// <response code="200">DateTime</response>
        /// <response code="404">Not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/dateoflastpasswordchange/{userId}")]
        public IActionResult DateOfLastPasswordChange(int userId)
        {
            try
            {
                DateTime date = _userService.DateOfLastPasswordChange(userId);
                return Ok(date);
            }
            catch (NotFoundException nfe)
            {
                _logger.LogError(nfe, nfe.Message);
                return NotFound(nfe.Message, nfe);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return InternalError(ex, ex.Message);
            }
        }

        /// <summary>
        /// Get Login fails quantity by user id.
        /// </summary>
        /// <param name="userId">User id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /api/identity/users/loginFails/1
        ///
        /// </remarks>
        /// <returns>int</returns>
        /// <response code="200">int</response>
        /// <response code="404">Not found.</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/loginFails/{userId}")]
        public IActionResult LoginFailsQuantity(int userId)
        {
            try
            {
                int? loginFails = _userService.GetLoginFailsQuantity(userId);
                return Ok(loginFails);
            }
            catch (NotFoundException nfe)
            {
                _logger.LogError(nfe, nfe.Message);
                return NotFound(nfe.Message, nfe);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return InternalError(ex, ex.Message);
            }
        }
    }
}