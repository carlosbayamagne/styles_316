﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Axos.Identity.Client.Models;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class BrandingsController : UdbBaseApiController
    {
        private readonly IBrandingService _brandingService;

        public BrandingsController(IBrandingService brandingService)
        {
            _brandingService = brandingService;
        }

        /// <summary>
        /// Get branding by Name
        /// </summary>
        /// <param name="brandingName">Branding Name</param>        
        /// <param name="settings">settings</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandings/{brandingName}?settings=true
        ///    
        /// </remarks>
        /// <returns>A Brandings response object</returns>
        /// <response code="200">A Branding response object</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("{brandingName}")]
        public async Task<ActionResult<BrandingDto>> Get(string brandingName, bool settings = false, bool GetDrafts = false)
        {
            var result = await _brandingService.GetBranding(brandingName, settings, GetDrafts);

            return Ok(result.Value);
        }

        /// <summary>
        /// Get branding by Id
        /// </summary>
        /// <param name="brandingId">Branding Id</param>        
        /// <param name="settings">settings</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandings/id/1?settings=true
        ///    
        /// </remarks>
        /// <returns>A Brandings response object</returns>
        /// <response code="200">A Branding response object</response>        
        /// <response code="500">If an error occurred</response>  
        [HttpGet("id/{brandingId}")]
        public async Task<ActionResult<BrandingDto>> GetById(int brandingId, bool settings, bool GetDrafts)
        {
            var result = await _brandingService.GetBranding(brandingId, settings, GetDrafts);

            return Ok(result.Value);
        }

        /// <summary>
        /// Get branding Id by branding name
        /// </summary>
        /// <param name="BrandingName">Branding Name</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandings/{BrandingName}/id
        ///    
        /// </remarks>
        /// <returns>A Brandings response object</returns>
        /// <response code="200">A Branding response object</response>        
        /// <response code="500">If an error occurred</response> 
        [HttpGet("{brandingName}/id")]
        public async Task<ActionResult<int>> GetIdByName(string BrandingName)
        {
            var result = await _brandingService.GetBranding(BrandingName, false, false);

            return Ok(result.Value.Id);
        }

        /// <summary>
        /// Get branding settings by branding name
        /// </summary>
        /// <param name="BrandingName">Branding Name</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brandings/{BrandingName}/settings
        ///    
        /// </remarks>
        /// <returns>A Brandings response object</returns>
        /// <response code="200">A Branding Settings response object</response>        
        /// <response code="500">If an error occurred</response> 
        [HttpGet("{brandingName}/settings")]
        public async Task<ActionResult<IEnumerable<BrandingSettingDto>>> GetBrandingSettings(string BrandingName, bool GetDrafts)
        {
            var result = await _brandingService.GetBrandingSettings(BrandingName, GetDrafts);

            return Ok(result.Value);
        }

        /// <summary>
        /// Create branding.
        /// </summary>
        /// <param name="data">branding</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/brandings
        ///     {
        ///         "Name": "Branding Test",
        ///	        "DisplayName": "Display Name",
        ///	        "Email": "Email",
        ///     	"Phone": "123456789",
        ///     	"Url": "Url",
        ///     }
        ///    
        /// </remarks>
        /// <returns>A branding method response object</returns>
        /// <response code="200">A branding method response object</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost]
        public async Task<ActionResult> CreateBranding(BrandingDto data)
        {
            var result = await _brandingService.CreateBranding(data);

            return Ok(result.Value);
        }


        /// <summary>
        /// Update the branding.
        /// </summary>
        /// <param name="data">Branding</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /api/brandings
        ///     {
        ///         "Id": 1,
        ///	        "Name": "Branding Test",
        ///	        "DisplayName": "Display Name",
        ///	        "Email": "Email",
        ///	        "Phone": "123456789",
        ///	        "Url": "Url",
        ///     }
        ///    
        /// </remarks>
        /// <returns>A branding method response object</returns>
        /// <response code="200">A branding method response object</response>      
        /// <response code="500">If an error occurred</response>
        [HttpPut]
        public async Task<ActionResult> UpdateBranding(BrandingDto data)
        {
            var result = await _brandingService.UpdateBranding(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Delete Branding
        /// </summary>
        /// <param name="brandingId">branding Id to delete</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/brandings/1
        ///    
        /// </remarks>
        /// <returns>A brandings bool value</returns>
        /// <response code="200">A bool value</response>      
        /// <response code="500">If an error occurred</response>
        [HttpDelete("{brandingId}")]
        public async Task<ActionResult> DeleteBranding(int brandingId)
        {
            var result = await _brandingService.DeleteBranding(brandingId);

            return Ok(result.Value);
        }

        /// <summary>
        /// Get BrandingSettings by Setting's name and value
        /// </summary>
        /// <param name="settingname">name of setting to search for</param>
        /// <param name="settingvalue">optional -- match this value</param>
        /// <remarks>
        /// 
        /// By parameter:
        /// 
        ///     settingname  -- Search for this settingname
        ///     settingvalue -- search for settings with this value for the propertyname (optional)
        /// 
        /// Sample requests:
        /// 
        /// <pre>
        /// <code>
        /// Single settingname/value:
        ///     GET /settingsbynameandvalue?settingname=subno&amp;settingvalue=1234
        /// All settingvalues for a settingname:
        ///     GET /settingsbynameandvalue?settingname=subno  
        /// </code>
        /// </pre>
        /// </remarks>
        /// <returns>A collection of BrandingSettings objects</returns>
        /// <response code="200">A collection of BrandingSettings objects</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(IEnumerable<BrandingSetting>), 200)]
        [ProducesResponseType(500)]
        [HttpGet("settingsbynameandvalue")]
        public IActionResult GetBrandingSettingsByNameAndValue(
            [FromQuery] string settingname,
            [FromQuery] string settingvalue,
            [FromServices] IBrandingSettingService _brandingSettingsService
        )
        {
            if(string.IsNullOrEmpty(settingname)) return BadRequest("settingname is required");
            var result = _brandingSettingsService.GetBrandingSettingsByNameAndValue(settingname, settingvalue);
            return Ok(result);
        }
    }
}
