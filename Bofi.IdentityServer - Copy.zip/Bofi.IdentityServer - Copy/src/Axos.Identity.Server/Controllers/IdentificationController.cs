﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading.Tasks;
using System.Xml;

using Axos.Extensions;
using Axos.Identity.Client.Models.IdentificationID;
using Axos.Identity.Ekata;
using Axos.Identity.Ekata.Models.Requests;
using Axos.Identity.Experian;
using Axos.Identity.Experian.Models;
using Axos.Identity.Experian.Services;
using Axos.Identity.Mitek.Models;
using Axos.Identity.Mitek.Services;
using Axos.Integration.Common.Exceptions;
using Axos.Integration.Core;
using Axos.Integration.Core.DTOs;
using Axos.Integration.Experian.Providers;
using Axos.Integration.Experian.Responses;
using Axos.Integration.InstantId.Models;
using Axos.Integration.InstantId.Services;
using Axos.Integration.MiTek.Models;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using ExperianResponse = Axos.Integration.Common.Models.ServiceResult<Axos.Identity.Experian.Models.PreciseId.ResponseModel>;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for Identification Services
    /// </summary>
    [Route("api/identification")]
    public class IdentificationController : UdbBaseController
    {
        private readonly ILogger<IdentificationController> _logger;
        private readonly string _environment;
        private readonly IExperianService _experianService;
        private readonly IExperianCreditScoresService _experianCreditScoresService;
        private readonly IEkataService _ekataService;
        private readonly IProvider<NameValueCollection, XmlDocument> _experianInitialCallProvider;
        private readonly IProvider<NameValueCollection, XmlDocument> _experianFinalCallProvider;
        private readonly IProvider<NameValueCollection, XmlDocument> _experianIDVProvider;

        private readonly IMitekService _mitekService;
        private readonly IInstantIdService _instantIdService;

        /// <summary>
        /// Constructor for Controller for Identification Services
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="experianService"></param>
        /// <param name="ekataService"></param>
        /// <param name="experianInitialCallProvider"></param>
        /// <param name="experianFinalCallProvider"></param>
        /// <param name="experianIDVProvider"></param>
        /// <param name="mitekService"></param>
        /// <param name="instantIdService"></param>
        public IdentificationController(ILogger<IdentificationController> logger,
            IExperianService experianService,
            //IExperianCreditScoresService experianCreditScoresService,
            IEkataService ekataService,
            IProvider<NameValueCollection, XmlDocument> experianInitialCallProvider = null,
            IProvider<NameValueCollection, XmlDocument> experianFinalCallProvider = null,
            IProvider<NameValueCollection, XmlDocument> experianIDVProvider = null,
            IMitekService mitekService = null,
            IInstantIdService instantIdService = null)
        {
            _logger = logger;
            _environment = Startup.CurrentEnvironmentName;
            _experianService = experianService;
            _ekataService = ekataService;
            _experianInitialCallProvider = experianInitialCallProvider;
            _experianFinalCallProvider = experianFinalCallProvider;
            _experianIDVProvider = experianIDVProvider;
            _mitekService = mitekService;
            _instantIdService = instantIdService;
            //_experianCreditScoresService = experianCreditScoresService;
        }

        /// <summary>
        /// Initiate an IDV session
        /// </summary>
        /// <param name="questionsRequest"></param>
        /// <returns></returns>
        [HttpPost("idvquestions")]
        public IActionResult GetIDVQuestions([FromBody] IdentificationIDVQuestionsRequest questionsRequest)
        {
            try
            {
                IdentificationIDVQuestionsResponse r = null;
                using (var experianInitialCallProvider = _experianInitialCallProvider ?? new ExperianInitialCallProvider())
                {
                    // use Development Properties
                    experianInitialCallProvider.OpenConnection(_environment);

                    var response = experianInitialCallProvider.ExecuteRequest(questionsRequest.GetNameValueCollection());
                    var experianResponseObject = response.InnerXml.XmlDeserializeFromString<NetConnectResponse>();
                    r = new IdentificationIDVQuestionsResponse
                    {
                        NetConnectResponse = experianResponseObject
                    };
                }
                return Ok(r);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call ExperianInitialCallProvider.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Execute the Final call for an IDV session
        /// </summary>
        /// <param name="answersRequest"></param>
        /// <returns></returns>
        [HttpPost("idvanswers")]
        public IActionResult PostIDVAnswers([FromBody] IdentificationIDVAnswersRequest answersRequest)
        {
            try
            {
                IdentificationIDVAnswersResponse r = null;
                using (var experianFinalCallProvider = _experianFinalCallProvider ?? new ExperianFinalCallProvider())
                {
                    // use Development Properties
                    experianFinalCallProvider.OpenConnection(_environment);

                    var response = experianFinalCallProvider.ExecuteRequest(answersRequest.GetNameValueCollection());
                    var experianResponseObject = response.InnerXml.XmlDeserializeFromString<NetConnectResponse>();

                    r = new IdentificationIDVAnswersResponse
                    {
                        NetConnectResponse = experianResponseObject
                    };
                }
                return Ok(r);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call ExperianFinalCallProvider.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Execute an IDV Provider Request
        /// </summary>
        /// <param name="providerRequest"></param>
        /// <returns></returns>
        [HttpPost("idvrequest")]
        public IActionResult PostIDVProviderRequest([FromBody] IdentificationIDVProviderRequest providerRequest)
        {
            try
            {
                IdentificationIDVProviderResponse r = null;
                using (var experianIDVProvider = _experianIDVProvider ?? new ExperianIDVProvider())
                {
                    // use Development Properties
                    experianIDVProvider.OpenConnection(_environment);

                    var response = experianIDVProvider.ExecuteRequest(providerRequest.GetNameValueCollection());
                    var experianResponseObject = response.InnerXml.XmlDeserializeFromString<NetConnectResponse>();
                    r = new IdentificationIDVProviderResponse
                    {
                        NetConnectResponse = experianResponseObject
                    };
                }
                return Ok(r);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call ExperianRequestProvider.", exception);
                return InternalError(exception.Message);
            }
        }


        #region Mitek
        /// <summary>
        /// Validate an ID using front and back pictures
        /// </summary>
        /// <remarks>
        ///
        /// api/identification/validateid
        /// {
        ///     "front": "...",
        ///     "Back": "...",
        ///     "DocumentType": "IdDocument"
        /// }  
        ///     
        /// </remarks>
        /// <param name="callingApplication">name of application calling IdentityService to validate ID</param>
        /// <param name="idDocument">Pictures of ID front and back</param>
        /// <returns></returns>
        [HttpPost("validateid")]
        public IActionResult ValidateId([FromQuery] string callingApplication, [FromBody] MiTekIdDocument idDocument)
        {
            try
            {
                string callingApp = callingApplication ?? "IdentityService";

                var mitekService = _mitekService ?? new MitekService(_environment, callingApp);
                MiTekServiceResponse r = mitekService.ValidateId(idDocument);

                return Ok(r);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call ValidateId.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Validate an ID using front and back and selfie pictures
        /// </summary>
        /// <remarks>
        ///
        /// api/identification/validateidandselfie
        /// [{
        ///     "front": "...",
        ///     "Back": "...",
        ///     "DocumentType": "IdDocument"
        /// },
        /// {
        ///     "front": "...",
        ///     "documentType": "Selfie"
        /// }]  
        ///     
        /// </remarks>
        /// <param name="callingApplication">name of application calling IdentityService to validate ID</param>
        /// <param name="idDocuments">one MiTekIdDocument with Pictures of ID front and back and another MiTekIdDocument with selfie (front)</param>
        /// <returns></returns>
        [HttpPost("validateidandselfie")]
        public IActionResult ValidateIdAndSelfie([FromQuery] string callingApplication, [FromBody] List<MiTekIdDocument> idDocuments)
        {
            try
            {
                string callingApp = callingApplication ?? "IdentityService";

                var mitekService = _mitekService ?? new MitekService(_environment, callingApp);
                MiTekServiceResponse r = mitekService.ValidateIdAndSelfie(idDocuments);

                return Ok(r);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call ValidateId and Selfie.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Validate an ID using front, back and selfie pictures.
        /// </summary>
        /// <remarks>
        ///
        /// api/identification/authenticatedocuments
        /// 
        /// {
        ///     "IdDocuments" : [{
        ///             "front": "...",
        ///             "Back": "...",
        ///             "DocumentType": "IdDocument"
        ///         },
        ///         {
        ///             "front": "...",
        ///             "documentType": "Selfie"
        ///         }] 
        /// }
        ///     
        /// </remarks>
        /// <param name="callingApplication">name of application calling IdentityService to validate ID</param>
        /// <param name="mitekModel">one MiTekIdDocument with Pictures of ID front and back and another MiTekIdDocument with selfie (front)</param>
        /// <returns></returns>
        [HttpPost("authenticatedocuments")]
        public async Task<IActionResult> AuthenticateDocumentsAsync([FromQuery] string callingApplication, [FromBody] MitekModel mitekModel)
        {
            try
            {
                string callingApp = callingApplication ?? "IdentityService";

                var mitekService = _mitekService ?? new MitekService(_environment, callingApp);
                MiTekServiceResponse response = await mitekService.AuthenticateDocuments(mitekModel);

                return Ok(response);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call Execute Authenticate Documents Async.", exception);
                return InternalError(exception.Message);
            }
        }
        #endregion

        /// <summary>
        /// Validate an ID using Lexis-Nexis InstantId
        /// </summary>
        /// <param name="dlPurpose">DLPurpose (default: NormalCourseOfBusiness)</param>
        /// <param name="glbPurpose">GLBPurpose (default: FraudPrevention)</param>
        /// <param name="searchBy">SearchBy parameters; minimum: firstname, lastname, ssn, zip</param>
        /// <returns></returns>
        [HttpPost("instantid")]
        public IActionResult RunInstantId([FromBody] InstantIdSearchBy searchBy, [FromQuery] GLBPurpose? glbPurpose, [FromQuery] DLPurpose? dlPurpose)
        {
            try
            {
                IInstantIdService instantIdService = _instantIdService ?? new InstantIdService(Startup.CurrentEnvironmentName);
                HttpServiceResult<InstantIdResponse> instantIdResult = instantIdService.VerifyIdAsync(searchBy, glbPurpose ?? GLBPurpose.FraudPrevention, dlPurpose ?? DLPurpose.NormalCourseOfBusiness)
                    .GetAwaiter().GetResult();
                if (instantIdResult.WasSuccessful)
                {
                    return Ok(instantIdResult.Data);
                }
                else
                {
                    return BadRequest(null, instantIdResult.Message);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call InstantId.", exception);
                return InternalError(exception.Message);
            }
        }

        #region Experian       

        /// <summary>
        /// Execute an RequestScores
        /// </summary>    
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /getidaquestions
        /// {
        ///    "FirstName": "RUTH",
        ///    "LastName": "SIMPSON",
        ///    "MiddleName": "A",
        ///    "SSN": "666-64-7983",
        ///    "Street": "3119 FOOTHILL BLVD APT 5",
        ///    "City": "LA CRESCENTA",
        ///    "State": "CA",
        ///    "PostalCode": "91214",
        ///    "DriverLicenseNumber": "234235",
        ///    "DriverLicenseState": "CA",
        ///    "PhoneNumber": "8183523798",
        ///    "PhoneType": "C",
        ///    "DateOfBirth": "1980-01-01",
        ///    "Reference": "Insonmia"
        /// }
        ///     
        /// </remarks>
        /// <param name="personalInformation"></param>
        /// <returns>Axos.Integration.Common.Models.ServiceResult&lt;Axos.Identity.Experian.Models.PreciseId.ResponseModel&gt;</returns>
        [HttpPost("getidaquestions")]
        public async Task<IActionResult> GetIdaQuestionsAsync([FromBody] PersonalInformation personalInformation)
        {
            try
            {
                ExperianResponse response = await _experianService.GetIdaQuestions(personalInformation);

                return Ok(response);
            }
            catch (RulesEngineException rex)
            {
                _logger.LogCritical(rex, "Rules engine error");
                return BadRequest(rex.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call Experian GetIdaQuestions.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Execute an ExecuteIdvAsync
        /// </summary> 
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /executeidv
        /// {
        ///    "FirstName": "RUTH",
        ///    "LastName": "SIMPSON",
        ///    "MiddleName": "A",
        ///    "SSN": "666-64-7983",
        ///    "Street": "3119 FOOTHILL BLVD APT 5",
        ///    "City": "LA CRESCENTA",
        ///    "State": "CA",
        ///    "PostalCode": "91214",
        ///    "DriverLicenseNumber": "234235",
        ///    "DriverLicenseState": "CA",
        ///    "PhoneNumber": "8183523798",
        ///    "PhoneType": "C",
        ///    "DateOfBirth": "1980-01-01",
        ///    "Reference": "Insonmia"
        /// }
        /// </remarks>
        /// <param name="personalInformation"></param>
        /// <returns>Axos.Integration.Common.Models.ServiceResult&lt;Axos.Identity.Experian.Models.PreciseId.ResponseModel&gt;</returns>
        [HttpPost("executeidv")]
        public async Task<IActionResult> ExecuteIdvAsync([FromBody] PersonalInformation personalInformation)
        {
            try
            {
                ExperianResponse response = await _experianService.RequestIdv(personalInformation);

                return Ok(response);
            }
            catch (RulesEngineException rex)
            {
                _logger.LogCritical(rex, "Rules engine error");
                return BadRequest(rex.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call Experian ExecuteIdvAsync.", exception);
                return InternalError(exception.Message);
            }
        }

        /// <summary>
        /// Execute an SendIdaAnswersAsync
        /// </summary>       
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /sendidaanswers
        ///{
        ///  "SessionId": "XHWLFK6CT3LWOJBOTBU84TRI.pidd1v-22011215592247379666",
        ///  "Reference": "Insonmia",
        ///  "Answers": [
        ///    { "QuestionId": 1, "AnswerId": 1 },
        ///    { "QuestionId": 2, "AnswerId": 3 },
        ///    { "QuestionId": 3, "AnswerId": 5 },
        ///    { "QuestionId": 4, "AnswerId": 1 },
        ///    { "QuestionId": 5, "AnswerId": 2 }
        ///  ]
        ///}
        /// </remarks>
        /// <param name="request"></param>        
        /// <returns>Axos.Integration.Common.Models.ServiceResult&lt;Axos.Identity.Experian.Models.PreciseId.ResponseModel&gt;</returns>
        [HttpPost("sendidaanswers")]
        public async Task<IActionResult> SendIdaAnswersAsync([FromBody] SendIdaAnswersRequest request)
        {
            try
            {
                //var wea = await _experianCreditScoresService.MainFlow();
                ExperianResponse response = await _experianService.SendIdaAnswers(request);

                return Ok(response);
            }
            catch (RulesEngineException rex)
            {
                _logger.LogCritical(rex, "Rules engine error");
                return BadRequest(rex.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Unexpected error when trying to call Experian SendIdaAnswers.", exception);
                return InternalError(exception.Message);
            }
        }
        #endregion

        /// <summary>
        /// Validate an identity using ekata service
        /// </summary>
        /// <param name="request"></param>
        /// <param name="useTestConfig"></param>
        /// <returns>Identity check</returns>        
        /// <response code="200">Identity check</response>               
        /// <response code="500">Internal server error</response>
        [HttpPost("ekata")]
        public IActionResult RunEkataIdentityCheck([FromBody] IdentityCheckRequestV33 request, [FromQuery] bool useTestConfig = false)
        {
            try
            {
                var result = _ekataService.PerformIdentityCheck(request,useTestConfig);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error when trying to call Ekata Service.", ex);
                return InternalError(ex.Message);
            }
        }
    }
}