﻿namespace Axos.Identity.Server.Controllers
{
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;

    using Axos.Identity.Server.Controllers.Base;
    using Axos.Identity.Server.Data.Repositories;
    using Axos.Identity.Server.Infra.Exceptions;
    using Axos.Identity.Server.Models.Biometrics;
    using Axos.Identity.Server.Models.Request;
    using Axos.Identity.Server.Services;
    using Axos.Identity.Server.Utils;
    using Axos.Identity.Server.Utils.Filters;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Controller for Daon Biometrics
    /// </summary>
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json"), ServiceFilter(typeof(APIExceptionFilter))]
    public class BiometricsController : UdbLoggingController
    {
        private readonly IUserDevicesService _userDevicesService;
        private readonly IUserRepository _userRepository;
        private readonly ILogger<BiometricsController> _logger;

        public BiometricsController(IUserDevicesService userDevicesService,
            ILogger<BiometricsController> logger,
            IUserRepository userRepository)
        {
            _userDevicesService = userDevicesService;
            _logger = logger;
            _userRepository = userRepository;
        }

        /// <summary>
        /// Verifies if the user set the given authentication factor
        /// </summary>
        /// <param name="request">Verify Authentication Factor Request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /biometrics/verify/factor
        ///     {
        ///         "userName": "johnTest",
        ///         "AuthenticationFactor": "PinEnrolled",
        ///         "device":"12345"
        ///     }
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the user set the given authentication factor</returns>
        /// <response code="200">Boolean that indicates if the user set the given authentication factor</response>
        /// <response code="400">The field AuthenticationFactor is invalid.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">No Device Found</response>           
        [HttpPost("verify/factor"), ValidateModelFilter]
        public async Task<IActionResult> VerifyAuthenticationFactor([FromBody]VerifyAuthenticationFactorRequest request)
        => Ok(await _userDevicesService.VerifyAuthenticationFactor(request));

        /// <summary>
        /// Authenticates the user using DaonService
        /// </summary>
        /// <param name="request">Biometric Authentication Request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /biometrics/verify/identity
        ///     {
        ///         "username": "JohnJohnson",  
        ///         "voicePrint": "UklGRiwoAQBXQVZF.."
        ///     }
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the user authentication is successful</returns>
        /// <response code="200">Boolean that indicates if the user authentication is successful</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">The request is not valid</response>           
        [HttpPost("verify/identity"), ValidateModelFilter]
        public IActionResult VerifyIdentity([FromBody] BiometricAuthenticationRequest request)
        {
            var user = _userRepository.GetSingle(x => x.UserName == request.Username)
                ?? throw new NotFoundException("User does not exist");

            return Ok(_userDevicesService.VerifyIdentity(user.Id, request as BiometricDeviceIdentity));
        }

        /// <summary>
        /// Updates the biometric information of the given user
        /// </summary>
        /// <param name="request">Update User Device Details Request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT /biometrics/device
        ///     {
        ///         "userId": 123,
        ///         "deviceId": "1234567890",  
        ///         "voicePrint": 
        ///             [
        ///                 "UklGRiwoAQBXQVZFZm10...",
        ///                 "UklGRiwoAQBXQVZFZm10...",
        ///                 "UklGRiwoAQBXQVZFZm10..."
        ///             ]
        ///     }
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the given biometrics were updated</returns>
        /// <response code="200">Boolean that indicates if the given biometrics were updated</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">The request is not valid</response>           
        [HttpPut("device"), ValidateModelFilter]
        public IActionResult UpdateUserDeviceDetails([FromBody] UpdateUserDeviceDetailsRequest request)
        => Ok(_userDevicesService.UpdateUserDeviceDetails(request));

        /// <summary>
        /// Deletes the voices of the user given user
        /// </summary>
        /// <param name="id">User Id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     DELETE /biometrics/voice/12345
        ///
        /// </remarks>
        /// <returns>Boolean that indicates if the voice was deleted</returns>
        /// <response code="200">Boolean that indicates if the voice was deleted</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">The given user has no devices added.</response>       
        /// <response code="500">If an error occurred</response>                          
        [HttpDelete("voice/{Id}"), ValidateModelFilter]
        public IActionResult DeleteUserDeviceDetails([FromRoute] int id)
        => Ok(_userDevicesService.DeleteUserVoice(id));

        /// <summary>
        /// List authentication factors of the given user
        /// </summary>
        /// <param name="listAuthenticationFactors">List Authentication Factors Request</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /biometrics/list-factors
        ///     {
        ///         "userId": 918104,
        ///         "deviceId": "MmNkZDFkNWUtOGQxZS00ZWI3LTkzYWQtMGY1MGQ0ZWFlN2Y0"
        ///     }
        ///
        /// </remarks>
        /// <returns>String list with the authentication factors of the given user</returns>
        /// <response code="200">String list with the authentication factors of the given user</response>
        /// <response code="400">Bad request.</response> 
        /// <response code="404">User does not exist</response>       
        /// <response code="500">If an error occurred</response>   
        /// <response code="502">The request is not valid</response>           
        [HttpPost("list-factors"), ValidateModelFilter]
        public IActionResult ListAuthenticationFactors([FromBody] ListAuthenticationFactorsRequest listAuthenticationFactors)
        => Ok(_userDevicesService.ListAuthenticationFactor(listAuthenticationFactors));

        /// <summary>
        /// Gets user voice details of all users with the specified phone
        /// </summary>
        /// <param name="phone">Phone number</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /biometrics/voice-details/phone/5512341234
        ///
        /// </remarks>
        /// <returns>Voice registration details of users with the specified phone</returns>
        /// <response code="200">Voice registration details of users with the specified phone</response>
        /// <response code="400">Invalid phone.</response>           
        /// <response code="500">If an error occurred</response>                           
        [HttpGet("voice-details/phone/{phone}")]
        public async Task<IActionResult> GetVoiceDetailsByPhoneAsync([FromRoute] string phone)
        {
            if (!Regex.IsMatch(phone, RegularExpressions.BasicPhone))
                return BadRequest("Invalid phone");

            return Ok(await _userDevicesService.GetVoiceDetailsByPhoneAsync(phone));
        }

        /// <summary>
        /// Gets user voice details of all users with the specified ssn
        /// </summary>
        /// <param name="ssn">User's ssn</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET /biometrics/voice-details/ssn/12345
        ///
        /// </remarks>
        /// <returns>Voice registration details of users with the specified ssn</returns>
        /// <response code="200">Voice registration details of users with the specified ssn</response>
        /// <response code="400">Invalid SSN.</response>           
        /// <response code="500">If an error occurred</response>                    
        [HttpGet("voice-details/ssn/{ssn}")]
        public async Task<IActionResult> GetVoiceDetailsBySSNAsync([FromRoute] string ssn)
        {
            if (!Regex.IsMatch(ssn, RegularExpressions.SSN))
                return BadRequest("Invalid SSN");

            return Ok(await _userDevicesService.GetVoiceDetailsBySSNAsync(ssn));
        }

    }
}
