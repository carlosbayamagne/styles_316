﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Axos.Identity.Server.Infra.Exceptions;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Models.Catalog;
using Axos.Identity.Server.Models.Request;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Exts;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller to manage Admin users
    /// </summary>
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class AdminsController : UdbBaseApiController
    {
        readonly IAdminUserService _adminUserService;
        ILogger<IdentityController> _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="adminUserService"></param>
        /// <param name="logger"></param>
        public AdminsController(IAdminUserService adminUserService, ILogger<IdentityController> logger)
        {
            _adminUserService = adminUserService;
            _logger = logger;
        }

        /// <summary>
        /// Authenticate an administrator user
        /// </summary>
        /// <param name="request">User name and password</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST api/Admins/authenticate
        ///     {
        ///	        "Username": "user_name",
        ///	        "Password": "password"
        ///     }
        ///     
        /// </remarks>
        /// <returns>Authentication response with User info</returns>
        /// <response code="200">Authentication response with User info</response>
        /// <response code="500">If an error occurred</response>                
        [HttpPost("authenticate")]
        public async Task<ActionResult<AuthenticationResponse>> Authenticate(AuthenticationRequest request)
        {
            try
            {
                var response = await _adminUserService.Authenticate(request);
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in Authenticate. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Get an admin user by id
        /// </summary>
        /// <param name="id">User Id</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET api/Admins/users/123456
        ///     
        /// </remarks>
        /// <returns>User info</returns>
        /// <response code="200">User info</response>
        /// <response code="404">User not found</response> 
        /// <response code="500">If an error occurred</response>                
        [HttpGet("users/{id}")]
        public async Task<ActionResult<AdminUserDto>> GetUser(int id)
        {
            try
            {
                var user = await _adminUserService.GetUser(id);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("User not found GetUser by ID. {id}", id);
                return NotFound(null, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in GetUser. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Get an admin user by name
        /// </summary>
        /// <param name="userName">User Name</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET api/Admins/users/username/johnTest
        ///     
        /// </remarks>
        /// <returns>User info</returns>
        /// <response code="200">User info</response>
        /// <response code="404">User not found</response> 
        /// <response code="500">If an error occurred</response>                
        [HttpGet("users/userName/{userName}")]
        public async Task<ActionResult<AdminUserDto>> GetUser(string userName)
        {
            try
            {
                var user = await _adminUserService.GetUser(userName);

                return Ok(user);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("User not found GetUser by username. {userName}", userName);
                return NotFound(null, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in GetUser. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Get all admin users               
        /// </summary>
        /// <param name="pageNum">Page number</param>
        /// <param name="pageSize">Page size (1000 default)</param>        
        /// <param name="refreshUsers">if set, updates their data with Active Directory current info</param>
        /// <param name="excludeClosed">if set, excludes status Closed and Active Directory's Disabled users</param>
        /// <param name="ids">Specific users to retrieve</param>     
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET api/Admins/users?pageNum=1&amp;pageSize=5&amp;refreshUsers=true&amp;excludeClosed=true&amp;ids=1&amp;ids=2&amp;ids=3
        ///     
        /// </remarks>
        /// <returns>List of User info</returns>
        /// <response code="200">List of User info</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("users")]
        public async Task<ActionResult<IEnumerable<AdminUserDto>>> GetUsers(int pageNum, int pageSize, bool refreshUsers, bool excludeClosed, [FromQuery(Name = "ids")] params int[] ids)
        {
            try
            {
                var users = await _adminUserService.GetUsers(pageNum, pageSize, refreshUsers, excludeClosed, ids);

                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in GetUsers. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Search admin users              
        /// </summary>
        /// <param name="searchText">Text to search in firstname or user name</param>    
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     GET api/Admins/users/search/johntest
        ///     
        /// </remarks>
        /// <returns>List of User info.</returns>
        /// <response code="200">List of User info.</response>    
        /// <response code="400">Search text must be at least 2 characters long.</response> 
        /// <response code="500">If an error occurred</response>         
        [HttpGet("users/search/{searchText}")]
        public async Task<ActionResult<IEnumerable<AdminUserDto>>> SearchUsers(string searchText)
        {
            if (searchText.Length < 2)
            {
                _logger.LogInformation("Bad Request, Searchtext not long enough {searchText}", searchText);
                return BadRequest("Search text must be at least 2 characters long.");
            }

            try
            {
                var users = await _adminUserService.SearchUnregisteredUsers(searchText);

                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in SearchUsers. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Update status of admin user
        /// </summary>
        /// <param name="userId">User id</param>
        /// <param name="request">New User Status</param>         
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     PUT api/Admins/users/12345/status
        ///     {
        ///	        "Status": "Active"        
        ///     }
        ///     
        /// </remarks>        
        /// <response code="200">Successful updated.</response>    
        /// <response code="400">Incorrect user status.</response> 
        /// <response code="404">User not found.</response> 
        /// <response code="500">If an error occurred.</response>         
        [HttpPut("users/{userId}/status")]
        public async Task<ActionResult> UpdateUserStatus(int userId, UpdateAdminUserStatusRequest request)
        {
            if (!Enum.IsDefined(typeof(AdminUserStatus), request.Status))
            {
                _logger.LogInformation("Incorrect user status {searchText} userid {userId}", request.Status.ToString(), userId);
                return BadRequest(null, "Incorrect user status");
            }

            try
            {
                await _adminUserService.UpdateUserStatus(userId, request);

                return Ok();
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("Not found UpdateUserStatus {userID, status}", userId, request.Status.ToString());
                return NotFound(null, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in UpdateUserStatus. {ex}", ex);
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Create admin user
        /// </summary>
        /// <param name="user">User name and status</param>         
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST api/Admins/users
        ///     {
        ///         "UserName" : "JohnTest",
        ///	        "Status" : "Active"        
        ///     }
        ///     
        /// </remarks>   
        /// <returns>The new userId.</returns>
        /// <response code="200">The new userId.</response>    
        /// <response code="400">Incorrect user status / User already exists.</response> 
        /// <response code="404">User not found on Active Directory.</response> 
        /// <response code="500">If an error occurred.</response>         
        [HttpPost("users")]
        public async Task<ActionResult<int>> CreateUser(CreateAdminUserRequest user)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation("CreateUser Model state is invalid {user}", user);
                return BadRequest(ModelState.GetErrorMessages());
            }
            if (!Enum.IsDefined(typeof(AdminUserStatus), user.Status))
            {
                _logger.LogInformation("Bad Request CreateUser, Incorrect user status (Must be adminuserstatus) {user}", user);
                return BadRequest(null, "Incorrect user status");
            }

            try
            {
                int userId = await _adminUserService.CreateUser(user);

                return Ok(userId);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError("Bad Request Error in CreateUser {ex}", ex);
                return BadRequest(null, ex.Message);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug("Not found CreateUser {user}", user);
                return NotFound(null, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("Error in CreateUser. {ex}", ex);
                return InternalError(ex.Message);
            }
        }
    }
}
