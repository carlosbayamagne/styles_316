﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Models.Request;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Exts;
using Axos.Identity.Server.Utils.Filters;
using Axos.Securities.Client.Advisor.Models;
using Axos.Securities.Client.Advisor.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Consumes("application/json", "multipart/form-data")]
    [ServiceFilter(typeof(APIExceptionFilter))]
    public class IBDController : UdbBaseApiController
    {
        private readonly IIBDService _ibdService;
        private readonly ILogger<IBDController> _logger;

        public IBDController(IIBDService ibdService, ILogger<IBDController> logger)
        {
            _ibdService = ibdService;
            _logger = logger;
        }

        /// <summary>
        /// Add broker to the user.
        /// </summary>
        /// <param name="addBrokerRequest">User Id and Broker Id</param>                     
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd
        ///     {
        ///         "userId": 123,
        ///         "brokerId": 321
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>        
        [HttpPost]
        public async Task<ActionResult> AddBroker(BrokerUserRequest addBrokerRequest)
        {
            var result = await _ibdService.AddBroker(addBrokerRequest);

            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Add broker to the users.
        /// </summary>
        /// <param name="request">Broker Id and Users</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/adduserstobroker
        ///     {
        ///         "brokerId": 123,
        ///         "userIds": [ 321 ]
        ///  }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>        
        [HttpPost("adduserstobroker")]
        public async Task<ActionResult> AddUsersToBroker(AddUsersToBrokerRequest request)
        {
            var result = await _ibdService.AddUsersToBroker(request.BrokerId, request.UserIds);

            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);              
            }
            return Ok();
        }

        /// <summary>
        /// Assign parent organization.
        /// </summary>
        /// <param name="request">Parent Id and Child Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/assignparentorganization
        ///     {
        ///         "parentId": 123,
        ///         "childId": 654
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost("assignparentorganization")]
        public async Task<ActionResult> AssignParentOrganization(AssingParentOrganizationRequest request)
        {
            var result = await _ibdService.AssignParentOrganization(request.ParentId, request.ChildId);
            if (result.IsFailed)
            {
                _logger.LogError("Could not assign parent organization", result.Errors);
                return InternalError(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Delete the Broker Id in the user relationship.
        /// </summary>
        /// <param name="request">Parent Id and Child Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/ibd?parentId=123&amp;childId=321
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpDelete]
        public async Task<ActionResult> RemoveBrokerUserRelationship(BrokerUserRequest request)
        {
            var result = await _ibdService.RemoveUserBrokerRelationship(request);

            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);              
            }
            return Ok();
        }

        /// <summary>
        /// Delete all the user from the broker.
        /// </summary>
        /// <param name="brokerId">Broker Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/ibd/removeallbrokerusers/123
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpDelete("removeallbrokerusers/{brokerId}")]
        public async Task<ActionResult> RemoveAllUsersFromBroker(int brokerId)
        {
            var result = await _ibdService.RemoveAllUsersFromBroker(brokerId);
            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Change Broker for a user.
        /// </summary>
        /// <param name="changeBrokerRequest">User Id and current and new Broker Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/changebrokerforuser
        ///     {
        ///         "userId": 0,
        ///         "currentBrokerId": 0,
        ///         "newBrokerId": 0
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost("changebrokerforuser")]
        public async Task<ActionResult> ChangeBrokerForUser(ChangeBrokerForUserRequest changeBrokerRequest)
        {
            var result = await _ibdService.ChangeBrokerForUser(
                            changeBrokerRequest.UserId,
                            changeBrokerRequest.CurrentBrokerId,
                            changeBrokerRequest.NewBrokerId);

            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Change all users from a broker to another.
        /// </summary>
        /// <param name="changeBrokerRequest">Current and new Broker Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/changebrokerforallusers
        ///     {
        ///         "currentBrokerId": 123,
        ///         "newBrokerId": 321
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost("ChangeBrokerForAllUsers")]
        public async Task<ActionResult> ChangeBrokerForAllUsers(ChangeBrokerForAllUsersRequest changeBrokerRequest)
        {
            var result = await _ibdService.ChangeAllBrokerUsers(
                                changeBrokerRequest.CurrentBrokerId, 
                                changeBrokerRequest.NewBrokerId);
            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message); 
            }
            return Ok();
        }

        /// <summary>
        /// Get the Organization Id of a User Id.
        /// </summary>
        /// <param name="id">User Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/ibd/organization/123
        ///    
        /// </remarks>
        /// <returns>Organization Id</returns>
        /// <response code="200">Organization Id</response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpGet("organization/{id}")]
        public async Task<ActionResult> GetOrganizationId(int id)
        {
            var result = await _ibdService.GetOrganizationId(id);
            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok(result.Value);
        }

        /// <summary>
        /// Assign parent organization user.
        /// </summary>
        /// <param name="request">Parent Id and Child Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/assignparentorganizationuser
        ///     {
        ///         "parentId": 123,
        ///         "childId": 654
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost("assignparentorganizationuser")]
        public async Task<ActionResult> AssignParentOrganizationUser(AssingParentOrganizationRequest request)
        {
            var result = await _ibdService.AssignParentOrganizationUser(request.ParentId, request.ChildId);
            if (result.IsFailed)
            {
                _logger.LogError("Could not assign parent organization", result.Errors);
                return InternalError(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Get the Repos of user from RIA id
        /// </summary>
        /// <param name="userid">User id</param>      
        /// <param name="riaid">Ria id</param>                          
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/ibd/assignrepsfromriaid?userid=123&amp;riaid=321
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="500">If an error occurred</response>                
        [HttpGet("assignrepsfromriaid")]
        public async Task<ActionResult> AssignRepsFromRIAId(
            [FromQuery] int userid,
            [FromQuery] string riaid)
        {
            var result = await _ibdService.AssignRepsFromRIAId(userid,riaid);

            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok();
        }

        /// <summary>
        /// Get the Organization Id of a User Id.
        /// </summary>
        /// <param name="udbUserId">User Id</param>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/ibd/organizationId/123
        ///    
        /// </remarks>
        /// <returns>Organization Id</returns>
        /// <response code="200">Organization Id</response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpGet("organizationId/{udbUserId}")]
        public async Task<ActionResult> GetUserOrganizationId(int udbUserId)
        {
            var result = await _ibdService.GetUserOrganizationId(udbUserId);
            if (result.IsFailed)
            {
                return BadRequest(result.Errors.FirstOrDefault().Message);
            }
            return Ok(result.Value);
        }

        /// <summary>
        /// Get User Firms and Reps by UdbUserId
        /// </summary>                           
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/ibd/organizationcontact
        ///     {
        ///         "Id": 0,
        ///         "UdbUserID": 0,
        ///         "LibertyAccountId": "554968435",
        ///         "AccountType": "I",
        ///         "RIAId": "32",
        ///         "PrimaryRepId": 1322264
        ///     }
        ///    
        /// </remarks>
        /// <returns></returns>
        /// <response code="200"></response>
        /// <response code="500">If an error occurred</response>                
        [HttpPost("organizationcontact")]
        public async Task<ActionResult<IEnumerable<FirmRepDto>>> GetUserFirmsAndReps([FromBody] LibertyAccountData[] request)
        {
            var result = await _ibdService.GetUserFirmsAndReps(request);
            return Ok(result.Value);
        }
    }
}
