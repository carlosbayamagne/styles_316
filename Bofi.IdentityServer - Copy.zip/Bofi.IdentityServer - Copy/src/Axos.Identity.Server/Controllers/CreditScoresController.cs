﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Axos.Identity.Experian.Models.Request;
using Axos.Identity.Experian.Models.Request.Details;
using Axos.Identity.Experian.Models.Response;
using Axos.Identity.Server.Models;
using Axos.Identity.Server.Models.Request;
using Axos.Identity.Server.Models.Response;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Exts;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Newtonsoft.Json;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for credit scores
    /// </summary>
    [Route("api/Identity")]
    public class CreditScoresController : UdbBaseController
    {
        private readonly ICreditScoresService _creditScoresService;
        private readonly ILogger<CreditScoresController> _logger;

        private CreditScoresPropertiesSet propertySet;
        private DateTime PropertiesTimestamp;

        private const string NOHITERROR = "Experian report pull no-hit";
        private const string NOTFOUNDERRORTYPE = "12";

        public CreditScoresController(ICreditScoresService creditScoresService, ILogger<CreditScoresController> logger)
        {
            _creditScoresService = creditScoresService;
            _logger = logger;
            string PropertySet = Startup.IdentityServiceConfig.Settings["ExperianCreditScoresPropertiesSet"];
            propertySet = JsonConvert.DeserializeObject<CreditScoresPropertiesSet>(PropertySet);
            PropertiesTimestamp = DateTime.Now;
        }

        private void PropertyRefresh()
        {
            if ((DateTime.Now - PropertiesTimestamp).TotalHours > 1)
            {
                string PropertySet = Startup.IdentityServiceConfig.Settings["ExperianCreditScoresPropertiesSet"];
                propertySet = JsonConvert.DeserializeObject<CreditScoresPropertiesSet>(PropertySet);
                PropertiesTimestamp = DateTime.Now;
            }
        }


        /// <summary>
        /// Gets the current credit scores assigned to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscore
        ///     
        /// </remarks>
        /// <returns>A ScoreDetails object</returns>
        /// <response code="200">A ScoreDetails object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscore")]
        [ProducesResponseType(typeof(ScoreDetails), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<ScoreDetails>> GetCreditScore(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.GetCurrentCreditScore(UdbUserID, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Gets the current credit scores tradelines assigned to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /api/Identity/users/1059716/creditscore/tradelines
        ///     
        /// </remarks>
        /// <returns>A CreditProfileTradelinesResponse object</returns>
        /// <response code="200">A CreditProfileTradelinesResponse object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscore/tradelines")]
        [ProducesResponseType(typeof(CreditProfileTradelinesResponse), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<CreditProfileTradelinesResponse>> GetCreditScoreTradelines(
            [FromRoute] int UdbUserID
        )
        {            
            try
            {
                var result = await _creditScoresService.GetCreditProfileTradelines(UdbUserID);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Gets a list of all the credit scores assigned to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="startdate">Start date filter</param>
        /// <param name="enddate">End date filter</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscorehistory
        ///     
        /// </remarks>
        /// <returns>A collection of custom property objects</returns>
        /// <response code="200">A collection of ScoreDetails objects</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscorehistory")]
        [ProducesResponseType(typeof(IEnumerable<ScoreDetails>), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<IEnumerable<ScoreDetails>>> GetCreditScores(
            [FromRoute] int UdbUserID,
            [FromQuery] DateTime startdate,
            [FromQuery] DateTime enddate
        )
        {
            PropertyRefresh();
            try
            {
                if (startdate != new DateTime() &&
                    enddate != new DateTime())
                {
                    if (startdate > enddate)
                    {
                        return BadRequest(null, "StartDate is bigger than EndDate");
                    }
                    var dateresult = await _creditScoresService.GetCreditScoresByDate(UdbUserID, propertySet, startdate, enddate);
                    if (dateresult.State != "Success")
                        return BadRequest(dateresult.Data, dateresult.Message);
                    return Ok(dateresult.Data);
                }
                else
                {
                    if ((startdate == new DateTime() || enddate == new DateTime()) && (startdate != new DateTime() && enddate != new DateTime()))
                    {
                        return BadRequest(null, ((startdate == new DateTime()) ? "StartDate" : "EndDate") + " is invalid");
                    }
                }
                var result = await _creditScoresService.GetAllCreditScores(UdbUserID, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Enrolls a user for credit scores
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="request">Optional request object for enrollment</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscore/enroll
        ///     
        /// </remarks>
        /// <returns>A Thinload enrollment object</returns>
        /// <response code="200">A Thinload enrollment object</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("users/{UdbUserID}/creditscore/enroll")]
        [ProducesResponseType(typeof(ThinLoadResponse), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<ThinLoadResponse>> CreditScoreEnrollment(
            [FromRoute] int UdbUserID,
            [FromBody] UserDataRequest request = null
        )
        {
            PropertyRefresh();
            if (request != null && !ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in UserDataRequest. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }
            try
            {
                //var propertySet = JsonConvert.DeserializeObject<CreditScoresPropertiesSet>(Startup.IdentityServiceConfig.Settings["CreditScoresPropertiesSet"]);
                var result = await _creditScoresService.ExperianSubscriberEnrollment(UdbUserID, propertySet, request);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                if (result.Data.BureauErrorMessage == NOHITERROR)
                    return BadRequest(result.Data, result.Data.BureauErrorMessage);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Requests verification to experian
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscore/requestverification
        ///     
        /// </remarks>
        /// <returns>A verification object</returns>
        /// <response code="200">A verification object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscore/requestverification")]
        [ProducesResponseType(typeof(GetIDVerificationResponse), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<GetIDVerificationResponse>> CreditScoreVerificationRequest(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.RequestExperianUserVerification(UdbUserID, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Submits verification to experian
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="request">Verification object</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     POST /users/1/creditscore/submitverification
        ///     
        /// </remarks>
        /// <returns>A verification result object</returns>
        /// <response code="200">A verification result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("users/{UdbUserID}/creditscore/submitverification")]
        [ProducesResponseType(typeof(SubmitIDVerificationDataResponse), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<SubmitIDVerificationDataResponse>> CreditScoreVerificationSubmit(
            [FromRoute] int UdbUserID,
            [FromBody] VerificationData request
        )
        {
            PropertyRefresh();
            if (!ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in VerificationData. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }
            try
            {
                //var propertySet = JsonConvert.DeserializeObject<CreditScoresPropertiesSet>(Startup.IdentityServiceConfig.Settings["CreditScoresPropertiesSet"]);
                var result = await _creditScoresService.SubmitExperianUserVerification(UdbUserID, request, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }


        /// <summary>
        /// Removes a user from credit scores
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     DELETE /users/1/creditscore/unenroll
        ///     
        /// </remarks>
        /// <returns>A verification result object</returns>
        /// <response code="200">A soa delete result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpDelete("users/{UdbUserID}/creditscore/unenroll")]
        [ProducesResponseType(typeof(SOADeleteResponse), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<SOADeleteResponse>> CreditScoreUnenrollment(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.ExperianSubscriberUnEnrollment(UdbUserID, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Enrolls a user for credit scores
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscore/enrollcheck
        ///     
        /// </remarks>
        /// <returns>A Thinload enrollment object</returns>
        /// <response code="200">A SOASearchResponse object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscore/enrollcheck")]
        [ProducesResponseType(typeof(SOASearchResponse), 200)]
        [ProducesResponseType(typeof(SOASearchResponse), 404)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<SOASearchResponse>> CreditScoreEnrollmentCheck(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.CheckUserEnrollment(UdbUserID, propertySet);
                if (result.Data.ErrorType == NOTFOUNDERRORTYPE)
                    await _creditScoresService.ExperianSubscriberUnEnrollment(UdbUserID, propertySet);
                if (result.State != "Success")
                    return NotFound(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Gets the current and previous credit scores
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditscore/scorenodes
        ///     
        /// </remarks>
        /// <returns>A ScoreNodesResponse object</returns>
        /// <response code="200">A ScoreNodesResponse object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("users/{UdbUserID}/creditscore/scorenodes")]
        [ProducesResponseType(typeof(ScoreNodesResponse), 200)]
        [ProducesResponseType(typeof(ScoreNodesResponse), 404)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<ScoreNodesResponse>> CreditScoreNodes(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.GetScorePropertyNodes(UdbUserID, propertySet);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Set user's alert and notification preferences
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="request">Verification object</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     POST /users/1/creditscore/notificationpreferences
        ///     
        /// </remarks>
        /// <returns>A notification prefrences result object</returns>
        /// <response code="200">A notification preferences result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("users/{UdbUserID}/creditscore/notificationpreferences")]
        [ProducesResponseType(typeof(CreditScoreNotificationPreferences), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<CreditScoreNotificationPreferences>> SetUserNotificationPreferences(
            [FromRoute] int UdbUserID,
            [FromBody] CreditScoreNotificationPreferences request
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.SetUserNotificationPreferences(UdbUserID, request);
                if (result.State != "Success")
                    return BadRequest(result.Data, result.Message);
                return Ok(result.Data);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

        /// <summary>
        /// Gets the credit profile from a user if available
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /users/1/creditprofile
        ///     
        /// </remarks>
        /// <returns>A CreditProfileContainer object</returns>
        /// <response code="200">A CreditProfileContainer object</response>
        /// <response code="500">If an error occurred</response>
        /// <response code="404">If no profile was found</response>
        [HttpGet("users/{UdbUserID}/creditprofile")]
        [ProducesResponseType(typeof(CreditProfileContainer), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<CreditProfileContainer>> GetCreditProfile(
            [FromRoute] int UdbUserID
        )
        {
            PropertyRefresh();
            try
            {
                var result = await _creditScoresService.GetCreditProfile(UdbUserID);
                switch (result.State)
                {
                    case "Success":
                        return Ok(result.Data);
                    case "Fail":
                        return BadRequest(result.Data, result.Message);
                    case "NotFound":
                        return NotFound(result.Data, result.Message);
                    default:
                        return InternalError(result.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }

    }
}
