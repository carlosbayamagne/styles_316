﻿namespace Axos.Identity.Server.Controllers
{
    using System;

    using Axos.Identity.Server.Infra.Exceptions;
    using Axos.Identity.Server.Models.Catalog;
    using Axos.Identity.Server.Models.Request;
    using Axos.Identity.Server.Models.Response;
    using Axos.Identity.Server.Services;
    using Axos.Identity.Server.Utils.Filters;

    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;

    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    public class AuthenticationController : UdbBaseController
    {
        private readonly ILogger<AuthenticationController> _logger;
        private readonly IAuthenticationService _authenticationService;
        private readonly IUserService _userService;
        public AuthenticationController(
             IAuthenticationService authenticationService,
              ILogger<AuthenticationController> logger,
              IUserService userService
            )
        {
            _logger = logger;
            _authenticationService = authenticationService;
            _userService = userService;
        }

        /// <summary>
        /// Get token for API Subscriber
        /// </summary>
        /// <param name="request">API Subscriber credentials</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST /authentication/subscriber
        ///     {
        ///         "Username" : "username",
        ///         "Password" : "password"
        ///     }
        ///
        /// </remarks>
        /// <returns>A user profile</returns>
        /// <response code="200">A user token</response>
        /// <response code="404">If user was not found</response>
        /// <response code="403">Invalid credentials</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("subscriber"), AllowAnonymous, ValidateModelFilter]
        [ProducesResponseType(typeof(AccessTokenResponse), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(403)]        
        public IActionResult AuthenticateSubscriber([FromBody] InternalServiceAuthenticationRequest request)
        {
            try
            {
                var res = _authenticationService.AuthenticateSubscriber(request);

                if (res.Status != AuthenticationStatus.Allow)
                    return Forbidden();

                var token = _userService.GetToken(request.Username, null, null, null);

                return Ok(token);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not Found");
                return NotFound(request.Username, ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Internal server error");

                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return InternalError(ex.Message);
            }
        }
    }
}
