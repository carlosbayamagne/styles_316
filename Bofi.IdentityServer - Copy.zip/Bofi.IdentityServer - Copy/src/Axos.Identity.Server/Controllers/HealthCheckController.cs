﻿using System.Threading.Tasks;

using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/healthcheck")]
    [ApiController]
    public class HealthCheckController : UdbBaseApiController
    {
        private readonly ILogger<HealthCheckController> _logger;
        private readonly IHealthCheckService _healthCheckService;
        public HealthCheckController(
            ILogger<HealthCheckController> logger,
            IHealthCheckService healthCheckService)
        {
            _logger = logger;
            _healthCheckService = healthCheckService;
        }

        /// <summary>
        /// Gets the current status of BankingCore service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/bankingcore
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("BankingCore")]
        public async Task<ActionResult> CheckAsync_BankingCore()
        {
            var result = await _healthCheckService.CheckAsync_BankingCore();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of Daon service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/daon
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("Daon")]
        public async Task<ActionResult> CheckAsync_Daon()
        {
            var result = await _healthCheckService.CheckAsync_Daon();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of Experian service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/experian
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("Experian")]
        public async Task<ActionResult> CheckAsync_Experian()
        {
            var result = await _healthCheckService.CheckAsync_Experian();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of IntegrationCore service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/integrationcore
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("IntegrationCore")]
        public async Task<ActionResult> CheckAsync_IntegrationCore()
        {
            var result = await _healthCheckService.CheckAsync_IntegrationCore();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of JXChange service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/jxchange
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("JXChange")]
        public async Task<ActionResult> CheckAsync_JXChange()
        {
            var result = await _healthCheckService.CheckAsync_JXChange();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of MiTek service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/mitek
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("MiTek")]
        public async Task<ActionResult> CheckAsync_MiTek()
        {
            var result = await _healthCheckService.CheckAsync_MiTek();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of Notification service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/notification
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("Notification")]
        public async Task<ActionResult> CheckAsync_Notification()
        {
            var result = await _healthCheckService.CheckAsync_Notification();
            return Ok(result);
        }

        /// <summary>
        /// Gets the current status of SalesForce service.
        /// </summary>
        /// <remarks>
        ///
        /// Sample requests:
        ///     GET /healthcheck/salesforce
        ///     
        /// </remarks>
        /// <returns>A status result object</returns>
        /// <response code="200">A result object</response>
        /// <response code="500">If an error occurred</response>
        [HttpGet("SalesForce")]
        public async Task<ActionResult> CheckAsync_SalesForce()
        {
            var result = await _healthCheckService.CheckAsync_SalesForce();
            return Ok(result);
        }

    }
}
