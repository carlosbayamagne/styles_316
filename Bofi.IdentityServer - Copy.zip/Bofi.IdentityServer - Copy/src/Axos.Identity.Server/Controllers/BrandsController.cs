﻿using System.Collections.Generic;
using System.Threading.Tasks;

using Axos.Identity.Server.Models;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class BrandsController : UdbBaseApiController
    {
        private readonly IBrandService _brandService;


        public BrandsController(IBrandService brandService)
        {
            _brandService = brandService;
        }

        /// <summary>
        /// Get brand by Name
        /// </summary>
        /// <param name="brandName">Brand Name</param>        
        /// <param name="settings">settings</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brands/{brandName}?settings=true
        ///    
        /// </remarks>
        /// <returns>A Brands response object</returns>
        /// <response code="200">A Brand response object</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("{brandName}")]
        public async Task<ActionResult<BrandDto>> Get(string brandName, bool settings = false)
        {
            var result = await _brandService.GetBrand(brandName, settings);

            return Ok(result.Value);
        }

        /// <summary>
        /// Get brand by Id
        /// </summary>
        /// <param name="brandId">Brand Id</param>        
        /// <param name="settings">settings</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brands/id/1?settings=true
        ///    
        /// </remarks>
        /// <returns>A Brands response object</returns>
        /// <response code="200">A Brand response object</response>        
        /// <response code="500">If an error occurred</response>  
        [HttpGet("id/{brandId}")]
        public async Task<ActionResult<BrandDto>> GetById(int brandId , bool settings)
        {
            var result = await _brandService.GetBrand(brandId, settings);

            return Ok(result.Value);
        }

        /// <summary>
        /// Get brand Id by brand name
        /// </summary>
        /// <param name="BrandName">Brand Name</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brands/{BrandName}/id
        ///    
        /// </remarks>
        /// <returns>A Brands response object</returns>
        /// <response code="200">A Brand response object</response>        
        /// <response code="500">If an error occurred</response> 
        [HttpGet("{brandName}/id")]
        public async Task<ActionResult<int>> GetIdByName(string BrandName)
        {
            var result = await _brandService.GetBrand(BrandName, false);

            return Ok(result.Value.Id);
        }

        /// <summary>
        /// Get brand settings by brand name
        /// </summary>
        /// <param name="BrandName">Brand Name</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/brands/{BrandName}/settings
        ///    
        /// </remarks>
        /// <returns>A Brands response object</returns>
        /// <response code="200">A Brand Settings response object</response>        
        /// <response code="500">If an error occurred</response> 
        [HttpGet("{brandName}/settings")]
        public async Task<ActionResult<IEnumerable<BrandSettingDto>>> GetBrandSettings(string BrandName)
        {
            var result = await _brandService.GetBrandSettings(BrandName);

            return Ok(result.Value);
        }

        /// <summary>
        /// Create brand.
        /// </summary>
        /// <param name="data">brand</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/brands
        ///     {
        ///         "Name": "Brand Test",
        ///	        "DisplayName": "Display Name",
        ///	        "Email": "Email",
        ///     	"Phone": "123456789",
        ///     	"Url": "Url",
        ///	        "IsWhiteLabel": true,
        ///	        "UserId": 123
        ///     }
        ///    
        /// </remarks>
        /// <returns>A brand method response object</returns>
        /// <response code="200">A brand method response object</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost]
        public async Task<ActionResult> CreateBrand(BrandDto data)
        {
            var result = await _brandService.CreateBrand(data);

            return Ok(result.Value);
        }


        /// <summary>
        /// Update the brand.
        /// </summary>
        /// <param name="data">Brand</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /api/deliverymethod
        ///     {
        ///         "Id": 1,
        ///	        "Name": "Brand Test",
        ///	        "DisplayName": "Display Name",
        ///	        "Email": "Email",
        ///	        "Phone": "123456789",
        ///	        "Url": "Url",
        ///	        "IsWhiteLabel": true,
        ///	        "UserId": 1
        ///     }
        ///    
        /// </remarks>
        /// <returns>A brand method response object</returns>
        /// <response code="200">A brand method response object</response>      
        /// <response code="500">If an error occurred</response>
        [HttpPut]
        public async Task<ActionResult> UpdateBrand(BrandDto data)
        {
            var result = await _brandService.UpdateBrand(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Delete Brand
        /// </summary>
        /// <param name="brandId">brand Id to delete</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /api/brands/1
        ///    
        /// </remarks>
        /// <returns>A brands bool value</returns>
        /// <response code="200">A bool value</response>      
        /// <response code="500">If an error occurred</response>
        [HttpDelete("{brandId}")]
        public async Task<ActionResult> DeleteBrand(int brandId)
        {
            var result = await _brandService.DeleteBrand(brandId);

            return Ok(result.Value);
        }
    }
}
