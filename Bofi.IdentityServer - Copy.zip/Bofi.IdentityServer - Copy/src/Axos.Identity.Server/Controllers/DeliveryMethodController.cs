﻿using System.Threading.Tasks;

using Axos.Identity.Server.Models;
using Axos.Identity.Server.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    [Route("api/[controller]")]
    [ResponseCache(CacheProfileName = "NoCache")]
    public class DeliveryMethodController : UdbBaseApiController
    {
        private readonly IUserService _userService;
        private readonly ILogger<DeliveryMethodController> _logger;


        public DeliveryMethodController(IUserService userService, ILogger<DeliveryMethodController> logger)
        {
            _userService = userService;
            _logger = logger;
        }

        /// <summary>
        /// Get the user delivery settings.
        /// </summary>
        /// <param name="userId">User Id</param>        
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     GET /api/deliverymethod/123
        ///    
        /// </remarks>
        /// <returns>A delivery method settings response object</returns>
        /// <response code="200">A delivery method settings response object</response>        
        /// <response code="500">If an error occurred</response>                
        [HttpGet("{userId}")]
        public async Task<ActionResult> GetSettings(int userId)
        {
            var data = await _userService.GetSettings(userId);

            return Ok(data.Value);
        }

        /// <summary>
        /// Update the user delivery settings.
        /// </summary>
        /// <param name="data">Delivery Method Settings User</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /api/deliverymethod
        ///     {
        /// 	    "emailAlertEnabled": true,
        /// 	    "smsAlertEnabled": false,
        /// 	    "userId": 123,
        /// 	    "id": "0b53bbe3-8eb1-4f8a-db7f-08d89b018269"
        ///     }
        ///    
        /// </remarks>
        /// <returns>A delivery method settings response object</returns>
        /// <response code="200">A delivery method settings response object</response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPut]
        public async Task<ActionResult> UpdateSettings(DeliveryMethodSettingsDto data)
        {
            var result = await _userService.Update(data);

            return Ok(result.Value);
        }

        /// <summary>
        /// Create the user delivery settings.
        /// </summary>
        /// <param name="data">Delivery Method Settings User</param>              
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     POST /api/deliverymethod
        ///     {
        /// 	    "emailAlertEnabled": true,
        /// 	    "smsAlertEnabled": false,
        /// 	    "userId": 123
        ///     }
        ///    
        /// </remarks>
        /// <returns>A delivery method settings response object</returns>
        /// <response code="200">A delivery method settings response object</response>      
        /// <response code="404">User does not exist</response>      
        /// <response code="500">If an error occurred</response>                
        [HttpPost]
        public async Task<ActionResult> CreateSettings(DeliveryMethodSettingsDto data)
        {
            var newSettings = await _userService.Add(data);

            return Ok(newSettings.Value);
        }
    }
}
