﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

using Axos.Identity.Server.Data.Entities;
using Axos.Identity.Server.Infra.Exceptions;
using Axos.Identity.Server.Models.Response;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Exts;
using Axos.Identity.Server.Utils.Filters;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for custom properties
    /// </summary>
    [Route("api/Identity")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    [ServiceFilter(typeof(APIExceptionFilter))]
    public class CustomPropertiesController : UdbBaseController
    {
        private readonly ICustomPropertiesService _customPropertiesService;
        private readonly ILogger<CustomPropertiesController> _logger;

        public CustomPropertiesController(ICustomPropertiesService customPropertiesService, ILogger<CustomPropertiesController> logger)
        {
            _customPropertiesService = customPropertiesService;
            _logger = logger;
        }

        /// <summary>
        /// Add custom properties to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="request">Custom property data</param>
        /// <remarks>
        ///
        /// Sample request:     
        /// 
        ///     POST /users/1/customproperties
        ///     {
        ///         "UdbUserId": 1,
        ///         "PropertyName":"Phones",
        ///         "PropertyValue":"['0000000000','1111111111']",
        ///         "EffectiveDate":"2012-01-31",
        ///         "ExpirationDate":"2012-01-31"
        ///     }
        /// 
        /// </remarks>
        /// <returns>A custom properties response object</returns>
        /// <response code="200">A custom properties response object</response>
        /// <response code="404">If user was not found</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(CustomPropertiesResponse), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        [HttpPost("users/{UdbUserID}/customproperties")]
        public IActionResult CreateCustomProperty([FromRoute] int UdbUserID, [FromBody] CustomProperty request)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in CreateCustomProperty. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }
            try
            {
                var result = _customPropertiesService.AddCustomProperty(request);
                return Ok(result);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound("Udb user not found");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update custom properties to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="request">Custom property data</param>
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     PUT /users/1/customproperties/effectivedate=2012-01-31&amp;name=Phones
        ///     {
        ///         "Id":2,
        ///         "UdbUserId": 1,
        ///         "PropertyName":"Phones",
        ///         "PropertyValue":"['0000000000']",
        ///         "EffectiveDate":"2012-01-31",
        ///         "ExpirationDate":"2012-01-31"
        ///     }
        ///   
        /// </remarks>
        /// <returns>A custom properties response object</returns>
        /// <response code="200">A custom properties response object</response>
        /// <response code="404">If user was not found</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(CustomPropertiesResponse), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        [HttpPut("users/{UdbUserID}/customproperties")]
        public IActionResult UpdateCustomProperty([FromRoute] int UdbUserID, [FromBody] CustomProperty request)
        {
            var updatedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!ModelState.IsValid)
            {
                _logger.LogInformation($"Modelstate is invalid in CreateCustomProperty. {string.Join(" ", ModelState.GetErrorMessages().ToArray())}");
                return BadRequest(ModelState.GetErrorMessages());
            }
            try
            {
                var result = _customPropertiesService.UpdateCustomProperty(request, updatedBy);
                return Ok(result);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Remove custom properties to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="effectivedate">Custom property effective date</param>
        /// <param name="propertyname">Custom property name</param>
        /// <remarks>
        /// 
        /// Sample request:
        /// 
        ///     DELETE /users/1/customproperties/effectivedate=2012-01-01&amp;name=phones
        ///    
        /// </remarks>
        /// <returns>A custom properties response object</returns>
        /// <response code="200">A custom properties response object</response>
        /// <response code="404">If user was not found</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(CustomPropertiesResponse), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        [HttpDelete("users/{UdbUserID}/customproperties")]
        public IActionResult RemoveCustomProperty([FromRoute] int UdbUserID, [FromQuery] DateTime effectivedate, [FromQuery] string propertyname)
        {
            var deletedBy = (HttpContext.User.Identity as ClaimsIdentity).FindFirst(ClaimTypes.NameIdentifier)?.Value;

            try
            {
                if (effectivedate == new DateTime() || String.IsNullOrEmpty(propertyname))
                {
                    return BadRequest("Not enough parameters");
                }
                var result = _customPropertiesService.RemoveCustomProperty(UdbUserID, effectivedate, propertyname, deletedBy);
                return Ok(result);
            }
            catch (NotFoundException ex)
            {
                _logger.LogDebug(ex, "Not found error");

                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Gets all properties assigned to a user
        /// </summary>
        /// <param name="UdbUserID">Udb User id</param>
        /// <param name="startdate">Date range start</param>
        /// <param name="enddate">Date range end</param>
        /// <param name="propertyname">Custom property name</param>
        /// <param name="filterdate">Date to filter</param>
        /// <param name="effectivedate">Custom property effective date</param>
        /// <remarks>
        /// 
        /// By parameter:
        /// 
        ///     (propertyname)                     Gets all custom propery objects that match a given name
        ///     (effectivedate, propertyname)      Gets an specific custom property
        ///     (filterdate)                       Gets all custom properties which have the filter date in its effective range and an matching name
        ///     (filterdate, propertyname)         Gets all custom properties which have the filter date in its effective range and an matching name
        ///     (startdate, enddate)               Gets all custom propery objects in a date range
        ///     (startdate, enddate, propertyname) Gets all custom propery objects that are in a date range and that match the given propertyname
        ///
        /// Sample requests:
        /// <pre>
        /// <code>
        ///     Single property:
        ///         GET /users/1/customproperties?effectivedate=2005-01-31&amp;propertyname=Phone%20list
        ///     All custom property assigned to a user:
        ///         GET /users/1/customproperties
        ///     Get properties by name:
        ///         GET /users/1/customproperties?propertyname=Phone%20list
        ///     Get properties by date:
        ///         GET /users/1/customproperties?filterdate=2022-08-15
        ///     Get properties by date and name:
        ///         GET /users/1/customproperties?propertyname=Phone%20List&amp;filterdate=2005-01-31
        ///     Get properties by range:
        ///         GET /users/1/customproperties?startdate=2000-08-15&amp;enddate=2030-08-15
        ///     Get properties by range and name:
        ///         GET /users/1/customproperties?propertyname=Phone list&amp;startdate=2000-08-15&amp;enddate=2030-08-15
        /// </code>
        /// </pre>
        /// </remarks>
        /// <returns>A collection of custom property objects</returns>
        /// <response code="200">A collection of custom property objects</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(IEnumerable<CustomPropertiesResponse>), 200)]
        [ProducesResponseType(500)]
        [HttpGet("users/{UdbUserID}/customproperties")]
        public IActionResult GetCustomProperties(
            [FromRoute] int UdbUserID,
            [FromQuery] DateTime startdate,
            [FromQuery] DateTime enddate,
            [FromQuery] string propertyname,
            [FromQuery] DateTime filterdate,
            [FromQuery] DateTime effectivedate
        )
        {
            try
            {
                var received_propertyName = !string.IsNullOrEmpty(propertyname);
                var received_dateRange = (startdate != new DateTime() && enddate != new DateTime());
                var received_filterDate = (filterdate != new DateTime());
                var received_effectiveDate = (effectivedate != new DateTime());
                var result = new object();
                if (received_filterDate)
                {
                    if (received_propertyName)
                    {
                        result = _customPropertiesService.GetCustomPropertiesByDateAndName(filterdate, propertyname, UdbUserID);
                    }
                    else
                    {
                        result = _customPropertiesService.GetCustomPropertiesByDate(filterdate, UdbUserID);
                    }
                }
                else if (received_propertyName)
                {
                    if (received_dateRange)
                    {
                        result = _customPropertiesService.GetCustomPropertiesByRangeAndName(startdate, enddate, propertyname, UdbUserID);
                    }
                    else if (received_effectiveDate)
                    {
                        result = _customPropertiesService.GetCustomProperty(UdbUserID, effectivedate, propertyname);
                    }
                    else
                    {
                        result = _customPropertiesService.GetCustomPropertiesByName(propertyname, UdbUserID);
                    }
                }
                else if (received_dateRange)
                {
                    result = _customPropertiesService.GetCustomPropertiesByRange(startdate, enddate, UdbUserID);
                }
                else
                {
                    result = _customPropertiesService.GetAllCustomProperties(UdbUserID);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest("Internal server error");
            }
        }

        /// <summary>
        /// Get custom properties
        /// </summary>
        /// <param name="propertyname">name of property to search for</param>
        /// <param name="propertyvalue">optional -- match this value</param>
        /// <remarks>
        /// 
        /// By parameter:
        /// 
        ///     propertyname  -- Search for this propertyname
        ///     propertyvalue -- search for properties with this value for the propertyname (optional)
        /// 
        /// Sample requests:
        /// 
        /// <pre>
        /// <code>
        /// Single propertyname/value:
        ///     GET /customproperties?propertname=subno&amp;propertyvalue=1234
        /// All properites for a propertyname:
        ///     GET /customproperties?propertyname=subno        
        /// All properties
        ///     GET /customproperties
        /// </code>
        /// </pre>
        /// </remarks>
        /// <returns>A collection of user objects</returns>
        /// <response code="200">A collection of user objects</response>
        /// <response code="500">If an error occurred</response>        
        [ProducesResponseType(typeof(IEnumerable<UdbUser>), 200)]
        [ProducesResponseType(500)]
        [HttpGet("customproperties")]
        public IActionResult GetUsersByProperty(
            [FromQuery] string propertyname,
            [FromQuery] string propertyvalue
        )
        {
            try
            {
                var received_propertyName = !string.IsNullOrEmpty(propertyname);

                if (!received_propertyName) return BadRequest("propertyname is required");

                var result = new object();
                result = _customPropertiesService.GetCustomProperties(propertyname, propertyvalue);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Internal server error");
                return BadRequest("Internal server error");
            }
        }
    }
}
