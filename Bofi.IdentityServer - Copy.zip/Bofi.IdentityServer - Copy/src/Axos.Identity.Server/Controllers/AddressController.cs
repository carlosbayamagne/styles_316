﻿using System.Collections.Generic;

using Axos.Identity.Server.Models.Request;
using Axos.Identity.Server.Models.Response;
using Axos.Identity.Server.Services;
using Axos.Identity.Server.Utils.Filters;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Axos.Identity.Server.Controllers
{
    /// <summary>
    /// Controller for Addresses
    /// </summary>
    [Route("api/Identity")]
    [ResponseCache(CacheProfileName = "NoCache")]
    [Produces("application/json")]
    [ServiceFilter(typeof(APIExceptionFilter))]
    public class AddressController : UdbBaseApiController
    {
        private readonly IAddressService _addressService;
        private readonly ILogger<AddressController> _logger;

        public AddressController(IAddressService addressService, ILogger<AddressController> logger)
        {
            _addressService = addressService;
            _logger = logger;
        }

        /// <summary>
        /// Validate an address
        /// </summary>
        /// <param name="request">Address data data</param>
        /// <remarks>
        ///
        /// Sample request:
        ///
        ///     POST api/identity/addressvalidation
        ///     {
        ///     	"ID":"0",
        ///     	"StreetAddress1":"2335 S State",
        ///     	"StreetAddress2":"Suite 300",
        ///     	"City":"Provo",
        ///     	"State":"UT",
        ///     	"Zip5":"84604",
        ///     	"Zip4":""
        ///     }
        ///     
        /// </remarks>
        /// <returns>An address details response list object</returns>
        /// <response code="200">An address details response list object</response>
        /// <response code="500">If an error occurred</response>
        [HttpPost("addressvalidation")]
        [ProducesResponseType(typeof(IEnumerable<AddressDetailsResponse>), 200)]
        [ProducesResponseType(500)]
        public IActionResult AddressValidation([FromBody] AddressDetailsRequest request)
        {
            var result = _addressService.Validate(request);
            return Ok(result);
        }
    }
}
