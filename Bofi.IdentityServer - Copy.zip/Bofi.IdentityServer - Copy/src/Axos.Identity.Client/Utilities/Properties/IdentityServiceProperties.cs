﻿using Axos.Properties.Services;
using System.Collections.Generic;
using System.Linq;

namespace Axos.Identity.Client.Utilities.Properties
{
    public static class IdentityServiceProperties
    {
        private static IList<Property> _properties;

        public static IList<Property> GetProperties(string environment)
        {
            if (_properties != null && _properties.Any()) return _properties;

            if (string.IsNullOrEmpty(environment) || environment == "Local")
                environment = "Development";

            _properties = new List<Property>();

            var propertyService = new PropertyService(PropertyService.GetUrlForEnvironment(environment));
            var props = propertyService.GetPropertiesForPackage("IdentityService");
            foreach (var p in props)
            {
                _properties.Add(p);
            }

            return _properties;
        }
    }
}