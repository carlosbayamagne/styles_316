﻿using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Models;

namespace Axos.Identity.Client.Utilities.Extensions
{
    public static class UserExtensions
    {
        public static bool IsAxosBank(this User user)
        => IsSubType(user, UserSubType.AxosBank);

        public static bool IsAxosInvest(this User user)
        => IsSubType(user, UserSubType.AxosInvest);

        public static bool IsAxosTrading(this User user)
        => IsSubType(user, UserSubType.AxosTrading);

        public static bool IsAxosFiduciaryServices(this User user)
        => IsSubType(user, UserSubType.AxosFiduciaryServices);

        public static void SetAxosBank(this User user)
        => SetSubType(user, UserSubType.AxosBank);

        public static void SetAxosInvest(this User user)
        => SetSubType(user, UserSubType.AxosInvest);

        public static void SetAxosTrading(this User user)
        => SetSubType(user, UserSubType.AxosTrading);

        public static void SetAxosFiduciaryServices(this User user)
        => SetSubType(user, UserSubType.AxosFiduciaryServices);

        private static bool IsSubType(User user, UserSubType subtype)
        {
            if (user == null)
                return false;

            return user.UserSubType.HasValue ? (user.UserSubType & subtype) != 0 : false;
        }

        private static void SetSubType(User user, UserSubType subtype)
        {
            if (user == null)
                return;

            user.UserSubType = user.UserSubType.HasValue ? (user.UserSubType | subtype) : subtype;
        } 
    }
}
