﻿using Axos.Integration.Core.DTOs;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Utilities.Extensions
{
    public static class HttpClientExtensions
    {
        public static Task<HttpResponseMessage> DeleteAsJsonAsync<T>(this HttpClient httpClient, string requestUri, T data)
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, requestUri) { Content = Serialize(data) };

            return httpClient.SendAsync(payload);
        }

        public static Task<HttpResponseMessage> DeleteAsJsonAsync<T>(this HttpClient httpClient, string requestUri, T data, CancellationToken cancellationToken)
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, requestUri) { Content = Serialize(data) };

            return httpClient.SendAsync(payload, cancellationToken);
        }

        public static async Task<HttpServiceResult> DeleteWithContentAsync<TReq>(this HttpClient httpClient, string url, TReq data)
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, url) { Content = Serialize(data) };

            var response = await httpClient.SendAsync(payload);

            return await response.Content.ReadAsAsync<HttpServiceResult>();
        }

        public static async Task<HttpServiceResult> DeleteWithDataAsync<TReq>(this HttpClient httpClient, string url, TReq data, CancellationToken cancellationToken)
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, url) { Content = Serialize(data) };

            var response = await httpClient.SendAsync(payload);

            return await response.Content.ReadAsAsync<HttpServiceResult>();
        }

        public static async Task<HttpServiceResult<TRes>> DeleteWithDataAsync<TReq, TRes>(this HttpClient httpClient, string url, TReq data)
            where TRes : class
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, url) { Content = Serialize(data) };

            var response = await httpClient.SendAsync(payload);

            return await response.Content.ReadAsAsync<HttpServiceResult<TRes>>();
        }

        public static async Task<HttpServiceResult<TRes>> DeleteWithDataAsync<TReq, TRes>(this HttpClient httpClient, string url, TReq data, CancellationToken cancellationToken)
            where TRes : class
        {
            var payload = new HttpRequestMessage(HttpMethod.Delete, url) { Content = Serialize(data) };

            var response = await httpClient.SendAsync(payload);

            return await response.Content.ReadAsAsync<HttpServiceResult<TRes>>();
        }

        private static HttpContent Serialize(object data)
        {
            return new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
        }
    }
}
