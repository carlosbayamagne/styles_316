﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Middleware
{
    public class TokenValidationOptions
    {
        public string RSAKey { get; set; }
        public string IdentityUrl { get; set; }
    }
}
