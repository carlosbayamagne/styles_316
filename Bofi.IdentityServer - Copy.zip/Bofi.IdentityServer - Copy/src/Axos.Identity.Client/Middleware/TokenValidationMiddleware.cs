﻿using Axos.Integration.Core.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Middleware
{
    public class TokenValidationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly TokenValidationOptions _options;
        private readonly RsaSecurityKey _key;
        private readonly TokenValidationParameters _validationParameters;

        public TokenValidationMiddleware(RequestDelegate next, IOptions<TokenValidationOptions> options)
        {
            var rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(options.Value.RSAKey);
            _key = new RsaSecurityKey(rsa);
            _next = next;
            _options = options.Value;
            _validationParameters = new TokenValidationParameters
            {
                ValidIssuer = _options.IdentityUrl,
                IssuerSigningKeys = new List<SecurityKey> { _key },
                ValidateAudience = false,
                ValidateIssuer = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true
            };
        }

        public async Task Invoke(HttpContext context)
        {

            var userToken = context.Request.Headers["USER_TOKEN"].FirstOrDefault() ?? GetAuthorizationToken(context);
            var adminToken = context.Request.Headers["PROXY_TOKEN"].FirstOrDefault();

            var adminClaims = ValidateToken(adminToken);

            if(adminClaims != null && !adminClaims.Any(x => x.Key == "client_id" && x.Value.Any(y => y == "adminportal.web")))
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsync(JsonConvert.SerializeObject(new JSendReply<string>("error", "Invalid proxy token", null)));
                return;
            }

            context.Items["USER_TOKEN"] = ValidateToken(userToken);
            context.Items["PROXY_TOKEN"] = adminClaims;

            await _next(context);
            return;
        }

        private string GetAuthorizationToken(HttpContext context)
        {
           var token =  context.Request.Headers["Authorization"].FirstOrDefault();

            if (string.IsNullOrEmpty(token) || token.Split(null).Length < 2)
            {
                return null;
            }

            return token.Split(null)[1];
        }

        private Dictionary<string, List<string>> ValidateToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                SecurityToken validatedToken;
                var claimsPrincipal = handler.ValidateToken(token, _validationParameters, out validatedToken);
                return claimsPrincipal.Claims.GroupBy(x => x.Type).ToDictionary(x => x.Key, y => y.Select(x => x.Value).ToList());
            }
            catch (Exception)
            {
                return null;
            }

        }
    }
}
