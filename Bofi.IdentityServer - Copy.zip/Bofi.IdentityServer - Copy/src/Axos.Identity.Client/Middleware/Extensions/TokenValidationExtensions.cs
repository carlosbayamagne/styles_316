﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Axos.Identity.Client.Middleware.Extensions
{
    public static class TokenValidationExtensions
    {
        public static IApplicationBuilder UseTokenValidation(this IApplicationBuilder builder)
         => builder.UseMiddleware<TokenValidationMiddleware>();

        public static IServiceCollection AddTokenValidation(this IServiceCollection service, Action<TokenValidationOptions> options = null)
        {
            options = options ?? (opts => { });
            service.Configure(options);

            return service;
        }
    }
}
