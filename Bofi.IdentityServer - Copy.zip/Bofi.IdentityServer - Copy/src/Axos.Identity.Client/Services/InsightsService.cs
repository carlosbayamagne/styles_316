﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Services.Interfaces;
using System;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class InsightsService : ServiceClientHttpServiceBase, IInsightsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseInsightsUrl = "api/insights";

        public InsightsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public bool InsightsEnabled(int userId)
        {
            var response = Get<object>($"{BaseInsightsUrl}/insightsEnabled/userId/{userId}");

            return Convert.ToBoolean(response);
        }

        public async Task<bool> InsightsEnabledAsync(int userId)
        {
            var response = await GetAsync<object>($"{BaseInsightsUrl}/insightsEnabled/userId/{userId}");

            return Convert.ToBoolean(response);
        }

        public bool InsightsEnabled(string cif)
        {
            var response = Get<object>($"{BaseInsightsUrl}/insightsEnabled/cif/{cif}");

            return Convert.ToBoolean(response);
        }

        public async Task<bool> InsightsEnabledAsync(string cif)
        {
            var response = await GetAsync<object>($"{BaseInsightsUrl}/insightsEnabled/cif/{cif}");

            return Convert.ToBoolean(response);
        }
    }
}
