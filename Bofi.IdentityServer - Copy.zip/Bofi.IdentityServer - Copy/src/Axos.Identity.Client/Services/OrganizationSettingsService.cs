﻿using Axos.Identity.Client.Constants;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    /// <summary>
    ///
    /// </summary>
    /// <seealso cref="Axos.Identity.Client.Http.ServiceClientHttpServiceBase" />
    /// <seealso cref="Axos.Identity.Client.Services.Interfaces.IOrganizationSettingsService" />
    public class OrganizationSettingsService : ServiceClientHttpServiceBase, IOrganizationSettingsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        /// <summary>
        /// Gets the name of the service configuration.
        /// </summary>
        /// <returns></returns>
        protected override string GetServiceConfigName() { return "IdentityService"; }

        /// <summary>
        /// Gets the local service URL.
        /// </summary>
        /// <returns></returns>
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }

        /// <summary>
        /// Gets the token.
        /// </summary>
        /// <returns></returns>
        protected override string GetToken() { return _token; }

        /// <summary>
        /// Sets the token.
        /// </summary>
        /// <param name="token">The token.</param>
        protected override void SetToken(string token) { _token = token; }

        /// <summary>
        /// Gets the refresh time.
        /// </summary>
        /// <returns></returns>
        protected override DateTime GetRefreshTime() { return _refreshTime; }

        /// <summary>
        /// Sets the refresh time.
        /// </summary>
        /// <param name="time">The time.</param>
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }

        /// <summary>
        /// The token
        /// </summary>
        private static string _token = null;

        /// <summary>
        /// The refresh time
        /// </summary>
        private static DateTime _refreshTime = new DateTime(1, 1, 1);

        // copy the above codeblock to all instances of HttpServiceBase

        /// <summary>
        /// Initializes a new instance of the <see cref="OrganizationSettingsService"/> class.
        /// </summary>
        /// <param name="environment">The environment.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public OrganizationSettingsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public Organization Add(Organization organization)
        {
            return Post<Organization, Organization>(UrlConstants.OrganizationUrl, organization);
        }

        public Task<HttpServiceResult<Organization>> AddAsync(Organization organization)
        {
            return PostRequestAsync<Organization, Organization>(UrlConstants.OrganizationUrl, organization);
        }

        public Organization Update(Organization organization)
        {
            return Put<Organization, Organization>(UrlConstants.OrganizationUrl, organization);
        }

        public Task<HttpServiceResult<Organization>> UpdateAsync(Organization organization)
        {
            return PutRequestAsync<Organization, Organization>(UrlConstants.OrganizationUrl, organization);
        }

        public bool Delete(int organizationId)
        {
            return Delete(UrlConstants.OrganizationUrl, organizationId);
        }

        public Task<HttpServiceResult> DeleteAsync(int organizationId)
        {
            return DeleteRequestAsync($"{UrlConstants.OrganizationUrl}/{organizationId}");
        }

        public Organization Get(string organizationName, bool settings, bool GetDrafts = false)
        {
            return Get<Organization>($"{UrlConstants.OrganizationUrl}/{organizationName}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<Organization>> GetAsync(string organizationName, bool settings, bool GetDrafts = false)
        {
            return GetRequestAsync<Organization>($"{UrlConstants.OrganizationUrl}/{organizationName}?settings={settings}&GetDrafts={GetDrafts}");

        }

        public Organization GetById(int organizationId, bool settings, bool GetDrafts = false)
        {
            return Get<Organization>($"{UrlConstants.OrganizationUrl}/id/{organizationId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<Organization>> GetByIdAsync(int organizationId, bool settings, bool GetDrafts = false)
        {
            return GetRequestAsync<Organization>($"{UrlConstants.OrganizationUrl}/id/{organizationId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public int GetIdByName(string organizationName)
        {
            var result = Get<object>($"{UrlConstants.OrganizationUrl}/{organizationName}/id");
            return Convert.ToInt32(result);
        }

        public Task<HttpServiceResult<int>> GetIdByNameAsync(string organizationName)
        {
            return GetRequestAsync<int>($"{UrlConstants.OrganizationUrl}/{organizationName}/id");
        }

        public IEnumerable<OrganizationSetting> GetSettings(string organizationName, bool GetDrafts = false)
        {
            return Get<IEnumerable<OrganizationSetting>>($"{UrlConstants.OrganizationUrl}/{organizationName}/settings?GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<IEnumerable<OrganizationSetting>>> GetSettingsAsync(string organizationName, bool GetDrafts = false)
        {
            return GetRequestAsync<IEnumerable<OrganizationSetting>>($"{UrlConstants.OrganizationUrl}/{organizationName}/settings?GetDrafts={GetDrafts}");
        }


        public Organization GetByUserId(int userId, bool settings, bool GetDrafts = false)
        {
            return Get<Organization>($"{UrlConstants.OrganizationUrl}/userId/{userId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<Organization>> GetByUserIdAsync(int userId, bool settings, bool GetDrafts = false)
        {
            return GetRequestAsync<Organization>($"{UrlConstants.OrganizationUrl}/userId/{userId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        #region Settings
        public OrganizationSetting GetSettingById(int settingId)
        {
            return Get<OrganizationSetting>($"{UrlConstants.OrganizationSettingsUrl}/{settingId}");
        }

        public Task<HttpServiceResult<OrganizationSetting>> GetSettingByIdAsync(int settingId)
        {
            return GetRequestAsync<OrganizationSetting>($"{UrlConstants.OrganizationSettingsUrl}/{settingId}");
        }

        public HttpServiceResult CreateOrganizationSetting(OrganizationSetting setting)
        {
            return Post<HttpServiceResult, OrganizationSetting>(UrlConstants.OrganizationSettingsUrl, setting);
        }

        public Task<HttpServiceResult> CreateOrganizationSettingAsync(OrganizationSetting setting)
        {
            return PostRequestAsync(UrlConstants.OrganizationSettingsUrl, setting);
        }

        public HttpServiceResult UpdateOrganizationSetting(OrganizationSetting setting)
        {
            return Put<HttpServiceResult, OrganizationSetting>(UrlConstants.OrganizationSettingsUrl, setting);
        }

        public Task<HttpServiceResult> UpdateOrganizationSettingAsync(OrganizationSetting setting)
        {
            return PutRequestAsync(UrlConstants.OrganizationSettingsUrl, setting);
        }

        public bool DeleteOrganizationSetting(int settingId)
        {
            return Delete(UrlConstants.OrganizationSettingsUrl, settingId);
        }

        public Task<HttpServiceResult> DeleteOrganizationSettingAsync(int settingId)
        {
            return DeleteRequestAsync($"{UrlConstants.OrganizationSettingsUrl}/{settingId}");
        }

        #endregion
    }
}