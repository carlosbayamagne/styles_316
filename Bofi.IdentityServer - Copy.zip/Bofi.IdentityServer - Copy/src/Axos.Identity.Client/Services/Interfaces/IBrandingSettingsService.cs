﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    /// <summary>
    ///
    /// </summary>
    public interface IBrandingSettingsService
    {
        /// <summary>
        /// Add a Branding.
        /// </summary>
        /// <param name="branding">The branding.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Branding Add(Branding branding);

        /// <summary>
        /// Add an Branding.
        /// </summary>
        /// <param name="branding">The branding.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Branding>> AddAsync (Branding branding);

        /// <summary>
        /// Update an Branding.
        /// </summary>
        /// <param name="branding">The branding.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Branding Update(Branding branding);

        /// <summary>
        /// Update an Branding.
        /// </summary>
        /// <param name="branding">The branding.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Branding>> UpdateAsync(Branding branding);

        /// <summary>
        /// Delete an Branding.
        /// </summary>
        /// <param name="brandingId">The branding id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool Delete(int brandingId);

        /// <summary>
        /// Delete an Branding.
        /// </summary>
        /// <param name="brandingId">The branding id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteAsync(int brandingId);

        /// <summary>
        /// Get an Branding by Name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>

        Branding Get(string brandingName, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Branding by Name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Branding>> GetAsync(string brandingName, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Branding by Id.
        /// </summary>
        /// <param name="brandingId">The branding id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Branding GetById(int brandingId, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Branding by Id.
        /// </summary>
        /// <param name="brandingId">The branding id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Branding>> GetByIdAsync(int brandingId, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Branding Id by Name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        int GetIdByName(string brandingName);

        /// <summary>
        /// Get an Branding Id by Name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<int>> GetIdByNameAsync(string brandingName);

        /// <summary>
        /// Get Branding Settings by branding name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        IEnumerable<BrandingSetting> GetSettings(string brandingName, bool GetDrafts = false);
        /// <summary>
        /// Get Branding Settings by branding name.
        /// </summary>
        /// <param name="brandingName">The branding name.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<IEnumerable<BrandingSetting>>> GetSettingsAsync(string brandingName, bool GetDrafts = false);

        /// <summary>
        /// Get Branding Settings by setting's name and value.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<IEnumerable<BrandingSetting>>> GetBrandingSettingsByNameAndValue(string name, string value = null);

        #region Settings
        /// <summary>
        /// Get branding Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The branding setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        BrandingSetting GetSettingById(int settingId);

        /// <summary>
        /// Get branding Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The branding setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<BrandingSetting>> GetSettingByIdAsync(int settingId);

        /// <summary>
        /// Add Settings to an Branding.
        /// </summary>
        /// <param name="setting">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult CreateBrandingSetting(BrandingSetting setting);

        /// <summary>
        /// Add Settings to an Branding.
        /// </summary>
        /// <param name="setting">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> CreateBrandingSettingAsync(BrandingSetting setting);

        /// <summary>
        /// Update Settings of an Branding.
        /// </summary>
        /// <param name="setting">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult UpdateBrandingSetting(BrandingSetting setting);

        /// <summary>
        /// Update Settings of an Branding.
        /// </summary>
        /// <param name="setting">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> UpdateBrandingSettingAsync(BrandingSetting setting);

        /// <summary>
        /// Delete Settings from an Branding.
        /// </summary>
        /// <param name="settingId">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool DeleteBrandingSetting(int settingId);

        /// <summary>
        /// Delete Settings from an Branding.
        /// </summary>
        /// <param name="settingId">The branding setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteBrandingSettingAsync(int settingId);

        #endregion

    }
}