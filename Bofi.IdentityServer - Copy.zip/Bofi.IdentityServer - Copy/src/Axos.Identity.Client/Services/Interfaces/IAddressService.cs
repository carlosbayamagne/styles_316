﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IAddressService
    {
        /// <summary>
        /// Validates an address and returns the corrections found
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        IEnumerable<AddressDetails> Validate(AddressDetails request);

        /// <summary>
        /// Validates an address and returns the corrections found
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<AddressDetails>>> ValidateAsync(AddressDetails request);
    }
}
