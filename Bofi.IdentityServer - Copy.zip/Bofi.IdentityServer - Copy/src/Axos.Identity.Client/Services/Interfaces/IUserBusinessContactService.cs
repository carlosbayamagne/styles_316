﻿using Axos.Identity.Client.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IUserBusinessContactService
    {
        /// <summary>
        /// Gets a Bussiness Contacts list
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        List<UserBusinessContactsDto> GetBusinessContacts(int userId);

        /// <summary>
        /// Gets an user business contact 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="organizationId"></param>
        /// <returns></returns>
        UserBusinessContactsDto GetBusinessContact(int userId, int organizationId);

        /// <summary>
        /// Adds a business contact to an user
        /// </summary>
        /// <param name="user"></param>
        /// <param name="userBusinessContacts"></param>
        /// <returns></returns>
        bool AddBusinessContact(int userId, UserBusinessContactsDto userBusinessContacts);

        /// <summary>
        /// Updates a business contact
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userBusinessContacts"></param>
        /// <returns></returns>
        bool UpdateBusinessContact(int userId, UserBusinessContactsDto userBusinessContacts);

        /// <summary>
        /// Deletes a buisiness contact
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="organizationId"></param>
        /// <returns></returns>
        bool DeleteBusinessContact(int userId, int organizationId);





    }
}
