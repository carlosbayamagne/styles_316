﻿using System.Collections.Generic;
using System.Threading.Tasks;

using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IIBDService
    {
        /// <summary>
        /// Add broker to user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        bool AddBroker(int userId, int brokerId);

        /// <summary>
        /// Add broker to user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        Task<HttpServiceResult> AddBrokerAsync(int userId, int brokerId);

        bool AssignParentOrganization(int parentId, int childId);

        Task<HttpServiceResult> AssignParentOrganizationAsync(int parentId, int childId);

        /// <summary>
        /// Add broker to multiple users
        /// </summary>
        /// <param name="brokerId"></param>
        /// <param name="userIdList"></param>
        /// <returns></returns>
        bool AddUsersToBroker(int brokerId, List<int> userIdList);

        /// <summary>
        /// Add broker to multiple users
        /// </summary>
        /// <param name="brokerId"></param>
        /// <param name="userIdList"></param>
        /// <returns></returns>
        Task<HttpServiceResult> AddUsersToBrokerAsync(int brokerId, List<int> userIdList);

        /// <summary>
        /// Removes user-broker relationship
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        bool RemoveBrokerUserRelationship(int userId, int brokerId);

        /// <summary>
        /// Removes user-broker relationship
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        Task<HttpServiceResult> RemoveBrokerUserRelationshipAsync(int userId, int brokerId);

        /// <summary>
        /// Remove broker for multiple users
        /// </summary>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        bool RemoveAllUsersForBroker(int brokerId);

        /// <summary>
        /// Remove broker for multiple users
        /// </summary>
        /// <param name="brokerId"></param>
        /// <returns></returns>
        Task<HttpServiceResult> RemoveAllUsersForBrokerAsync(int brokerId);

        /// <summary>
        /// Change broker for user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="currentBrokerId"></param>
        /// <param name="newBrokerId"></param>
        /// <returns></returns>
        bool ChangeBrokerForUser(int userId, int currentBrokerId, int newBrokerId);

        /// <summary>
        /// Change broker for user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="currentBrokerId"></param>
        /// <param name="newBrokerId"></param>
        /// <returns></returns>
        Task<HttpServiceResult> ChangeBrokerForUserAsync(int userId, int currentBrokerId, int newBrokerId);

        /// <summary>
        /// update all users froma broker
        /// </summary>
        /// <param name="currentBrokerId"></param>
        /// <param name="newBrokerId"></param>
        /// <returns></returns>
        bool ChangeBrokerForAllUsers(int currentBrokerId, int newBrokerId);

        /// <summary>
        /// update all users froma broker
        /// </summary>
        /// <param name="currentBrokerId"></param>
        /// <param name="newBrokerId"></param>
        /// <returns></returns>
        Task<HttpServiceResult> ChangeBrokerForAllUsersAsync(int currentBrokerId, int newBrokerId);

        GetOrganizationIdResponse GetUserOrganizationId(int userId);

        Task<GetOrganizationIdResponse> GetUserOrganizationIdAsync(int userId);

        /// <summary>
        /// Adds a parent user for a organization user
        /// </summary>
        /// <param name="parentId">Parent user id</param>
        /// <param name="childId">Child user id</param>
        /// <returns></returns>
        bool AssignParentOrganizationUser(int parentId, int childId);

        /// <summary>
        /// Adds a parent user for a organization user
        /// </summary>
        /// <param name="parentId">Parent user id</param>
        /// <param name="childId">Child user id</param>
        /// <returns></returns>
        Task<HttpServiceResult> AssignParentOrganizationUserAsync(int parentId, int childId);

        bool AssignRepsFromRIAId(int UserId, string RiaId);

        Task<HttpServiceResult> AssignRepsFromRIAIdAsync(int UserId, string RiaId);

        /// <summary>
        /// Get the Organization Id of a User Id.
        /// </summary>
        /// <param name="udbUserId"></param>
        /// <returns></returns>
        GetOrganizationIdResponse GetOrganizationId(int userId);

        /// <summary>
        /// Get the Organization Id of a User Id.
        /// </summary>
        /// <param name="udbUserId"></param>
        /// <returns></returns>
        Task<GetOrganizationIdResponse> GetOrganizationIdAsync(int userId);

        /// <summary>
        /// Get User Firm and Reps by primary rep id or RiaId if the first is null
        /// </summary>
        /// <param name="request">array of LibertyAccountDataDto objects to request</param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<FirmRepDto>>> GetUserFirmsAndReps(LibertyAccountDataDto[] request);


    }
}
