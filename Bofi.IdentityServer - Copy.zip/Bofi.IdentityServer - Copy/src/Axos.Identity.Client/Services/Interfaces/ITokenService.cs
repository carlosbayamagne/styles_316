﻿using IdentityModel.Client;
using System;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ITokenService
    {
        /// <summary>
        /// Request a token using Resource Owner method
        /// </summary>
        /// <param name="clientId">Application ClientId</param>
        /// <param name="clientSecret">Application Secret</param>
        /// <param name="identityScopes">The scopes to request access to</param>
        /// <param name="username">Username</param>
        /// <param name="password">Password</param>        
        /// <returns cref="IdentityModel.Client.TokenResponse">IdentityModel.Client.TokenResponse</returns>
        [Obsolete("Use IdentityService GetTokenForUser")]
        Task<TokenResponse> RequestUserTokenAsync(string clientId, string clientSecret, string identityScopes, string username, string password);
    }
}