﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    /// <summary>
    ///
    /// </summary>
    public interface IDeliveryMethodSettingsService
    {
        /// <summary>
        /// Adds the specified settings.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <returns>The newly created settings.</returns>
        DeliveryMethodSettingsUpdate Add(DeliveryMethodSettings settings);

        /// <summary>
        /// Adds the specified settings.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <returns>The newly created settings.</returns>
        Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> AddSettingsAsync(DeliveryMethodSettings settings);

        /// <summary>
        /// Gets the settings.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        DeliveryMethodSettingsUpdate GetSettings(int userId);

        /// <summary>
        /// Gets the settings.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> GetSettingsAsync(int userId);

        /// <summary>
        /// Updates the specified settings.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <returns>The updated settings.</returns>
        DeliveryMethodSettingsUpdate Update(DeliveryMethodSettingsUpdate settings);

        /// <summary>
        /// Updates the specified settings.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <returns>The updated settings.</returns>
        Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> UpdateSettingsAsync(DeliveryMethodSettingsUpdate settings);
    }
}