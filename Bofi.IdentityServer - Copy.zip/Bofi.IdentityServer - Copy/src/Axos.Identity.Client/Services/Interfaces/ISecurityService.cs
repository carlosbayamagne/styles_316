﻿using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.Response;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface ISecurityService
    {
        /// <summary>
        /// Sends an email to the users with his username.
        /// </summary>
        /// <param name="email">User's email address</param>
        /// <param name="brand">Specify a brand</param>
        /// <param name="subBrand">Specify a sub-brand</param>
        /// <returns></returns>
        Task<bool> RecoverUsernameAsync(string email, string brand = null, string subBrand = null, Dictionary<string, string> tokens = null);

        bool ResetPassword(ResetPasswordRequest resetPasswordRequest, bool isAdminReset = false);
        Task<HttpServiceResult> ResetPasswordAsync(ResetPasswordRequest request, bool isAdminReset = false);

        bool EnablePassword(ResetPasswordRequest request);
        Task<HttpServiceResult> EnablePasswordAsync(ResetPasswordRequest request);

        string ChangePassword(ChangePasswordRequest request);
        Task<HttpServiceResult<string>> ChangePasswordAsync(ChangePasswordRequest request);

        string ChangeSecurityQuestions(IEnumerable<ChallengeQuestion> request, string username, string brand = null);
        Task<HttpServiceResult<string>> ChangeSecurityQuestionsAsync(IEnumerable<ChallengeQuestion> request, string username, string brand = null);

        QuestionChallengeResponse ChallengeUser(string username);
        Task<HttpServiceResult<QuestionChallengeResponse>> ChallengeUserAsync(string username);

        VerificationResponse VerifyAnswers(IEnumerable<ChallengeQuestion> questions);
        Task<HttpServiceResult<VerificationResponse>> VerifyAnswersAsync(IEnumerable<ChallengeQuestion> request);

        QuestionsConfigurationResponse GetSecurityQuestions();
        Task<HttpServiceResult<QuestionsConfigurationResponse>> GetSecurityQuestionsAsync();

        QuestionsConfigurationResponse GetUserQuestions(string username);
        Task<HttpServiceResult<QuestionsConfigurationResponse>> GetUserQuestionsAsync(string username);

        EditionResponse SetSecurityQuestions(string username, IEnumerable<ChallengeQuestion> questions);
        Task<HttpServiceResult<EditionResponse>> SetSecurityQuestionsAsync(string username, IEnumerable<ChallengeQuestion> request);

        RiskResponse EvaluateDevice(RiskRequest request);
        Task<HttpServiceResult<RiskResponse>> EvaluateDeviceAsync(RiskRequest request);

        RiskResponse PostEvaluationAnalysis(RiskRequest request, bool challengePassed);
        Task<HttpServiceResult<RiskResponse>> PostEvaluationAnalysisAsync(RiskRequest request, bool challengePassed);

        OtpChallengeResponse GetOTP(OTPRequest request);
        Task<HttpServiceResult<OtpChallengeResponse>> GetOtpAsync(OTPRequest request);

        /// <summary>
        /// It sends an OTP so a phone number that is not in Identity database, it can be validated.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        OtpChallengeResponse GetOTP(OTPSmsRequest request);
        Task<HttpServiceResult<OtpChallengeResponse>> GetOtpAsync(OTPSmsRequest request);

        /// <summary>
        /// It sends an OTP so a phone number and user that are not in Identity database, it can be validated.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        OtpChallengeResponse GetOTPNoUser(OTPSmsNoUserRequest request);
        Task<HttpServiceResult<OtpChallengeResponse>> GetOtpNoUserAsync(OTPSmsNoUserRequest request);

        VerificationResponse ValidateOTP(ValidateOtpRequest request);
        Task<HttpServiceResult<VerificationResponse>> ValidateOtpAsync(ValidateOtpRequest request);

        VerificationResponse ValidateOTPNoUser(ValidateOtpNoUserRequest request);
        Task<HttpServiceResult<VerificationResponse>> ValidateOtpNoUserAsync(ValidateOtpNoUserRequest request);

        string SendConfirmationCode(int userId, DeliveryMethod deliveryMethod, string applicationName, string brand);
        Task<HttpServiceResult<string>> SendConfirmationCodeAsync(int userId, DeliveryMethod deliveryMethod, string appName, string brand);

        void ResetPassword(int userId, string applicationUrl, string applicationName, string brand);
        Task<HttpServiceResult> ResetPasswordAsync(int userId, string appUrl, string appName, string brand);

        void RecoverUsername(string email, string applicationName, string brand, string subBrand = null, Dictionary<string, string> tokens = null);
        Task<HttpServiceResult> RecoverUsernameAsync(string email, string appName, string brand, string subBrand = null, Dictionary<string, string> tokens = null);

        #region GoogleAuthenticator
        GASignupResponse GetGoogleAuthenticatorStringForUser(string username);
        bool ValidateGoogleAuthenticatorCodeForUser(string username, string code);
        bool ResetGoogleAuthenticatorForUser(string username);
        #endregion
    }
}
