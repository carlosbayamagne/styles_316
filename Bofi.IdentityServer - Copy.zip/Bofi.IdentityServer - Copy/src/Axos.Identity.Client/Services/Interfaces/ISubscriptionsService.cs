﻿using Axos.Identity.Client.Models.Subscriptions;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ISubscriptionsService
    {
        IEnumerable<Entitlement> GetEntitlements();

        Task<IEnumerable<Entitlement>> GetEntitlementsAsync();

        Entitlement GetEntitlementById(Guid entitlementId);
        Task<Entitlement> GetEntitlementByIdAsync(Guid entitlementId);

        Entitlement CreateEntitlement(CreateEntitlement request);

        Task<HttpServiceResult> CreateEntitlementAsync(CreateEntitlement request);

        bool DeleteEntitlement(Guid entitlementId);

        Task<HttpServiceResult> DeleteEntitlementAsync(Guid entitlementId);

        HttpServiceResult UpdateEntitlement(EntitlementModel request);

        Task<HttpServiceResult> UpdateEntitlementAsync(EntitlementModel request);
        SubscriptionsServiceResult CreateBundle(CreateBundleModel request);
        Task<HttpServiceResult> CreateBundleAsync(CreateBundleModel request);
        bool DeleteBundle(Guid bundleId);
        Task<HttpServiceResult> DeleteBundleAsync(Guid bundleId);
        List<Bundle> GetBundles();
        Task<List<Bundle>> GetBundlesAsync();
        Bundle GetBundleById(Guid bundleId);
        Task<Bundle> GetBundleByIdAsync(Guid bundleId);
        HttpServiceResult UpdateBundle(BundleModel request);
        Task<HttpServiceResult> UpdateBundleAsync(BundleModel request);
        SubscriptionsServiceResult AddEntitlementToUser(AddEntitlementToUser userEntitlement);
        SubscriptionsServiceResult RemoveUserEntitlements(UserEntitlements request);

    }
}
