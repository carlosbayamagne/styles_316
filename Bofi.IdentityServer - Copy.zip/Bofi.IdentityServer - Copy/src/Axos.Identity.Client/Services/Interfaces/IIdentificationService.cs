﻿using Axos.Identity.Client.Models.Experian;
using Axos.Identity.Client.Models.Ekata.Requests;
using Axos.Identity.Client.Models.Ekata.Response;
using Axos.Identity.Client.Models.IdentificationID;
using Axos.Identity.Client.Models.Mitek;
using Axos.Integration.Core.DTOs;
using Axos.Integration.InstantId.Models;
using Axos.Integration.MiTek.Models;
using System.Threading.Tasks;
using ExperianResponse = Axos.Identity.Client.Models.Experian.ServiceResult<Axos.Identity.Client.Models.Experian.PreciseId.ResponseModel>;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IIdentificationService
    {
        #region Mitek
        MiTekServiceResponse ValidateId(string front, string back);
        Task<HttpServiceResult<MiTekServiceResponse>> ValidateIdAsync(string front, string back);

        MiTekServiceResponse ValidateIdAndSelfie(string front, string back, string selfie);
        Task<HttpServiceResult<MiTekServiceResponse>> ValidateIdAndSelfieAsync(string front, string back, string selfie);

        MiTekServiceResponse AuthenticateDocuments(MitekModel mitekModel);
        Task<HttpServiceResult<MiTekServiceResponse>> AuthenticateDocumentsAsync(MitekModel mitekModel);
        #endregion

        IdentificationIDVQuestionsResponse GetIDVQuestions(IdentificationIDVQuestionsRequest request);
        Task<HttpServiceResult<IdentificationIDVQuestionsResponse>> GetIDVQuestionsAsync(IdentificationIDVQuestionsRequest request);

        IdentificationIDVAnswersResponse PostIDVAnswers(IdentificationIDVAnswersRequest request);
        Task<HttpServiceResult<IdentificationIDVAnswersResponse>> PostIDVAnswersAsync(IdentificationIDVAnswersRequest request);

        IdentificationIDVProviderResponse PostIDVProviderRequest(IdentificationIDVProviderRequest request);
        Task<HttpServiceResult<IdentificationIDVProviderResponse>> PostIDVProviderRequestAsync(IdentificationIDVProviderRequest request);

        InstantIdResponse ValidateInstantId(InstantIdSearchBy searchBy, GLBPurpose glbPurpose = GLBPurpose.FraudPrevention, DLPurpose dlPurpose = DLPurpose.NormalCourseOfBusiness);

        #region Experian
        ExperianResponse GetIdaQuestions(PersonalInformation request);
        Task<HttpServiceResult<ExperianResponse>> GetIdaQuestionsAsync(PersonalInformation request);

        ExperianResponse SendIdaAnswers(SendIdaAnswersRequest request);
        Task<HttpServiceResult<ExperianResponse>> SendIdaAnswersAsync(SendIdaAnswersRequest request);

        ExperianResponse ExecuteIdv(PersonalInformation request);
        Task<HttpServiceResult<ExperianResponse>> ExecuteIdvAsync(PersonalInformation request);
        #endregion

        IdentityCheckResponseV33 EkataIdentityCheck(IdentityCheckRequestV33 request, bool useTestConfig = false);
        Task<HttpServiceResult<IdentityCheckResponseV33>> EkataIdentityCheckAsync(IdentityCheckRequestV33 request, bool useTestConfig = false);
    }
}
