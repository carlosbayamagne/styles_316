﻿using Axos.Identity.Client.Models.Biometrics;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IUserDevicesService
    {
        /// <summary>
        /// Register a new biometric device for an existing user
        /// </summary>        
        /// <returns>True when user and/or device were added correctly</returns>
        bool AddUserDevice(int userId, BiometricDeviceDetailsRequest deviceDetailsRequest);

        /// <summary>
        /// Register a new biometric device for an existing user
        /// </summary>        
        /// <returns>True when user and/or device were added correctly</returns>
        Task<HttpServiceResult> AddUserDeviceAsync(int userId, BiometricDeviceDetailsRequest deviceDetailsRequest);

        /// <summary>
        /// Removes the user device / unregisters the user if no devices are registered
        /// </summary>
        /// <returns>True when user and/or device were deleted correctly</returns>
        bool DeleteDevice(int userId, DeleteBiometricDeviceRequest deleteDeviceRequest);

        /// <summary>
        /// Removes the user device / unregisters the user if no devices are registered
        /// </summary>
        /// <returns>True when user and/or device were deleted correctly</returns>
        Task<HttpServiceResult> DeleteDeviceAsync(int userId, DeleteBiometricDeviceRequest deleteDeviceRequest);

        /// <summary>
        /// Returns the device ids registered
        /// </summary>
        /// <returns>The list of Device Ids</returns>
        IEnumerable<string> GetUserDevices(int userId);

        /// <summary>
        /// Returns the device ids registered
        /// </summary>
        /// <returns>The list of Device Ids</returns>
        Task<HttpServiceResult<IList<string>>> GetUserDevicesAsync(int userId);

        /// <summary>
        /// This will Delete the user and all of the user registered devices from DaonService and UdbUserDevices table
        /// </summary>
        bool DeleteUser(int userId);

        /// <summary>
        /// This will Delete the user and all of the user registered devices from DaonService and UdbUserDevices table
        /// </summary>
        Task<HttpServiceResult> DeleteUserAsync(int userId);
    }
}
