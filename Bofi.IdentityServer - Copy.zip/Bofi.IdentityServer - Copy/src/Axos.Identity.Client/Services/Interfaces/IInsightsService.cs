﻿
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IInsightsService
    {
		/// <summary>
		/// Gets InsightsEnabled bool property for user by userId
		/// from UdbUsers in Identity DB
		/// </summary>
		/// <param name="userid"></param>
		/// <returns></returns>
		bool InsightsEnabled(int userid);

		/// <summary>
		/// Gets InsightsEnabled bool property for user by userId
		/// from UdbUsers in Identity DB
		/// </summary>
		/// <param name="userid"></param>
		/// <returns></returns>
		Task<bool> InsightsEnabledAsync(int userid);

		/// <summary>
		/// Gets InsightsEnabled bool property for user by cif
		/// /// from UdbUsers in Identity DB
		/// </summary>
		/// <param name="cif"></param>
		/// <returns></returns>
		bool InsightsEnabled(string cif);

		/// <summary>
		/// Gets InsightsEnabled bool property for user by cif
		/// /// from UdbUsers in Identity DB
		/// </summary>
		/// <param name="cif"></param>
		/// <returns></returns>
		Task<bool> InsightsEnabledAsync(string cif);
	}
}
