﻿using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using IdentityClient.Models.Request;
using IdentityClient.Models.Response;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface IIdentityService
    {
        /// <summary>
        ///  Adds credentials to a user
        /// </summary>
        /// <param name="request">The credentials request</param>
        /// <returns></returns>
        EnrollmentResult AddUserCredentials(AddUserCredentialsRequest request);

        /// <summary>
        ///  Adds credentials to a user
        /// </summary>
        /// <param name="request">The credentials request</param>
        /// <returns></returns>
        Task<HttpServiceResult<EnrollmentResult>> AddUserCredentialsAsync(AddUserCredentialsRequest request);

        /// <summary>
        /// Gets a User by id. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeStatus">This optional parameter avoids extra call to CA to get Customer Status when is not needed</param>
        /// <returns></returns>
        User GetUser(int id, bool includeStatus = false);

        /// <summary>
        /// Gets a User by id. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeStatus">This optional parameter avoids extra call to CA to get Customer Status when is not needed</param>
        /// <returns></returns>
        Task<HttpServiceResult<User>> GetUserAsync(int id, bool includeStatus = false);

        /// <summary>
        /// Gets a User by username
        /// </summary>
        /// <param name="username"></param>
        /// <param name="includeStatus">This optional parameter avoids extra call to CA to get Customer Status when is not needed</param>
        /// <returns></returns>
        User GetUser(string username, bool includeStatus = false);

        /// <summary>
        /// Gets a User by username
        /// </summary>
        /// <param name="username"></param>
        /// <param name="includeStatus">This optional parameter avoids extra call to CA to get Customer Status when is not needed</param>
        /// <returns></returns>
        Task<HttpServiceResult<User>> GetUserAsync(string username, bool includeStatus = false);

        User GetUserwithCA(string username);

        Task<HttpServiceResult<User>> GetUserwithCAAsync(string username);

        /// <summary>
        /// Gets a User by the CIF
        /// </summary>
        /// <param name="cif">The CIF of the user</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        User GetUserByCif(string cif, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Gets a User by the CIF
        /// </summary>
        /// <param name="cif">The CIF of the user</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        Task<User> GetUserByCifAsync(string cif, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Gets a User by the SSN
        /// </summary>
        /// <param name="ssn">The SSN of the user</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        User GetUserBySsn(string ssn, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Gets a User by the SSN
        /// </summary>
        /// <param name="ssn">The SSN of the user</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        Task<HttpServiceResult<User>> GetUserBySsnAsync(string ssn, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Gets a User by the phone number
        /// </summary>
        /// <param name="phoneNumber">The user's phone number</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        IEnumerable<User> GetUsersByPhoneNumber(string phoneNumber, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Gets a User by the phone number
        /// </summary>
        /// <param name="phoneNumber">The user's phone number</param>
        /// <param name="includeStatus">Should include the CA status</param>
        /// <param name="shouldSendException">Should send an exception if the user is not found</param>
        /// <returns></returns>
        Task<HttpServiceResult<IList<User>>> GetUsersByPhoneNumberAsync(string phoneNumber, bool includeStatus = false, bool shouldSendException = true);

        /// <summary>
        /// Checks if the User CIF creation date is within 30 day period
        /// </summary>
        /// <param name="cif"></param>
        /// <returns>true if cif creation has more than 30 days, otherwise false</returns>
        bool GetCheckUserCifDate(string cif);

        /// <summary>
        /// Checks if the User CIF creation date is within 30 day period
        /// </summary>
        /// <param name="cif"></param>
        /// <returns>true if cif creation has more than 30 days, otherwise false</returns>
        Task<bool> CheckUserCifDateAsync(string cif);

        /// <summary>
        /// Overload for GetCheckUserCifDate, passing User Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        bool GetCheckUserCifDate(int id);

        /// <summary>
        /// Overload for GetCheckUserCifDate, passing User Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> CheckUserCifDateAsync(int id);

        [Obsolete("This API is obsolete.  Use Search", false)]
        IEnumerable<User> GetUsers(params string[] username);

        /// <summary>
        /// Gets the info related to the provided ids, but does not include details like user status.
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [Obsolete("This API is obsolete.  Use Search", false)]
        IEnumerable<User> GetUsers(IEnumerable<int> ids);

        /// <summary>
        /// Gets the info related to the provided CIF.
        /// </summary>
        /// <param name="cif"></param>
        /// <returns></returns>
        [Obsolete("This API is obsolete.  Use Search", false)]
        IEnumerable<User> GetUsers(string cif);

        /// <summary>
        /// Gets a paginated list of Users
        /// </summary>
        /// <param name="pageNum">Zero base</param>
        /// <param name="pageSize"></param>
        /// <param name="enrollmentCompleted">Get users only with enrollment complete</param>
        /// <param name="usersFilter"></param>
        /// <returns></returns>
        [Obsolete("This API is obsolete.  Use Search", false)]
        IEnumerable<User> GetUsers(int pageNum, int pageSize, bool enrollmentCompleted = false,
            UsersTypeFilter usersFilter = UsersTypeFilter.All, bool includeCredentialsInfo = true, bool includeSSN = true, string cif = null);

        BofiBrand GetCustomerBrand(string userName);

        Task<HttpServiceResult<BofiBrand>> GetCustomerBrandAsync(string userName);

        UserProfileInfo GetUserProfileInfo(int id);

        Task<HttpServiceResult<UserProfileInfo>> GetUserProfileInfoAsync(int id);

        /// <summary>
        /// Get user detail info
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        UserDetail GetUserDetail(int id);

        /// <summary>
        /// Get user detail info
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<HttpServiceResult<UserDetail>> GetUserDetailAsync(int id);

        /// <summary>
        /// Determines if a username is not already registered
        /// </summary>
        /// <param name="username"></param>
        /// <returns>returns true if username is not found</returns>
        bool IsUsernameAvailable(string username);

        /// <summary>
        /// Determines if a username is not already registered
        /// </summary>
        /// <param name="username"></param>
        /// <returns>returns true if username is not found</returns>
        Task<bool> IsUsernameAvailableAsync(string username);

        IEnumerable<User> Search(UserSearchRequest vm, int pageSize, int pageNum);

        Task<HttpServiceResult<IList<User>>> SearchAsync(UserSearchRequest vm, int pageSize, int pageNum);

        /// <summary>
        /// Gets the user that matches the request criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns>returns user if a match was found</returns>
        User UserMatch(UserMatchRequest request);

        /// <summary>
        /// Gets the user that matches the request criteria
        /// </summary>
        /// <param name="request"></param>
        /// <returns>returns user if a match was found</returns>
        Task<HttpServiceResult<User>> UserMatchAsync(UserMatchRequest request);

        /// <summary>
        /// Validates a token and returns all claims
        /// </summary>
        /// <param name="token">The token to be validated</param>
        /// <param name="isAdmin">Flag that indicates whether or not the token is associated to an admin user </param>
        /// <returns></returns>
        Dictionary<string, List<string>> ValidateTokenAndExtractClaims(string token, out bool isAdmin);

        /// <summary>
        /// Update Employer and Occupation in JackHenry for the provided userId
        /// </summary>
        /// <param name="userId">The Customer Id</param>
        /// <param name="request">The Employment Information to update</param>
        /// <returns>The json string result from Identity.Server</returns>
        string UpdateEmploymentInfo(int userId, UpdateEmploymentInfoRequest request);

        /// <summary>
        /// Update Employer and Occupation in JackHenry for the provided userId
        /// </summary>
        /// <param name="userId">The Customer Id</param>
        /// <param name="request">The Employment Information to update</param>
        /// <returns>The json string result from Identity.Server</returns>
        Task<HttpServiceResult<string>> UpdateEmploymentInfoAsync(int userId, UpdateEmploymentInfoRequest request);

        string UpdateUserStatuses(UpdateUserStatusRequest request);

        Task<HttpServiceResult<string>> UpdateUserStatusesAsync(UpdateUserStatusRequest request);

        /// <summary>
        /// Updates a user's profile information
        /// </summary>
        /// <param name="request">The user profile information to be updated</param>
        string UpdateUserProfileInfo(UserProfileInfo request);

        /// <summary>
        /// Updates a user's profile information
        /// </summary>
        /// <param name="request">The user profile information to be updated</param>
        Task<HttpServiceResult<string>> UpdateUserProfileInfoAsync(UserProfileInfo request);

        string UpdateEmailInfo(int id, UpdateEmailRequest request);

        Task<HttpServiceResult<string>> UpdateEmailInfoAsync(int userId, UpdateEmailRequest request);

        string UpdatesPhones(int id, UpdateUserPhonesRequest request);

        Task<HttpServiceResult<string>> UpdatePhonesAsync(int userId, UpdateUserPhonesRequest request);

        [Obsolete("This API is obsolete.  Use RegisterUserAsync(GenericCreateUserRequest)", false)]
        EnrollmentResult RegisterUser(CreateUserRequest user);

        /// <summary>
        /// Register non olb user (users that don't have a CIF. E.g. Realtor)
        /// </summary>
        /// <param name="user">Non-Olb User data</param>
        /// <returns></returns>
        [Obsolete("This API is obsolete.  Use RegisterUserAsync(GenericCreateUserRequest)", false)]
        EnrollmentResult RegisterUser(CreateNonOlbUserRequest user);

        /// <summary>
        /// Register a generic user. If the <see cref="UserType"/> is not specified,
        /// one will be assigned automatically
        /// </summary>
        /// <param name="user">Generic User data</param>
        /// <returns></returns>
        EnrollmentResult RegisterUser(GenericCreateUserRequest user, bool waitForSync = false);

        /// <summary>
        /// Register a generic user. If the <see cref="UserType"/> is not specified,
        /// one will be assigned automatically
        /// </summary>
        /// <param name="request">Generic User data</param>
        /// <returns></returns>
        Task<HttpServiceResult<EnrollmentResult>> RegisterUserAsync(GenericCreateUserRequest request, bool waitForSync = false);

        /// <summary>
        /// Eliminates reference from a node and his parent
        /// </summary>
        /// <param name="userId">User to eliminate reference</param>
        void DissociateUser(int userId);

        /// <summary>
        /// Eliminates reference from a node and his parent
        /// </summary>
        /// <param name="userId">User to eliminate reference</param>
        Task<HttpServiceResult> DissociateUserAsync(int userId);

        /// <summary>
        /// Asssociates two users with a parent / child reference
        /// </summary>
        /// <param name="parentId">Parent</param>
        /// <param name="childId">Child</param>

        [Obsolete("Should use AssignParentOrganization on IBD Service")]
        void AssociateUser(int parentId, int childId);

        /// <summary>
        /// Asssociates two users with a parent / child reference
        /// </summary>
        /// <param name="parentId">Parent</param>
        /// <param name="childId">Child</param>
        Task<HttpServiceResult> AssociateUserAsync(int parentId, int childId);

        /// <summary>
        /// Finds users which has a given child
        /// </summary>
        /// <param name="childId">Child Id</param>
        /// <returns>Parent of the child</returns>
        UserTree FindUserByChildID(int childId);

        /// <summary>
        /// Finds users which has a given child
        /// </summary>
        /// <param name="childId">Child Id</param>
        /// <returns>Parent of the child</returns>
        Task<HttpServiceResult<UserTree>> FindUserByChildIdAsync(int childId);

        /// <summary>
        /// Get users which has a given parent
        /// </summary>
        /// <param name="parentId">Parent</param>
        /// <returns>Children of given parent</returns>
        List<UserTree> FindUsersByParentID(int parentId);

        /// <summary>
        /// Get users which has a given parent
        /// </summary>
        /// <param name="parentId">Parent</param>
        /// <returns>Children of given parent</returns>
        Task<HttpServiceResult<IList<UserTree>>> FindUsersByParentIdAsync(int parentId);

        /// <summary>
        /// Gets User Id Tree
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Users Tree</returns>
        UserTree GetTree(int userId);

        /// <summary>
        /// Gets User Id Tree
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Users Tree</returns>
        Task<HttpServiceResult<UserTree>> GetTreeAsync(int userId);

        UserTree GetRelationshipsTree(int userId);

        Task<HttpServiceResult<UserTree>> GetRelationshipsTreeAsync(int userId);

        /// <summary>
        /// Complete registration user
        /// </summary>
        /// <param name="user">User info</param>
        /// <returns></returns>
        PreloadUserStatus CompleteRegistration(CompleteRegistrationRequest user);

        /// <summary>
        /// Complete registration user
        /// </summary>
        /// <param name="user">User info</param>
        /// <returns></returns>
        Task<PreloadUserStatus> CompleteRegistrationAsync(CompleteRegistrationRequest user);

        /// <summary>
        /// Enroll OLB user in vendor specified.
        /// </summary>
        /// <param name="username">User name</param>
        /// <param name="vendorName">Vendor name</param>
        /// <returns></returns>
        string EnrollUser(string username, string vendorName);

        /// <summary>
        /// Enroll OLB user in vendor specified.
        /// </summary>
        /// <param name="username">User name</param>
        /// <param name="vendorName">Vendor name</param>
        /// <returns></returns>
        Task<HttpServiceResult<string>> EnrollUserAsync(string username, string vendorName);

        [Obsolete("This is deprecated functionality ")]
        string UpdatePrimaryAddress(int id, Address primaryAddress);

        IEnumerable<Address> GetAllAddresses(int id);

        Task<HttpServiceResult<IList<Address>>> GetAllAddressesAsync(int userId);

        /// <summary>
        /// Syncs the user's profile with external services.
        /// </summary>
        /// <param name="id">User's ID</param>
        /// <returns>True/False whether if the sync succeed or fails.</returns>
        bool SyncUserProfile(int id);

        /// <summary>
        /// Syncs the user's profile with external services.
        /// </summary>
        /// <param name="id">User's ID</param>
        /// <returns>True/False whether if the sync succeed or fails.</returns>
        Task<HttpServiceResult> SyncUserProfileAsync(int id);

        string DeleteAccountAddress(string addressId);

        Task<HttpServiceResult<string>> DeleteAccountAddressAsync(string addressId);

        string UpdateAccountAssociations(IEnumerable<Address> request);

        Task<HttpServiceResult<string>> UpdateAccountAssociationsAsync(IEnumerable<Address> request);

        Credential GetPasswordInformation(string username);

        Task<HttpServiceResult<Credential>> GetPasswordInformationAsync(string username);

        bool DeclineRegistration(DeclineRegistrationRequest request);

        Task<HttpServiceResult> DeclineRegistrationAsync(DeclineRegistrationRequest request);

        bool ApproveRegistration(ApproveRegistrationRequest request);

        Task<HttpServiceResult> ApproveRegistrationAsync(ApproveRegistrationRequest request);

        PrivacySettings GetPrivacySettings(int userId);

        Task<HttpServiceResult<PrivacySettings>> GetPrivacySettingsAsync(int userId);

        string UpdateCustomerPrivacy(string cif, bool shareCreditWorthinessOptOut, bool shareWithAffiliatesOptOut,
            bool shareWithNonAffiliatesOptOut);

        Task<HttpServiceResult<string>> UpdateCustomerPrivacyAsync(string cif, bool shareCreditWorthinessOptOut,
            bool shareWithAffiliatesOptOut, bool shareWithNonAffiliatesOptOut);

        /// <summary>
        /// Repairs the Marketo LeadId in udbuser
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Obsolete("This is deprecated functionality")]
        int RepairMarketoLeadId(int userId);

        /// <summary>
        /// Gets the HasSecurityQuestionsFlag by querying CA
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>       
        [Obsolete("This is deprecated functionality, use HasSecurityQuestions", false)]
        bool GetHasSecurityQuestionsFlag(int userID);

        /// <summary>
        /// Gets the HasSecurityQuestionsFlag by querying CA
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        [Obsolete("This is deprecated functionality, use HasSecurityQuestionsAsync", false)]
        Task<bool> HasSecurityQuestionsFlagAsync(int userID);

        /// <summary>
        /// Returns if the user has security questions.<br/>
        /// Look in dbo.UserAnswers and update the dbo.Udbusers.HasSecurityQuestions value.
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        bool HasSecurityQuestions(int userID);

        /// <summary>
        /// Returns if the user has security questions.<br/>
        /// Look in dbo.UserAnswers and update the dbo.Udbusers.HasSecurityQuestions value.
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        Task<bool> HasSecurityQuestionsAsync(int userID);

        /// <summary>
        /// Get a Token for a user
        /// </summary>
        /// <param name="atr"></param>
        /// <returns></returns>
        AccessTokenResponse GetTokenForUser(AccessTokenRequest atr);

        /// <summary>
        /// Get a Token for a user
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<AccessTokenResponse>> GetTokenForUserAsync(AccessTokenRequest request);

        /// <summary>
        /// Refresh a Token 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        AccessTokenResponse RefreshToken(AccessTokenRequest request);

        /// <summary>
        /// Refresh a Token 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<AccessTokenResponse>> RefreshTokenAsync(AccessTokenRequest request);

        /// <summary>
        /// Gets the health check response in order to know the if the API is working fine
        /// </summary>
        /// <returns>The health check response</returns>
        HealthCheckResponse GetHealthCheck(bool isDeep);

        /// <summary>
        /// Gets the health check response in order to know the if the API is working fine
        /// </summary>
        /// <returns>The health check response</returns>
        Task<HttpServiceResult<HealthCheckResponse>> GetHealthCheckAsync(bool isDeep);

        /// <summary>
        /// Assign default username by ID
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Default username</returns>
        string AssignDefaultUsernameForUser(int userId);

        /// <summary>
        /// Assign default username by ID
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Default username</returns>
        Task<HttpServiceResult<string>> AssignDefaultUsernameForUserAsync(int userId);

        /// <summary>
        /// Get login fails quantity by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Default username</returns>
        int? GetLoginFailsQuantity(int userId);

        /// <summary>
        /// Get login fails quantity by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Default username</returns>
        Task<HttpServiceResult<int?>> GetLoginFailsQuantityAsync(int userId);

        #region Confirmed Flag

        /// <summary>
        /// Confirm the User Email.        
        /// </summary>        
        /// <param name="userId">User Id</param> 
        string ConfirmEmail(int userId);

        /// <summary>
        /// Confirm the User Email.        
        /// </summary>        
        /// <param name="userId">User Id</param>
        Task<HttpServiceResult<string>> ConfirmEmailAsync(int userId);

        /// <summary>
        /// Confirm the User Address for the request Type <see cref="AddressType"/> enum.        
        /// </summary>        
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        string ConfirmAddress(int userId, ConfirmAddressRequest request);

        /// <summary>
        /// Confirm the User Address for the request Type <see cref="AddressType"/> enum.        
        /// </summary>        
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        Task<HttpServiceResult<string>> ConfirmAddressAsync(int userId, ConfirmAddressRequest request);

        /// <summary>
        /// Confirm the User Phone, only PhoneType == 1 (HomeCellPhone).       
        /// </summary>        
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        string ConfirmPhone(int userId, ConfirmPhoneRequest request);

        /// <summary>
        /// Confirm the User Phone, only PhoneType == 1 (HomeCellPhone).       
        /// </summary>        
        /// <param name="userId">User Id</param>
        /// <param name="request"><see cref="ConfirmAddressRequest"/></param>
        Task<HttpServiceResult<string>> ConfirmPhoneAsync(int userId, ConfirmPhoneRequest request);

        /// <summary>
        /// Get date of last successful login.
        /// </summary> 
        /// <param name="userId">User id</param> 
        DateTime DateOfLastSuccessfulLogin(int userId);
        /// <summary>
        /// Get date of last successful login async.
        /// </summary> 
        /// <param name="userId">User id</param> 
        Task<HttpServiceResult<DateTime?>> DateOfLastSuccessfulLoginAsync(int userId);
        /// <summary>
        /// Get date of last password change.
        /// </summary> 
        /// <param name="userId">User id</param>  
        DateTime DateOfLastPasswordChange(int userId);
        /// <summary>
        /// Get date of last password change async.
        /// </summary> 
        /// <param name="userId">User id</param>  
        Task<HttpServiceResult<DateTime?>> DateOfLastPasswordChangeAsync(int userId);
        #endregion
    }
}
