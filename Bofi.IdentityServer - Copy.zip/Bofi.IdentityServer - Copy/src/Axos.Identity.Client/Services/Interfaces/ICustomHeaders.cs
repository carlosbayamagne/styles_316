﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Contracts
{
    public interface ICustomHeaders
    {
        IDictionary<string, string> GetCustomHeaders();
        void AppendCustomHeader(string key, string value);
    }
}
