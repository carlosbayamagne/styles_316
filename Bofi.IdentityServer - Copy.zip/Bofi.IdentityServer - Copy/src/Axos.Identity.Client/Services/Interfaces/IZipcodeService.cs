﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IZipcodeService
    {
        /// <summary>
        /// Will receive a zipcode and call IdentityServer to return information for the zipcode if found in the database
        /// </summary>
        /// <param name="zipcode">A valid US zipcode, no need to add leading zeroes</param>
        /// <returns>ZipcodeInformation object</returns>
        ZipcodeInformation GetZipcodeInformation(string zipcode);

        /// <summary>
        /// Will receive a zipcode and call IdentityServer to return information for the zipcode if found in the database
        /// </summary>
        /// <param name="zipcode">A valid US zipcode, no need to add leading zeroes</param>
        /// <returns>ZipcodeInformation object</returns>
        Task<HttpServiceResult<ZipcodeInformation>> GetZipcodeInformationAsync(string zipcode);

        /// <summary>
        /// Will receive a zipcode and call IdentityServer to return information for the zipcode if found in the USPS API
        /// </summary>
        /// <param name="zipcode">A valid US zipcode, no need to add leading zeroes</param>
        /// <returns>CityStateResponse object</returns>
        CityStateResponse GetZipcodeUSPSInformation(string zipcode);

        /// <summary>
        /// Will receive a zipcode and call IdentityServer to return information for the zipcode if found in the USPS API
        /// </summary>
        /// <param name="zipcode">A valid US zipcode, no need to add leading zeroes</param>
        /// <returns>CityStateResponse object</returns>
        Task<HttpServiceResult<CityStateResponse>> GetZipcodeUSPSInformationAsync(string zipcode);
    }
}
