﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    /// <summary>
    ///
    /// </summary>
    public interface IOrganizationSettingsService
    {
        /// <summary>
        /// Add a Organization.
        /// </summary>
        /// <param name="organization">The organization.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Organization Add(Organization organization);

        /// <summary>
        /// Add an Organization.
        /// </summary>
        /// <param name="organization">The organization.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Organization>> AddAsync (Organization organization);

        /// <summary>
        /// Update an Organization.
        /// </summary>
        /// <param name="organization">The organization.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Organization Update(Organization organization);

        /// <summary>
        /// Update an Organization.
        /// </summary>
        /// <param name="organization">The organization.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Organization>> UpdateAsync(Organization organization);

        /// <summary>
        /// Delete an Organization.
        /// </summary>
        /// <param name="organizationId">The organization id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool Delete(int organizationId);

        /// <summary>
        /// Delete an Organization.
        /// </summary>
        /// <param name="organizationId">The organization id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteAsync(int organizationId);

        /// <summary>
        /// Get an Organization by Name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>

        Organization Get(string organizationName, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization by Name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Organization>> GetAsync(string organizationName, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization by Id.
        /// </summary>
        /// <param name="organizationId">The organization id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Organization GetById(int organizationId, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization by Id.
        /// </summary>
        /// <param name="organizationId">The organization id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Organization>> GetByIdAsync(int organizationId, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization Id by Name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        int GetIdByName(string organizationName);

        /// <summary>
        /// Get an Organization Id by Name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<int>> GetIdByNameAsync(string organizationName);

        /// <summary>
        /// Get Organization Settings by organization name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        IEnumerable<OrganizationSetting> GetSettings(string organizationName, bool GetDrafts = false);
        /// <summary>
        /// Get Organization Settings by organization name.
        /// </summary>
        /// <param name="organizationName">The organization name.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<IEnumerable<OrganizationSetting>>> GetSettingsAsync(string organizationName, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization by user Id.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Organization GetByUserId(int userId, bool settings, bool GetDrafts = false);

        /// <summary>
        /// Get an Organization by user Id.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <param name="GetDrafts">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Organization>> GetByUserIdAsync(int userId, bool settings, bool GetDrafts = false);

        #region Settings
        /// <summary>
        /// Get organization Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The organization setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        OrganizationSetting GetSettingById(int settingId);

        /// <summary>
        /// Get organization Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The organization setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<OrganizationSetting>> GetSettingByIdAsync(int settingId);

        /// <summary>
        /// Add Settings to an Organization.
        /// </summary>
        /// <param name="setting">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult CreateOrganizationSetting(OrganizationSetting setting);

        /// <summary>
        /// Add Settings to an Organization.
        /// </summary>
        /// <param name="setting">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> CreateOrganizationSettingAsync(OrganizationSetting setting);

        /// <summary>
        /// Update Settings of an Organization.
        /// </summary>
        /// <param name="setting">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult UpdateOrganizationSetting(OrganizationSetting setting);

        /// <summary>
        /// Update Settings of an Organization.
        /// </summary>
        /// <param name="setting">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> UpdateOrganizationSettingAsync(OrganizationSetting setting);

        /// <summary>
        /// Delete Settings from an Organization.
        /// </summary>
        /// <param name="settingId">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool DeleteOrganizationSetting(int settingId);

        /// <summary>
        /// Delete Settings from an Organization.
        /// </summary>
        /// <param name="settingId">The organization setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteOrganizationSettingAsync(int settingId);

        #endregion

    }
}