﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface IAdminService
    {
        /// <summary>
        /// Authenticates the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        AuthenticationResponse Authenticate(AuthenticationRequest request);

        /// <summary>
        /// Authenticates the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<HttpServiceResult<AuthenticationResponse>> AuthenticateAsync(AuthenticationRequest request);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The admin user.</returns>
        AdminUserDto GetUser(int id);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <returns>The admin user.</returns>
        AdminUserDto GetUser(string username);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The admin user.</returns>
        Task<HttpServiceResult<AdminUserDto>> GetUserAsync(int id);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <returns>The admin user.</returns>
        Task<HttpServiceResult<AdminUserDto>> GetUserAsync(string username);

        /// <summary>
        /// Gets users and optionally updates their data with Active Directory current info.
        /// </summary>
        /// <param name="pageNum">0 based</param>
        /// <param name="pageSize"></param>
        /// <param name="refreshUsers">if set, updates their data with Active Directory current info</param>
        /// <param name="excludeClosed">if set, excludes status Closed and Active Directory's Disabled users</param>
        /// <param name="ids">Specific users to retrieve</param>
        /// <returns></returns>
        IEnumerable<AdminUserDto> GetUsers(
            int pageNum = 0, int pageSize = 0, bool refreshUsers = false, bool excludeClosed = false, params int[] ids);

        /// <summary>
        /// Gets users and optionally updates their data with Active Directory current info.
        /// </summary>
        /// <param name="pageNum">0 based</param>
        /// <param name="pageSize"></param>
        /// <param name="refreshUsers">if set, updates their data with Active Directory current info</param>
        /// <param name="excludeClosed">if set, excludes status Closed and Active Directory's Disabled users</param>
        /// <param name="ids">Specific users to retrieve</param>
        /// <returns></returns>
        Task<HttpServiceResult<IList<AdminUserDto>>> GetUsersAsync(
            int pageNum = 0, int pageSize = 0, bool refreshUsers = false, bool excludeClosed = false, params int[] ids);

        /// <summary>
        /// Searches the users.
        /// </summary>
        /// <param name="searchText">The search text.</param>
        /// <returns>A list of the admin users that matches the search text.</returns>
        IEnumerable<AdminUserDto> SearchUsers(string searchText);

        /// <summary>
        /// Searches the users.
        /// </summary>
        /// <param name="searchText">The search text.</param>
        /// <returns>A list of the admin users that matches the search text.</returns>
        Task<HttpServiceResult<IList<AdminUserDto>>> SearchUsersAsync(string searchText);

        /// <summary>
        /// Updates the user statuses.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        string UpdateUserStatuses(int userId, UpdateAdminUserStatusRequest request);

        /// <summary>
        /// Updates the user statuses.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<HttpServiceResult<string>> UpdateUserStatusesAsync(int userId, UpdateAdminUserStatusRequest request);

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The newly created admin user.</returns>
        int CreateUser(CreateAdminUserRequest user);

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The newly created admin user.</returns>
        Task<HttpServiceResult<int>> CreateUserAsync(CreateAdminUserRequest user);
    }
}