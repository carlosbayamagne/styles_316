﻿using Axos.Identity.Client.Models.Biometrics;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IBiometricsService
    {
        /// <summary>
        /// Authenticates the user using DaonService
        /// </summary>        
        /// <returns>Boolean from calling DaonService</returns>
        bool VerifyIdentity(BiometricAuthenticationRequest deviceIdentity);

        /// <summary>
        /// Authenticates the user using DaonService
        /// </summary>        
        /// <returns>Boolean from calling DaonService</returns>
        Task<HttpServiceResult<bool>> VerifyIdentityAsync(BiometricAuthenticationRequest deviceIdentity);


        /// <summary>
        /// Verifies if the user set the given authentication factor
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Boolean that indicates if the user set the given authentication factor</returns>
        bool VerifyAuthenticationFactor(VerifyAuthenticationFactorRequest request);

        /// <summary>
        /// Verifies if the user set the given authentication factor
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Boolean that indicates if the user set the given authentication factor</returns>
        Task<HttpServiceResult<bool>> VerifyAuthenticationFactorAsync(VerifyAuthenticationFactorRequest request);

        /// <summary>
        /// Updates the biometric information of the given user
        /// </summary>
        /// <param name="updateUserDeviceDetailsRequest"></param>
        /// <returns>Boolean that indicates if the given biometrics were updated</returns>
        bool UpdateUserDeviceDetails(UpdateUserDeviceDetailsRequest updateUserDeviceDetailsRequest);

        /// <summary>
        /// Updates the biometric information of the given user
        /// </summary>
        /// <param name="updateUserDeviceDetailsRequest"></param>
        /// <returns>Boolean that indicates if the given biometrics were updated</returns>
        Task<HttpServiceResult<bool>> UpdateUserDeviceDetailsAsync(UpdateUserDeviceDetailsRequest updateUserDeviceDetailsRequest);

        /// <summary>
        /// Deletes the voices of the user given user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Boolean that indicates if the voice was deleted</returns>
        bool DeleteUserVoice(int userId);

        /// <summary>
        /// Deletes the voices of the user given user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Boolean that indicates if the voice was deleted</returns>
        Task<HttpServiceResult<bool>> DeleteUserVoiceAsync(int userId);

        /// <summary>
        /// List authentication factors of the given user
        /// </summary>
        /// <param name="listAuthenticationFactorRequest"></param>
        /// <returns>String list with the authentication factors of the given user</returns>
        List<string> ListAuthenticationFactor(ListAuthenticationFactorsRequest listAuthenticationFactorRequest);

        /// <summary>
        /// List authentication factors of the given user
        /// </summary>
        /// <param name="listAuthenticationFactorRequest"></param>
        /// <returns>String list with the authentication factors of the given user</returns>
        Task<HttpServiceResult<IList<string>>> ListAuthenticationFactorAsync(ListAuthenticationFactorsRequest listAuthenticationFactorRequest);

        /// <summary>
        /// Gets user voice details of all users with the specified phone
        /// </summary>
        /// <param name="phoneNumber">User's phone</param>
        /// <returns>Voice registration details of users with the specified phone</returns>
        Task<IEnumerable<UserVoiceDetails>> GetVoiceDetailsByPhoneAsync(string phoneNumber);

        /// <summary>
        /// Gets user voice details of all users with the specified ssn
        /// </summary>
        /// <param name="ssn">User's ssn</param>
        /// <returns>Voice registration details of users with the specified ssn</returns>
        Task<IEnumerable<UserVoiceDetails>> GetVoiceDetailsBySSNAsync(string ssn);
    }
}
