﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ISecondaryRegistryService
    {
        string GetContactId(int id);
        Task<HttpServiceResult<string>> GetContactIdAsync(int id);

        string GetContactIdByCif(string cif);
        Task<HttpServiceResult<string>> GetContactIdByCifAsync(string cif);

        string GetContactIdByRequest(ContactIdRequest request);
        Task<HttpServiceResult<string>> GetContactIdByRequestAsync(ContactIdRequest request);

        /// <summary>
        /// Updates contact info last confirmation dates of a user
        /// </summary>
        /// <param name="id">User id</param>
        /// <returns>True if successful</returns>
        Task<bool> ConfirmContactInfoAsync(int id);

        Task<SalesForceServiceResponse> ForceSync(int id);
    }
}
