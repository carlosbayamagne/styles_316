﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface IUnregisterService
    {
        /// <summary>
        /// Preload user list in UDB services.
        /// </summary>
        /// <param name="users">User list to preload</param>
        /// <returns>Unregister user list response with status result.</returns>
        IEnumerable<UnregisteredUser> PreloadUsers(UnregisterUserPack users);

        /// <summary>
        /// Preload user list in UDB services.
        /// </summary>
        /// <param name="users">User list to preload</param>
        /// <returns>Unregistered user list response with status result.</returns>
        Task<HttpServiceResult<IList<UnregisteredUser>>> PreloadUsersAsync(UnregisterUserPack users);

        /// <summary>
        /// Set preload user status.
        /// </summary>
        /// <param name="preloadUser">Preload to update</param>
        void SetPreloadStatus(User preloadUser);

        /// <summary>
        /// Set preload user status.
        /// </summary>
        /// <param name="preloadUser">Preload to update</param>
        Task<HttpServiceResult> SetPreloadStatusAsync(User preloadUser);

        /// <summary>
        /// Find or create by cif a user that exists in JH
        /// </summary>
        /// <param name="cif"></param>
        /// <returns>User found or created</returns>
        User FindOrCreateFromJHAByCIF(string cif, bool waitForSync = false);

        /// <summary>
        /// Find or create by cif a user that exists in JH
        /// </summary>
        /// <param name="cif"></param>
        /// <returns>User found or created</returns>
        Task<HttpServiceResult<User>> FindOrCreateFromJhaByCifAsync(string cif, bool waitForSync = false);

        /// <summary>
        /// Find or create by phone a user that exists in JH
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="waitForSync"></param>
        /// <returns></returns>
        IEnumerable<User> FindOrCreateFromJHAByPhone(string phoneNumber, bool waitForSync = false);

        /// <summary>
        /// Find or create by phone a user that exists in JH
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="waitForSync"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IList<User>>> FindOrCreateFromJhaByPhoneAsync(string phoneNumber, bool waitForSync = false);
    }
}
