﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ICustomPropertiesService
    {
        /// <summary>
        /// Adds a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        CustomPropertyResponse AddCustomProperty(CustomPropertyRequest request);

        /// <summary>
        /// Adds a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CustomPropertyResponse>> AddCustomPropertyAsync(CustomPropertyRequest request);

        /// <summary>
        /// Updates a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        CustomPropertyResponse UpdateCustomProperty(CustomPropertyRequest request);

        /// <summary>
        /// Updates a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CustomPropertyResponse>> UpdateCustomPropertyAsync(CustomPropertyRequest request);

        /// <summary>
        /// Deletes a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        CustomPropertyResponse DeleteCustomProperty(CustomPropertyRequest request);

        /// <summary>
        /// Deletes a custom property
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CustomPropertyResponse>> DeleteCustomPropertyAsync(CustomPropertyRequest request);

        /*
        //Get by id
        /// <summary>
        /// Gets a property by it's Id
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="CustomPropertyID"></param>
        /// <returns></returns>
        CustomPropertyResponse GetCustomProperty(int UdbUserID,int CustomPropertyID);
        */

        /// <summary>
        /// Gets a property by it's key
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="EffectiveDate"></param>
        /// <returns></returns>
        CustomPropertyResponse GetCustomProperty(int UdbUserID, string PropertyName, DateTime EffectiveDate);

        /*
        //Get by id
        /// <summary>
        /// Gets a property by it's key
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="CustomPropertyID"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CustomPropertyResponse>> GetCustomPropertyAsync(int UdbUserID, int CustomPropertyID);
        */

        /// <summary>
        /// Gets a property by it's Id
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="EffectiveDate"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CustomPropertyResponse>> GetCustomPropertyAsync(int UdbUserID, string PropertyName, DateTime EffectiveDate);

        /// <summary>
        /// Gets all custom properties assigned to a user
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetAllCustomProperties(int UdbUserID);

        /// <summary>
        /// Gets all custom properties assigned to a user
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetAllCustomPropertiesAsync(int UdbUserID);

        /// <summary>
        /// Gets all custom properties assigned to a user that match the property name given
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetCustomPropertiesByName(int UdbUserID, string PropertyName);

        /// <summary>
        /// Gets all custom properties assigned to a user that match the property name given
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByNameAsync(int UdbUserID, string PropertyName);

        /// <summary>
        /// Gets all custom properties assigned to a user between a date range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetCustomPropertiesByRange(int UdbUserID, DateTime StartDate, DateTime EndDate);

        /// <summary>
        /// Gets all custom properties assigned to a user between a date range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByRangeAsync(int UdbUserID, DateTime StartDate, DateTime EndDate);


        /// <summary>
        /// Gets all custom properties which have the filter date in its effective range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="FilterDate"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetCustomPropertiesByDate(int UdbUserID, DateTime FilterDate);

        /// <summary>
        /// Gets all custom properties which have the filter date in its effective range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="FilterDate"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByDateAsync(int UdbUserID, DateTime FilterDate);

        /// <summary>
        /// Gets all custom properties which match the given property name and have the filter date in its effective range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="FilterDate"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetCustomPropertiesByDateAndName(int UdbUserID, string PropertyName, DateTime FilterDate);

        /// <summary>
        /// Gets all custom properties which match the given property name and have the filter date in its effective range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="FilterDate"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByDateAndNameAsync(int UdbUserID, string PropertyName, DateTime FilterDate);

        /// <summary>
        /// Gets all custom properties assigned to a user that match a name and are between a date range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        IEnumerable<CustomPropertyResponse> GetCustomPropertiesByRangeAndName(int UdbUserID, string PropertyName, DateTime StartDate, DateTime EndDate);

        /// <summary>
        /// Gets all custom properties assigned to a user that match a name and are between a date range
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <param name="PropertyName"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByRangeAndNameAsync(int UdbUserID, string PropertyName, DateTime StartDate, DateTime EndDate);

        /// <summary>
        /// Get properties by propertyname w/ optional propertyvalue
        /// </summary>
        /// <param name="propertyname"></param>
        /// <param name="propertyvalue"></param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomProperties(string PropertyName, string PropertyValue = null);
    }
}
