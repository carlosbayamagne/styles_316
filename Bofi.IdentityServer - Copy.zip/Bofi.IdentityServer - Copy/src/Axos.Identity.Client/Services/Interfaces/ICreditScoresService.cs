﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.CreditScores;
using Axos.Integration.Core.DTOs;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ICreditScoresService
    {
        /// <summary>
        /// Gets the most recent credit score
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        ScoreDetailsResponse GetCurrentCreditScore(int UdbUserID);

        /// <summary>
        /// Gets the most recent credit score
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<ScoreDetailsResponse>> GetCurrentCreditScoreAsync(int UdbUserID);

        /// <summary>
        /// Gets all the saved credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        IEnumerable<ScoreDetailsResponse> GetAllCreditScores(int UdbUserID);

        /// <summary>
        /// Gets all the saved credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<ScoreDetailsResponse>>> GetAllCreditScoresAsync(int UdbUserID);

        /// <summary>
        /// Gets all the saved credit scores between a date range
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="StartDate">Start of the date range</param>
        /// <param name="EndDate">End of the date range</param>
        /// <returns></returns>
        IEnumerable<ScoreDetailsResponse> GetCreditScoresByDateRange(int UdbUserID, DateTime StartDate, DateTime EndDate);

        /// <summary>
        /// Gets all the saved credit scores between a date range
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="StartDate">Start of the date range</param>
        /// <param name="EndDate">End of the date range</param>
        /// <returns></returns>
        Task<HttpServiceResult<IEnumerable<ScoreDetailsResponse>>> GetCreditScoresByDateRangeAsync(int UdbUserID, DateTime StartDate, DateTime EndDate);

        /// <summary>
        /// Enroll a user for credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="request">User data for unregistered users</param>
        /// <returns></returns>
        ThinLoadResponse CreditScoreEnrollment(int UdbUserID, UserDataRequest request = null);

        /// <summary>
        /// Enroll a user for credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="request">User data for unregistered users</param>
        /// <returns></returns>
        Task<HttpServiceResult<ThinLoadResponse>> CreditScoreEnrollmentAsync(int UdbUserID, UserDataRequest request = null);

        /// <summary>
        /// Request a user verification questions
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        GetIDVerificationResponse RequestVerification(int UdbUserID);

        /// <summary>
        /// Request a user verification questions
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<GetIDVerificationResponse>> RequestVerificationAsync(int UdbUserID);

        /// <summary>
        /// Submit a user verification questions
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="request">Verification questions data</param>
        /// <returns></returns>
        SubmitIDVerificationDataResponse SubmitVerfication(int UdbUserID, VerificationDataRequest request);

        /// <summary>
        /// Submit a user verification questions
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <param name="request">Verification questions data</param>
        /// <returns></returns>
        Task<HttpServiceResult<SubmitIDVerificationDataResponse>> SubmitVerficationAsync(int UdbUserID, VerificationDataRequest request);

        /// <summary>
        /// Unenrolls a user from credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        UnenrollmentResponse CreditScoreUnEnrollment(int UdbUserID);

        /// <summary>
        /// Unenrolls a user from credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<UnenrollmentResponse>> CreditScoreUnEnrollmentAsync(int UdbUserID);

        /// <summary>
        /// Checks if a user is enrolled for credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        UserCheckResponse CreditScoreEnrollmentCheck(int UdbUserID);

        /// <summary>
        /// Checks if a user is enrolled for credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<UserCheckResponse>> CreditScoreEnrollmentCheckAsync(int UdbUserID);

        /// <summary>
        /// Gets the previous and current credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        ScoreNodesResponse CreditScoreNodes(int UdbUserID);

        /// <summary>
        /// Gets the previous and current credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<ScoreNodesResponse>> CreditScoreNodesAsync(int UdbUserID);

        /// <summary>
        /// Gets the previous and current credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        CreditScoreNotificationPreferences SetUserNotificationPreferences(int UdbUserID, CreditScoreNotificationPreferences preferences);

        /// <summary>
        /// Gets the previous and current credit scores
        /// </summary>
        /// <param name="UdbUserID">User Id</param>
        /// <returns></returns>
        Task<HttpServiceResult<CreditScoreNotificationPreferences>> SetUserNotificationPreferencesAsync(int UdbUserID, CreditScoreNotificationPreferences preferences);

        /// <summary>
        /// Gets the credit score profile tradelines for a user if available
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        CreditProfileTradelinesResponse GetCreditProfileTradelines(int UdbUserID);

        /// <summary>
        /// Gets the credit score profile tradelines for a user if available
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CreditProfileTradelinesResponse>> GetCreditProfileTradelinesAsync(int UdbUserID);

        /// <summary>
        /// Gets the credit score profile for a user if available
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        Task<HttpServiceResult<CreditProfileContainer>> GetCreditProfileAsync(int UdbUserID);

        /// <summary>
        /// Gets the credit score profile for a user if available
        /// </summary>
        /// <param name="UdbUserID"></param>
        /// <returns></returns>
        CreditProfileContainer GetCreditProfile(int UdbUserID);        
    }
}
