﻿using Axos.Identity.Client.DTOs.FraudLinks;
using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.FraudLinks;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IFraudLinksService
    {
        Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto> Match(Applicant request);

        Task<HttpServiceResult<Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto>>> MatchAsync(Applicant request);
    }
}
