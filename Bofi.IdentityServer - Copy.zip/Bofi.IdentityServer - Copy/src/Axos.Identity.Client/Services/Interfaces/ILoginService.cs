﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface ILoginService : ICustomHeaders
    {
        [Obsolete("Deprecated in favor of the one with the AuthenticateRequest")]
        AuthenticationResponse Authenticate(AuthenticationRequest request);

        AuthenticateResponse Authenticate(AuthenticateRequest request);
        Task<HttpServiceResult<AuthenticateResponse>> AuthenticateAsync(AuthenticateRequest request);
        AuthenticateResponse AuthenticateAggregators(AuthenticateRequest request);
        Task<HttpServiceResult<AuthenticateResponse>> AuthenticateAggregatorsAsync(AuthenticateRequest request);

        InternalServiceAuthenticationResponse AuthenticateServiceAccount(InternalServiceAuthenticationRequest request);
        Task<HttpServiceResult<InternalServiceAuthenticationResponse>> AuthenticateServiceAccountAsync(InternalServiceAuthenticationRequest request);

        void LogOut(LogOutRequest request);
        Task<HttpServiceResult> LogOutAsync(LogOutRequest request);
    }    
}
