﻿using Axos.Identity.Client.Models.Qualifile;
using Axos.Identity.Client.Models.Qualifile.Business;
using Axos.Identity.Client.Models.Qualifile.Consumers;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface IQualifileService
    {
        Axos.Identity.Client.Models.Qualifile.ServiceResult<ConsumerResponse> RequestPersonQuery(ConsumerQueryModel request);

        Task<HttpServiceResult<Axos.Identity.Client.Models.Qualifile.ServiceResult<ConsumerResponse>>> RequestPersonQueryAsync(ConsumerQueryModel request);

        Axos.Identity.Client.Models.Qualifile.ServiceResult<BusinessResponse> RequestBusinessQuery(BusinessQueryModel request);

        Task<HttpServiceResult<Axos.Identity.Client.Models.Qualifile.ServiceResult<BusinessResponse>>> RequestBusinessQueryAsync(BusinessQueryModel request);

        ConsumerResponse DeserializeResponse(string request);

        Task<HttpServiceResult<ConsumerResponse>> DeserializeResponseAsync(string request);
    }
}
