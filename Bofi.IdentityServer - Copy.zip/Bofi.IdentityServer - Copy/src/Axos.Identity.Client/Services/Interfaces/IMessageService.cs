﻿using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Contracts
{
    public interface IMessageService
    {
        /// <summary>
        /// Send Forgot Password Email
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="unlockURL"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendForgotPasswordEmail(string userName, string unlockURL, string brand = null);

        /// <summary>
        /// Send Forgot Password Email
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="unlockURL"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendForgotPasswordEmailAsync(string userName, string unlockURL, string brand = null);

        /// <summary>
        /// Send Unlock Account Email
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="unlockURL"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendUnlockAccountEmail(string userName, string unlockURL, string brand = null);

        /// <summary>
        /// Send Unlock Account Email
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="unlockURL"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendUnlockAccountEmailAsync(string userName, string unlockURL, string brand = null);

        /// <summary>
        /// Send Otp
        /// </summary>
        /// <param name="username"></param>
        /// <param name="deliveryMethod"></param>
        /// <param name="otp"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendOtp(string username, DeliveryMethod deliveryMethod, string otp, string brand = null);

        /// <summary>
        /// Send Otp
        /// </summary>
        /// <param name="username"></param>
        /// <param name="deliveryMethod"></param>
        /// <param name="otp"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendOtpAsync(string username, DeliveryMethod deliveryMethod, string otp, string brand = null);

        /// <summary>
        /// Send Change Security Questions Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendChangeSecurityQuestionsEmail(string username, string brand = null);

        /// <summary>
        /// Send Change Security Questions Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendChangeSecurityQuestionsEmailAsync(string username, string brand = null);

        /// <summary>
        /// Send Change Password Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendChangePasswordEmail(string username, string brand = null);

        /// <summary>
        /// Send Change Password Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendChangePasswordEmailAsync(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendChangeProfileEmail(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendChangeProfileEmailAsync(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Phone
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendChangeProfilePhone(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Phone
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendChangeProfilePhoneAsync(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Address
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns></returns>
        bool SendChangeProfileAddress(string username, string brand = null);

        /// <summary>
        /// Send Change Profile Address
        /// </summary>
        /// <param name="username"></param>
        /// <param name="brand"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendChangeProfileAddressAsync(string username, string brand = null);

        /// <summary>
        /// Send Mortgage Link Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="applicationName"></param>
        /// <param name="brand"></param>
        void SendMortgageLinkEmail(string username, string applicationName, string brand);

        /// <summary>
        /// Send Mortgage Link Email
        /// </summary>
        /// <param name="username"></param>
        /// <param name="applicationName"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> SendMortgageLinkEmailAsync(string username, string applicationName, string brand);

    }
}
