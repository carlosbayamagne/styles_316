﻿using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    /// <summary>
    ///
    /// </summary>
    public interface IBrandSettingsService
    {
        /// <summary>
        /// Add a Brand.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Brand Add(Brand brand);

        /// <summary>
        /// Add an Brand.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Brand>> AddAsync (Brand brand);

        /// <summary>
        /// Update an Brand.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Brand Update(Brand brand);

        /// <summary>
        /// Update an Brand.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Brand>> UpdateAsync(Brand brand);

        /// <summary>
        /// Delete an Brand.
        /// </summary>
        /// <param name="brandId">The brand id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool Delete(int brandId);

        /// <summary>
        /// Delete an Brand.
        /// </summary>
        /// <param name="brandId">The brand id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteAsync(int brandId);

        /// <summary>
        /// Get an Brand by Name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>

        Brand Get(string brandName, bool settings);

        /// <summary>
        /// Get an Brand by Name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Brand>> GetAsync(string brandName, bool settings);

        /// <summary>
        /// Get an Brand by Id.
        /// </summary>
        /// <param name="brandId">The brand id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Brand GetById(int brandId, bool settings);

        /// <summary>
        /// Get an Brand by Id.
        /// </summary>
        /// <param name="brandId">The brand id.</param>
        /// <param name="settings">Bool value to get or not settings.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<Brand>> GetByIdAsync(int brandId, bool settings);

        /// <summary>
        /// Get an Brand Id by Name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        int GetIdByName(string brandName);

        /// <summary>
        /// Get an Brand Id by Name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<int>> GetIdByNameAsync(string brandName);

        /// <summary>
        /// Get Brand Settings by brand name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        IEnumerable<BrandSetting> GetSettings(string brandName);
        /// <summary>
        /// Get Brand Settings by brand name.
        /// </summary>
        /// <param name="brandName">The brand name.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<IEnumerable<BrandSetting>>> GetSettingsAsync(string brandName);

        #region Settings
        /// <summary>
        /// Get brand Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The brand setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        BrandSetting GetSettingById(int settingId);

        /// <summary>
        /// Get brand Settings by settings Id.
        /// </summary>
        /// <param name="settingId">The brand setting id.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult<BrandSetting>> GetSettingByIdAsync(int settingId);

        /// <summary>
        /// Add Settings to an Brand.
        /// </summary>
        /// <param name="setting">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult CreateBrandSetting(BrandSetting setting);

        /// <summary>
        /// Add Settings to an Brand.
        /// </summary>
        /// <param name="setting">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> CreateBrandSettingAsync(BrandSetting setting);

        /// <summary>
        /// Update Settings of an Brand.
        /// </summary>
        /// <param name="setting">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        HttpServiceResult UpdateBrandSetting(BrandSetting setting);

        /// <summary>
        /// Update Settings of an Brand.
        /// </summary>
        /// <param name="setting">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> UpdateBrandSettingAsync(BrandSetting setting);

        /// <summary>
        /// Delete Settings from an Brand.
        /// </summary>
        /// <param name="settingId">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        bool DeleteBrandSetting(int settingId);

        /// <summary>
        /// Delete Settings from an Brand.
        /// </summary>
        /// <param name="settingId">The brand setting.</param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        Task<HttpServiceResult> DeleteBrandSettingAsync(int settingId);

        #endregion

    }
}