﻿using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.CreditReports;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services.Interfaces
{
    public interface ICreditReportsService
    {
        Axos.Identity.Client.Models.CreditReports.ServiceResult<CreditReportResponse> RequestReport(PersonalInformation request);

        Task<HttpServiceResult<Axos.Identity.Client.Models.CreditReports.ServiceResult<CreditReportResponse>>> RequestReportAsync(PersonalInformation request);
    }
}
