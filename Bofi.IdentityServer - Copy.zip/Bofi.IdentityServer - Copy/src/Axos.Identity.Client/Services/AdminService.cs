﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class AdminService : ServiceClientHttpServiceBase, IAdminService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseAdminUrl = "api/admins";

        public AdminService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public AuthenticationResponse Authenticate(AuthenticationRequest request)
            => Post<AuthenticationResponse, AuthenticationRequest>($"{BaseAdminUrl}/authenticate", request);

        public Task<HttpServiceResult<AuthenticationResponse>> AuthenticateAsync(AuthenticationRequest request)
            => PostRequestAsync<AuthenticationRequest, AuthenticationResponse>($"{BaseAdminUrl}/authenticate", request);

        public AdminUserDto GetUser(int id)
            => Get<AdminUserDto>($"{BaseAdminUrl}/users/{id}");

        public AdminUserDto GetUser(string username)
            => Get<AdminUserDto>($"{BaseAdminUrl}/users/userName/{username}");

        public Task<HttpServiceResult<AdminUserDto>> GetUserAsync(int id)
            => GetRequestAsync<AdminUserDto>($"{BaseAdminUrl}/users/{id}");

        public Task<HttpServiceResult<AdminUserDto>> GetUserAsync(string username)
            => GetRequestAsync<AdminUserDto>($"{BaseAdminUrl}/users/userName/{username}");

        public IEnumerable<AdminUserDto> GetUsers(
            int pageNum = 0, int pageSize = 0, bool refreshUsers = false, bool excludeClosed = false, params int[] ids)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < ids.Length; i++)
            {
                sb.Append($"&ids[{i}]={ids[i]}");
            }

            return Get<IEnumerable<AdminUserDto>>($"{BaseAdminUrl}/users?pageNum={pageNum}&pageSize={pageSize}&refreshUsers={refreshUsers}&excludeClosed={excludeClosed}{sb}");
        }

        public Task<HttpServiceResult<IList<AdminUserDto>>> GetUsersAsync(
            int pageNum = 0, int pageSize = 0, bool refreshUsers = false, bool excludeClosed = false, params int[] ids)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < ids.Length; i++)
            {
                sb.Append($"&ids[{i}]={ids[i]}");
            }

            return GetRequestAsync<IList<AdminUserDto>>($"{BaseAdminUrl}/users?pageNum={pageNum}&pageSize={pageSize}&refreshUsers={refreshUsers}&excludeClosed={excludeClosed}{sb}");
        }

        public IEnumerable<AdminUserDto> SearchUsers(string searchText)
            => Get<IEnumerable<AdminUserDto>>($"{BaseAdminUrl}/users/search/{searchText}");

        public Task<HttpServiceResult<IList<AdminUserDto>>> SearchUsersAsync(string searchText)
            => GetRequestAsync<IList<AdminUserDto>>($"{BaseAdminUrl}/users/search/{searchText}");

        public string UpdateUserStatuses(int userId, UpdateAdminUserStatusRequest request)
            => Put<string, UpdateAdminUserStatusRequest>($"{BaseAdminUrl}/users/{userId}/status", request);

        public Task<HttpServiceResult<string>> UpdateUserStatusesAsync(int userId, UpdateAdminUserStatusRequest request)
            => PutRequestAsync<UpdateAdminUserStatusRequest, string>($"{BaseAdminUrl}/users/{userId}/status", request);

        public int CreateUser(CreateAdminUserRequest user)
            => Convert.ToInt32(Post<object, CreateAdminUserRequest>($"{BaseAdminUrl}/users", user));

        public Task<HttpServiceResult<int>> CreateUserAsync(CreateAdminUserRequest user)
            => PostRequestAsync<CreateAdminUserRequest, int>($"{BaseAdminUrl}/users", user);
    }
}