﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Net;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class LoginService : CustomHeadersServiceClient, ILoginService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/identity";

        public LoginService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        [Obsolete("Deprecated in favor of the one with the AuthenticateRequest")]
        /// <inheritdoc/>
        public AuthenticationResponse Authenticate(AuthenticationRequest request)
        {
            return Post<AuthenticationResponse, AuthenticationRequest>($"{BaseIdentityUrl}/authenticate", request);
        }

        /// <inheritdoc/>
        public AuthenticateResponse Authenticate(AuthenticateRequest request)
        {
            return Post<AuthenticateResponse, AuthenticateRequest>($"{BaseIdentityUrl}/authenticate/v2", request, GetCustomHeaders());
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<AuthenticateResponse>> AuthenticateAsync(AuthenticateRequest request)
            => PostRequestAsync<AuthenticateRequest, AuthenticateResponse>($"{BaseIdentityUrl}/authenticate/v2", request, GetCustomHeaders());

        /// <inheritdoc/>
        public AuthenticateResponse AuthenticateAggregators(AuthenticateRequest request)
        {
            return Post<AuthenticateResponse, AuthenticateRequest>($"{BaseIdentityUrl}/authenticate/aggregators", request, GetCustomHeaders());
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<AuthenticateResponse>> AuthenticateAggregatorsAsync(AuthenticateRequest request)
        {
            return PostRequestAsync<AuthenticateRequest, AuthenticateResponse>($"{BaseIdentityUrl}/authenticate/agregators", request, GetCustomHeaders());
        }

        /// <inheritdoc/>
        public InternalServiceAuthenticationResponse AuthenticateServiceAccount(InternalServiceAuthenticationRequest request)
        {
            return Post<InternalServiceAuthenticationResponse, InternalServiceAuthenticationRequest>($"{BaseIdentityUrl}/authenticate/serviceaccount", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<InternalServiceAuthenticationResponse>> AuthenticateServiceAccountAsync(InternalServiceAuthenticationRequest request)
            => PostRequestAsync<InternalServiceAuthenticationRequest, InternalServiceAuthenticationResponse>($"{BaseIdentityUrl}/authenticate/serviceaccount", request);

        /// <inheritdoc/>
        public void LogOut(LogOutRequest request)
        {
            try
            {
                Post($"{BaseIdentityUrl}/logout", request);
            }
            catch (Exception)
            {
                // The user flow should not be affected.
            }
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> LogOutAsync(LogOutRequest request)
        {
            try
            {
                return PostRequestAsync($"{BaseIdentityUrl}/logout", request);
            }
            catch
            {
                // The user flow should not be affected.
                return Task.FromResult(new HttpServiceResult(HttpStatusCode.OK));
            }
        }
    }
}

