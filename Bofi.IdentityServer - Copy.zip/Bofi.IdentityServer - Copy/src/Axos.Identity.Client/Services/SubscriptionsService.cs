﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models.Subscriptions;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class SubscriptionsService : ServiceClientHttpServiceBase, ISubscriptionsService 
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/subscriptions";

        public SubscriptionsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public IEnumerable<Entitlement> GetEntitlements()
        {
            return Get<IEnumerable<Entitlement>>($"{BaseIdentityUrl}/entitlement");
        }        

        public Task<IEnumerable<Entitlement>> GetEntitlementsAsync()
        {
            return GetAsync<IEnumerable<Entitlement>>($"{BaseIdentityUrl}/entitlement");
        }

        public Entitlement GetEntitlementById(Guid entitlementId)
        {
            return Get<Entitlement>($"{BaseIdentityUrl}/entitlement/{entitlementId}");
        }

        public Task<Entitlement> GetEntitlementByIdAsync(Guid entitlementId)
        {
            return GetAsync<Entitlement>($"{BaseIdentityUrl}/entitlement/{entitlementId}");
        }

        public Entitlement CreateEntitlement(CreateEntitlement request)
        {
            return Post<Entitlement, CreateEntitlement>($"{BaseIdentityUrl}/entitlement", request);
        }

        public Task<HttpServiceResult> CreateEntitlementAsync(CreateEntitlement request)
        {
            return PostRequestAsync($"{BaseIdentityUrl}/entitlement", request);
        }

        public bool DeleteEntitlement(Guid entitlementId)
        {
            return Delete($"{BaseIdentityUrl}/entitlement/{entitlementId}", new Dictionary<string, string>());
        }

        public Task<HttpServiceResult> DeleteEntitlementAsync(Guid entitlementId)
        {
            return DeleteRequestAsync($"{BaseIdentityUrl}/entitlement/{entitlementId}", new Dictionary<string, string>());
        }

        public HttpServiceResult UpdateEntitlement(EntitlementModel request)
        {
            return Put<HttpServiceResult, EntitlementModel>($"{BaseIdentityUrl}/entitlement", request);
            
        }

        public Task<HttpServiceResult> UpdateEntitlementAsync(EntitlementModel request)
        {
            return PutRequestAsync($"{BaseIdentityUrl}/entitlement", request);
        }

        public SubscriptionsServiceResult CreateBundle(CreateBundleModel request)
        {
            return Post<SubscriptionsServiceResult, CreateBundleModel>($"{BaseIdentityUrl}/bundle", request);
        }

        public Task<HttpServiceResult> CreateBundleAsync(CreateBundleModel request)
        {
            return PostRequestAsync($"{BaseIdentityUrl}/bundle", request);
        }

        public bool DeleteBundle(Guid bundleId)
        {
            return Delete($"{BaseIdentityUrl}/bundle/{bundleId}", new Dictionary<string, string>());
        }

        public Task<HttpServiceResult> DeleteBundleAsync(Guid bundleId)
        {
            return DeleteRequestAsync($"{BaseIdentityUrl}/bundle/{bundleId}", new Dictionary<string, string>());
        }

        public List<Bundle> GetBundles()
        {
            return Get<List<Bundle>>($"{BaseIdentityUrl}/bundle");
        }

        public Task<List<Bundle>> GetBundlesAsync()
        {
            return GetAsync<List<Bundle>>($"{BaseIdentityUrl}/bundle");
        }

        public Bundle GetBundleById(Guid bundleId)
        {
            return Get<Bundle>($"{BaseIdentityUrl}/bundle/{bundleId}");
        }

        public Task<Bundle> GetBundleByIdAsync(Guid bundleId)
        {
            return GetAsync<Bundle>($"{BaseIdentityUrl}/bundle/{bundleId}");
        }

        public HttpServiceResult UpdateBundle(BundleModel request)
        {
            return Put<HttpServiceResult, BundleModel>($"{BaseIdentityUrl}/bundle", request);
        }

        public Task<HttpServiceResult> UpdateBundleAsync(BundleModel request)
        {
            return PutRequestAsync($"{BaseIdentityUrl}/bundle", request);
        }

        public SubscriptionsServiceResult AddEntitlementToUser(AddEntitlementToUser userEntitlement)
        {
            return Post<SubscriptionsServiceResult, AddEntitlementToUser>($"{BaseIdentityUrl}/userentitlement", userEntitlement);
        }

        public Task<HttpServiceResult> AddEntitlementToUserAsync(AddEntitlementToUser userEntitlement)
        {
            return PostRequestAsync($"{BaseIdentityUrl}/userentitlement", userEntitlement);
        }

        public SubscriptionsServiceResult RemoveUserEntitlements(UserEntitlements request)
        {
            return Post<SubscriptionsServiceResult, UserEntitlements>($"{BaseIdentityUrl}/removeuserentitlements", request);
        }

        public Task<HttpServiceResult> RemoveUserEntitlementsAsync(UserEntitlements request)
        {
            return PostRequestAsync($"{BaseIdentityUrl}/removeuserentitlements", request);
        }

        public List<UserEntitlement> GetUserEntitlements(int userId)
        {
            return Get<List<UserEntitlement>>($"{BaseIdentityUrl}/userentitlement/{userId}");
        }

        public Task<List<UserEntitlement>> GetUserEntitlementsAsync(int userId)
        {
            return GetAsync<List<UserEntitlement>>($"{BaseIdentityUrl}/userentitlement/{userId}");
        }

    }
}
