﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class CustomPropertiesService : ServiceClientHttpServiceBase, ICustomPropertiesService
    {

        private const string BaseIdentityUrl = "api/identity";
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        static string _token = null;

        public CustomPropertiesService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public CustomPropertyResponse AddCustomProperty(CustomPropertyRequest request)
        {
            return Post<CustomPropertyResponse, CustomPropertyRequest>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties", request);
        }

        public Task<HttpServiceResult<CustomPropertyResponse>> AddCustomPropertyAsync(CustomPropertyRequest request)
        {
            return PostRequestAsync<CustomPropertyRequest, CustomPropertyResponse>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties", request);
        }

        public CustomPropertyResponse UpdateCustomProperty(CustomPropertyRequest request)
        {
            return Put<CustomPropertyResponse, CustomPropertyRequest>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties", request);
        }

        public Task<HttpServiceResult<CustomPropertyResponse>> UpdateCustomPropertyAsync(CustomPropertyRequest request)
        {
            return PutRequestAsync<CustomPropertyRequest, CustomPropertyResponse>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties", request);
        }

        public CustomPropertyResponse DeleteCustomProperty(CustomPropertyRequest request)
        {
            return Delete<CustomPropertyResponse>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties?effectivedate={request.EffectiveDate.Year}-{request.EffectiveDate.Month}-{request.EffectiveDate.Day}&propertyname={request.PropertyName}");
        }

        public Task<HttpServiceResult<CustomPropertyResponse>> DeleteCustomPropertyAsync(CustomPropertyRequest request)
        {
            return DeleteRequestAsync<CustomPropertyResponse>($"{BaseIdentityUrl}/users/{request.UdbUserID}/customproperties?effectivedate={request.EffectiveDate.Year}-{request.EffectiveDate.Month}-{request.EffectiveDate.Day}&propertyname={request.PropertyName}");
        }

        public IEnumerable<CustomPropertyResponse> GetAllCustomProperties(int UdbUserID)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetAllCustomPropertiesAsync(int UdbUserID)
        {
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties");
        }

        public IEnumerable<CustomPropertyResponse> GetCustomPropertiesByName(int UdbUserID, string PropertyName)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByNameAsync(int UdbUserID, string PropertyName)
        {
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}");
        }

        public IEnumerable<CustomPropertyResponse> GetCustomPropertiesByRange(int UdbUserID, DateTime StartDate, DateTime EndDate)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?startdate={StartDate.Year}-{StartDate.Month}-{StartDate.Day}&enddate={EndDate.Year}-{EndDate.Month}-{EndDate.Day}");
        }
        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByRangeAsync(int UdbUserID, DateTime StartDate, DateTime EndDate)
        {
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?startdate={StartDate.Year}-{StartDate.Month}-{StartDate.Day}&enddate={EndDate.Year}-{EndDate.Month}-{EndDate.Day}");
        }

        public CustomPropertyResponse GetCustomProperty(int UdbUserID, string PropertyName, DateTime EffectiveDate)
        {
            return Get<CustomPropertyResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?effectivedate={EffectiveDate.Year}-{EffectiveDate.Month}-{EffectiveDate.Day}&propertyname={PropertyName}");
        }

        public Task<HttpServiceResult<CustomPropertyResponse>> GetCustomPropertyAsync(int UdbUserID, string PropertyName, DateTime EffectiveDate)
        {
            return GetRequestAsync<CustomPropertyResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?effectivedate={EffectiveDate.Year}-{EffectiveDate.Month}-{EffectiveDate.Day}&propertyname={PropertyName}");
        }

        public IEnumerable<CustomPropertyResponse> GetCustomPropertiesByDate(int UdbUserID, DateTime FilterDate)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?filterdate={FilterDate.Year}-{FilterDate.Month}-{FilterDate.Day}");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByDateAsync(int UdbUserID, DateTime FilterDate)
        {
            return GetRequestAsync< IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?filterdate={FilterDate.Year}-{FilterDate.Month}-{FilterDate.Day}");
        }

        public IEnumerable<CustomPropertyResponse> GetCustomPropertiesByDateAndName(int UdbUserID, string PropertyName, DateTime FilterDate)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}&filterdate={FilterDate.Year}-{FilterDate.Month}-{FilterDate.Day}");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByDateAndNameAsync(int UdbUserID, string PropertyName, DateTime FilterDate)
        {
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}&filterdate={FilterDate.Year}-{FilterDate.Month}-{FilterDate.Day}");
        }

        public IEnumerable<CustomPropertyResponse> GetCustomPropertiesByRangeAndName(int UdbUserID, string PropertyName, DateTime StartDate, DateTime EndDate)
        {
            return Get<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}&startdate={StartDate.Year}-{StartDate.Month}-{StartDate.Day}&enddate={EndDate.Year}-{EndDate.Month}-{EndDate.Day}");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomPropertiesByRangeAndNameAsync(int UdbUserID, string PropertyName, DateTime StartDate, DateTime EndDate)
        {
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/customproperties?propertyname={PropertyName}&startdate={StartDate.Year}-{StartDate.Month}-{StartDate.Day}&enddate={EndDate.Year}-{EndDate.Month}-{EndDate.Day}");
        }

        public Task<HttpServiceResult<IEnumerable<CustomPropertyResponse>>> GetCustomProperties( string PropertyName, string PropertyValue = null)
        {
            string queryString = $"?propertyname={PropertyName}";
            if(!string.IsNullOrEmpty(PropertyValue))
            {
                queryString += $"&propertyvalue={PropertyValue}";
            } 
            return GetRequestAsync<IEnumerable<CustomPropertyResponse>>($"{BaseIdentityUrl}/customproperties{queryString}");
        }

        protected override string GetLocalServiceUrl()
        {
            return LocalIdentityUrl;
        }

        protected override DateTime GetRefreshTime()
        {
            return _refreshTime;
        }

        protected override string GetServiceConfigName()
        {
            return "IdentityService";
        }

        protected override string GetToken()
        {
            return _token;
        }

        protected override void SetRefreshTime(DateTime time)
        {
            _refreshTime = time;
        }

        protected override void SetToken(string token)
        {
            _token = token;
        }
    }
}
