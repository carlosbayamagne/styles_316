﻿using Axos.Identity.Client.Services.Interfaces;
using Axos.Identity.Client.Utilities.Properties;
using IdentityModel.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class TokenService : ITokenService
    {
        private static IList<IdentityToken> _identityTokens;
        private readonly string _environment;
        private static string _identityUrl;

        [Obsolete("Use IdentityService GetTokenForUser and RefreshToken methods")]
        public TokenService(string environment = null)
        {
            if (_identityTokens == null)
                _identityTokens = new List<IdentityToken>();

            _environment = environment;
        }

        [Obsolete("Use IdentityService GetTokenForUser")]
        public async Task<TokenResponse> RequestUserTokenAsync(string clientId, string clientSecret, string identityScopes, string username, string password)
        {
            TokenResponse result = null;
            var tokenEndpoint = GetIdentityUrl() + "/connect/token";
            //using (var tokenClient = new TokenClient(tokenEndpoint, clientId, clientSecret))
            HttpClient httpClient = new HttpClient()
            {
                BaseAddress = new Uri(tokenEndpoint)
            };
            TokenClientOptions tokenClientOptions = new TokenClientOptions
            {
                ClientId = clientId,
                ClientSecret = clientSecret
            };
            TokenClient tokenClient = new TokenClient(httpClient, tokenClientOptions);
            {
                var extra = new Dictionary<string, string> { { "UserVerifiedByClient", "true" } };

                result = await tokenClient.RequestPasswordTokenAsync(username, password, identityScopes, extra);
                // result = await tokenClient.RequestResourceOwnerPasswordAsync(username, password, identityScopes, extra);
            }
            return result;
        }
        #region private methods

        private string GetIdentityUrl()
        {
            if (!string.IsNullOrEmpty(_identityUrl)) return _identityUrl;

            if (_environment == "Local")
            {
                _identityUrl = "http://localhost:5901";
            }
            else
            {
                var properties = IdentityServiceProperties.GetProperties(_environment);
                var apiProperty = properties.FirstOrDefault(x => x.PropertyName == "ApiURL");
                _identityUrl = apiProperty != null ? apiProperty.PropertyValue : string.Empty;
            }
            return _identityUrl;
        }

        #endregion

        #region internal class

        public class IdentityToken
        {
            public IdentityToken()
            {

            }

            public IdentityToken(string clientId, TokenResponse token)
            {
                ClientId = clientId;
                Token = token;
                ExpirationDate = GetExpirationDate(token);
            }

            public string ClientId { get; set; }
            public TokenResponse Token { get; set; }
            public DateTime ExpirationDate { get; set; }

            private static DateTime GetExpirationDate(TokenResponse token)
            {
                return DateTime.Now.AddSeconds(token.ExpiresIn);
            }
        }

        #endregion
    }
}