﻿using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.CreditScores;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;

namespace Axos.Identity.Client.Services
{
    public class CreditScoresService : ServiceClientHttpServiceBase, ICreditScoresService
    {
        private const string BaseIdentityUrl = "api/identity";
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        static string _token = null;

        public CreditScoresService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }
        /// <inheritdoc/>
        public ScoreDetailsResponse GetCurrentCreditScore(int UdbUserID)
        {
            return Get<ScoreDetailsResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<ScoreDetailsResponse>> GetCurrentCreditScoreAsync(int UdbUserID) 
        {
            return GetRequestAsync<ScoreDetailsResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore");
        }
        /// <inheritdoc/>

        public IEnumerable<ScoreDetailsResponse> GetAllCreditScores(int UdbUserID)
        {
            return Get<IEnumerable<ScoreDetailsResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscorehistory");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<IEnumerable<ScoreDetailsResponse>>> GetAllCreditScoresAsync(int UdbUserID)
        {
            return GetRequestAsync<IEnumerable<ScoreDetailsResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscorehistory");
        }

        /// <inheritdoc/>
        public IEnumerable<ScoreDetailsResponse> GetCreditScoresByDateRange(int UdbUserID, DateTime StartDate, DateTime EndDate)
        {
            return Get<IEnumerable<ScoreDetailsResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscorehistory?startdate={StartDate.ToString("yyyy-MM-dd")}&enddate={EndDate.ToString("yyyy-MM-dd")}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<IEnumerable<ScoreDetailsResponse>>> GetCreditScoresByDateRangeAsync(int UdbUserID, DateTime StartDate, DateTime EndDate)
        {
            return GetRequestAsync<IEnumerable<ScoreDetailsResponse>>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscorehistory?startdate={StartDate.ToString("yyyy-MM-dd")}&enddate={EndDate.ToString("yyyy-MM-dd")}");
        }

        /// <inheritdoc/>
        public ThinLoadResponse CreditScoreEnrollment(int UdbUserID, UserDataRequest request = null)
        {
            return Post<ThinLoadResponse, UserDataRequest>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/enroll", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<ThinLoadResponse>> CreditScoreEnrollmentAsync(int UdbUserID, UserDataRequest request = null)
        {
            return PostRequestAsync<UserDataRequest, ThinLoadResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/enroll", request);
        }

        /// <inheritdoc/>
        public GetIDVerificationResponse RequestVerification(int UdbUserID)
        {
            return Get<GetIDVerificationResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/requestverification");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<GetIDVerificationResponse>> RequestVerificationAsync(int UdbUserID)
        {
            return GetRequestAsync<GetIDVerificationResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/requestverification");
        }

        /// <inheritdoc/>
        public SubmitIDVerificationDataResponse SubmitVerfication(int UdbUserID, VerificationDataRequest request)
        {
            return Post<SubmitIDVerificationDataResponse, VerificationDataRequest>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/submitverification", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<SubmitIDVerificationDataResponse>> SubmitVerficationAsync(int UdbUserID, VerificationDataRequest request)
        {
            return PostRequestAsync<VerificationDataRequest, SubmitIDVerificationDataResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/submitverification", request);
        }

        /// <inheritdoc/>
        public UnenrollmentResponse CreditScoreUnEnrollment(int UdbUserID)
        {
            return Delete<UnenrollmentResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/unenroll");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<UnenrollmentResponse>> CreditScoreUnEnrollmentAsync(int UdbUserID)
        {
            return DeleteRequestAsync<UnenrollmentResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/unenroll");
        }

        /// <inheritdoc/>
        public UserCheckResponse CreditScoreEnrollmentCheck(int UdbUserID)
        {
            return Get<UserCheckResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/enrollcheck");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<UserCheckResponse>> CreditScoreEnrollmentCheckAsync(int UdbUserID)
        {
            return GetRequestAsync<UserCheckResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/enrollcheck");
        }

        /// <inheritdoc/>
        public ScoreNodesResponse CreditScoreNodes(int UdbUserID)
        {
            return Get<ScoreNodesResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/scorenodes");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<ScoreNodesResponse>> CreditScoreNodesAsync(int UdbUserID)
        {
            return GetRequestAsync<ScoreNodesResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/scorenodes");
        }

        /// <inheritdoc/>
        public CreditScoreNotificationPreferences SetUserNotificationPreferences(int UdbUserID, CreditScoreNotificationPreferences preferences)
        {
            return Post<CreditScoreNotificationPreferences, CreditScoreNotificationPreferences>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/notificationpreferences", preferences);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<CreditScoreNotificationPreferences>> SetUserNotificationPreferencesAsync(int UdbUserID, CreditScoreNotificationPreferences preferences)
        {
            return PostRequestAsync<CreditScoreNotificationPreferences, CreditScoreNotificationPreferences>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/notificationpreferences", preferences);
        }

        /// <inheritdoc/>
        public CreditProfileContainer GetCreditProfile(int UdbUserID)
        {
            return Get<CreditProfileContainer>($"{BaseIdentityUrl}/users/{UdbUserID}/creditprofile");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<CreditProfileContainer>> GetCreditProfileAsync(int UdbUserID)
        {
            return GetRequestAsync<CreditProfileContainer>($"{BaseIdentityUrl}/users/{UdbUserID}/creditprofile");
        }

        /// <inheritdoc/>
        public CreditProfileTradelinesResponse GetCreditProfileTradelines(int UdbUserID)
        {
            return Get<CreditProfileTradelinesResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/tradelines");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<CreditProfileTradelinesResponse>> GetCreditProfileTradelinesAsync(int UdbUserID)
        {
            return GetRequestAsync<CreditProfileTradelinesResponse>($"{BaseIdentityUrl}/users/{UdbUserID}/creditscore/tradelines");
        }

        protected override string GetLocalServiceUrl()
        {
            return LocalIdentityUrl;
        }

        protected override DateTime GetRefreshTime()
        {
            return _refreshTime;
        }

        protected override string GetServiceConfigName()
        {
            return "IdentityService";
        }

        protected override string GetToken()
        {
            return _token;
        }

        protected override void SetRefreshTime(DateTime time)
        {
            _refreshTime = time;
        }

        protected override void SetToken(string token)
        {
            _token = token;
        }
    }
}