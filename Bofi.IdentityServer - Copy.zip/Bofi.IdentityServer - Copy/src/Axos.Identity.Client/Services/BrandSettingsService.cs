﻿using Axos.Identity.Client.Constants;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    /// <summary>
    ///
    /// </summary>
    /// <seealso cref="Axos.Identity.Client.Http.ServiceClientHttpServiceBase" />
    /// <seealso cref="Axos.Identity.Client.Services.Interfaces.IBrandSettingsService" />
    public class BrandSettingsService : ServiceClientHttpServiceBase, IBrandSettingsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        /// <summary>
        /// Gets the name of the service configuration.
        /// </summary>
        /// <returns></returns>
        protected override string GetServiceConfigName() { return "IdentityService"; }

        /// <summary>
        /// Gets the local service URL.
        /// </summary>
        /// <returns></returns>
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }

        /// <summary>
        /// Gets the token.
        /// </summary>
        /// <returns></returns>
        protected override string GetToken() { return _token; }

        /// <summary>
        /// Sets the token.
        /// </summary>
        /// <param name="token">The token.</param>
        protected override void SetToken(string token) { _token = token; }

        /// <summary>
        /// Gets the refresh time.
        /// </summary>
        /// <returns></returns>
        protected override DateTime GetRefreshTime() { return _refreshTime; }

        /// <summary>
        /// Sets the refresh time.
        /// </summary>
        /// <param name="time">The time.</param>
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }

        /// <summary>
        /// The token
        /// </summary>
        private static string _token = null;

        /// <summary>
        /// The refresh time
        /// </summary>
        private static DateTime _refreshTime = new DateTime(1, 1, 1);

        // copy the above codeblock to all instances of HttpServiceBase

        /// <summary>
        /// Initializes a new instance of the <see cref="BrandSettingsService"/> class.
        /// </summary>
        /// <param name="environment">The environment.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public BrandSettingsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public Brand Add(Brand brand)
        {
            return Post<Brand, Brand>(UrlConstants.BrandUrl, brand);
        }

        public Task<HttpServiceResult<Brand>> AddAsync(Brand brand)
        {
            return PostRequestAsync<Brand, Brand>(UrlConstants.BrandUrl, brand);
        }

        public Brand Update(Brand brand)
        {
            return Put<Brand, Brand>(UrlConstants.BrandUrl, brand);
        }

        public Task<HttpServiceResult<Brand>> UpdateAsync(Brand brand)
        {
            return PutRequestAsync<Brand, Brand>(UrlConstants.BrandUrl, brand);
        }

        public bool Delete(int brandId)
        {
            return Delete(UrlConstants.BrandUrl, brandId);
        }

        public Task<HttpServiceResult> DeleteAsync(int brandId)
        {
            return DeleteRequestAsync($"{UrlConstants.BrandUrl}/{brandId}");
        }

        public Brand Get(string brandName, bool settings)
        {
            return Get<Brand>($"{UrlConstants.BrandUrl}/{brandName}?settings={settings}");
        }

        public Task<HttpServiceResult<Brand>> GetAsync(string brandName, bool settings)
        {
            return GetRequestAsync<Brand>($"{UrlConstants.BrandUrl}/{brandName}?settings={settings}");

        }

        public Brand GetById(int brandId, bool settings)
        {
            return Get<Brand>($"{UrlConstants.BrandUrl}/id/{brandId}?settings={settings}");
        }

        public Task<HttpServiceResult<Brand>> GetByIdAsync(int brandId, bool settings)
        {
            return GetRequestAsync<Brand>($"{UrlConstants.BrandUrl}/id/{brandId}?settings={settings}");
        }

        public int GetIdByName(string brandName)
        {
            var result = Get<object>($"{UrlConstants.BrandUrl}/{brandName}/id");
            return Convert.ToInt32(result);
        }

        public Task<HttpServiceResult<int>> GetIdByNameAsync(string brandName)
        {
            return GetRequestAsync<int>($"{UrlConstants.BrandUrl}/{brandName}/id");
        }

        public IEnumerable<BrandSetting> GetSettings(string brandName)
        {
            return Get<IEnumerable<BrandSetting>>($"{UrlConstants.BrandUrl}/{brandName}/settings");
        }

        public Task<HttpServiceResult<IEnumerable<BrandSetting>>> GetSettingsAsync(string brandName)
        {
            return GetRequestAsync<IEnumerable<BrandSetting>>($"{UrlConstants.BrandUrl}/{brandName}/settings");
        }

        #region Settings
        public BrandSetting GetSettingById(int settingId)
        {
            return Get<BrandSetting>($"{UrlConstants.BrandSettingsUrl}/{settingId}");
        }

        public Task<HttpServiceResult<BrandSetting>> GetSettingByIdAsync(int settingId)
        {
            return GetRequestAsync<BrandSetting>($"{UrlConstants.BrandSettingsUrl}/{settingId}");
        }

        public HttpServiceResult CreateBrandSetting(BrandSetting setting)
        {
            return Post<HttpServiceResult, BrandSetting>(UrlConstants.BrandSettingsUrl, setting);
        }

        public Task<HttpServiceResult> CreateBrandSettingAsync(BrandSetting setting)
        {
            return PostRequestAsync(UrlConstants.BrandSettingsUrl, setting);
        }

        public HttpServiceResult UpdateBrandSetting(BrandSetting setting)
        {
            return Put<HttpServiceResult, BrandSetting>(UrlConstants.BrandSettingsUrl, setting);
        }

        public Task<HttpServiceResult> UpdateBrandSettingAsync(BrandSetting setting)
        {
            return PutRequestAsync(UrlConstants.BrandSettingsUrl, setting);
        }

        public bool DeleteBrandSetting(int settingId)
        {
            return Delete(UrlConstants.BrandSettingsUrl, settingId);
        }

        public Task<HttpServiceResult> DeleteBrandSettingAsync(int settingId)
        {
            return DeleteRequestAsync($"{UrlConstants.BrandSettingsUrl}/{settingId}");
        }

        #endregion
    }
}