﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using IdentityClient.Models.Request;
using IdentityClient.Models.Response;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class IdentityService : ServiceClientHttpServiceBase, IIdentityService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/identity";
        private string BaseIdentityHealthCheckUrl = "api/healthcheck";

        public IdentityService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc />
        public EnrollmentResult AddUserCredentials(AddUserCredentialsRequest request)
        {
            return Put<EnrollmentResult, AddUserCredentialsRequest>($"{BaseIdentityUrl}/credentials", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<EnrollmentResult>> AddUserCredentialsAsync(AddUserCredentialsRequest request)
            => PutRequestAsync<AddUserCredentialsRequest, EnrollmentResult>($"{BaseIdentityUrl}/credentials", request);

        /// <inheritdoc />
        public User GetUser(int id, bool includeStatus = false)
        {
            return Get<User>($"{BaseIdentityUrl}/users/{id}?includestatus={includeStatus}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<User>> GetUserAsync(int id, bool includeStatus = false)
            => GetRequestAsync<User>($"{BaseIdentityUrl}/users/{id}?includestatus={includeStatus}");

        /// <inheritdoc />
        public User GetUser(string username, bool includeStatus = false)
        {
            return Get<User>($"{BaseIdentityUrl}/users/userName/{username}/?includestatus={includeStatus}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<User>> GetUserAsync(string username, bool includeStatus = false)
            => GetRequestAsync<User>($"{BaseIdentityUrl}/users/userName/{username}/?includestatus={includeStatus}");

        /// <inheritdoc />
        public User GetUserwithCA(string username)
        {
            return Get<User>($"{BaseIdentityUrl}/users/userName/{username}/cadetails");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<User>> GetUserwithCAAsync(string username)
            => GetRequestAsync<User>($"{BaseIdentityUrl}/users/userName/{username}/cadetails");

        /// <inheritdoc />
        public User GetUserByCif(string cif, bool includeStatus = false, bool shouldSendException = true)
        {
            return Get<User>(
                $"{BaseIdentityUrl}/users/cif/{cif}?includeStatus={includeStatus}&shouldSendException={shouldSendException}");
        }

        /// <inheritdoc />
        public async Task<User> GetUserByCifAsync(string cif, bool includeStatus = false,
            bool shouldSendException = true)
        {
            return await GetAsync<User>(
                    $"{BaseIdentityUrl}/users/cif/{cif}?includeStatus={includeStatus}&shouldSendException={shouldSendException}")
                .ConfigureAwait(false);
        }

        /// <inheritdoc />
        public User GetUserBySsn(string ssn, bool includeStatus = false, bool shouldSendException = true)
        {
            return Get<User>(
                $"{BaseIdentityUrl}/users/ssn/{ssn}?includeStatus={includeStatus}&shouldSendException={shouldSendException}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<User>> GetUserBySsnAsync(string ssn, bool includeStatus = false, bool shouldSendException = true)
            => GetRequestAsync<User>(
                $"{BaseIdentityUrl}/users/ssn/{ssn}?includeStatus={includeStatus}&shouldSendException={shouldSendException}");

        /// <inheritdoc />
        public IEnumerable<User> GetUsersByPhoneNumber(string phoneNumber, bool includeStatus = false, bool shouldSendException = true)
        {
            return Get<IEnumerable<User>>($"{BaseIdentityUrl}/users/phoneNumber/{phoneNumber}?includeStatus={includeStatus}&shouldSendException={shouldSendException}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<IList<User>>> GetUsersByPhoneNumberAsync(string phoneNumber, bool includeStatus = false, bool shouldSendException = true)
            => GetRequestAsync<IList<User>>($"{BaseIdentityUrl}/users/phoneNumber/{phoneNumber}?includeStatus={includeStatus}&shouldSendException={shouldSendException}");

        /// <inheritdoc />
        public bool GetCheckUserCifDate(string cif)
        {
            var result = Get<object>($"{BaseIdentityUrl}/user/cifdate/{cif}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public async Task<bool> CheckUserCifDateAsync(string cif)
        {
            var result = await GetAsync<object>($"{BaseIdentityUrl}/user/cifdate/{cif}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public bool GetCheckUserCifDate(int id)
        {
            var result = Get<object>($"{BaseIdentityUrl}/user/cifdate/{id}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public async Task<bool> CheckUserCifDateAsync(int id)
        {
            var result = await GetAsync<object>($"{BaseIdentityUrl}/user/cifdate/{id}");

            return Convert.ToBoolean(result);
        }

        [Obsolete("This API is obsolete.  Use Search", false)]
        public IEnumerable<User> GetUsers(params string[] username)
        {
            var getUrl = $"{BaseIdentityUrl}/users?";
            if (username.Length > 0)
            {
                getUrl = username.Aggregate(getUrl, (current, s) => current + $"usernames={s}&").TrimEnd('&');
            }

            return Get<IEnumerable<User>>(getUrl);
        }

        [Obsolete("This API is obsolete.  Use Search", false)]
        public IEnumerable<User> GetUsers(IEnumerable<int> ids)
        {
            var getUrl = $"{BaseIdentityUrl}/users?";
            if (ids.Any())
            {
                getUrl = ids.Aggregate(getUrl, (current, s) => current + $"ids={s}&").TrimEnd('&');
            }

            return Get<IEnumerable<User>>(getUrl);
        }

        [Obsolete("This API is obsolete.  Use Search", false)]
        public IEnumerable<User> GetUsers(string cif)
        {
            var getUrl = $"{BaseIdentityUrl}/users?";

            return Get<IEnumerable<User>>($"{BaseIdentityUrl}/users?cif={cif}");
        }


        [Obsolete("This API is obsolete.  Use Search", false)]
        public IEnumerable<User> GetUsers(int pageNum, int pageSize, bool enrollmentCompleted = false,
            UsersTypeFilter usersFilter = UsersTypeFilter.All, bool includeCredentialsInfo = true, bool includeSSN = true, string cif = null)
        {
            return Get<IEnumerable<User>>(
                $"{BaseIdentityUrl}/users?pageNum={pageNum}&pageSize={pageSize}&cif={cif}&enrollmentCompleted={enrollmentCompleted}" +
                $"&usersFilter={usersFilter}&includeCredentialsInfo={includeCredentialsInfo}&includeSSN={includeSSN}");
        }

        /// <inheritdoc />
        public BofiBrand GetCustomerBrand(string userName)
        {
            return Get<BofiBrand>($"{BaseIdentityUrl}/users/userName/{userName}/brand");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<BofiBrand>> GetCustomerBrandAsync(string userName)
            => GetRequestAsync<BofiBrand>($"{BaseIdentityUrl}/users/userName/{userName}/brand");

        /// <inheritdoc />
        public UserProfileInfo GetUserProfileInfo(int id)
        {
            return Get<UserProfileInfo>($"{BaseIdentityUrl}/users/{id}/profile");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<UserProfileInfo>> GetUserProfileInfoAsync(int id)
            => GetRequestAsync<UserProfileInfo>($"{BaseIdentityUrl}/users/{id}/profile");

        /// <inheritdoc />
        public UserDetail GetUserDetail(int id)
        {
            return Get<UserDetail>($"{BaseIdentityUrl}/users/{id}/detail");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<UserDetail>> GetUserDetailAsync(int id)
            => GetRequestAsync<UserDetail>($"{BaseIdentityUrl}/users/{id}/detail");

        /// <inheritdoc />
        public bool IsUsernameAvailable(string username)
        {
            var result = Get<object>($"{BaseIdentityUrl}/user/{username}/available");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public async Task<bool> IsUsernameAvailableAsync(string username)
        {
            var result = await GetAsync<object>($"{BaseIdentityUrl}/user/{username}/available");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public IEnumerable<User> Search(UserSearchRequest request, int pageSize, int pageNum)
        {
            return Post<IEnumerable<User>, UserSearchRequest>(
                $"{BaseIdentityUrl}/users/search?pageSize={pageSize}&pageNum={pageNum}", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<IList<User>>> SearchAsync(UserSearchRequest request, int pageSize, int pageNum)
            => PostRequestAsync<UserSearchRequest, IList<User>>(
                $"{BaseIdentityUrl}/users/search?pageSize={pageSize}&pageNum={pageNum}", request);

        /// <inheritdoc />
        public User UserMatch(UserMatchRequest request)
        {
            return Post<User, UserMatchRequest>(
                $"{BaseIdentityUrl}/users/match", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<User>> UserMatchAsync(UserMatchRequest request)
            => PostRequestAsync<UserMatchRequest, User>(
                $"{BaseIdentityUrl}/users/match", request);

        /// <inheritdoc />
        public Dictionary<string, List<string>> ValidateTokenAndExtractClaims(string token, out bool isAdmin)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(identityConfig.Settings["RSAKeyValue"]);
            SecurityKey sk = new RsaSecurityKey(rsa);

            TokenValidationParameters validationParameters = new TokenValidationParameters
            {
                ValidIssuer = identityConfig.Settings["ApiURL"],
                IssuerSigningKeys = new List<SecurityKey>() { sk },
                ValidateAudience = false,
                ValidateIssuer = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true
            };

            var handler = new JwtSecurityTokenHandler();
            SecurityToken validatedToken;
            ClaimsPrincipal claimsPrincipal = handler.ValidateToken(token, validationParameters, out validatedToken);
            isAdmin = claimsPrincipal.Claims.Any(x => x.Type == "client_id" && x.Value == "adminportal.web");
            return claimsPrincipal.Claims.GroupBy(x => x.Type).ToDictionary(x => x.Key, y => y.Select(x => x.Value).ToList());

        }

        /// <inheritdoc />
        public string UpdateEmploymentInfo(int id, UpdateEmploymentInfoRequest request)
        {
            return Put<string, UpdateEmploymentInfoRequest>($"{BaseIdentityUrl}/users/{id}/employmentinfo", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateEmploymentInfoAsync(int userId, UpdateEmploymentInfoRequest request)
            => PutRequestAsync<UpdateEmploymentInfoRequest, string>($"{BaseIdentityUrl}/users/{userId}/employmentinfo", request);

        /// <inheritdoc />
        public string UpdateUserStatuses(UpdateUserStatusRequest request)
        {
            return Put<string, UpdateUserStatusRequest>($"{BaseIdentityUrl}/users/statuses", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateUserStatusesAsync(UpdateUserStatusRequest request)
            => PutRequestAsync<UpdateUserStatusRequest, string>($"{BaseIdentityUrl}/users/statuses", request);

        /// <inheritdoc />
        public string UpdateUserProfileInfo(UserProfileInfo request)
        {
            return Put<string, UserProfileInfo>($"{BaseIdentityUrl}/users/profile", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateUserProfileInfoAsync(UserProfileInfo request)
            => PutRequestAsync<UserProfileInfo, string>($"{BaseIdentityUrl}/users/profile", request);

        /// <inheritdoc />
        public string UpdateEmailInfo(int id, UpdateEmailRequest request)
        {
            return Put<string, UpdateEmailRequest>($"{BaseIdentityUrl}/users/{id}/emails", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateEmailInfoAsync(int userId, UpdateEmailRequest request)
            => PutRequestAsync<UpdateEmailRequest, string>($"{BaseIdentityUrl}/users/{userId}/emails", request);

        /// <inheritdoc />
        public string UpdatesPhones(int id, UpdateUserPhonesRequest request)
        {
            return Put<string, UpdateUserPhonesRequest>($"{BaseIdentityUrl}/users/{id}/phones", request);
        }

        public Task<HttpServiceResult<string>> UpdatePhonesAsync(int userId, UpdateUserPhonesRequest request)
            => PutRequestAsync<UpdateUserPhonesRequest, string>($"{BaseIdentityUrl}/users/{userId}/phones", request);

        [Obsolete("This API is obsolete.  Use RegisterUser(GenericCreateUserRequest)", false)]
        public EnrollmentResult RegisterUser(CreateUserRequest request)
        {
            return Post<EnrollmentResult, CreateUserRequest>($"{BaseIdentityUrl}/register", request);
        }

        [Obsolete("This API is obsolete.  Use RegisterUser(GenericCreateUserRequest)", false)]
        public EnrollmentResult RegisterUser(CreateNonOlbUserRequest request)
        {
            return Post<EnrollmentResult, CreateNonOlbUserRequest>($"{BaseIdentityUrl}/registerNonOlb", request);
        }

        /// <inheritdoc />
        public EnrollmentResult RegisterUser(GenericCreateUserRequest request, bool waitForSync = true)
        {
            return Post<EnrollmentResult, GenericCreateUserRequest>($"{BaseIdentityUrl}/register/generic/{waitForSync}", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<EnrollmentResult>> RegisterUserAsync(GenericCreateUserRequest request, bool waitForSync = true)
            => PostRequestAsync<GenericCreateUserRequest, EnrollmentResult>($"{BaseIdentityUrl}/register/generic/{waitForSync}", request);

        /// <inheritdoc />
        public void DissociateUser(int userId)
        {
            Post($"{BaseIdentityUrl}/users/dissociate/", userId);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult> DissociateUserAsync(int userId)
            => PostRequestAsync($"{BaseIdentityUrl}/users/dissociate/", userId);

        /// <inheritdoc />
        public void AssociateUser(int parentId, int childId)
        {
            var parameters = new Dictionary<string, int>
            {
                { "ParentId", parentId },
                { "ChildId", childId }
            };

            Post($"{BaseIdentityUrl}/users/associate/", parameters);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult> AssociateUserAsync(int parentId, int childId)
        {
            var parameters = new Dictionary<string, int>
            {
                { "ParentId", parentId },
                { "ChildId", childId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}/users/associate/", parameters);
        }

        /// <inheritdoc />
        public UserTree FindUserByChildID(int childId)
        {
            return Get<UserTree>($"{BaseIdentityUrl}/users/{childId}/parent");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<UserTree>> FindUserByChildIdAsync(int childId)
            => GetRequestAsync<UserTree>($"{BaseIdentityUrl}/users/{childId}/parent");

        /// <inheritdoc />
        public List<UserTree> FindUsersByParentID(int parentId)
        {
            return Get<List<UserTree>>($"{BaseIdentityUrl}/users/{parentId}/children");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<IList<UserTree>>> FindUsersByParentIdAsync(int parentId)
            => GetRequestAsync<IList<UserTree>>($"{BaseIdentityUrl}/users/{parentId}/children");

        /// <inheritdoc />
        public UserTree GetTree(int userId)
        {
            return Get<UserTree>($"{BaseIdentityUrl}/users/{userId}/tree");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<UserTree>> GetTreeAsync(int userId)
            => GetRequestAsync<UserTree>($"{BaseIdentityUrl}/users/{userId}/tree");

        /// <inheritdoc />
        public UserTree GetRelationshipsTree(int userId)
        {
            return Get<UserTree>($"{BaseIdentityUrl}/users/{userId}/tree");
        }

        public Task<HttpServiceResult<UserTree>> GetRelationshipsTreeAsync(int userId)
            => GetRequestAsync<UserTree>($"{BaseIdentityUrl}/users/{userId}/tree");

        /// <summary>
        /// Really, really Hard Delete the User
        /// DO NOT USE THIS INTEFACE!  ONLY FOR INTEGRATION TESTS!
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool HardDeleteUser(int id)
        {
            try
            {
                var response = Delete<object>($"{BaseIdentityUrl}/harddeleteuser/{id}");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <inheritdoc />
        public PreloadUserStatus CompleteRegistration(CompleteRegistrationRequest request)
        {
            var result =
                Convert.ToByte(
                    Post<object, CompleteRegistrationRequest>($"{BaseIdentityUrl}/register/complete", request));
            return (PreloadUserStatus)result;
        }

        /// <inheritdoc />
        public async Task<PreloadUserStatus> CompleteRegistrationAsync(CompleteRegistrationRequest request)
        {
            var result = await PostRequestAsync<object, CompleteRegistrationRequest>($"{BaseIdentityUrl}/register/complete", request);

            return (PreloadUserStatus)Convert.ToByte(result.Data);
        }

        /// <inheritdoc />
        public string EnrollUser(string username, string vendorName)
        {
            return Put<string, string>($"{BaseIdentityUrl}/{username}/enroll/{vendorName}", string.Empty);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> EnrollUserAsync(string username, string vendorName)
            => PutRequestAsync<string, string>($"{BaseIdentityUrl}/{username}/enroll/{vendorName}", string.Empty);

        [Obsolete("This is deprecated functionality ")]
        public string UpdatePrimaryAddress(int id, Address request)
        {
            return Put<string, Address>($"{BaseIdentityUrl}/users/{id}/addresses/primary", request);
        }

        /// <inheritdoc />
        public IEnumerable<Address> GetAllAddresses(int id)
        {
            return Get<IEnumerable<Address>>($"{BaseIdentityUrl}/users/{id}/addresses");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<IList<Address>>> GetAllAddressesAsync(int userId)
            => GetRequestAsync<IList<Address>>($"{BaseIdentityUrl}/users/{userId}/addresses");

        /// <inheritdoc />
        public bool SyncUserProfile(int id)
        {
            return Get($"{BaseIdentityUrl}/sync/{id}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult> SyncUserProfileAsync(int id)
            => GetRequestAsync($"{BaseIdentityUrl}/sync/{id}");

        /// <inheritdoc />
        public string DeleteAccountAddress(string addressId)
        {
            return Delete<string>($"{BaseIdentityUrl}/users/addresses/{addressId}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> DeleteAccountAddressAsync(string addressId)
            => DeleteRequestAsync<string>($"{BaseIdentityUrl}/users/addresses/{addressId}");

        /// <inheritdoc />
        public string UpdateAccountAssociations(IEnumerable<Address> request)
        {
            return Put<string, IEnumerable<Address>>($"{BaseIdentityUrl}/users/addresses/accountassociations", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateAccountAssociationsAsync(IEnumerable<Address> request)
            => PutRequestAsync<IEnumerable<Address>, string>($"{BaseIdentityUrl}/users/addresses/accountassociations", request);

        /// <inheritdoc />
        public Credential GetPasswordInformation(string username)
        {
            return Get<Credential>($"{BaseIdentityUrl}/users/password/{username}/info");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<Credential>> GetPasswordInformationAsync(string username)
            => GetRequestAsync<Credential>($"{BaseIdentityUrl}/users/password/{username}/info");

        /// <inheritdoc />
        public bool DeclineRegistration(DeclineRegistrationRequest request)
        {
            return Post($"{BaseIdentityUrl}/declineRegistration", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult> DeclineRegistrationAsync(DeclineRegistrationRequest request)
            => PostRequestAsync($"{BaseIdentityUrl}/declineRegistration", request);

        /// <inheritdoc />
        public bool ApproveRegistration(ApproveRegistrationRequest request)
        {
            return Post($"{BaseIdentityUrl}/approveregistration", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult> ApproveRegistrationAsync(ApproveRegistrationRequest request)
            => PostRequestAsync($"{BaseIdentityUrl}/approveregistration", request);

        /// <inheritdoc />
        public PrivacySettings GetPrivacySettings(int userId)
        {
            return Get<PrivacySettings>($"{BaseIdentityUrl}/privacy/{userId}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<PrivacySettings>> GetPrivacySettingsAsync(int userId)
            => GetRequestAsync<PrivacySettings>($"{BaseIdentityUrl}/privacy/{userId}");

        /// <inheritdoc />
        public string UpdateCustomerPrivacy(string cif, bool shareCreditWorthinessOptOut,
            bool shareWithAffiliatesOptOut, bool shareWithNonAffiliatesOptOut)
        {
            var request = new PrivacySettingsRequest
            {
                Cif = cif,
                ShareCreditWorthinessOptOut = shareCreditWorthinessOptOut,
                ShareWithAffiliatesOptOut = shareWithAffiliatesOptOut,
                ShareWithNonAffiliatesOptOut = shareWithNonAffiliatesOptOut
            };
            return Put<string, PrivacySettingsRequest>($"{BaseIdentityUrl}/privacy", request);

        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> UpdateCustomerPrivacyAsync(string cif, bool shareCreditWorthinessOptOut,
            bool shareWithAffiliatesOptOut, bool shareWithNonAffiliatesOptOut)
        {
            var request = new PrivacySettingsRequest
            {
                Cif = cif,
                ShareCreditWorthinessOptOut = shareCreditWorthinessOptOut,
                ShareWithAffiliatesOptOut = shareWithAffiliatesOptOut,
                ShareWithNonAffiliatesOptOut = shareWithNonAffiliatesOptOut
            };

            return PutRequestAsync<PrivacySettingsRequest, string>($"{BaseIdentityUrl}/privacy", request);
        }

        [Obsolete("This is deprecated functionality")]
        public int RepairMarketoLeadId(int request)
        {
            var result = Get<object>($"{BaseIdentityUrl}/repairMarketo/{request}");

            return Convert.ToInt32(result);
        }

        /// <inheritdoc />
        public bool HasSecurityQuestions(int udbUserID)
        {
            var result = Get<object>($"{BaseIdentityUrl}/users/hasSecurityQuestions/{udbUserID}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public async Task<bool> HasSecurityQuestionsAsync(int udbUserID)
        {
            var result = await GetAsync<object>($"{BaseIdentityUrl}/users/hasSecurityQuestions/{udbUserID}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        [Obsolete("This is deprecated functionality ")]
        public bool GetHasSecurityQuestionsFlag(int request)
        {
            var result = Get<object>($"{BaseIdentityUrl}/users/hasSecurityQuestions/{request}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        [Obsolete("This is deprecated functionality ")]
        public async Task<bool> HasSecurityQuestionsFlagAsync(int userID)
        {
            var result = await GetAsync<object>($"{BaseIdentityUrl}/users/hasSecurityQuestions/{userID}");

            return Convert.ToBoolean(result);
        }

        /// <inheritdoc />
        public AccessTokenResponse GetTokenForUser(AccessTokenRequest request)
        {
            return Post<AccessTokenResponse, AccessTokenRequest>($"{BaseIdentityUrl}/token/mint", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<AccessTokenResponse>> GetTokenForUserAsync(AccessTokenRequest request)
            => PostRequestAsync<AccessTokenRequest, AccessTokenResponse>($"{BaseIdentityUrl}/token/mint", request);

        /// <inheritdoc />
        public AccessTokenResponse RefreshToken(AccessTokenRequest request)
        {
            return Post<AccessTokenResponse, AccessTokenRequest>($"{BaseIdentityUrl}/token/refresh", request);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<AccessTokenResponse>> RefreshTokenAsync(AccessTokenRequest request)
            => PostRequestAsync<AccessTokenRequest, AccessTokenResponse>($"{BaseIdentityUrl}/token/refresh", request);

        /// <inheritdoc />
        public HealthCheckResponse GetHealthCheck(bool isDeep)
        {
            string deepUrl = "?deep=true";
            if (isDeep)
                BaseIdentityHealthCheckUrl += deepUrl;

            return GetHealthCheck<HealthCheckResponse>(BaseIdentityHealthCheckUrl);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<HealthCheckResponse>> GetHealthCheckAsync(bool isDeep)
        {
            string deepUrl = "?deep=true";
            if (isDeep)
                BaseIdentityHealthCheckUrl += deepUrl;

            return GetHealthCheckAsync<HealthCheckResponse>(BaseIdentityHealthCheckUrl);
        }

        /// <inheritdoc />
        public string AssignDefaultUsernameForUser(int userId)
        {
            return Get<string>($"{BaseIdentityUrl}/users/AssignDefaultUsernameForUser/{userId}");
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> AssignDefaultUsernameForUserAsync(int userId)
            => GetRequestAsync<string>($"{BaseIdentityUrl}/users/AssignDefaultUsernameForUser/{userId}");

        #region Confirmed Flag
        /// <inheritdoc />
        public string ConfirmEmail(int userId) => Put<string, object>($"{BaseIdentityUrl}/users/{userId}/confirmemail", new { });

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> ConfirmEmailAsync(int userId) => PutRequestAsync<object, string>($"{BaseIdentityUrl}/users/{userId}/confirmemail", new { });

        /// <inheritdoc />
        public string ConfirmAddress(int userId, ConfirmAddressRequest request) => Put<string, object>($"{BaseIdentityUrl}/users/{userId}/confirmaddress", request);

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> ConfirmAddressAsync(int userId, ConfirmAddressRequest request) => PutRequestAsync<ConfirmAddressRequest, string>($"{BaseIdentityUrl}/users/{userId}/confirmaddress", request);

        /// <inheritdoc />
        public string ConfirmPhone(int userId, ConfirmPhoneRequest request) => Put<string, object>($"{BaseIdentityUrl}/users/{userId}/confirmphone", request);

        /// <inheritdoc />
        public Task<HttpServiceResult<string>> ConfirmPhoneAsync(int userId, ConfirmPhoneRequest request) => PutRequestAsync<ConfirmPhoneRequest, string>($"{BaseIdentityUrl}/users/{userId}/confirmphone", request);
        #endregion

        /// <inheritdoc />
        public DateTime DateOfLastSuccessfulLogin(int userId)
        {
            var response = Get<object>($"{BaseIdentityUrl}users/dateoflastsuccessfullogin/{userId}");

            return Convert.ToDateTime(response);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<DateTime?>> DateOfLastSuccessfulLoginAsync(int userId) => GetRequestAsync<DateTime?>($"{BaseIdentityUrl}/users/dateoflastsuccessfullogin/{userId}");

        /// <inheritdoc />
        public DateTime DateOfLastPasswordChange(int userId)
        {
            var response = Get<object>($"{BaseIdentityUrl}users/dateoflastpasswordchange/{userId}");

            return Convert.ToDateTime(response);
        }

        /// <inheritdoc />
        public Task<HttpServiceResult<DateTime?>> DateOfLastPasswordChangeAsync(int userId) => GetRequestAsync<DateTime?>($"{BaseIdentityUrl}/users/dateoflastpasswordchange/{userId}");

        /// <inheritdoc />
        public int? GetLoginFailsQuantity(int userId)
        {
            return Convert.ToInt32(Get<string>($"{BaseIdentityUrl}/users/loginfails/{userId}"));
        }
        /// <inheritdoc />
        public Task<HttpServiceResult<int?>> GetLoginFailsQuantityAsync(int userId) => GetRequestAsync<int?>($"{BaseIdentityUrl}/users/loginfails/{userId}");
    }
}
