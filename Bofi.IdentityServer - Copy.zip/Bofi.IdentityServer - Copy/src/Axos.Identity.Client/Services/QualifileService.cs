﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models.Qualifile.Business;
using Axos.Identity.Client.Models.Qualifile.Consumers;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class QualifileService : ServiceClientHttpServiceBase, IQualifileService
    {
        private const string BaseIdentityUrl = "api/identity";
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        static string _token = null;

        public QualifileService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public Axos.Identity.Client.Models.Qualifile.ServiceResult<ConsumerResponse> RequestPersonQuery(ConsumerQueryModel request)
        {
            return Post<Models.Qualifile.ServiceResult<ConsumerResponse>, ConsumerQueryModel>($"{BaseIdentityUrl}/qualifile/personquery", request);
        }

        public Task<HttpServiceResult<Models.Qualifile.ServiceResult<ConsumerResponse>>> RequestPersonQueryAsync(ConsumerQueryModel request)
        {
            return PostRequestAsync<ConsumerQueryModel, Models.Qualifile.ServiceResult<ConsumerResponse>>($"{BaseIdentityUrl}/qualifile/personquery", request);
        }

        public Axos.Identity.Client.Models.Qualifile.ServiceResult<BusinessResponse> RequestBusinessQuery(BusinessQueryModel request)
        {
            return Post<Models.Qualifile.ServiceResult<BusinessResponse>, BusinessQueryModel>($"{BaseIdentityUrl}/qualifile/businessquery", request);
        }

        public Task<HttpServiceResult<Axos.Identity.Client.Models.Qualifile.ServiceResult<BusinessResponse>>> RequestBusinessQueryAsync(BusinessQueryModel request)
        {
            return PostRequestAsync<BusinessQueryModel, Models.Qualifile.ServiceResult<BusinessResponse>>($"{BaseIdentityUrl}/qualifile/businessquery", request);
        }

        public ConsumerResponse DeserializeResponse(string request)
        {
            return Post<ConsumerResponse, string>($"{BaseIdentityUrl}/qualifile/deserializeresponse", request);
        }

        public Task<HttpServiceResult<ConsumerResponse>> DeserializeResponseAsync(string request)
        {
            return PostRequestAsync<string, ConsumerResponse>($"{BaseIdentityUrl}/qualifile/deserializeresponse", request);
        }

        protected override string GetLocalServiceUrl()
        {
            return LocalIdentityUrl;
        }

        protected override DateTime GetRefreshTime()
        {
            return _refreshTime;
        }

        protected override string GetServiceConfigName()
        {
            return "IdentityService";
        }

        protected override string GetToken()
        {
            return _token;
        }

        protected override void SetRefreshTime(DateTime time)
        {
            _refreshTime = time;
        }

        protected override void SetToken(string token)
        {
            _token = token;
        }
    }
}
