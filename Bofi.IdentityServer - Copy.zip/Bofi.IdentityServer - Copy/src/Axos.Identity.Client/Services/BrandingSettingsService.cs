﻿using Axos.Identity.Client.Constants;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using Microsoft.AspNetCore.WebUtilities;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Security.Authentication;
using System.Threading.Tasks;
using System.Web;

namespace Axos.Identity.Client.Services
{
    /// <summary>
    ///
    /// </summary>
    /// <seealso cref="Axos.Identity.Client.Http.ServiceClientHttpServiceBase" />
    /// <seealso cref="Axos.Identity.Client.Services.Interfaces.IBrandingSettingsService" />
    public class BrandingSettingsService : ServiceClientHttpServiceBase, IBrandingSettingsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        /// <summary>
        /// Gets the name of the service configuration.
        /// </summary>
        /// <returns></returns>
        protected override string GetServiceConfigName()
        { return "IdentityService"; }

        /// <summary>
        /// Gets the local service URL.
        /// </summary>
        /// <returns></returns>
        protected override string GetLocalServiceUrl()
        { return LocalIdentityUrl; }

        /// <summary>
        /// Gets the token.
        /// </summary>
        /// <returns></returns>
        protected override string GetToken()
        { return _token; }

        /// <summary>
        /// Sets the token.
        /// </summary>
        /// <param name="token">The token.</param>
        protected override void SetToken(string token)
        { _token = token; }

        /// <summary>
        /// Gets the refresh time.
        /// </summary>
        /// <returns></returns>
        protected override DateTime GetRefreshTime()
        { return _refreshTime; }

        /// <summary>
        /// Sets the refresh time.
        /// </summary>
        /// <param name="time">The time.</param>
        protected override void SetRefreshTime(DateTime time)
        { _refreshTime = time; }

        /// <summary>
        /// The token
        /// </summary>
        private static string _token = null;

        /// <summary>
        /// The refresh time
        /// </summary>
        private static DateTime _refreshTime = new DateTime(1, 1, 1);

        // copy the above codeblock to all instances of HttpServiceBase

        /// <summary>
        /// Initializes a new instance of the <see cref="BrandingSettingsService"/> class.
        /// </summary>
        /// <param name="environment">The environment.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public BrandingSettingsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public Branding Add(Branding branding)
        {
            return Post<Branding, Branding>(UrlConstants.BrandingUrl, branding);
        }

        public Task<HttpServiceResult<Branding>> AddAsync(Branding branding)
        {
            return PostRequestAsync<Branding, Branding>(UrlConstants.BrandingUrl, branding);
        }

        public Branding Update(Branding branding)
        {
            return Put<Branding, Branding>(UrlConstants.BrandingUrl, branding);
        }

        public Task<HttpServiceResult<Branding>> UpdateAsync(Branding branding)
        {
            return PutRequestAsync<Branding, Branding>(UrlConstants.BrandingUrl, branding);
        }

        public bool Delete(int brandingId)
        {
            return Delete(UrlConstants.BrandingUrl, brandingId);
        }

        public Task<HttpServiceResult> DeleteAsync(int brandingId)
        {
            return DeleteRequestAsync($"{UrlConstants.BrandingUrl}/{brandingId}");
        }

        public Branding Get(string brandingName, bool settings, bool GetDrafts = false)
        {
            return Get<Branding>($"{UrlConstants.BrandingUrl}/{brandingName}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<Branding>> GetAsync(string brandingName, bool settings, bool GetDrafts = false)
        {
            return GetRequestAsync<Branding>($"{UrlConstants.BrandingUrl}/{brandingName}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Branding GetById(int brandingId, bool settings, bool GetDrafts = false)
        {
            return Get<Branding>($"{UrlConstants.BrandingUrl}/id/{brandingId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<Branding>> GetByIdAsync(int brandingId, bool settings, bool GetDrafts = false)
        {
            return GetRequestAsync<Branding>($"{UrlConstants.BrandingUrl}/id/{brandingId}?settings={settings}&GetDrafts={GetDrafts}");
        }

        public int GetIdByName(string brandingName)
        {
            var result = Get<object>($"{UrlConstants.BrandingUrl}/{brandingName}/id");
            return Convert.ToInt32(result);
        }

        public Task<HttpServiceResult<int>> GetIdByNameAsync(string brandingName)
        {
            return GetRequestAsync<int>($"{UrlConstants.BrandingUrl}/{brandingName}/id");
        }

        public IEnumerable<BrandingSetting> GetSettings(string brandingName, bool GetDrafts = false)
        {
            return Get<IEnumerable<BrandingSetting>>($"{UrlConstants.BrandingUrl}/{brandingName}/settings?GetDrafts={GetDrafts}");
        }

        public Task<HttpServiceResult<IEnumerable<BrandingSetting>>> GetSettingsAsync(string brandingName, bool GetDrafts = false)
        {
            return GetRequestAsync<IEnumerable<BrandingSetting>>($"{UrlConstants.BrandingUrl}/{brandingName}/settings?GetDrafts={GetDrafts}");
        }

        #region Settings

        public BrandingSetting GetSettingById(int settingId)
        {
            return Get<BrandingSetting>($"{UrlConstants.BrandingSettingsUrl}/{settingId}");
        }

        public Task<HttpServiceResult<BrandingSetting>> GetSettingByIdAsync(int settingId)
        {
            return GetRequestAsync<BrandingSetting>($"{UrlConstants.BrandingSettingsUrl}/{settingId}");
        }

        public Task<HttpServiceResult<IEnumerable<BrandingSetting>>> GetBrandingSettingsByNameAndValue(string name, string value)
        {
            var url = $"{UrlConstants.BrandingUrl}/settingsbynameandvalue";
            url = QueryHelpers.AddQueryString(url, "settingname", HttpUtility.UrlEncode(name));

            if (!string.IsNullOrEmpty(value))
                url = QueryHelpers.AddQueryString(url, "settingvalue", HttpUtility.UrlEncode(value));

            return GetRequestAsync<IEnumerable<BrandingSetting>>(url);
        }

        public HttpServiceResult CreateBrandingSetting(BrandingSetting setting)
        {
            return Post<HttpServiceResult, BrandingSetting>(UrlConstants.BrandingSettingsUrl, setting);
        }

        public Task<HttpServiceResult> CreateBrandingSettingAsync(BrandingSetting setting)
        {
            return PostRequestAsync(UrlConstants.BrandingSettingsUrl, setting);
        }

        public HttpServiceResult UpdateBrandingSetting(BrandingSetting setting)
        {
            return Put<HttpServiceResult, BrandingSetting>(UrlConstants.BrandingSettingsUrl, setting);
        }

        public Task<HttpServiceResult> UpdateBrandingSettingAsync(BrandingSetting setting)
        {
            return PutRequestAsync(UrlConstants.BrandingSettingsUrl, setting);
        }

        public bool DeleteBrandingSetting(int settingId)
        {
            return Delete(UrlConstants.BrandingSettingsUrl, settingId);
        }

        public Task<HttpServiceResult> DeleteBrandingSettingAsync(int settingId)
        {
            return DeleteRequestAsync($"{UrlConstants.BrandingSettingsUrl}/{settingId}");
        }

        #endregion Settings
    }
}