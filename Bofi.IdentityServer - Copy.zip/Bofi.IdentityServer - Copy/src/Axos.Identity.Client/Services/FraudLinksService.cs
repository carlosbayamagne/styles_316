﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Axos.Identity.Client.DTOs;
using Axos.Identity.Client.DTOs.FraudLinks;
using Axos.Identity.Client.Models.FraudLinks;
using System.Security.Authentication;

namespace Axos.Identity.Client.Services
{
    public class FraudLinksService : ServiceClientHttpServiceBase, IFraudLinksService
    {
        private const string BaseIdentityUrl = "api/identity";
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        static string _token = null;

        public FraudLinksService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto> Match(Applicant request)
        {
            return Post<Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto>, Applicant>($"{BaseIdentityUrl}/fraudlinks", request);
        }

        public Task<HttpServiceResult<Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto>>> MatchAsync(Applicant request)
        {
            return PostRequestAsync<Applicant, Axos.Identity.Client.Models.FraudLinks.ServiceResult<OverAllVerificationResultDto>>($"{BaseIdentityUrl}/fraudlinks", request);
        }

        protected override string GetLocalServiceUrl()
        {
            return LocalIdentityUrl;
        }

        protected override DateTime GetRefreshTime()
        {
            return _refreshTime;
        }

        protected override string GetServiceConfigName()
        {
            return "IdentityService";
        }

        protected override string GetToken()
        {
            return _token;
        }

        protected override void SetRefreshTime(DateTime time)
        {
            _refreshTime = time;
        }

        protected override void SetToken(string token)
        {
            _token = token;
        }
    }
}
