﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models.Biometrics;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class UserDevicesService : ServiceClientHttpServiceBase, IUserDevicesService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/identity";

        public UserDevicesService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public bool AddUserDevice(int userId, BiometricDeviceDetailsRequest deviceDetailsRequest)
        {
            return Post($"{BaseIdentityUrl}/{userId}/devices", deviceDetailsRequest);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AddUserDeviceAsync(int userId, BiometricDeviceDetailsRequest deviceDetailsRequest)
            => PostRequestAsync($"{BaseIdentityUrl}/{userId}/devices", deviceDetailsRequest);

        /// <inheritdoc/>
        public bool DeleteDevice(int userId, DeleteBiometricDeviceRequest deleteDeviceRequest)
        {
            return Delete($"{BaseIdentityUrl}/{userId}/devices", deleteDeviceRequest);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> DeleteDeviceAsync(int userId, DeleteBiometricDeviceRequest deleteDeviceRequest)
            => DeleteRequestWithContentAsync($"{BaseIdentityUrl}/{userId}/devices", deleteDeviceRequest);

        /// <inheritdoc/>
        public IEnumerable<string> GetUserDevices(int userId)
        {
            return Get<IEnumerable<string>>($"{BaseIdentityUrl}/{userId}/devices");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<IList<string>>> GetUserDevicesAsync(int userId)
            => GetRequestAsync<IList<string>>($"{BaseIdentityUrl}/{userId}/devices");

        /// <inheritdoc/>
        public bool DeleteUser(int userId)
        {
            try
            {
                var response = Delete<object>($"{BaseIdentityUrl}/{userId}/devices/deleteuser");
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> DeleteUserAsync(int userId)
            => DeleteRequestAsync($"{BaseIdentityUrl}/{userId}/devices/deleteuser");
    }
}
