﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models.Biometrics;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class BiometricsService : ServiceClientHttpServiceBase, IBiometricsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseBiometricsUrl = "api/Biometrics";

        public BiometricsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public bool VerifyIdentity(BiometricAuthenticationRequest deviceIdentity)
        {
            return (bool)Post<object, BiometricDeviceIdentity>($"{BaseBiometricsUrl}/verify/identity", deviceIdentity);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<bool>> VerifyIdentityAsync(BiometricAuthenticationRequest deviceIdentity)
            => PostRequestAsync<BiometricDeviceIdentity, bool>($"{BaseBiometricsUrl}/verify/identity", deviceIdentity);

        /// <inheritdoc/>
        public bool VerifyAuthenticationFactor(VerifyAuthenticationFactorRequest request)
        {
            return (bool)Post<object, VerifyAuthenticationFactorRequest>($"{BaseBiometricsUrl}/verify/factor", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<bool>> VerifyAuthenticationFactorAsync(VerifyAuthenticationFactorRequest request)
            => PostRequestAsync<VerifyAuthenticationFactorRequest, bool>($"{BaseBiometricsUrl}/verify/factor", request);

        /// <inheritdoc/>
        public bool UpdateUserDeviceDetails(UpdateUserDeviceDetailsRequest updateUserDeviceDetailsRequest)
        {
            return (bool)Put<object, UpdateUserDeviceDetailsRequest>($"{BaseBiometricsUrl}/device", updateUserDeviceDetailsRequest);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<bool>> UpdateUserDeviceDetailsAsync(UpdateUserDeviceDetailsRequest updateUserDeviceDetailsRequest)
            => PutRequestAsync<UpdateUserDeviceDetailsRequest, bool>($"{BaseBiometricsUrl}/device", updateUserDeviceDetailsRequest);

        /// <inheritdoc/>
        public bool DeleteUserVoice(int userId)
        {
            return (bool)Delete<object>($"{BaseBiometricsUrl}/voice/{userId}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<bool>> DeleteUserVoiceAsync(int userId)
            => DeleteRequestAsync<bool>($"{BaseBiometricsUrl}/voice/{userId}");

        /// <inheritdoc/>
        public List<string> ListAuthenticationFactor(ListAuthenticationFactorsRequest listAuthenticationFactorRequest)
        {
            return Post<List<string>, ListAuthenticationFactorsRequest>($"{BaseBiometricsUrl}/list-factors", listAuthenticationFactorRequest);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<IList<string>>> ListAuthenticationFactorAsync(ListAuthenticationFactorsRequest listAuthenticationFactorRequest)
            => PostRequestAsync<ListAuthenticationFactorsRequest, IList<string>>($"{BaseBiometricsUrl}/list-factors", listAuthenticationFactorRequest);

        /// <inheritdoc/>
        public async Task<IEnumerable<UserVoiceDetails>> GetVoiceDetailsByPhoneAsync(string phoneNumber)
        {
            return await GetAsync<IEnumerable<UserVoiceDetails>>($"{BaseBiometricsUrl}/voice-details/phone/{phoneNumber}")
                .ConfigureAwait(false);
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<UserVoiceDetails>> GetVoiceDetailsBySSNAsync(string ssn)
        {
            return await GetAsync<IEnumerable<UserVoiceDetails>>($"{BaseBiometricsUrl}/voice-details/ssn/{ssn}")
                .ConfigureAwait(false);
        }

    }
}
