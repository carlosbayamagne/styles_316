﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class SecondaryRegistryService : ServiceClientHttpServiceBase, ISecondaryRegistryService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }


        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/salesforce";

        public SecondaryRegistryService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public string GetContactId(int id)
        {
            return Get<string>($"{BaseIdentityUrl}/contact/{id}");
        }

        public Task<HttpServiceResult<string>> GetContactIdAsync(int id)
            => GetRequestAsync<string>($"{BaseIdentityUrl}/contact/{id}");

        public string GetContactIdByCif(string cif)
        {
            return Get<string>($"{BaseIdentityUrl}/contact/{cif}");
        }

        public Task<HttpServiceResult<string>> GetContactIdByCifAsync(string cif)
            => GetRequestAsync<string>($"{BaseIdentityUrl}/contact/{cif}");

        public string GetContactIdByRequest(ContactIdRequest request)
        {
            return Post<string, ContactIdRequest>($"{BaseIdentityUrl}/contact", request, null);
        }

        public Task<HttpServiceResult<string>> GetContactIdByRequestAsync(ContactIdRequest request)
            => PostRequestAsync<ContactIdRequest, string>($"{BaseIdentityUrl}/contact", request, null);

        /// <inheritdoc/>
        public async Task<bool> ConfirmContactInfoAsync(int id)
        {
            var response = await GetAsync<object>($"{BaseIdentityUrl}/confirm/{id}");
            return Convert.ToBoolean(response);
        }

        public async Task<SalesForceServiceResponse> ForceSync(int id)
        {
            return await GetAsync<SalesForceServiceResponse>($"{BaseIdentityUrl}/sync/{id}");
        }
    }
}
