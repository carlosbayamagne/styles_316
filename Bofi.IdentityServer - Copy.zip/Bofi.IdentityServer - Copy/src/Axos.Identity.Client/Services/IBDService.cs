﻿using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.Request;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;

namespace Axos.Identity.Client.Services
{
    public class IBDService : ServiceClientHttpServiceBase, IIBDService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/ibd";

        public IBDService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public bool AddBroker(int userId, int brokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"UserId", userId },
                {"BrokerId", brokerId }
            };

            return Post($"{BaseIdentityUrl}", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AddBrokerAsync(int userId, int brokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"UserId", userId },
                {"BrokerId", brokerId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}", request);
        }

        /// <inheritdoc/>
        public bool AssignParentOrganization(int parentId, int childId)
        {
            var request = new Dictionary<string, int>
            {
                {"ParentId", parentId },
                {"ChildId", childId }
            };

            return Post($"{BaseIdentityUrl}/assignparentorganization", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AssignParentOrganizationAsync(int parentId, int childId)
        {
            var request = new Dictionary<string, int>
            {
                {"ParentId", parentId },
                {"ChildId", childId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}/assignparentorganization", request);
        }

        /// <inheritdoc/>
        public bool AddUsersToBroker(int brokerId, List<int> userIdList)
        {
            var request = new AddUsersToBrokerRequest
            {
                BrokerId = brokerId,
                UserIds = userIdList
            };

            return Post($"{BaseIdentityUrl}/adduserstobroker", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AddUsersToBrokerAsync(int brokerId, List<int> userIdList)
        {
            var request = new AddUsersToBrokerRequest
            {
                BrokerId = brokerId,
                UserIds = userIdList
            };

            return PostRequestAsync($"{BaseIdentityUrl}/adduserstobroker", request);
        }

        /// <inheritdoc/>
        public bool RemoveBrokerUserRelationship(int userId, int brokerId)
        {
            return Delete($"{BaseIdentityUrl}?UserId={userId}&BrokerId={brokerId}", new Dictionary<string, string>());
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> RemoveBrokerUserRelationshipAsync(int userId, int brokerId)
        {
            return DeleteRequestAsync($"{BaseIdentityUrl}?UserId={userId}&BrokerId={brokerId}");
        }

        /// <inheritdoc/>
        public bool RemoveAllUsersForBroker(int brokerId)
        {
            return Delete($"{BaseIdentityUrl}/removeallbrokerusers/{brokerId}", new Dictionary<string, string>());
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> RemoveAllUsersForBrokerAsync(int brokerId)
        {
            return DeleteRequestAsync($"{BaseIdentityUrl}/removeallbrokerusers/{brokerId}", new Dictionary<string, string>());
        }

        /// <inheritdoc/>
        public bool ChangeBrokerForUser(int userId, int currentBrokerId, int newBrokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"UserId", userId },
                {"CurrentBrokerId", currentBrokerId },
                {"NewBrokerId", newBrokerId }
            };

            return Post($"{BaseIdentityUrl}/changebrokerforuser", request);
        }
        /// <inheritdoc/>
        public Task<HttpServiceResult> ChangeBrokerForUserAsync(int userId, int currentBrokerId, int newBrokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"UserId", userId },
                {"CurrentBrokerId", currentBrokerId },
                {"NewBrokerId", newBrokerId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}/changebrokerforuser", request);
        }

        /// <inheritdoc/>
        public bool ChangeBrokerForAllUsers(int currentBrokerId, int newBrokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"CurrentBrokerId", currentBrokerId },
                {"NewBrokerId", newBrokerId }
            };

            return Post($"{BaseIdentityUrl}/ChangeBrokerForAllUsers", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> ChangeBrokerForAllUsersAsync(int currentBrokerId, int newBrokerId)
        {
            var request = new Dictionary<string, int>
            {
                {"CurrentBrokerId", currentBrokerId },
                {"NewBrokerId", newBrokerId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}/ChangeBrokerForAllUsers", request);
        }

        /// <inheritdoc/>
        public GetOrganizationIdResponse GetUserOrganizationId(int userId)
        {
            return Get<GetOrganizationIdResponse>($"{BaseIdentityUrl}/Organization/{userId}");
        }

        /// <inheritdoc/>
        public Task<GetOrganizationIdResponse> GetUserOrganizationIdAsync(int userId)
        {
            return GetAsync<GetOrganizationIdResponse>($"{BaseIdentityUrl}/Organization/{userId}");
        }

        /// <inheritdoc/>
        public GetOrganizationIdResponse GetOrganizationId(int userId)
        {
            return Get<GetOrganizationIdResponse>($"{BaseIdentityUrl}/organizationId/{userId}");
        }

        public Task<GetOrganizationIdResponse> GetOrganizationIdAsync(int userId)
        {
            return GetAsync<GetOrganizationIdResponse>($"{BaseIdentityUrl}/organizationId/{userId}");
        }

        /// <inheritdoc/>
        public bool AssignParentOrganizationUser(int parentId, int childId)
        {
            var request = new Dictionary<string, int>
            {
                {"ParentId", parentId },
                {"ChildId", childId }
            };

            return Post($"{BaseIdentityUrl}/assignparentorganizationuser", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AssignParentOrganizationUserAsync(int parentId, int childId)
        {
            var request = new Dictionary<string, int>
            {
                {"ParentId", parentId },
                {"ChildId", childId }
            };

            return PostRequestAsync($"{BaseIdentityUrl}/assignparentorganizationuser", request);
        }

        /// <inheritdoc/>
        public bool AssignRepsFromRIAId(int UserId, string RiaId)
        {
            return Get($"{BaseIdentityUrl}/assignrepsfromriaid?userid={UserId}&riaid={RiaId}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> AssignRepsFromRIAIdAsync(int UserId, string RiaId)
        {
            return GetRequestAsync($"{BaseIdentityUrl}/assignrepsfromriaid?userid={UserId}&riaid={RiaId}");
        }

        private string BuildURLQuery(int? UdbUserId, string AccountId, string AccountType, string RIAId)
        {
            List<string> filters = new List<string>();
            if (UdbUserId != null && UdbUserId != 0)
                filters.Add($"userid={UdbUserId}");
            if (!string.IsNullOrEmpty(AccountId))
                filters.Add($"accountid={AccountId}");
            if (!string.IsNullOrEmpty(AccountType))
                filters.Add($"accounttype={AccountType}");
            if (!string.IsNullOrEmpty(RIAId))
                filters.Add($"riaid={RIAId}");
            return filters.Count != 0 ? "?" + string.Join("&", filters) : null;
        }

        public Task<HttpServiceResult<IEnumerable<FirmRepDto>>> GetUserFirmsAndReps(LibertyAccountDataDto[] request)
        {
            return PostRequestAsync<LibertyAccountDataDto[], IEnumerable<FirmRepDto>>($"{BaseIdentityUrl}/organizationcontact", request);
        }
    }
}
