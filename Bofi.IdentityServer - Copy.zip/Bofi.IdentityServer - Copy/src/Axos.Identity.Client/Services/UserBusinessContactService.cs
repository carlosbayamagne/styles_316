﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;

namespace Axos.Identity.Client.Services
{
    public class UserBusinessContactService : ServiceClientHttpServiceBase, IUserBusinessContactService
    {

        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseUrl = "api/BusinessContact";

        public UserBusinessContactService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public bool AddBusinessContact(int userId, UserBusinessContactsDto userBusinessContacts) =>
            (bool)Post<object, UserBusinessContactsDto>($"{BaseUrl}/{userId}", userBusinessContacts);

        public bool DeleteBusinessContact(int userId, int organizationId) =>
            (bool)Delete<object>($"{BaseUrl}/{userId}/{organizationId}");

        public UserBusinessContactsDto GetBusinessContact(int userId, int organizationId) =>
            Get<UserBusinessContactsDto>($"{BaseUrl}/{userId}/{organizationId}");

        public List<UserBusinessContactsDto> GetBusinessContacts(int userId) =>
            Get<List<UserBusinessContactsDto>>($"{BaseUrl}/{userId}");

        public bool UpdateBusinessContact(int userId, UserBusinessContactsDto userBusinessContacts) =>
            (bool)Put<object, UserBusinessContactsDto>($"{BaseUrl}/{userId}", userBusinessContacts);
    }
}
