﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models.Experian;
using Axos.Identity.Client.Models.Ekata.Requests;
using Axos.Identity.Client.Models.Ekata.Response;
using Axos.Identity.Client.Models.IdentificationID;
using Axos.Identity.Client.Models.Mitek;
using Axos.Identity.Client.Services.Interfaces;

using Axos.Integration.Core.DTOs;
using Axos.Integration.InstantId.Models;
using Axos.Integration.MiTek.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ExperianResponse = Axos.Identity.Client.Models.Experian.ServiceResult<Axos.Identity.Client.Models.Experian.PreciseId.ResponseModel>;
using System.Security.Authentication;

namespace Axos.Identity.Client.Services
{
    public class IdentificationService : ServiceClientHttpServiceBase, IIdentificationService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private readonly string _callingApp;
        public IdentificationService(string environment, string username, string password, string callingApp = null) : base(environment, username, password)
        {
            _callingApp = callingApp ?? "Unknown";
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        #region Mitek
        public MiTekServiceResponse ValidateId(string front, string back)
        {
            MiTekIdDocument mid = new MiTekIdDocument
            {
                DocumentType = "IdDocument",
                Front = front,
                Back = back
            };
            string url = $"api/identification/validateid";
            if (!string.IsNullOrEmpty(_callingApp)) url += "?callingApplication=" + _callingApp;
            return Post<MiTekServiceResponse, MiTekIdDocument>(url, mid);
        }
        public Task<HttpServiceResult<MiTekServiceResponse>> ValidateIdAsync(string front, string back)
        {
            var mid = new MiTekIdDocument
            {
                DocumentType = "IdDocument",
                Front = front,
                Back = back
            };

            var url = $"api/identification/validateid";

            if (!string.IsNullOrEmpty(_callingApp)) url += $"?callingApplication={ _callingApp}";

            return PostRequestAsync<MiTekIdDocument, MiTekServiceResponse>(url, mid);
        }

        public MiTekServiceResponse ValidateIdAndSelfie(string front, string back, string selfie)
        {
            MiTekIdDocument mid = new MiTekIdDocument
            {
                DocumentType = "IdDocument",
                Front = front,
                Back = back
            };
            MiTekIdDocument mid2 = new MiTekIdDocument
            {
                DocumentType = "Selfie",
                Front = selfie
            };
            List<MiTekIdDocument> midList = new List<MiTekIdDocument>
            {
                mid,
                mid2
            };

            string url = $"api/identification/validateidandselfie";
            if (!String.IsNullOrEmpty(_callingApp)) url += "?callingApplication=" + _callingApp;
            return Post<MiTekServiceResponse, List<MiTekIdDocument>>(url, midList);
        }
        public Task<HttpServiceResult<MiTekServiceResponse>> ValidateIdAndSelfieAsync(string front, string back, string selfie)
        {
            var mid = new MiTekIdDocument
            {
                DocumentType = "IdDocument",
                Front = front,
                Back = back
            };
            var mid2 = new MiTekIdDocument
            {
                DocumentType = "Selfie",
                Front = selfie
            };
            var midList = new List<MiTekIdDocument>
            {
                mid,
                mid2
            };

            var url = $"api/identification/validateidandselfie";

            if (!string.IsNullOrEmpty(_callingApp)) url += $"?callingApplication={ _callingApp}";

            return PostRequestAsync<List<MiTekIdDocument>, MiTekServiceResponse>(url, midList);
        }
        
        public async Task<HttpServiceResult<MiTekServiceResponse>> AuthenticateDocumentsAsync(MitekModel mitekModel)
        {
            string url = $"api/identification/authenticatedocuments";
            if (!String.IsNullOrEmpty(_callingApp)) url += "?callingApplication=" + _callingApp;

            return await PostRequestAsync<MitekModel, MiTekServiceResponse>(url, mitekModel);
        }
        public MiTekServiceResponse AuthenticateDocuments(MitekModel mitekModel)
        {
            string url = $"api/identification/authenticatedocuments";
            if (!String.IsNullOrEmpty(_callingApp)) url += "?callingApplication=" + _callingApp;

            return Post<MiTekServiceResponse, MitekModel>(url, mitekModel);
        }       
        #endregion

        public IdentificationIDVQuestionsResponse GetIDVQuestions(IdentificationIDVQuestionsRequest request)
        {
            return Post<IdentificationIDVQuestionsResponse, IdentificationIDVQuestionsRequest>($"api/identification/idvquestions", request);
        }

        public Task<HttpServiceResult<IdentificationIDVQuestionsResponse>> GetIDVQuestionsAsync(IdentificationIDVQuestionsRequest request)
            => PostRequestAsync<IdentificationIDVQuestionsRequest, IdentificationIDVQuestionsResponse>("api/identification/idvquestions", request);

        public IdentificationIDVAnswersResponse PostIDVAnswers(IdentificationIDVAnswersRequest request)
        {
            return Post<IdentificationIDVAnswersResponse, IdentificationIDVAnswersRequest>($"api/identification/idvanswers", request);
        }

        public Task<HttpServiceResult<IdentificationIDVAnswersResponse>> PostIDVAnswersAsync(IdentificationIDVAnswersRequest request)
            => PostRequestAsync<IdentificationIDVAnswersRequest, IdentificationIDVAnswersResponse>("api/identification/idvanswers", request);

        public IdentificationIDVProviderResponse PostIDVProviderRequest(IdentificationIDVProviderRequest request)
        {
            return Post<IdentificationIDVProviderResponse, IdentificationIDVProviderRequest>($"api/identification/idvrequest", request);
        }

        public Task<HttpServiceResult<IdentificationIDVProviderResponse>> PostIDVProviderRequestAsync(IdentificationIDVProviderRequest request)
            => PostRequestAsync<IdentificationIDVProviderRequest, IdentificationIDVProviderResponse>("api/identification/idvrequest", request);

        public InstantIdResponse ValidateInstantId(InstantIdSearchBy searchBy, GLBPurpose glbPurpose, DLPurpose dlPurpose)
        {
            string url = $"api/identification/instantid?glbPurpose={(int)glbPurpose}&dlPurpose={(int)dlPurpose}";
            return Post<InstantIdResponse, InstantIdSearchBy>(url, searchBy);
        }

        #region Experian
        public ExperianResponse GetIdaQuestions(PersonalInformation request)
            => Post<ExperianResponse, PersonalInformation>($"api/identification/getidaquestions", request);

        public Task<HttpServiceResult<ExperianResponse>> GetIdaQuestionsAsync(PersonalInformation request)
            => PostRequestAsync<PersonalInformation, ExperianResponse>("api/identification/getidaquestions", request);

        public ExperianResponse SendIdaAnswers(SendIdaAnswersRequest request)
            => Post<ExperianResponse, SendIdaAnswersRequest>($"api/identification/sendidaanswers", request);

        public Task<HttpServiceResult<ExperianResponse>> SendIdaAnswersAsync(SendIdaAnswersRequest request)
            => PostRequestAsync<SendIdaAnswersRequest, ExperianResponse>("api/identification/sendidaanswers", request);

        public ExperianResponse ExecuteIdv(PersonalInformation request)
           => Post<ExperianResponse, PersonalInformation>($"api/identification/executeidv", request);

        public Task<HttpServiceResult<ExperianResponse>> ExecuteIdvAsync(PersonalInformation request)
            => PostRequestAsync<PersonalInformation, ExperianResponse>("api/identification/executeidv", request);       

        #endregion

        public IdentityCheckResponseV33 EkataIdentityCheck(IdentityCheckRequestV33 request, bool useTestConfig = false)
        {
            string url = $"api/identification/ekata?useTestConfig={useTestConfig}";
            return Post<IdentityCheckResponseV33, IdentityCheckRequestV33>(url, request);
        }

        public Task<HttpServiceResult<IdentityCheckResponseV33>> EkataIdentityCheckAsync(IdentityCheckRequestV33 request, bool useTestConfig = false)
        {
            string url = $"api/identification/ekata?useTestConfig={useTestConfig}";
            return PostRequestAsync<IdentityCheckRequestV33, IdentityCheckResponseV33>(url, request, new Dictionary<string, string>());
        }
    }
}
