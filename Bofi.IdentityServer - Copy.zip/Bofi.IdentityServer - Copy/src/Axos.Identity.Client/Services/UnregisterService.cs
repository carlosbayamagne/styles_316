﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.Request;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class UnregisterService : ServiceClientHttpServiceBase, IUnregisterService
    {

        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseIdentityUrl = "api/unregistereduser";

        public UnregisterService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        public IEnumerable<UnregisteredUser> PreloadUsers(UnregisterUserPack request)
        {
            return Post<IEnumerable<UnregisteredUser>, UnregisterUserPack>($"{BaseIdentityUrl}/preload/users", request);
        }

        public Task<HttpServiceResult<IList<UnregisteredUser>>> PreloadUsersAsync(UnregisterUserPack users)
            => PostRequestAsync<UnregisterUserPack, IList<UnregisteredUser>>($"{BaseIdentityUrl}/preload/users", users);

        public void SetPreloadStatus(User preloadUser)
        {
            Post<Object, User>($"{BaseIdentityUrl}/preload/setuserstatus", preloadUser);
        }

        public Task<HttpServiceResult> SetPreloadStatusAsync(User preloadUser)
            => PostRequestAsync($"{BaseIdentityUrl}/preload/setuserstatus", preloadUser);

        public User FindOrCreateFromJHAByCIF(string cif, bool waitForSync = false)
        {
            return Post<User, JHExistingUserWithCIFRequest>($"{BaseIdentityUrl}/users/FindOrCreateFromJHAByCIF/{waitForSync}",
                new JHExistingUserWithCIFRequest { CIF = cif });
        }

        public Task<HttpServiceResult<User>> FindOrCreateFromJhaByCifAsync(string cif, bool waitForSync = false)
            => PostRequestAsync<JHExistingUserWithCIFRequest, User>($"{BaseIdentityUrl}/users/FindOrCreateFromJHAByCIF/{waitForSync}",
                new JHExistingUserWithCIFRequest { CIF = cif });

        public IEnumerable<User> FindOrCreateFromJHAByPhone(string phoneNumber, bool waitForSync = false)
        {
            return Post<IEnumerable<User>, JHExistingUserWithPhoneRequest>($"{BaseIdentityUrl}/users/FindOrCreateFromJHAByPhone/{waitForSync}",
                new JHExistingUserWithPhoneRequest { PhoneNumber = phoneNumber });
        }

        public Task<HttpServiceResult<IList<User>>> FindOrCreateFromJhaByPhoneAsync(string phoneNumber, bool waitForSync = false)
            => PostRequestAsync<JHExistingUserWithPhoneRequest, IList<User>>($"{BaseIdentityUrl}/users/FindOrCreateFromJHAByPhone/{waitForSync}",
                new JHExistingUserWithPhoneRequest { PhoneNumber = phoneNumber });
    }
}
