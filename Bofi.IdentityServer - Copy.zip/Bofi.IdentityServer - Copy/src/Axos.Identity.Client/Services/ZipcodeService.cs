﻿using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class ZipcodeService : ServiceClientHttpServiceBase, IZipcodeService
    {

        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BASEIDENTITYURL = "api/zipcodes";

        public ZipcodeService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public ZipcodeInformation GetZipcodeInformation(string zipcode)
        {
            return Get<ZipcodeInformation>($"{BASEIDENTITYURL}/{zipcode}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<ZipcodeInformation>> GetZipcodeInformationAsync(string zipcode)
            => GetRequestAsync<ZipcodeInformation>($"{BASEIDENTITYURL}/{zipcode}");

        /// <inheritdoc/>
        public CityStateResponse GetZipcodeUSPSInformation(string zipcode)
        {
            return Get<CityStateResponse>($"{BASEIDENTITYURL}/usps/{zipcode}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult<CityStateResponse>> GetZipcodeUSPSInformationAsync(string zipcode)
            => GetRequestAsync<CityStateResponse>($"{BASEIDENTITYURL}/usps/{zipcode}");
    }
}
