﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Integration.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    public class MessageService : ServiceClientHttpServiceBase, IMessageService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseMessageUrl = "api/message";

        public MessageService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public bool SendForgotPasswordEmail(string userName, string unlockURL, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"Username", userName},
                {"ApplicationUrl", unlockURL},
                 {"Brand", brand}
            };
            return Post($"{BaseMessageUrl}/forgotpassword", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendForgotPasswordEmailAsync(string userName, string unlockURL, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"Username", userName},
                {"ApplicationUrl", unlockURL},
                 {"Brand", brand}
            };
            return PostRequestAsync($"{BaseMessageUrl}/forgotpassword", request);
        }

        /// <inheritdoc/>
        public bool SendUnlockAccountEmail(string userName, string unlockURL, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"Username", userName},
                {"ApplicationUrl", unlockURL},
                {"Brand", brand}
            };

            return Post($"{BaseMessageUrl}/unlockaccount", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendUnlockAccountEmailAsync(string userName, string unlockURL, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"Username", userName},
                {"ApplicationUrl", unlockURL},
                {"Brand", brand}
            };

            return PostRequestAsync($"{BaseMessageUrl}/unlockaccount", request);
        }

        /// <inheritdoc/>
        public bool SendOtp(string userName, DeliveryMethod deliveryMethod, string otp, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"UserName", userName},
                {"DeliveryMethod", deliveryMethod.ToString()},
                {"Otp", otp},
                {"Brand", brand}
            };

            return Post($"{BaseMessageUrl}/otp", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendOtpAsync(string userName, DeliveryMethod deliveryMethod, string otp, string brand = null)
        {
            var request = new Dictionary<string, string>
            {
                {"UserName", userName},
                {"DeliveryMethod", deliveryMethod.ToString()},
                {"Otp", otp},
                {"Brand", brand}
            };

            return PostRequestAsync($"{BaseMessageUrl}/otp", request);
        }

        /// <inheritdoc/>
        public bool SendChangeSecurityQuestionsEmail(string username, string brand = null)
        {
            return Get($"{BaseMessageUrl}/securityquestions/{username}?Brand={brand}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendChangeSecurityQuestionsEmailAsync(string username, string brand = null)
            => GetRequestAsync($"{BaseMessageUrl}/securityquestions/{username}?Brand={brand}");

        /// <inheritdoc/>
        public bool SendChangePasswordEmail(string username, string brand = null)
        {
            return Get($"{BaseMessageUrl}/changepassword/{username}?Brand={brand}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendChangePasswordEmailAsync(string username, string brand = null)
            => GetRequestAsync($"{BaseMessageUrl}/changepassword/{username}?Brand={brand}");

        /// <inheritdoc/>
        public bool SendChangeProfileEmail(string username, string brand = null)
        {
            return Get($"{BaseMessageUrl}/profile/email/{username}?Brand={brand}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendChangeProfileEmailAsync(string username, string brand = null)
            => GetRequestAsync($"{BaseMessageUrl}/profile/email/{username}?Brand={brand}");

        /// <inheritdoc/>
        public bool SendChangeProfilePhone(string username, string brand = null)
        {
            return Get($"{BaseMessageUrl}/profile/phone/{username}?Brand={brand}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendChangeProfilePhoneAsync(string username, string brand = null)
            => GetRequestAsync($"{BaseMessageUrl}/profile/phone/{username}?Brand={brand}");

        /// <inheritdoc/>
        public bool SendChangeProfileAddress(string username, string brand = null)
        {
            return Get($"{BaseMessageUrl}/profile/address/{username}?Brand={brand}");
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendChangeProfileAddressAsync(string username, string brand = null)
            => GetRequestAsync($"{BaseMessageUrl}/profile/address/{username}?Brand={brand}");

        #region Realtor method (non-olb)
        /// <inheritdoc/>
        public void SendMortgageLinkEmail(string username, string applicationName, string brand)
        {
            var request = new MortgageLinkRequest
            {
                ApplicationName = applicationName,
                Brand = brand,
                UserName = username
            };

            Post($"{BaseMessageUrl}/mortgagelink", request);
        }

        /// <inheritdoc/>
        public Task<HttpServiceResult> SendMortgageLinkEmailAsync(string username, string applicationName, string brand)
        {
            var request = new MortgageLinkRequest
            {
                ApplicationName = applicationName,
                Brand = brand,
                UserName = username
            };

            return PostRequestAsync($"{BaseMessageUrl}/mortgagelink", request);
        }
        #endregion

    }
}
