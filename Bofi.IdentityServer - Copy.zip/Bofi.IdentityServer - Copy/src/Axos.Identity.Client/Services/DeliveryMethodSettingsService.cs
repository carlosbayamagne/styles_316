﻿using Axos.Identity.Client.Constants;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Services.Interfaces;
using Axos.Integration.Core.DTOs;
using System;
using System.Security.Authentication;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Services
{
    /// <summary>
    ///
    /// </summary>
    /// <seealso cref="Axos.Identity.Client.Http.ServiceClientHttpServiceBase" />
    /// <seealso cref="Axos.Identity.Client.Services.Interfaces.IDeliveryMethodSettingsService" />
    public class DeliveryMethodSettingsService : ServiceClientHttpServiceBase, IDeliveryMethodSettingsService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        /// <summary>
        /// Gets the name of the service configuration.
        /// </summary>
        /// <returns></returns>
        protected override string GetServiceConfigName() { return "IdentityService"; }

        /// <summary>
        /// Gets the local service URL.
        /// </summary>
        /// <returns></returns>
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }

        /// <summary>
        /// Gets the token.
        /// </summary>
        /// <returns></returns>
        protected override string GetToken() { return _token; }

        /// <summary>
        /// Sets the token.
        /// </summary>
        /// <param name="token">The token.</param>
        protected override void SetToken(string token) { _token = token; }

        /// <summary>
        /// Gets the refresh time.
        /// </summary>
        /// <returns></returns>
        protected override DateTime GetRefreshTime() { return _refreshTime; }

        /// <summary>
        /// Sets the refresh time.
        /// </summary>
        /// <param name="time">The time.</param>
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }

        /// <summary>
        /// The token
        /// </summary>
        private static string _token = null;

        /// <summary>
        /// The refresh time
        /// </summary>
        private static DateTime _refreshTime = new DateTime(1, 1, 1);

        // copy the above codeblock to all instances of HttpServiceBase

        /// <summary>
        /// Initializes a new instance of the <see cref="DeliveryMethodSettingsService"/> class.
        /// </summary>
        /// <param name="environment">The environment.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public DeliveryMethodSettingsService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc/>
        public DeliveryMethodSettingsUpdate Add(DeliveryMethodSettings settings)
            => Post<DeliveryMethodSettingsUpdate, DeliveryMethodSettings>(UrlConstants.DeliveryMethodUrl, settings);

        /// <inheritdoc/>
        public Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> AddSettingsAsync(DeliveryMethodSettings settings)
            => PostRequestAsync<DeliveryMethodSettings, DeliveryMethodSettingsUpdate>(UrlConstants.DeliveryMethodUrl, settings);

        /// <inheritdoc/>
        public DeliveryMethodSettingsUpdate GetSettings(int userId)
            => Get<DeliveryMethodSettingsUpdate>($"{UrlConstants.DeliveryMethodUrl}/{userId}");

        /// <inheritdoc/>
        public Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> GetSettingsAsync(int userId)
            => GetRequestAsync<DeliveryMethodSettingsUpdate>($"{UrlConstants.DeliveryMethodUrl}/{userId}");

        /// <inheritdoc/>
        public DeliveryMethodSettingsUpdate Update(DeliveryMethodSettingsUpdate settings)
            => Put<DeliveryMethodSettingsUpdate, DeliveryMethodSettings>(UrlConstants.DeliveryMethodUrl, settings);

        /// <inheritdoc/>
        public Task<HttpServiceResult<DeliveryMethodSettingsUpdate>> UpdateSettingsAsync(DeliveryMethodSettingsUpdate settings)
            => PutRequestAsync<DeliveryMethodSettings, DeliveryMethodSettingsUpdate>(UrlConstants.DeliveryMethodUrl, settings);
    }
}