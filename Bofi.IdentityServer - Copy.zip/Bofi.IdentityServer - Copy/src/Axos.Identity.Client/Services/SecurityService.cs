﻿using Axos.Identity.Client.Contracts;
using Axos.Identity.Client.Enums;
using Axos.Identity.Client.Http;
using Axos.Identity.Client.Models;
using Axos.Identity.Client.Models.Request;
using Axos.Identity.Client.Models.Response;
using Axos.Integration.Core.DTOs;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Threading.Tasks;
using System.Web;

namespace Axos.Identity.Client.Services
{
    public class SecurityService : ServiceClientHttpServiceBase, ISecurityService
    {
        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        protected override string GetServiceConfigName() { return "IdentityService"; }
        protected override string GetLocalServiceUrl() { return LocalIdentityUrl; }
        protected override string GetToken() { return _token; }
        protected override void SetToken(string token) { _token = token; }
        protected override DateTime GetRefreshTime() { return _refreshTime; }
        protected override void SetRefreshTime(DateTime time) { _refreshTime = time; }
        static string _token = null;
        static DateTime _refreshTime = new DateTime(1, 1, 1);
        // copy the above codeblock to all instances of HttpServiceBase

        private const string BaseSecurityUrl = "api/security";

        public SecurityService(string environment, string username, string password) : base(environment, username, password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                throw new InvalidCredentialException("The provided User name and/or Password are null or empty");
        }

        /// <inheritdoc />
        public async Task<bool> RecoverUsernameAsync(string email, string brand = null, string subBrand = null, Dictionary<string, string> tokens = null)
        {
            var url = $"{BaseSecurityUrl}/recover/username/{email}";
            if (brand != null)
                url = QueryHelpers.AddQueryString(url, "Brand", brand);
            if(subBrand != null)
                url = QueryHelpers.AddQueryString(url, "SubBrand", subBrand);
            if(tokens != null)
                url = QueryHelpers.AddQueryString(url, tokens);
            
            return await GetAsync(url);
        }

        #region Realtor overrides (non-udb)

        public void RecoverUsername(string email, string applicationName, string brand, string subBrand = null, Dictionary<string, string> tokens = null)
        {
            var request = new ForgotUsernameRequest
            {
                ApplicationName = applicationName,
                Brand = brand,
                Email = email,
                SubBrand = subBrand,
                Tokens = tokens
            };

            Post($"{BaseSecurityUrl}/recover/username", request);
        }

        public Task<HttpServiceResult> RecoverUsernameAsync(string email, string appName, string brand, string subBrand = null, Dictionary<string, string> tokens = null)
        {
            var request = new ForgotUsernameRequest
            {
                ApplicationName = appName,
                Brand = brand,
                Email = email,
                SubBrand = subBrand,
                Tokens = tokens
            };

            return PostRequestAsync($"{BaseSecurityUrl}/recover/username", request);
        }

        public void ResetPassword(int userId, string applicationUrl, string applicationName, string brand)
        {
            var request = new ResetPasswordRequest
            {
                ApplicationName = applicationName,
                Brand = brand,
                ApplicationUrl = applicationUrl,
                UserId = userId
            };

            Post($"{BaseSecurityUrl}/resetpassword", request);
        }

        public Task<HttpServiceResult> ResetPasswordAsync(int userId, string appUrl, string appName, string brand)
        {
            var request = new ResetPasswordRequest
            {
                ApplicationName = appName,
                Brand = brand,
                ApplicationUrl = appUrl,
                UserId = userId
            };

            return PostRequestAsync($"{BaseSecurityUrl}/resetpassword", request);
        }

        public string SendConfirmationCode(int userId, DeliveryMethod deliveryMethod, string applicationName,
            string brand)
        {
            var request = new ConfirmationCodeRequest
            {
                ApplicationName = applicationName,
                Brand = brand,
                UserId = userId,
                DeliveryMethod = deliveryMethod
            };

            return Post<string, ConfirmationCodeRequest>($"{BaseSecurityUrl}/confirmationcode", request);
        }

        public Task<HttpServiceResult<string>> SendConfirmationCodeAsync(int userId, DeliveryMethod deliveryMethod, string appName,
            string brand)
        {
            var request = new ConfirmationCodeRequest
            {
                ApplicationName = appName,
                Brand = brand,
                UserId = userId,
                DeliveryMethod = deliveryMethod
            };

            return PostRequestAsync<ConfirmationCodeRequest, string>($"{BaseSecurityUrl}/confirmationcode", request);
        }

        #endregion

        #region password mgmt

        public bool ResetPassword(ResetPasswordRequest request, bool isAdminReset = false)
        {
            return Post($"{BaseSecurityUrl}/reset/{isAdminReset}/password", request);
        }

        public Task<HttpServiceResult> ResetPasswordAsync(ResetPasswordRequest request, bool isAdminReset = false)
            => PostRequestAsync($"{BaseSecurityUrl}/reset/{isAdminReset}/password", request);

        public bool EnablePassword(ResetPasswordRequest request)
        {
            return Post($"{BaseSecurityUrl}/enable/password", request);
        }

        public Task<HttpServiceResult> EnablePasswordAsync(ResetPasswordRequest request)
            => PostRequestAsync($"{BaseSecurityUrl}/enable/password", request);

        public string ChangePassword(ChangePasswordRequest request)
        {
            return Put<string, ChangePasswordRequest>($"{BaseSecurityUrl}/password", request);
        }

        public Task<HttpServiceResult<string>> ChangePasswordAsync(ChangePasswordRequest request)
            => PutRequestAsync<ChangePasswordRequest, string>($"{BaseSecurityUrl}/password", request);

        #endregion

        #region security questions

        public string ChangeSecurityQuestions(IEnumerable<ChallengeQuestion> request, string username, string brand = null)
        {
            return Post<string, IEnumerable<ChallengeQuestion>>($"{BaseSecurityUrl}/{username}/questions?Brand={brand}", request);
        }

        public Task<HttpServiceResult<string>> ChangeSecurityQuestionsAsync(IEnumerable<ChallengeQuestion> request, string username, string brand = null)
            => PostRequestAsync<IEnumerable<ChallengeQuestion>, string>($"{BaseSecurityUrl}/{username}/questions?Brand={brand}", request);

        public QuestionChallengeResponse ChallengeUser(string username)
        {
            return Get<QuestionChallengeResponse>($"{BaseSecurityUrl}/{username}/questions/challenge");
        }

        public Task<HttpServiceResult<QuestionChallengeResponse>> ChallengeUserAsync(string username)
            => GetRequestAsync<QuestionChallengeResponse>($"{BaseSecurityUrl}/{username}/questions/challenge");

        public VerificationResponse VerifyAnswers(IEnumerable<ChallengeQuestion> request)
        {
            return Post<VerificationResponse, IEnumerable<ChallengeQuestion>>($"{BaseSecurityUrl}/questions/verify",
                request);
        }

        public Task<HttpServiceResult<VerificationResponse>> VerifyAnswersAsync(IEnumerable<ChallengeQuestion> request)
            => PostRequestAsync<IEnumerable<ChallengeQuestion>, VerificationResponse>($"{BaseSecurityUrl}/questions/verify",
                request);

        public QuestionsConfigurationResponse GetSecurityQuestions()
        {
            return Get<QuestionsConfigurationResponse>($"{BaseSecurityUrl}/questions");
        }

        public Task<HttpServiceResult<QuestionsConfigurationResponse>> GetSecurityQuestionsAsync()
            => GetRequestAsync<QuestionsConfigurationResponse>($"{BaseSecurityUrl}/questions");

        public QuestionsConfigurationResponse GetUserQuestions(string username)
        {
            return Get<QuestionsConfigurationResponse>($"{BaseSecurityUrl}/{username}/questions");
        }

        public Task<HttpServiceResult<QuestionsConfigurationResponse>> GetUserQuestionsAsync(string username)
            => GetRequestAsync<QuestionsConfigurationResponse>($"{BaseSecurityUrl}/{username}/questions");

        public EditionResponse SetSecurityQuestions(string username, IEnumerable<ChallengeQuestion> request)
        {
            return Post<EditionResponse, IEnumerable<ChallengeQuestion>>($"{BaseSecurityUrl}/{username}/questions/set",
                request);
        }

        public Task<HttpServiceResult<EditionResponse>> SetSecurityQuestionsAsync(string username, IEnumerable<ChallengeQuestion> request)
            => PostRequestAsync<IEnumerable<ChallengeQuestion>, EditionResponse>($"{BaseSecurityUrl}/{username}/questions/set",
                request);

        #endregion

        #region risk evaluation

        public RiskResponse EvaluateDevice(RiskRequest request)
        {
            return Post<RiskResponse, RiskRequest>($"{BaseSecurityUrl}/risk/evaluate", request);
        }

        public Task<HttpServiceResult<RiskResponse>> EvaluateDeviceAsync(RiskRequest request)
            => PostRequestAsync<RiskRequest, RiskResponse>($"{BaseSecurityUrl}/risk/evaluate", request);

        public RiskResponse PostEvaluationAnalysis(RiskRequest request, bool challengePassed)
        {
            return Post<RiskResponse, RiskRequest>($"{BaseSecurityUrl}/risk/postevaluation/{challengePassed}", request);
        }

        public Task<HttpServiceResult<RiskResponse>> PostEvaluationAnalysisAsync(RiskRequest request, bool challengePassed)
            => PostRequestAsync<RiskRequest, RiskResponse>($"{BaseSecurityUrl}/risk/postevaluation/{challengePassed}", request);

        #endregion

        #region otp

        public OtpChallengeResponse GetOTP(OTPRequest request)
        {
            return Post<OtpChallengeResponse, OTPRequest>($"{BaseSecurityUrl}/getotp", request);
        }

        public Task<HttpServiceResult<OtpChallengeResponse>> GetOtpAsync(OTPRequest request)
            => PostRequestAsync<OTPRequest, OtpChallengeResponse>($"{BaseSecurityUrl}/getotp", request);

        public OtpChallengeResponse GetOTP(OTPSmsRequest request)
        {
            return Post<OtpChallengeResponse, OTPSmsRequest>($"{BaseSecurityUrl}/sms/getotp", request);
        }

        public Task<HttpServiceResult<OtpChallengeResponse>> GetOtpAsync(OTPSmsRequest request)
            => PostRequestAsync<OTPSmsRequest, OtpChallengeResponse>($"{BaseSecurityUrl}/sms/getotp", request);


        public OtpChallengeResponse GetOTPNoUser(OTPSmsNoUserRequest request)
        {
            return Post<OtpChallengeResponse, OTPSmsNoUserRequest>($"{BaseSecurityUrl}/sms/getotpnouser", request);
        }

        public Task<HttpServiceResult<OtpChallengeResponse>> GetOtpNoUserAsync(OTPSmsNoUserRequest request)
            => PostRequestAsync<OTPSmsNoUserRequest, OtpChallengeResponse>($"{BaseSecurityUrl}/sms/getotpnouser", request);


        public VerificationResponse ValidateOTP(ValidateOtpRequest request)
        {
            return Post<VerificationResponse, ValidateOtpRequest>($"{BaseSecurityUrl}/validateotp", request);
        }

        public Task<HttpServiceResult<VerificationResponse>> ValidateOtpAsync(ValidateOtpRequest request)
            => PostRequestAsync<ValidateOtpRequest, VerificationResponse>($"{BaseSecurityUrl}/validateotp", request);

        public VerificationResponse ValidateOTPNoUser(ValidateOtpNoUserRequest request)
        {
            return Post<VerificationResponse, ValidateOtpNoUserRequest>($"{BaseSecurityUrl}/validateotpnouser", request);
        }

        public Task<HttpServiceResult<VerificationResponse>> ValidateOtpNoUserAsync(ValidateOtpNoUserRequest request)
            => PostRequestAsync<ValidateOtpNoUserRequest, VerificationResponse>($"{BaseSecurityUrl}/validateotpnouser", request);

        public GASignupResponse GetGoogleAuthenticatorStringForUser(string username)
        {
            return Get<GASignupResponse>($"{BaseSecurityUrl}/GetGAString?username={username}");
        }

        public bool ValidateGoogleAuthenticatorCodeForUser(string username, string code)
        {
            GACodeRequest req = new GACodeRequest()
            {
                Username = username,
                GACode = code
            };
            var r = PostRequestAsync<GACodeRequest, bool>($"{BaseSecurityUrl}/ValidateGACode", req).GetAwaiter().GetResult();
            return r.Data;
        }

        public bool ResetGoogleAuthenticatorForUser(string username)
        {
            GACodeRequest req = new GACodeRequest()
            {
                Username = username
            };
            var r = PostRequestAsync<GACodeRequest, bool>($"{BaseSecurityUrl}/ResetGA", req).GetAwaiter().GetResult();
            return r.Data;
        }

        
        #endregion
    }
}
