﻿using Axos.Identity.Client.Utilities.Extensions;
using Axos.Integration.Core.DTOs;
using Axos.Integration.Core.Extensions;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using Polly;
using Polly.Contrib.WaitAndRetry;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Http
{
    public class ApiClientHttpTools
    {
        public HttpClient Client;

        public ApiClientHttpTools(string url, HttpClient client = null)
        {
            try
            {
                if (client is null)
                {
                    var serviceCollection = new ServiceCollection();
                    serviceCollection.AddHttpClient("IdentityClient", httpClient =>
                    {
                        httpClient.BaseAddress = new Uri(url);
                    })
                    .AddTransientHttpErrorPolicy(p => p.WaitAndRetryAsync(Backoff.DecorrelatedJitterBackoffV2(TimeSpan.FromSeconds(1), 2),
                    (outcome, timespan, retryAttempt, context) =>
                    {
                        using (var serv = serviceCollection.BuildServiceProvider())
                        {
                            serv.GetRequiredService<ILogger<ApiClientHttpTools>>()?
                                .LogWarning("Delaying for {delay}ms, then making retry {retry}.", timespan.TotalMilliseconds, retryAttempt);
                        }
                    }));

                    var serviceProvider = serviceCollection.BuildServiceProvider();
                    var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
                    client = httpClientFactory.CreateClient("IdentityClient");
                }

                Client = client;
            }
            catch (Exception e)
            {
                throw new Exception("Could not initialize HttpClient", e);
            }
        }

        public HttpResponseMessage PostToServer<T>(string url, T value, HttpClient client, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(client, headers);

            var task = client.PostAsJsonAsync(url, value);

            task.Wait();
            return task.Result;
        }

        public Task<HttpServiceResult<TRes>> PostRequestAsync<TReq, TRes>(string url, TReq data, IDictionary<string, string> headers = null)
            where TRes : class
        {
            UpdateHeaders(Client, headers);

            return Client.PostRequestAsync<TReq, TRes>(url, data);
        }

        public Task<HttpResponseMessage> PostAsync<T>(string url, T value, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(Client, headers);

            return Client.PostAsJsonAsync(url, value);
        }

        public HttpResponseMessage PutToServer<T>(string url, T value, HttpClient client, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(client, headers);

            var task = client.PutAsJsonAsync(url, value);

            task.Wait();
            return task.Result;
        }

        public HttpResponseMessage DeleteResourceFromServer(string url, HttpClient client, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(client, headers);

            var task = client.DeleteAsync(url);

            task.Wait();
            return task.Result;
        }

        public Task<HttpResponseMessage> DeleteAsync(string url, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(Client, headers);

            return Client.DeleteAsync(url);
        }

        public HttpResponseMessage DeleteResourceFromServer<T>(string url, T value, HttpClient client, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(client, headers);

            var task = client.DeleteAsJsonAsync(url, value);

            task.Wait();
            return task.Result;
        }

        public Task<HttpResponseMessage> DeleteRequestAsync<TData>(string url, TData data, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(Client, headers);

            return Client.DeleteAsJsonAsync(url, data);
        }

        public HttpResponseMessage GetFromServer(string url, HttpClient client, IDictionary<string, string> headers = null)
        {
            UpdateHeaders(client, headers);

            var task = client.GetAsync(url);

            task.Wait();
            return task.Result;
        }

        public Task<HttpServiceResult<T>> GetRequestAsync<T>(string url, IDictionary<string, string> headers = null) where T : class
        {
            UpdateHeaders(Client, headers);

            return Client.GetRequestAsync<T>(url);
        }

        public HttpResponseMessage PostFormDataToServer(string url, HttpClient client,
            IDictionary<string, string> formFields = null, IDictionary<string, byte[]> files = null, IDictionary<string, string> headers = null)
        {
            var form = new MultipartFormDataContent();

            if (formFields != null)
            {
                foreach (var field in formFields)
                {
                    if (!string.IsNullOrEmpty(field.Key) && !string.IsNullOrEmpty(field.Value))
                    {
                        form.Add(new StringContent(field.Value), field.Key);
                    }
                }
            }


            if (files != null)
            {
                foreach (var file in files)
                {
                    if (!string.IsNullOrEmpty(file.Key) && file.Value.Length > 0)
                    {
                        form.Add(new StreamContent(new MemoryStream(file.Value)), $"file{files.Keys.ToList().IndexOf(file.Key)}", file.Key);
                    }
                }
            }

            var task = client.PostAsync(url, form);
            task.Wait();

            return task.Result;
        }

        public async Task<HttpResponseMessage> PostFormDataToServerAsync(string url, HttpClient client,
            IDictionary<string, string> formFields = null, IDictionary<string, byte[]> files = null, IDictionary<string, string> headers = null)
        {
            var form = new MultipartFormDataContent();

            if (formFields != null)
            {
                foreach (var field in formFields)
                {
                    if (!string.IsNullOrEmpty(field.Key) && !string.IsNullOrEmpty(field.Value))
                    {
                        form.Add(new StringContent(field.Value), field.Key);
                    }
                }
            }

            if (files != null)
            {
                foreach (var file in files)
                {
                    if (!string.IsNullOrEmpty(file.Key) && file.Value.Length > 0)
                    {
                        form.Add(new StreamContent(new MemoryStream(file.Value)), $"file{files.Keys.ToList().IndexOf(file.Key)}", file.Key);
                    }
                }
            }           

            return await client.PostAsync(url, form);
        }

        private static void UpdateHeaders(HttpClient client, IDictionary<string, string> headers)
        {
            if (headers == null) return;

            var requestHeaders = client.DefaultRequestHeaders;
            foreach (var header in headers.Keys)
            {
                requestHeaders.Remove(header);

                if (!string.IsNullOrEmpty(headers[header]))
                    requestHeaders.Add(header, headers[header]);
            }
        }
    }
}