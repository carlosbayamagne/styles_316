﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Http
{
    public abstract class CustomHeadersServiceClient : ServiceClientHttpServiceBase
    {
        protected CustomHeadersServiceClient(string environment, string username = null, string password = null) : base(environment, username, password)
        {

        }

        #region CustomHeaders
        private Dictionary<string, string> _customHeaders;

        public IDictionary<string, string> GetCustomHeaders()
        {
            return _customHeaders;
        }

        /// <summary>
        /// This will initialize the custom headers collection and insert or replace the passed value for the given key
        /// </summary>
        /// <param name="key">Header name</param>
        /// <param name="value">Header value</param>
        public void AppendCustomHeader(string key, string value)
        {
            if (_customHeaders == null)
            {
                _customHeaders = new Dictionary<string, string>();
                _customHeaders.Add(key, value);
            }
            else if (_customHeaders.ContainsKey(key))
            {
                _customHeaders[key] = value;
            }
            else
            {
                _customHeaders.Add(key, value);
            }
        }
        #endregion
    }
}
