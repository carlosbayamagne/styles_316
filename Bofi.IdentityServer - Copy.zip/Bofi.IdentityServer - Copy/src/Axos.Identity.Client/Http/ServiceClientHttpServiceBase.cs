﻿using Axos.Identity.Client.Models;
using Axos.Identity.Client.Utilities.Extensions;
using Axos.Integration.Core;
using Axos.Integration.Core.DTOs;
using Axos.Integration.Core.Extensions;
using IdentityModel.Client;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Http
{
    public abstract class ServiceClientHttpServiceBase
    {
        protected readonly ApiClientHttpTools _serviceHttpTools;

        protected readonly HttpClient httpClient;

        protected string _username;

        protected string _password;

        protected long _expiresIn;

        protected string _identityUrl;

        protected string _serviceUrl;

        protected ServiceConfig identityConfig { get; }

        protected abstract string GetToken();

        protected abstract void SetToken(string token);

        protected abstract DateTime GetRefreshTime();

        protected abstract void SetRefreshTime(DateTime time);

        protected abstract string GetServiceConfigName();

        protected abstract string GetLocalServiceUrl();

        protected string LocalIdentityUrl
        {
            get
            {
                return _environment == "Testing" ? "http://localhost" : "http://localhost:5901";
            }
        }

        private readonly string _environment;

        // in order to cache the token properly, implement a get/set in the derived class for _token and _refreshTime that uses a static for the storage -- this lets the token be shared across instances of the class
        private string _token { get { return GetToken(); } set { SetToken(value); } }

        private DateTime _refreshTime { get { return GetRefreshTime(); } set { SetRefreshTime(value); } }

        private readonly object lockMe = new object();

        protected ServiceClientHttpServiceBase(string environment, string username = null, string password = null)
        {
            ServiceConfig serviceConfig;

            ServicePointManager.DefaultConnectionLimit = int.MaxValue;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var env = environment ?? Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? Environment.GetEnvironmentVariable("ASPNET_ENV") ?? "Development";
            _environment = env;
            if (environment == "Local" || environment == "Testing")
            {
                serviceConfig = new ServiceConfig("Development", GetServiceConfigName());
                identityConfig = new ServiceConfig("Development", "IdentityService");
                _identityUrl = LocalIdentityUrl;
                _serviceUrl = GetLocalServiceUrl();
            }
            else
            {
                serviceConfig = new ServiceConfig(env, GetServiceConfigName());
                identityConfig = new ServiceConfig(env, "IdentityService");
                _identityUrl = identityConfig.Settings["ApiURL"];
                _serviceUrl = serviceConfig.Settings["ApiUrl"] ?? serviceConfig.Settings["ApiURL"];
            }

            _serviceHttpTools = new ApiClientHttpTools(_serviceUrl);
            httpClient = _serviceHttpTools.Client;
            _username = username ?? serviceConfig.Settings["DefaultServiceAccount"];
            _password = password ?? serviceConfig.Settings["DefaultServicePassword"];
        }

        protected void EnsureBearerToken()
        {
            if ((_username != null && _password != null && DateTime.Now > _refreshTime) || string.IsNullOrEmpty(_token))
            {
                lock (lockMe)
                {
                    var isar = new InternalServiceAuthenticationRequest
                    {
                        Username = _username,
                        Password = _password
                    };

                    var response = ServiceAccountLogin(isar);
                    if (string.IsNullOrEmpty(response.AccessToken))
                    {
                        response = ServiceAccountLogin(isar);
                    }
                    _token = response.AccessToken;
                    _expiresIn = response.ExpiresIn;
                    _refreshTime = DateTime.Now.AddSeconds(_expiresIn / 2);
                }
            }

            httpClient.SetBearerToken(_token);
        }

        // interface to override in UnitTests
        protected virtual HttpContext GetHttpContext()
        {
            return new HttpContextAccessor().HttpContext;
        }

        protected IDictionary<string, string> AddUserProxyHeaders(IDictionary<string, string> headers)
        {
            bool hasUserToken = false;

            // get new Dictionary and copy existing headers in
            IDictionary<string, string> retval = new Dictionary<string, string>();
            if (headers != null)
            {
                foreach (KeyValuePair<string, string> header in headers)
                {
                    if (header.Key == "USER_TOKEN") hasUserToken = true;
                    retval.Add(header.Key, header.Value);
                }
            }

            // have user token -- we're done.
            if (hasUserToken)
            {
                return retval;
            }

            // don't have user token -- look for it in Request headersr

            string authToken = null;
            bool hasAuthToken = false;

            // get the current context and look at the headers
            HttpContext currentContext = GetHttpContext();
            if (currentContext != null && currentContext.Request != null && currentContext.Request.Headers != null)
            {
                HttpRequest request = currentContext.Request;
                foreach (var header in currentContext.Request.Headers)
                {
                    if (header.Key == "USER_TOKEN")
                    {
                        hasUserToken = true;
                        retval.Add(header.Key, header.Value);
                    }
                    if (header.Key == "PROXY_TOKEN")
                    {
                        retval.Add(header.Key, header.Value);
                    }
                    if (header.Key == "Authorization" && !String.IsNullOrWhiteSpace(header.Value))
                    {
                        hasAuthToken = true;
                        string val = header.Value;
                        authToken = val.Replace("Bearer ", "");
                    }
                }
            }

            // if no USER_TOKEN, and we have an Auth Token, take the Auth Token
            if (!hasUserToken && hasAuthToken)
            {
                retval.Add("USER_TOKEN", authToken);
            }

            // if no headers, don't return anything
            if (retval.Count == 0) return null;

            // Send the Dictionary back
            return retval;
        }

        public T Get<T>(string requestUri, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(_serviceHttpTools.GetFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        public bool Get(string requestUri, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage(_serviceHttpTools.GetFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        public T GetHealthCheck<T>(string requestUri, IDictionary<string, string> headers = null) where T : class
        {
            headers = AddUserProxyHeaders(headers);
            return HandleHealthCheckResponseMessage<T>(_serviceHttpTools.GetFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        public Task<HttpServiceResult<T>> GetHealthCheckAsync<T>(string url, IDictionary<string, string> headers = null)
            where T : class
        {
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.GetRequestAsync<T>(url);
        }

        public async Task<T> GetAsync<T>(string requestUri, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return await HandleResponseMessageAsync<T>(_serviceHttpTools.GetFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        public async Task<bool> GetAsync(string requestUri, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return await HandleResponseMessageAsync(_serviceHttpTools.GetFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        protected InternalServiceAuthenticationResponse ServiceAccountLogin(InternalServiceAuthenticationRequest request)
        {
            UpdateHeaders(AddUserProxyHeaders(null));
            var res = httpClient.PostRequestAsync<InternalServiceAuthenticationRequest, InternalServiceAuthenticationResponse>($"{_identityUrl}/api/identity/authenticate/serviceaccount", request)
                        .GetAwaiter()
                        .GetResult();

            return res.Data;
        }

        public T Post<T, TData>(string requestUri, TData data, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(_serviceHttpTools.PostToServer(requestUri, data, _serviceHttpTools.Client, headers));
        }

        public bool Post<TData>(string requestUri, TData data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage(_serviceHttpTools.PostToServer(requestUri, data, _serviceHttpTools.Client, headers));
        }

        public T PostFormData<T>(string requestUri, IDictionary<string, string> formFields = null,
            IDictionary<string, byte[]> formFiles = null, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(_serviceHttpTools.PostFormDataToServer(requestUri, _serviceHttpTools.Client,
                formFields, formFiles, headers));
        }

        public async Task<T> PostFormDataAsync<T>(
            string requestUri, 
            IDictionary<string, string> formFields = null,
            IDictionary<string, byte[]> formFiles = null, 
            IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(await _serviceHttpTools.PostFormDataToServerAsync(
                requestUri, 
                _serviceHttpTools.Client,
                formFields, 
                formFiles, 
                headers));
        }

        public T Put<T, TData>(string requestUri, TData data, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(_serviceHttpTools.PutToServer(requestUri, data, _serviceHttpTools.Client, headers));
        }

        public T Delete<T>(string requestUri, IDictionary<string, string> headers = null) where T : class
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage<T>(_serviceHttpTools.DeleteResourceFromServer(requestUri, _serviceHttpTools.Client, headers));
        }

        public bool Delete<TData>(string requestUri, TData data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            return HandleResponseMessage(_serviceHttpTools.DeleteResourceFromServer(requestUri, data, _serviceHttpTools.Client, headers));
        }

        #region Self-Client methods

        /// <summary>
        /// Sends a GET request to the specified URL, with the given headers.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult with Data wrapping the result of the operation.</returns>
        public Task<HttpServiceResult> GetRequestAsync(string url, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.GetRequestAsync(url);
        }

        /// <summary>
        /// Sends a GET request to the specified URL, with the given headers.
        /// </summary>
        /// <typeparam name="TRes">Type of the response data.</typeparam>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult with Data wrapping the result of the operation.</returns>
        public Task<HttpServiceResult<TRes>> GetRequestAsync<TRes>(string url, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.GetRequestAsync<TRes>(url);
        }

        /// <summary>
        /// Sends a POST request to the specified URL, with the given data and headers.
        /// </summary>
        /// <typeparam name="TReq">Type of the request data.</typeparam>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        public Task<HttpServiceResult> PostRequestAsync<TReq>(string url, TReq data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.PostRequestAsync(url, data);
        }

        /// <summary>
        /// Sends a POST request to the specified URL, with the given data and headers.
        /// </summary>
        /// <typeparam name="TReq">Type of the request data.</typeparam>
        /// <typeparam name="TRes">Type of the response data.</typeparam>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult with Data wrapping the result of the operation.</returns>
        public Task<HttpServiceResult<TRes>> PostRequestAsync<TReq, TRes>(string url, TReq data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.PostRequestAsync<TReq, TRes>(url, data);
        }

        /// <summary>
        /// Sends a PUT request to the specified URL, with the given data and headers.
        /// </summary>
        /// <typeparam name="TReq">Type of the request data.</typeparam>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        public Task<HttpServiceResult> PutRequestAsync<TReq>(string url, TReq data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.PutRequestAsync(url, data);
        }

        /// <summary>
        /// Sends a PUT request to the specified URL, with the given data and headers.
        /// </summary>
        /// <typeparam name="TReq">Type of the request data.</typeparam>
        /// <typeparam name="TRes">Type of the response data.</typeparam>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult with Data wrapping the result of the operation.</returns>
        public Task<HttpServiceResult<TRes>> PutRequestAsync<TReq, TRes>(string url, TReq data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.PutRequestAsync<TReq, TRes>(url, data);
        }

        /// <summary>
        /// Sends a DELETE request to the specified URL, with the given headers.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        public Task<HttpServiceResult> DeleteRequestAsync(string url, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.DeleteRequestAsync(url);
        }

        /// <summary>
        /// Sends a DELETE request to the specified URL, with the given headers.
        /// </summary>
        /// /// <typeparam name="TRes">Type of the response data.</typeparam>
        /// <param name="url"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        public Task<HttpServiceResult<TRes>> DeleteRequestAsync<TRes>(string url, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.DeleteRequestAsync<TRes>(url);
        }

        /// <summary>
        /// Sends a DELETE request to the specified URL, with the given data and headers.
        /// </summary>
        /// <typeparam name="TReq">Type of the request data.</typeparam>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <param name="headers"></param>
        /// <returns>An HttpServiceResult wrapping the result of the operation.</returns>
        public Task<HttpServiceResult> DeleteRequestWithContentAsync<TReq>(string requestUri, TReq data, IDictionary<string, string> headers = null)
        {
            EnsureBearerToken();
            headers = AddUserProxyHeaders(headers);
            UpdateHeaders(headers);

            return httpClient.DeleteWithContentAsync(requestUri, data);
        }

        #endregion Self-Client methods

        private static T HandleResponseMessage<T>(HttpResponseMessage response) where T : class
        {
            try
            {
                var readTask = response.Content.ReadAsStringAsync();
                readTask.Wait();
                var reply = readTask.Result;

                if (!response.IsSuccessStatusCode)
                    throw new Exception(GetExceptionMessage(response.StatusCode, reply));

                var jsend = JsonConvert.DeserializeObject<JSendReply<T>>(reply);
                return jsend.data;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static bool HandleResponseMessage(HttpResponseMessage response)
        {
            try
            {
                var readTask = response.Content.ReadAsStringAsync();
                readTask.Wait();
                var reply = readTask.Result;

                if (!response.IsSuccessStatusCode)
                    throw new Exception(GetExceptionMessage(response.StatusCode, reply));

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static async Task<T> HandleResponseMessageAsync<T>(HttpResponseMessage response) where T : class
        {
            try
            {
                var reply = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                    throw new Exception(GetExceptionMessage(response.StatusCode, reply));

                var jsend = JsonConvert.DeserializeObject<JSendReply<T>>(reply);
                return jsend.data;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static async Task<bool> HandleResponseMessageAsync(HttpResponseMessage response)
        {
            try
            {
                var reply = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                    throw new Exception(GetExceptionMessage(response.StatusCode, reply));

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static T HandleHealthCheckResponseMessage<T>(HttpResponseMessage response) where T : class
        {
            try
            {
                var readTask = response.Content.ReadAsStringAsync();
                readTask.Wait();
                var reply = readTask.Result;

                if (!response.IsSuccessStatusCode)
                    throw new Exception(GetExceptionMessage(response.StatusCode, reply));

                reply = "{\"data\":" + reply + "}";
                var jsend = JsonConvert.DeserializeObject<JSendReply<T>>(reply);
                return jsend.data;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private static string GetExceptionMessage(HttpStatusCode statusCode, string reply)
        {
            return $"Invalid status from server: {statusCode}; reply: {reply}";
        }

        private void UpdateHeaders(IDictionary<string, string> headers)
        {
            if (headers == null) return;

            var requestHeaders = httpClient.DefaultRequestHeaders;
            foreach (var header in headers.Keys)
            {
                requestHeaders.Remove(header);

                if (!string.IsNullOrEmpty(headers[header]))
                    requestHeaders.Add(header, headers[header]);
            }
        }
    }
}