﻿namespace Axos.Identity.Client.Models
{
    public class ValidateOtpRequest
    {
        public string Username { get; set; }
        public string Otp { get; set; }
    }
}
