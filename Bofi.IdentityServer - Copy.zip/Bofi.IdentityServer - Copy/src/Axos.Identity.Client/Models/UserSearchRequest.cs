﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class UserSearchRequest
    {
        public int[] UserIds { get; set; }
        public string SSN { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get; set; }
        public string CIF { get; set; }
        public string Username { get; set; }
        public string CommonName { get; set; }
        public UserType? UserType { get; set; }
        public UserSubType? UserSubType { get; set; }
        public UserState? UserState { get; set; }
        public string[] UserNames { get; set; }
        public bool EnrollmentCompleted { get; set; }
        public bool IncludeCredentialsInfo { get; set; }
        public bool IncludeSSN { get; set; }
        public bool GetAll { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string PostalCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Address { get; set; }
        public int? JHABrandId { get; set; }

        public UserSearchRequest()
        {
            EnrollmentCompleted = false;
            IncludeCredentialsInfo = false;
            IncludeSSN = false;
        }
    }
}
