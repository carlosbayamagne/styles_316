﻿namespace Axos.Identity.Client.Models
{
    public class BrandingSetting
    {
        public int Id { get; set; }

        public int BrandingId { get; set; }

        public string Value { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public bool IsDraft { get; set; }
    }
}
