﻿using Axos.Identity.Client.Enums;
using System;

namespace Axos.Identity.Client.Models
{
    public class InternalServiceAuthenticationResponse
    {
        public AuthenticationStatus Status { get; set; }
        public String AccessToken { get; set; }
        public long ExpiresIn { get; set; }
    }
}
