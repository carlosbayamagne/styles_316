﻿using Axos.Identity.Client.Enums;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class Branding
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Url { get; set; }

        public OrgType OrgType { get; set; }

        public bool IsWhiteLabel
        {
            get
            {
                return (this.OrgType == OrgType.IBD || this.OrgType == OrgType.RIA);
            }
        }

        public IEnumerable<BrandingSetting> Settings { get; set; }
    }
}
