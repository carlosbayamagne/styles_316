﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.FraudLinks
{
    public class Applicant
    {
        public string TaxId { get; set; }
        public string CellPhone { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string Email { get; set; }
        public string IpAddress { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string Unit { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string MailingStreet { get; set; }
        public string MailingUnit { get; set; }
        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public string MailingZip { get; set; }
        public string SecondaryEmail { get; set; }

        public Applicant()
        {

        }

        public Applicant(string ssn, string cellPhone, string homePhone, string workPhone, string email, string ipAddress, string firstName, string lastName, string city, string street, string unit, string state, string zip, string mailingStreet, string mailingUnit, string mailingCity, string mailingState, string mailingZip, string secondaryEmail)
        {
            TaxId = ssn;
            CellPhone = cellPhone;
            HomePhone = homePhone;
            WorkPhone = workPhone;
            Email = email;
            IpAddress = ipAddress;
            FirstName = firstName;
            LastName = lastName;
            City = city;
            Street = street;
            Unit = unit;
            State = state;
            Zip = zip;
            MailingStreet = mailingStreet;
            MailingUnit = mailingUnit;
            MailingCity = mailingCity;
            MailingState = mailingState;
            MailingZip = mailingZip;
            SecondaryEmail = secondaryEmail;
        }
    }
}
