﻿namespace Axos.Identity.Client.Models
{
    public class ResetPasswordRequest
    {
        public int UserId { get; set; }
        public string ApplicationUrl { get; set; }
        public string ApplicationName { get; set; }
        public string Brand { get; set; }
        public string SubBrand { get; set; }
    }
}
