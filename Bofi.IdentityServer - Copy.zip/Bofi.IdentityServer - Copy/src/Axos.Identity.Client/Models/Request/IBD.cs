﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Axos.Identity.Client.Models.Request
{
    [ExcludeFromCodeCoverage]
    public class AddUsersToBrokerRequest
    {
        public int BrokerId { get; set; }
        public List<int> UserIds { get; set; }
    }
}
