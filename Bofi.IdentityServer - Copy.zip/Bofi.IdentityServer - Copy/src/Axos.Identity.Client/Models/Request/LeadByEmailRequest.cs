﻿namespace Axos.Identity.Client.Models.Request
{
    public class LeadByEmailRequest
    {
        public string Email { get; set; }
    }
}
