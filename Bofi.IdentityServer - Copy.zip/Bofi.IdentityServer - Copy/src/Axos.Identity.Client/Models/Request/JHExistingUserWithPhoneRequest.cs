﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models.Request
{
    public class JHExistingUserWithPhoneRequest
    {
        public string PhoneNumber { get; set; }
    }
}
