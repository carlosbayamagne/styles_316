﻿namespace IdentityClient.Models.Request
{
    public class AccessTokenRequest
    {
        public string Username { get; set; }
        public string Token { get; set; }
        public string Client { get; set; }
        public string Secret { get; set; }
        public string Scopes { get; set; }
        public int? AccessTokenLifetime { get; set; }
    }
}
