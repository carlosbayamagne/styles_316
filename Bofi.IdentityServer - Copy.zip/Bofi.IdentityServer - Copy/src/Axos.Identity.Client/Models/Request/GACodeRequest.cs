﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models.Request
{
    public class GACodeRequest
    {
        [Required]
        public string Username { get; set; }

        public string GACode { get; set; }
    }
}
