﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class ForgotUsernameRequest
    {
        public string Email { get; set; }
        public string ApplicationName { get; set; }
        public string Brand { get; set; }
        public string SubBrand { get; set; }
        public Dictionary<string, string> Tokens { get; set; } = null;
    }
}
