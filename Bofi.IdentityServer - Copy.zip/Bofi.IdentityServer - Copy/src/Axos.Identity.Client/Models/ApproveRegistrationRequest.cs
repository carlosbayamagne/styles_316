﻿using Axos.Identity.Client.Enums;
using System;

namespace Axos.Identity.Client.Models
{
    public class ApproveRegistrationRequest
    {
        public string CIF { get; set; }
        public string Username { get; set; }
        public string ApplicationUrl { get; set; }
        public RegistrationStatus RegistrationStatus { get; set; } = RegistrationStatus.Complete;
        public DeliveryMethod DeliveryMethod { get; set; } = DeliveryMethod.Email;
    }
}
