﻿
using Axos.Identity.Client.Enums;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class OTPRequest
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public DeliveryMethod DeliveryMethod { get; set; }
        public string Brand { get; set; }
        public string Recipient { get; set; }
        public string SubBrand { get; set; }
    }
}
