﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class IdentityUser
    {
        public IdentityUser()
        {

        }
        public IdentityUser(string username)
        {
            UserName = username;
        }
        public IdentityUser(string firstName, string lastName, string email, string phoneNumber, string username)
        {
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            PhoneNumber = phoneNumber;
            UserName = username;
        }

        public string Cif { get; set; }
        public Dictionary<string, string> CustomProperties { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public string UserName { get; set; }
    }
}
