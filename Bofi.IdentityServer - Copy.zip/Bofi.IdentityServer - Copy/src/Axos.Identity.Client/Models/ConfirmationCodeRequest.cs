﻿
using Axos.Identity.Client.Enums;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class ConfirmationCodeRequest
    {
        [Required]
        public int UserId { get; set; }
        public string ApplicationName { get; set; }
        [Required]
        public DeliveryMethod DeliveryMethod { get; set; }
        public string Brand { get; set; }
    }
}
