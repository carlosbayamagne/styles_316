﻿namespace Axos.Identity.Client.Models
{
    public class AddressDetails
    {
        public string ID { get; set; }

        public string StreetAddress1 { get; set; }

        public string StreetAddress2 { get; set; }
       
        public string StreetAddress3 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip5 { get; set; }

        public string Zip4 { get; set; }
    }
}
