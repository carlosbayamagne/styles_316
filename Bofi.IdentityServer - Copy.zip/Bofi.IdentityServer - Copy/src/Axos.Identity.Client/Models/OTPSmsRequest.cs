﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class OTPSmsRequest
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        public string Brand { get; set; }
    }
}
