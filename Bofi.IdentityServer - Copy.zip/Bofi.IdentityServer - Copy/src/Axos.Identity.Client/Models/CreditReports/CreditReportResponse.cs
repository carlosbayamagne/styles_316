﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditReports
{
    public class CreditReportResponse
    {
        public CreditProfile[] CreditProfile { get; set; }
    }
}
