﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditReports
{
    public class ScoreFactor
    {
        public string Importance { get; set; }
        public string Code { get; set; }
    }
}
