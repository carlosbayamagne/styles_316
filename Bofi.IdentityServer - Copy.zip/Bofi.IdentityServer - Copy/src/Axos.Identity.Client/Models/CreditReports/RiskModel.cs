﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditReports
{
    public class RiskModel
    {
        public string Evaluation { get; set; }
        public string ModelIndicator { get; set; }
        public string Score { get; set; }
        public ScoreFactor[] ScoreFactors { get; set; }
    }
}
