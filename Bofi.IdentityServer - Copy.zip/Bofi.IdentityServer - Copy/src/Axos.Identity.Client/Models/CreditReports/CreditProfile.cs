﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditReports
{
    public class CreditProfile
    {
        public RiskModel[] RiskModel { get; set; }
    }
}
