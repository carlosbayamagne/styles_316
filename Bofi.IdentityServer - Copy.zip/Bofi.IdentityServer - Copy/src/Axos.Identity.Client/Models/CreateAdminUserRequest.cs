﻿using Axos.Identity.Client.Enums;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class CreateAdminUserRequest
    {
        [Required]
        public string UserName { get; set; }
        public AdminUserStatus Status { get; set; }
    }
}

