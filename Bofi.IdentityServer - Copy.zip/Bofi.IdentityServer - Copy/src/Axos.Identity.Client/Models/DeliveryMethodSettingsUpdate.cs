﻿using System;

namespace Axos.Identity.Client.Models
{
    public class DeliveryMethodSettingsUpdate : DeliveryMethodSettings
    {
		public Guid Id { get; set; }
	}
}
