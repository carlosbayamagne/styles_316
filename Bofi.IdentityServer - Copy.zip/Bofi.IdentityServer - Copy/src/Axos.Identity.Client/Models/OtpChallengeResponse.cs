﻿namespace Axos.Identity.Client.Models
{
    public class OtpChallengeResponse: IdentityResponse
    {
        public OtpChallengeResponse()
        {

        }

        public OtpChallengeResponse(string otp)
        {
            Otp = otp;
        }

        public string Otp { get; set; }
    }
}
