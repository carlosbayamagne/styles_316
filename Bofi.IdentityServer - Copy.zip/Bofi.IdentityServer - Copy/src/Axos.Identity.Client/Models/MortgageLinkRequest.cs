﻿namespace Axos.Identity.Client.Models
{
    public class MortgageLinkRequest
    {
        public string UserName { get; set; }
        public string ApplicationName { get; set; }
        public string Brand { get; set; }
    }
}
