﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models
{
    public class UpdateEmploymentInfoRequest
    {
        public string Employer { get; set; }
        public string Occupation { get; set; }
    }
}
