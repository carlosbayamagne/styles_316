﻿namespace Axos.Identity.Client.Models
{
    public class BrandSetting
    {
        public int Id { get; set; }

        public int BrandId { get; set; }

        public string Value { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }
    }
}
