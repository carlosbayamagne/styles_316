﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class QuestionChallengeResponse : IdentityResponse
    {
        public QuestionChallengeResponse()
        {

        }
        public QuestionChallengeResponse(bool success)
        {
            Success = success;
        }
        public QuestionChallengeResponse(IEnumerable<ChallengeQuestion> questions)
        {
            Questions = questions;
        }
        
        public IEnumerable<ChallengeQuestion> Questions { get; set; }
    }
}
