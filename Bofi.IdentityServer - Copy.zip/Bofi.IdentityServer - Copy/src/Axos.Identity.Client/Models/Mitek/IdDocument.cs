﻿namespace Axos.Identity.Client.Models.Mitek
{
    public class IdDocument
    {
        public string Front { get; set; }
        public string Back { get; set; }
        public string DocumentType { get; set; }
    }
}
