﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models.Mitek
{
    public interface IMitekModel
    {
        List<IdDocument> IdDocuments { get; }
        void AddIdDocument(string front, string back);
        void AddSelfieDocument(string selfie);
    }
}
