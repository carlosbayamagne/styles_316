﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class UserTree : User
    {
        public List<UserTree> ChildUsers { get; set; }

        public int? ParentUserId { get; set; }

        public int Id { get; set; }

    }
}
