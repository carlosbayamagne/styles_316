﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class QuestionsConfigurationResponse : IdentityResponse
    {
        public QuestionsConfigurationResponse(string[] questions, int max, int min)
        {
            QuestionBank = questions;
            Max = max;
            Min = min;
        }

        public int Max { get; set; }
        public int Min { get; set; }
        public IEnumerable<string> QuestionBank { get; set; }
    }
}
