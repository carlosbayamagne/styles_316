﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class OTPSmsNoUserRequest
    {
        [Required]
        public string PhoneNumber { get; set; }
        public string Brand { get; set; }
    }
}
