﻿namespace Axos.Identity.Client.Models
{
    public class ServiceResponse<T> where T : IdentityResponse
    {
        public T Data { get; set; }
        public string ErrorMessage { get; set; }
        public bool Success { get; set; }
    }
}
