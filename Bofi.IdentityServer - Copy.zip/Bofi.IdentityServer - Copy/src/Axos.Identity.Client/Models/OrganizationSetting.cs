﻿namespace Axos.Identity.Client.Models
{
    public class OrganizationSetting
    {
        public int Id { get; set; }

        public int OrganizationId { get; set; }

        public string Value { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public bool IsDraft { get; set; }
    }
}
