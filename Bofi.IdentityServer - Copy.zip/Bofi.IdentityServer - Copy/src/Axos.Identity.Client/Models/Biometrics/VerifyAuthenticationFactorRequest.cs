﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class VerifyAuthenticationFactorRequest
    {
        public string UserName { get; set; }
        public AuthenticationFactors AuthenticationFactor { get; set; }
        public string Device { get; set; }
    }
}
