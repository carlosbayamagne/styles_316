﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class BiometricDeviceIdentity
    {
        public string DeviceId { get; set; }
        public string DeviceSig { get; set; }
        public string FingerprintSig { get; set; }
        public string DeviceChallengeKey { get; set; }
        public string FingerprintChallengeKey { get; set; }
        public string FaceVideo { get; set; }
        public string VoicePrint { get; set; }
    }
}
