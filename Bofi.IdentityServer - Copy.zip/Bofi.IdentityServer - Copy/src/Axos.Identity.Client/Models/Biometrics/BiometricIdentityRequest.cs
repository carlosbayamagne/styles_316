﻿namespace Axos.Identity.Client.Models.Biometrics
{
    public class BiometricIdentityRequest
    {
        public string DeviceId { get; set; }
        public string DeviceChallengeKey { get; set; }
        public string DeviceSig { get; set; }
        public string FingerprintChallengeKey { get; set; }
        public string FingerprintSig { get; set; }
        public string VoicePrint { get; set; }
    }
}
