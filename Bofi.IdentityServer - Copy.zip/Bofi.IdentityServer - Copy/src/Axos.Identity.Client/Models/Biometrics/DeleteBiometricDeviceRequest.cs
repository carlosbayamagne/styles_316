﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class DeleteBiometricDeviceRequest
    {
        [Required]
        public string DeviceId { get; set; }
    }
}
