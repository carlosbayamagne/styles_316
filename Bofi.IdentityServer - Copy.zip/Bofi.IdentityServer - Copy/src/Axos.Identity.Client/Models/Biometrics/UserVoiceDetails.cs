﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class UserVoiceDetails
    {
        public string Last4SSN { get; set; }
        public bool RegisteredForVoice { get; set; }
        public DateTime? Birthdate { get; set; }
        public int Id { get; set; }
        public string Username { get; set; }
    }
}
