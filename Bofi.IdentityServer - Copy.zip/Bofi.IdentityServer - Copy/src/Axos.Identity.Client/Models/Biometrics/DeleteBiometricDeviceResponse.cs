﻿namespace Axos.Identity.Client.Models.Biometrics
{
    public class DeleteBiometricDeviceResponse
    {
        public int UserId { get; set; }
        public string DeviceId { get; set; }
    }
}
