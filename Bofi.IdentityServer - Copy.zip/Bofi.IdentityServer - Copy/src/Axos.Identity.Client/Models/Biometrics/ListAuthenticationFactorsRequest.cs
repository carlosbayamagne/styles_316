﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class ListAuthenticationFactorsRequest
    {
        public int UserId { get; set; }

        public string DeviceId { get; set; }
    }
}
