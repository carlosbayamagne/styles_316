﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models.Biometrics
{
    public class BiometricDeviceDetailsRequest
    {
        [Required]
        public string DeviceId { get; set; }        
        public string DeviceChallenge { get; set; }        
        public string FingerprintChallenge { get; set; }
        public string FaceVideo { get; set; }
        public string[] VoicePrint { get; set; }
    }
}
