﻿using Axos.Identity.Client.Models.Ekata.Abstractions;
using Newtonsoft.Json;

namespace Axos.Identity.Client.Models.Ekata
{
    public class SecondaryApplicantInformationModel :
    IApplicantInformation,
    IBasicPersonInformation,
    IAddress,
    IPhoneInformation
    {
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string StreetLine1 { get; set; }
        public string StreetLine2 { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string StateCode { get; set; }
        public Enums.CountryCode? CountryCode { get; set; } = new Enums.CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        public string Phone { get; set; }
        public Enums.CountryCode? CountryHint { get; set; } = new Enums.CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        public string EmailAddress { get; set; }
    }
}
