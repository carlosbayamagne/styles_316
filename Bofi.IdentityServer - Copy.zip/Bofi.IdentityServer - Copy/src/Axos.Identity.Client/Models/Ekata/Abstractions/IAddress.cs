﻿using Axos.Identity.Client.Models.Ekata.Enums;

namespace Axos.Identity.Client.Models.Ekata.Abstractions  
{
    public interface IAddress
    {
        string StreetLine1 { get; set; }

        string StreetLine2 { get; set; }

        string City { get; set; }

        string PostalCode { get; set; }

        string StateCode { get; set; }

        CountryCode? CountryCode { get; set; }
    }
}
