﻿namespace Axos.Identity.Client.Models.Ekata.Abstractions
{
    public interface IApplicantInformation : IBasicPersonInformation, IAddress, IPhoneInformation
    {
    }
}
