﻿using Axos.Identity.Client.Models.Ekata.Enums;

namespace Axos.Identity.Client.Models.Ekata.Abstractions
{
    public interface IPhoneInformation
    {
        string Phone { get; set; }
        CountryCode? CountryHint { get; set; }
    }
}
