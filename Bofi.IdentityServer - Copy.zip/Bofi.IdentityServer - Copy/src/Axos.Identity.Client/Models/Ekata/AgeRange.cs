﻿using Newtonsoft.Json;

namespace Axos.Identity.Client.Models.Ekata
{
    public class AgeRange
    {
        [JsonProperty("from")]
        public int From { get; set; }

        [JsonProperty("to")]
        public int? To { get; set; }
    }
}
