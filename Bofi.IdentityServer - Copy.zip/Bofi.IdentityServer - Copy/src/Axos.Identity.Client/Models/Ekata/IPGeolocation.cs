﻿using Newtonsoft.Json;

namespace Axos.Identity.Client.Models.Ekata
{
    public class IPGeolocation
    {
        [JsonProperty("postal_code")]
        public string PostalCode { get; set; }

        [JsonProperty("city_name")]
        public string CityName { get; set; }

        [JsonProperty("subdivision")]
        public string SubDivision { get; set; }

        [JsonProperty("country_name")]
        public string CountryName { get; set; }

        [JsonProperty("country_code")]
        public string CountryCode { get; set; }

        [JsonProperty("continent_code")]
        public string ContinentCode { get; set; }
    }
}
