﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PhoneCheckErrorV33Enum
    {
        [Description("Partial"), EnumMember(Value = "Partial")] Partial,
        [Description("InternationalPhoneDisabled"), EnumMember(Value = "InternationalPhoneDisabled")] InternationalPhoneDisabled,
    }
}
