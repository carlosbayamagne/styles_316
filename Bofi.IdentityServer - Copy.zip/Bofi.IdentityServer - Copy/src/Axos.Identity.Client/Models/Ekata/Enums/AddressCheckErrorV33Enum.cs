﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressCheckErrorV33Enum
    {
        [Description("Partial"), EnumMember(Value = "Partial")] Partial,
        [Description("InternationalAddressDisabled"), EnumMember(Value = "InternationalAddressDisabled")] InternationalAddressDisabled,
    }
}
