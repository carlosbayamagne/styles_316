﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressInputCompletenessV33Enum
    {
        [Description("Empty"), EnumMember(Value = "Empty")] Empty,
        [Description("Partial"), EnumMember(Value = "Partial")] Partial,
        [Description("Missing"), EnumMember(Value = "Missing")] Missing,
        [Description("Complete"), EnumMember(Value = "Complete")] Complete,
    }
}
