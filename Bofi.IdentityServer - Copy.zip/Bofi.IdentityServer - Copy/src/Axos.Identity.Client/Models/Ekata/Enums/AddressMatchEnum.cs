﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressMatchEnum
    {
        [Description("No match"), EnumMember(Value = "No match")] NoMatch,
        [Description("Country match"), EnumMember(Value = "Country match")] CountryMatch,
        [Description("Zip+4 match"), EnumMember(Value = "Zip+4 match")] ZipPlus4Match,
        [Description("Metro match"), EnumMember(Value = "Metro match")] MetroMatch,
        [Description("City/State match"), EnumMember(Value = "City/State match")] CityStateMatch,
        [Description("Postal match"), EnumMember(Value = "Postal match")] PostalMatch,
        [Description("Match"), EnumMember(Value = "Match")] Match,
    }
}
