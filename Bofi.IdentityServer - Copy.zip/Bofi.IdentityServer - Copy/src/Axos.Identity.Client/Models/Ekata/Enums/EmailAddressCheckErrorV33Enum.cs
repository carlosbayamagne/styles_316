﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EmailAddressCheckErrorV33Enum
    {
        [Description("Partial"), EnumMember(Value = "Partial")] Partial,
        [Description("EmailValidationDisabledError "), EnumMember(Value = "EmailValidationDisabledError ")] EmailValidationDisabledError,
    }
}
