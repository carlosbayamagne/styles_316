﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AddressTypeEnum
    {
        [Description("Unknown address type"), EnumMember(Value = "Unknown address type")] Unknown,
        [Description("Partial address"), EnumMember(Value = "Partial address")] PartialAddress,
        [Description("PO box"), EnumMember(Value = "PO box")] PoBox,
        [Description("Multi unit"), EnumMember(Value = "Multi unit")] MultiUnit,
        [Description("Single unit"), EnumMember(Value = "Single unit")] SingleUnit,
        [Description("Commercial mail drop"), EnumMember(Value = "Commercial mail drop")] CommercialMailDrop,
        [Description("PO box throwback"), EnumMember(Value = "PO box throwback")] PoBoxThrowback,
    }
}
