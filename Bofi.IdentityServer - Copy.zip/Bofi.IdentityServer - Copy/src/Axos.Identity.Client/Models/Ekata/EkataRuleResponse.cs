﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Ekata
{
    public class EkataRuleResponse
    {
        public bool IdentityCheckFail { get; set; }
        public bool CountryCodeCheckFail { get; set; }

        public EkataRuleResponse(bool identityCheckFail, bool countryCodeCheckFail)
        {
            IdentityCheckFail = identityCheckFail;
            CountryCodeCheckFail = countryCodeCheckFail;
        }
        public static EkataRuleResponse Create(bool identityCheckFail, bool countryCodeCheckFail)
        {
            return new EkataRuleResponse(identityCheckFail, countryCodeCheckFail);
        }
    }
}
