﻿using Newtonsoft.Json;
using System;
using System.Net;

namespace Axos.Identity.Client.Models.Ekata.Converters
{
    public class IpConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType) => objectType == typeof(IPAddress);

        public override object ReadJson(
          JsonReader reader,
          Type objectType,
          object existingValue,
          JsonSerializer serializer)
        {
            if (reader.Value == null)
                return (object)null;
            IPAddress address;
            return !IPAddress.TryParse(reader.Value.ToString(), out address) ? (object)null : (object)address;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value.GetType() == typeof(IPAddress))
            {
                IPAddress ipAddress = (IPAddress)value;
                writer.WriteValue(ipAddress.MapToIPv4().ToString());
            }
            else
                writer.WriteNull();
        }
    }
}
