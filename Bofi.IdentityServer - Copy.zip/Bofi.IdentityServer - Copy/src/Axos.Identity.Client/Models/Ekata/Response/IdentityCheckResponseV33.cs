﻿using Axos.Identity.Client.Models.Ekata.Requests;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace Axos.Identity.Client.Models.Ekata.Response
{
    public class IdentityCheckResponseV33
    {
        [JsonProperty("request")]
        public IdentityCheckRequestV33 Request { get; set; }

        [JsonProperty("primary_phone_checks")]
        public PhoneChecksV33 PrimaryApplicantPhoneChecks { get; set; }

        [JsonProperty("secondary_phone_checks")]
        public PhoneChecksV33 SecondaryApplicantPhoneChecks { get; set; }

        [JsonProperty("primary_address_checks")]
        public AddressChecksV33Primary PrimaryApplicantAddressChecks { get; set; }

        [JsonProperty("secondary_address_checks")]
        public AddressChecksV33Secondary SecondaryApplicantAddressChecks { get; set; }

        [JsonProperty("primary_email_address_checks")]
        public EmailAddressChecksV33 PrimaryApplicantEmailAddressChecks { get; set; }

        [JsonProperty("secondary_email_address_checks")]
        public EmailAddressChecksV33 SecondaryApplicantEmailAddressChecks { get; set; }

        [JsonProperty("ip_address_checks")]
        public IpAddressChecksV33 IpAddressChecks { get; set; }

        [JsonProperty("identity_check_score")]
        public int? IdentityCheckScore { get; set; }

        [JsonProperty("identity_network_score")]
        public double? IdentityNetworkScore { get; set; }

        [OnDeserialized]
        internal void OnDeserializedMethod(StreamingContext context)
        {
            if (this.Request == null || this.Request.AdditionalData == null)
                return;
            this.Request.ApiKey = (string)null;
        }
    }
}
