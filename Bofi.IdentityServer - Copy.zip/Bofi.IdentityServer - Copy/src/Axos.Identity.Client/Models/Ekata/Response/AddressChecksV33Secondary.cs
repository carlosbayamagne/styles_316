﻿using Axos.Identity.Client.Models.Ekata.Enums;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models.Ekata.Response
{
    public class AddressChecksV33Secondary
    {
        [JsonProperty("error")]
        public AddressCheckErrorV33Enum? Error { get; set; }

        public bool HasError => this.Error.HasValue;

        [JsonProperty("warnings")]
        public IList<string> Warnings { get; set; }

        [JsonProperty("is_valid")]
        public bool? IsValid { get; set; }

        [JsonProperty("input_completeness")]
        public AddressInputCompletenessV33Enum? InputCompleteness { get; set; }

        [JsonProperty("match_to_name")]
        public NameMappingStatusEnum? AddressMatchToName { get; set; }

        [JsonProperty("resident")]
        public EcommerceResident Resident { private get; set; }

        [JsonProperty("is_commercial")]
        public bool? IsCommercial { get; set; }

        [JsonProperty("is_forwarder")]
        public bool? IsForwarder { get; set; }

        [JsonProperty("type")]
        public AddressTypeEnum? AddressType { get; set; }

        [JsonProperty("distance_from_primary_address")]
        public int? DistanceFromPrimaryAddress { get; set; }

        [JsonProperty("linked_to_primary_resident")]
        public bool? LinkedToPrimaryResident { get; set; }
    }
}
