﻿using Newtonsoft.Json;

namespace Axos.Identity.Client.Models.Ekata
{
    public class EcommerceSubscriber
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("age_range")]
        public AgeRange AgeRange { get; set; }
    }
}
