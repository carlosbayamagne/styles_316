﻿using Axos.Identity.Client.Models.Ekata.Converters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;

namespace Axos.Identity.Client.Models.Ekata.Requests
{
    public class IdentityCheckRequestV33
    {
        public string ApiKey { get; set; }

        public string TransactionId { get; set; } = Guid.NewGuid().ToString();

        public DateTime TransactionTime { get; private set; } = DateTime.Now;

        public DateTime TransactionDate
        {
            get => this.TransactionTime.Date;
            set => this.TransactionTime = value;
        }

        [JsonConverter(typeof(IpConverter))]
        public IPAddress IpAddress { get; set; }
        public PrimaryApplicantInformationModel PrimaryApplicant { get; set; }
        public SecondaryApplicantInformationModel SecondaryApplicant { get; set; }

        [JsonExtensionData]
        internal IDictionary<string, JToken> AdditionalData { get; set; }
    }
}
