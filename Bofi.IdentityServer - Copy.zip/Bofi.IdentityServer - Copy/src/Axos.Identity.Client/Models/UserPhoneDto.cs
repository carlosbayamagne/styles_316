﻿using Axos.Identity.Client.Enums;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class UserPhoneDto
    {
       
        public string Number { get; set; }
        
        public string Extension { get; set; }

        public bool IsPrimary { get; set; }
        
        public PhoneType PhoneType { get; set; }

        public bool Confirmed { get; set; }

        public override string ToString()
        {
            if (string.IsNullOrEmpty(Extension))
                return Number;
            else
                return $"{Number} x{Extension}";
        }
    }
}
