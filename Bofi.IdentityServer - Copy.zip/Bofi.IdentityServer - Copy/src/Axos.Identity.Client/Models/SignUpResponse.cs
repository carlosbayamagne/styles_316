﻿namespace Axos.Identity.Client.Models
{
    public class SignUpResponse : IdentityResponse
    {
        public SignUpResponse()
        {

        }

        public SignUpResponse(bool success)
        {
            Registered = success;
        }

        public bool Registered { get; set; }
    }
}
