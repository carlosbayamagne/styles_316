﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class Organization
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Url { get; set; }

        public bool IsWhiteLabel { get; set; }

        public int UserId { get; set; }

        public IEnumerable<OrganizationSetting> Settings { get; set; }

        public IEnumerable<CustomPropertyResponse> RIAIdProperties { get; set; }

    }
}
