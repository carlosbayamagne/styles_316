﻿using System;
using Axos.Identity.Client.Enums;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Suffix { get; set; }
        public string CommonName { get; set; }
        public string Status { get; set; }
        public string CIF { get; set; }
        public string ClassCode { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string SSN { get; set; }
        public string Address { get; set; }
        public DateTime Birthdate { get; set; }
        public int? BrandId { get; set; }
        public int? JHABrandId { get; set; }
        public DateTime RegistrationDate { get; set; }
        public DateTime? LastContactDate { get; set; }
        public bool EnrollmentCompleted { get; set; }
        public PreloadUserStatus? PreloadedUser { get; set; }
        public DateTime? CACreationDate { get; set; }
		public bool InsightsEnabled { get; set; }
        public UserType? UserType { get; set; }
        public UserState? UserState { get; set; }
        public UserSubType? UserSubType { get; set; }
        public bool? HasSecurityQuestions { get; set; }
        public int? ParentUserId { get; set; }
        public string SecretWord { get; set; }
        public string SecretWordHint { get; set; }
        public string SegmentCode { get; set; }
        public bool SMSOptIn { get; set; }
        public string Occupation { get; set; }
        public string Employer { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string AlternateEmail { get; set; }
        public string AuthenticationCode { get; set; }
        public bool HasGoogleAuthenticator { get { return !String.IsNullOrEmpty(AuthenticationCode); } }

        public List<Address> Addresses { get; set; }

        public List<Relationship> Relationships { get; set; }

        public List<UserPhoneDto> Phones { get; set; }        

        public string SourceTypeCode { get; set; }

        public DateTime? MailingAddressLastUpdate { get; set; }
        public DateTime? MailingAddressLastConfirmation { get; set; }
        public bool MailingAddressInvalidFlag { get; set; }

        public bool EmailConfirmed { get; set; }

        public int? LoginFails {  get; set; }

        #region IRA
        public string AnnualIncome { get; set; }
        public string TotalNetWorth { get; set; }
        public string LiquidNetWorth { get; set; }
        public int? Dependents { get; set; }
        public string TaxBracket { get; set; }
        public string EmploymentStatus { get; set; }
        public int? YearsEmployed { get; set; }
        public CountryCitizenship? CountryCitizenship { get; set; }
        #endregion

        public bool RIAUser { get; set; }

    }
}
