﻿namespace Axos.Identity.Client.Models
{
    public class ValidateOtpNoUserRequest
    {
        public string PhoneNumber { get; set; }
        public string Otp { get; set; }
    }
}
