﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class UpdateAdminUserStatusRequest
    {
        public AdminUserStatus Status { get; set; }
    }
}
