﻿namespace Axos.Identity.Client.Models
{
    public class ChallengeQuestion
    {
        public string QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string Answer { get; set; }

        public ChallengeQuestion()
        {

        }

        public ChallengeQuestion(string id, string text)
        {
            QuestionId = id;
            QuestionText = text;
        }

        public ChallengeQuestion(string id, string text, string answer)
        {
            QuestionId = id;
            QuestionText = text;
            Answer = answer;
        }
    }
}
