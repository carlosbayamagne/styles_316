﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class RiskResponse : IdentityResponse
    {
        public RiskResponse()
        {

        }
        public RiskResponse(string transactionId)
        {
            TransactionId = transactionId;
        }
        public RiskResponse(string transactionId, int score)
        {
            TransactionId = transactionId;
            Score = score;
        }

        public IdentityAdvice Advice { get; set; }
        public string DeviceId { get; set; }
        public string DeviceSignature { get; set; }
        public string DeviceType { get; set; }
        public string MatchedRule { get; set; }
        public string RuleAnnotation { get; set; }
        public int Score { get; set; }
    }
}
