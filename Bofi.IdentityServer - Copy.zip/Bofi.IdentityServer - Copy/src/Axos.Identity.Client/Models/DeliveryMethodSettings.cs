﻿using System;

namespace Axos.Identity.Client.Models
{
    public class DeliveryMethodSettings
    {
		public bool EmailAlertEnabled { get; set; }
		public bool SmsAlertEnabled { get; set; }
		public int UserId { get; set; }
	}
}
