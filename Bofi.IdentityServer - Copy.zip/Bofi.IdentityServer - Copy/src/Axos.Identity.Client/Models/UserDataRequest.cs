﻿using Axos.Identity.Client.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class UserDataRequest
    {
        [Required]
        public string SSN { get; set; }

        [Required]
        public DateTime Birthdate { get; set; }

        [Required]
        public string Address { get; set; }

        public string Suite { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public State State { get; set; }

        [Required]
        public string PostalCode { get; set; }
    }
}
