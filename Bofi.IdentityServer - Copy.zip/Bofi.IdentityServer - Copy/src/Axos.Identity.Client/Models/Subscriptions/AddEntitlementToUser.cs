﻿using System;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class AddEntitlementToUser
    {
        public int UdBUserId { get; set; }
        public Guid EntitlementId { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }             // * Is there a catalog (BC for example)
        public string AccountNumberToBill { get; set; }
        public string AccountTypeToBill { get; set; }
        public string Source { get; set; }
    }
}
