﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class BundleEntitlement
    {
        public Guid Id { get; set; }
        public Guid EntitlementId { get; set; }
        public Entitlement Entitlement { get; set; }
        public Guid BundleId { get; set; }
        public Bundle Bundle { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
