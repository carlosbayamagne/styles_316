﻿using System;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class UserEntitlements
    {
        public int UserId { get; set; }
        public List<Guid> EntitlementIds { get; set; }
    }
}
