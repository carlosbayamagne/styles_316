﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class Bundle
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DiscountType DiscountType { get; set; }
        public decimal Discount { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastEditedDate { get; set; }

        public ICollection<BundleEntitlement> BundleEntitlements { get; set; }
    }
}
