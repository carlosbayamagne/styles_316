﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class SubscriptionsServiceResult
    {
        public bool Success { get; set; }
        public string ErrorMessage { get; set; }

        public object Data { get; set; }
    }
}
