﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class CreateEntitlement
    {
        public string Name { get; set; }
        public RewardTypes RewardType { get; set; }         // * Is there a catalog elsewhere
        public decimal Amount { get; set; }
        public string Source { get; set; }
    }
}
