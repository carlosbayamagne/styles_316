﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class UserEntitlement
    {
        public int Id { get; set; }
        public int UdBUserId { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }             // * Is there a catalog (BC for example)
        public string AccountNumberToBill { get; set; }
        public string AccountTypeToBill { get; set; }
        public string Source { get; set; }
        public DateTime CreatedDate { get; set; }
        public Guid EntitlementId { get; set; }
        public Entitlement Entitlement { get; set; }
    }
}
