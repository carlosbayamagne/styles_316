﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class CreateBundleModel
    {
        public string Name { get; set; }
        public DiscountType DiscountType { get; set; }
        public decimal Discount { get; set; }

        public List<Guid> EntitlementIds { get; set; }
    }

    public enum DiscountType
    {
        DollarsPerMonth,
        PercentagePerMonth
    }
}
