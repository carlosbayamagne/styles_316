﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class EntitlementModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public RewardTypes RewardType { get; set; }
        public decimal Amount { get; set; }
        public string Source { get; set; }
    }
}
