﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Subscriptions
{
    public class BundleModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DiscountType DiscountType { get; set; }
        public decimal Discount { get; set; }

        public List<Guid> EntitlementIds { get; set; }
    }
}
