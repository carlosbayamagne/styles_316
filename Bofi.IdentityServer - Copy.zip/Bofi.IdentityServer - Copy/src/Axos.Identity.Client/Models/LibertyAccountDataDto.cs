﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class LibertyAccountDataDto
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public int UdbUserID { get; set; }

        [Required]
        public string LibertyAccountId { get; set; }

        public string AccountType { get; set; }

        public string RIAId { get; set; }

        public int? primaryRepId { get; set; }
    }
}
