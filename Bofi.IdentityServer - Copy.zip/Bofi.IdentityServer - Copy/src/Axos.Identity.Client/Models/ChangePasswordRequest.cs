﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class ChangePasswordRequest 
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Brand { get; set; }
        public bool IsTemporary { get; set; }
        public string SubBrand { get; set; }
        public Dictionary<string, string> Tokens { get; set; }
    }
}
