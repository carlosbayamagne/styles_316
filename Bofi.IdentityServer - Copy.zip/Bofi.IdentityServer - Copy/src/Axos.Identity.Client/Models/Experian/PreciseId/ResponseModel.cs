﻿using System.Xml.Serialization;

namespace Axos.Identity.Client.Models.Experian.PreciseId
{
    [XmlRoot("NetConnectResponse", Namespace = "http://www.experian.com/NetConnectResponse")]
    public class ResponseModel
    {
        public string CompletionCode { get; set; }
        public string ReferenceId { get; set; }
        [XmlElement("Products")]
        public Products Products { get; set; }
        public string ErrorMessage { get; set; }

        public bool IsServiceError()
        {
            return !string.IsNullOrWhiteSpace(Products.PreciseIDServer.Error?.ErrorCode);
        }

        public string GetErrorMessage()
        {
            if (!string.IsNullOrWhiteSpace(Products.PreciseIDServer.Error.ErrorDescription))
                return Products.PreciseIDServer.Error.ErrorDescription;
            return ErrorMessage;
        }

        public ResponseModel()
        {
            Products = new Products();
        }
    }
}
