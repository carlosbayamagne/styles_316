﻿namespace Axos.Identity.Client.Models.Experian.PreciseId
{
    public class Answer
    {
        public int QuestionId { get; set; }
        public int AnswerId { get; set; }

        public Answer(int questionId, int answerId)
        {
            QuestionId = questionId;
            AnswerId = answerId;
        }
    }
}
