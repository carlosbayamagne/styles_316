﻿using Axos.Identity.Client.Models.Experian.PreciseId;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models.Experian
{
    public class SendIdaAnswersRequest
    {
        public string SessionId { get; set; }
        public string Reference { get; set; }
        public IEnumerable<Answer> Answers { get; set; }
    }
}
