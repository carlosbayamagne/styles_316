﻿namespace Axos.Identity.Client.Models.Experian.NetConnect
{
    public class ScoreModel
    {
        private ScoreModel(string sessionId, string responseCode, int bankrupcy, int dti, int fico, bool mla = false)
        {
            SessionId = sessionId;
            ResponseCode = responseCode;
            Bankrupcy = bankrupcy;
            DTI = dti;
            FICO = fico;
            MLA = mla;
        }


        public string SessionId { get; protected set; }
        public string ResponseCode { get; set; }

        public int Bankrupcy { get; set; }
        public int DTI { get; set; }
        public int FICO { get; set; }
        public bool MLA { get; set; }

        public static ScoreModel Create(string sessionId, string responseCode)
        {
            return new ScoreModel(sessionId, responseCode, 0, 0, 0);
        }
    }
}
