﻿using System;
using System.Xml.Serialization;

namespace Axos.Identity.Client.Models.Experian.NetConnect
{
    public class Products
    {
        public CreditProfile CreditProfile { get; set; }

        public Products()
        {
            CreditProfile = new CreditProfile();
        }
    }
    
    public class CreditProfile
    {
        public Header Header { get; set; }
        public Summary Summary { get; set; }
        public Subscriber Subscriber { get; set; }
        public Applicant PrimaryApplicant { get; set; }
        public AddOns AddOns { get; set; }
        public OutputType OutputType { get; set; }
        public Vendor Vendor { get; set; }
        public Options Options { get; set; }
        public Error Error { get; set; }

        public CreditProfile()
        {
            Header = new Header();
            Summary = new Summary();
            Subscriber = new Subscriber();
            PrimaryApplicant = new Applicant();
            Vendor = new Vendor();
            Options = new Options();
            Error = new Error();
            AddOns = new AddOns();
            OutputType = new OutputType();
        }
    }

    public class Header
    {
        public string ReportDate { get; set; }
        public string ReportTime { get; set; }
        public string Preamble { get; set; }
        public string ReferenceNumber { get; set; }
    }

    public class Subscriber
    {
        public string Preamble { get; set; }
        public string OpInitials { get; set; }
        public int SubCode { get; set; }
    }

    public class Applicant
    {
        public Name Name { get; set; }
        public string SSN { get; set; }

        public Address CurrentAddress { get; set; }
        public Phone Phone { get; set; }
        [XmlElement("YOB")]
        public int YOB { get; set; }

        public Applicant()
        {
            Name = new Name();
            CurrentAddress = new Address();
            Phone = new Phone();
        }
    }

    public class Name
    {
        public string Surname { get; set; }
        public string First { get; set; }
        public string Middle { get; set; }
    }

    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
    }

    public class Phone
    {
        public string Number { get; set; }
    }

    public class Vendor
    {
        [XmlElement("VendorNumber")]
        public string Number { get; set; }
        [XmlElement("VendorVersion")]
        public string Version { get; set; }
    }

    public class Options
    {
        public string ReferenceNumber { get; set; }

        public Options()
        {
            ReferenceNumber = Guid.NewGuid().ToString();
        }
    }

    public class Summary
    {
        public InitialResuts InitialResults { get; set; }
        public string PreciseIDScore { get; set; }
        public string DateOfBirthMatch { get; set; }

        public Summary()
        {
            InitialResults = new InitialResuts();
        }
    }

    public class InitialResuts
    {
        public string InitialDecision { get; set; }
        public string FinalDecision { get; set; }
        public string AuthenticationIndex { get; set; }
        public string MostLikelyFraudType { get; set; }
    }

    public class AddOns
    {
        public string MLA { get; set; }
        public RiskModels RiskModels { get; set; }

        public AddOns()
        {
            RiskModels = new RiskModels();
        }
    }

    public class RiskModels
    {
        public string Bankruptcy { get; set; }
        [XmlElement("FICO8")]
        public string FICO { get; set; }
        public string TotalDebtToIncome { get; set; }
    }



    public class OutputType
    {
       public XML XML { get; set; }

        public OutputType()
        {
            XML = new XML();
        }
    }

    public class XML
    {
        public string ARFVersion { get; set; }
        public string Verbose { get; set; }
    }

    public class Error
    {
        [XmlElement("HostID")]
        public string HostId { get; set; }
        [XmlElement("ApplicationID")]
        public string ApplicationId { get; set; }
        public string ReportDate { get; set; }
        public string ReportTime { get; set; }
        public string ReportType { get; set; }
        public string Preamble { get; set; }
        public string RegionCode { get; set; }
        [XmlElement("ARFVersion")]
        public string ArfVersion { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string ActionIndicator { get; set; }
        [XmlElement("ModuleID")]
        public string ModuleId { get; set; }
        public string ReferenceNumber { get; set; }
    }
}
