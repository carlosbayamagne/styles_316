﻿using System;
using System.Xml.Serialization;

namespace Axos.Identity.Client.Models.Experian.NetConnect
{
    [XmlRoot("NetConnectRequest", Namespace = "http://www.experian.com/NetConnect")]
    public class RequestModel
    {
        //[XmlAttribute("xsi:schemaLocation")]
        //public string Location { get; set; }
        public string EAI { get; set; }
        public string DBHost { get; set; }
        public string ReferenceId { get; set; }
        public RequestBody Request { get; set; }


        public RequestModel()
        {
            ReferenceId = Guid.NewGuid().ToString();
            Request = new RequestBody();
            Request.Products.CreditProfile.Options.ReferenceNumber = ReferenceId;
        }
    }

    [XmlRoot("Request", Namespace = "http://www.experian.com/WebDelivery")]
    public class RequestBody
    {
        [XmlAttribute("version")]
        public decimal Version { get; set; }
        public Products Products { get; set; }

        public RequestBody()
        {
            Products = new Products();
            Products.CreditProfile.Header = null;
            Products.CreditProfile.Summary = null;
            Products.CreditProfile.Error = null;
        }
    }
}
