﻿namespace Axos.Identity.Client.Models.Experian
{
    public class ServiceResult<T> : Result<T>
    {
        public string Request { get; private set; }
        public string Response { get; private set; }
        public new bool IsSuccess => base.IsSuccess;
        public new bool IsFailure => base.IsFailure;

        public ServiceResult(T value, string request, string response, bool isSuccess, string error)
            : base(value, isSuccess, error)
        {
            Request = request;
            Response = response;
        }

        public static ServiceResult<T> Ok(T value, string request, string response)
        {
            return new ServiceResult<T>(value, request, response, true, string.Empty);
        }

        public new static ServiceResult<T> Fail(string message)
        {
            return new ServiceResult<T>(default(T), string.Empty, string.Empty, false, message);
        }

        public static ServiceResult<T> Fail(string message, string request, string response)
        {
            return new ServiceResult<T>(default(T), string.Empty, string.Empty, false, message);
        }
    }
}
