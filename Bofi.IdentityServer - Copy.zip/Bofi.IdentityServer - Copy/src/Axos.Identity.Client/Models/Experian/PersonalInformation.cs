﻿using System;

namespace Axos.Identity.Client.Models.Experian
{
    public class PersonalInformation
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string SSN { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string DriverLicenseNumber { get; set; }
        public string DriverLicenseState { get; set; }
        public string PhoneNumber { get; set; }
        public string PhoneType { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Reference { get; set; }
    }
}
