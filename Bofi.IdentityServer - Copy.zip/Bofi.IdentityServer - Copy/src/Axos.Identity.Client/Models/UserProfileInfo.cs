﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class UserProfileInfo : User
    {
        public string MaskedCellPhone { get; set; }
        public string MaskedEmail { get; set; }
        public IEnumerable<AddressAccountAssociation> AddressAssociations { get; set; }
        public Address GroupPrimaryAddress { get; set; }
        public AddressAccountAssociation PrimaryAddress { get; set; }
        public AddressAccountAssociation MailingAddress { get; set; }
        public string PrimaryEmail { get; set; }
        public UserPhoneDto HomePhone { get; set; }
        public UserPhoneDto CellPhone1 { get; set; }
        public UserPhoneDto CellPhone2 { get; set; }
        public UserPhoneDto WorkPhone { get; set; }
        public UserPhoneDto PrimaryPhone { get; set; }
    }
}
