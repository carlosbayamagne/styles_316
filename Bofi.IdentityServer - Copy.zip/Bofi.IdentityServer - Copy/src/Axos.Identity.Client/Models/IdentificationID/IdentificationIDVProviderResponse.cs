﻿using Axos.Extensions;
using Axos.Integration.Experian.Responses;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Axos.Identity.Client.Models.IdentificationID
{
    public class IdentificationIDVProviderResponse
    {
        const int InitialResultsItem = 4;
        const int SessionIdItem = 1;
        const int KBAItem = 10;
        const int KBAScoreItem = 10;

        [JsonIgnore]
        public NetConnectResponse NetConnectResponse { get; set; }

        private InitialResults _initialResults = null;
        public InitialResults InitialResults
        {
            get
            {
                if (_initialResults == null)
                {
                    try
                    {
                        if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items != null && NetConnectResponse.Item.PreciseIDServer.Items.Count() >= 4)
                        {
                            _initialResults = ((Summary)NetConnectResponse.Item.PreciseIDServer.Items[InitialResultsItem]).InitialResults;
                        }

                    }
                    catch (Exception)
                    {
                    }
                }
                return _initialResults;
            }
            set { _initialResults = value; }
        }

        private string _sessionId = null;
        public string SessionId
        {
            get
            {
                if (_sessionId == null)
                {
                    try
                    {
                        if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items != null && NetConnectResponse.Item.PreciseIDServer.Items.Count() >= 1)
                        {
                            _sessionId = NetConnectResponse.Item.PreciseIDServer.Items[SessionIdItem].ToString();
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                return _sessionId;
            }
            set { _sessionId = value; }
        }

        private string _preciseIdScore { get; set; }
        public string PreciseIDScore
        {
            get
            {
                if (_preciseIdScore == null)
                {
                    try
                    {
                        if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items != null && NetConnectResponse.Item.PreciseIDServer.Items.Count() >= 4)
                        {
                            _preciseIdScore = NetConnectResponse.Item.PreciseIDServer.Items[InitialResultsItem].GetPropertyValue<string>("PreciseIDScore");
                        }
                        else if (ScoreSummary != null)
                        {
                            _preciseIdScore = ScoreSummary.GetPropertyValue<string>("PreciseIDScore");
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                return _preciseIdScore;
            }
            set { _preciseIdScore = value; }
        }

        private string _outWalletScore { get; set; }
        public string OutWalletScore
        {
            get
            {
                if (_outWalletScore == null)
                {
                    try
                    {
                        if (ScoreSummary != null)
                        {
                            _outWalletScore = ScoreSummary.GetPropertyValue<string>("OutWalletScore");
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                return _outWalletScore;
            }
            set { _outWalletScore = value; }
        }

        private string _acceptReferCode { get; set; }
        public string AcceptReferCode
        {
            get
            {
                if (_acceptReferCode == null)
                {
                    try
                    {
                        if (ScoreSummary != null)
                        {
                            _acceptReferCode = ScoreSummary.GetPropertyValue<string>("AcceptReferCode");
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                return _acceptReferCode;

            }
            set { _acceptReferCode = value; }
        }

        private object ScoreSummary
        {
            get
            {
                try
                {
                    if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items != null && NetConnectResponse.Item.PreciseIDServer.Items.Count() >= KBAScoreItem && NetConnectResponse.Item.PreciseIDServer.Items[KBAScoreItem] is KBAScore)
                    {
                        return NetConnectResponse.Item.PreciseIDServer.Items[KBAScoreItem].GetPropertyValue<object>("ScoreSummary");
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (Exception)
                {
                    return null;
                }
            }
            set { }
        }

        private List<QuestionSet> _questions = null;
        public List<QuestionSet> IDAQuestions
        {
            get
            {
                if (_questions == null)
                {
                    if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items.Length >= KBAItem && NetConnectResponse.Item.PreciseIDServer.Items[KBAItem] is KBA)
                    {
                        object[] genericQuestionSetArray = (object[])((KBA)NetConnectResponse.Item.PreciseIDServer.Items[KBAItem]).Items;

                        if (genericQuestionSetArray.Length > 0)
                        {
                            _questions = new List<QuestionSet>();
                        }
                        foreach (object o in genericQuestionSetArray)
                        {
                            if (o is QuestionSet)
                            {
                                _questions.Add((QuestionSet)o);
                            }
                        }
                    }
                }
                return _questions;
            }
            set
            {
                _questions = value;
            }
        }
    }
}
