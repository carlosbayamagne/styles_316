﻿using Axos.Integration.Experian.Responses;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Axos.Identity.Client.Models.IdentificationID
{
    public class IdentificationIDVQuestionsResponse
    {
        const int InitialResultsItem = 4;
        const int SessionIdItem = 1;
        const int KBAItem = 10;

        [JsonIgnore]
        public NetConnectResponse NetConnectResponse { get; set; }

        private InitialResults _initialResults = null;
        public InitialResults InitialResults
        {
            get
            {
                if (_initialResults == null)
                {
                    try
                    {
                        if (NetConnectResponse != null
                            && NetConnectResponse.Item != null
                            && NetConnectResponse.Item.PreciseIDServer != null
                            && NetConnectResponse.Item.PreciseIDServer.Items != null
                            && NetConnectResponse.Item.PreciseIDServer.Items.Count() > InitialResultsItem)
                        {
                            _initialResults = ((Summary)NetConnectResponse.Item.PreciseIDServer.Items[InitialResultsItem]).InitialResults;
                        }

                    }
                    catch (Exception)
                    {
                        // Intentional error swallow 
                    }
                }
                return _initialResults;
            }
            set { _initialResults = value; }
        }

        private Summary _summary = null;
        public Summary Summary
        {
            get
            {
                if (_summary == null)
                {
                    try
                    {
                        if (NetConnectResponse != null && NetConnectResponse.Item != null && NetConnectResponse.Item.PreciseIDServer != null && NetConnectResponse.Item.PreciseIDServer.Items != null)
                        {
                            _summary = (Summary)NetConnectResponse.Item.PreciseIDServer.Items[InitialResultsItem];
                        }

                    }
                    catch (Exception)
                    {
                        // Intentional error swallow 
                    }
                }
                return _summary;
            }
            set { _summary = value; }
        }

        private string _sessionId = null;
        public string SessionId
        {
            get
            {
                if (_sessionId == null)
                {
                    try
                    {
                        if (NetConnectResponse != null
                            && NetConnectResponse.Item != null
                            && NetConnectResponse.Item.PreciseIDServer != null
                            && NetConnectResponse.Item.PreciseIDServer.Items != null
                            && NetConnectResponse.Item.PreciseIDServer.Items.Count() > SessionIdItem)
                        {
                            _sessionId = NetConnectResponse.Item.PreciseIDServer.Items[SessionIdItem].ToString();
                        }
                    }
                    catch (Exception)
                    {
                        // Intentional error swallow 
                    }
                }
                return _sessionId;
            }
            set { _sessionId = value; }
        }

        private List<QuestionSet> _questions = null;
        public List<QuestionSet> IDAQuestions
        {
            get
            {
                if (_questions == null)
                {
                    if (NetConnectResponse != null && NetConnectResponse.Item != null
                        && NetConnectResponse.Item.PreciseIDServer != null
                        && NetConnectResponse.Item.PreciseIDServer.Items != null
                        && NetConnectResponse.Item.PreciseIDServer.Items.Length > KBAItem
                        && NetConnectResponse.Item.PreciseIDServer.Items[KBAItem] is KBA)
                    {
                        object[] genericQuestionSetArray = (object[])((KBA)NetConnectResponse.Item.PreciseIDServer.Items[KBAItem]).Items;

                        if (genericQuestionSetArray.Length > 0)
                        {
                            _questions = new List<QuestionSet>();
                        }
                        foreach (object o in genericQuestionSetArray)
                        {
                            if (o is QuestionSet)
                            {
                                _questions.Add((QuestionSet)o);
                            }
                        }
                    }
                }
                return _questions;
            }
            set
            {
                _questions = value;
            }
        }
    }
}

