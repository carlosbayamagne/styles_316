﻿using System;
using System.Collections.Specialized;

namespace Axos.Identity.Client.Models.IdentificationID
{
    public class IdentificationIDVAnswersRequest : IdentificationIDVProviderRequest
    {
        public string SessionId { get; set; }
        public string OutWalletAnswer1 { get; set; }
        public string OutWalletAnswer2 { get; set; }
        public string OutWalletAnswer3 { get; set; }
        public string OutWalletAnswer4 { get; set; }
        public string OutWalletAnswer5 { get; set; }

        public override NameValueCollection GetNameValueCollection()
        {
            NameValueCollection retval = base.GetNameValueCollection();
            if (!String.IsNullOrEmpty(SessionId)) retval.Add("SessionId", SessionId);
            if (!String.IsNullOrEmpty(OutWalletAnswer1)) retval.Add("OutWalletAnswer1", OutWalletAnswer1);
            if (!String.IsNullOrEmpty(OutWalletAnswer2)) retval.Add("OutWalletAnswer2", OutWalletAnswer2);
            if (!String.IsNullOrEmpty(OutWalletAnswer3)) retval.Add("OutWalletAnswer3", OutWalletAnswer3);
            if (!String.IsNullOrEmpty(OutWalletAnswer4)) retval.Add("OutWalletAnswer4", OutWalletAnswer4);
            if (!String.IsNullOrEmpty(OutWalletAnswer5)) retval.Add("OutWalletAnswer5", OutWalletAnswer5);
            return retval;
        }
    }
}