﻿namespace Axos.Identity.Client.Models.IdentificationID
{
    public class IdentificationIDVQuestionsRequest : IdentificationIDVProviderRequest
    {

    }
}
