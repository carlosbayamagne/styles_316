﻿using System;
using System.Collections.Specialized;

namespace Axos.Identity.Client.Models.IdentificationID
{
    public class IdentificationIDVProviderRequest
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string SSN { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string DLState { get; set; }
        public string DLNum { get; set; }
        public string Phone { get; set; }
        public string PhoneType { get; set; }
        public string DOB { get; set; }

        public virtual NameValueCollection GetNameValueCollection()
        {
            NameValueCollection retval = new NameValueCollection();
            if (!String.IsNullOrEmpty(LastName)) retval.Add("LastName", LastName);
            if (!String.IsNullOrEmpty(FirstName)) retval.Add("FirstName", FirstName);
            if (!String.IsNullOrEmpty(MiddleName)) retval.Add("MiddleName", MiddleName);
            if (!String.IsNullOrEmpty(SSN)) retval.Add("SSN", SSN);
            if (!String.IsNullOrEmpty(StreetAddress)) retval.Add("StreetAddress", StreetAddress);
            if (!String.IsNullOrEmpty(City)) retval.Add("City", City);
            if (!String.IsNullOrEmpty(State)) retval.Add("State", State);
            if (!String.IsNullOrEmpty(PostalCode)) retval.Add("PostalCode", PostalCode);
            if (!String.IsNullOrEmpty(DLState)) retval.Add("DLState", DLState);
            if (!String.IsNullOrEmpty(DLNum)) retval.Add("DLNum", DLNum);
            if (!String.IsNullOrEmpty(Phone)) retval.Add("Phone", Phone);
            if (!String.IsNullOrEmpty(PhoneType)) retval.Add("PhoneType", PhoneType);
            if (!String.IsNullOrEmpty(DOB)) retval.Add("DOB", DOB);
            return retval;
        }
    }
}
