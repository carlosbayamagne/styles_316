﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class AddressAccountAssociation
    {
        public Address Address { get; set; }
        public IEnumerable<int> AccountIds { get; set; }
    }
}
