﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class UserDetail : User
    {
        
        public CredentialStatus PasswordStatus { get; set; }

        public CredentialStatus QuestionsStatus { get; set; }
    }
}
