﻿using System;

namespace Axos.Identity.Client.Models
{
    public class Credential : IdentityResponse
    {
        public Credential()
        {

        }
        public Credential(DateTime creation, DateTime expiration)
        {
            CreationDate = creation;
            ExpirationDate = expiration;
        }

        public DateTime CreationDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string ProfileName { get; set; }
    }
}
