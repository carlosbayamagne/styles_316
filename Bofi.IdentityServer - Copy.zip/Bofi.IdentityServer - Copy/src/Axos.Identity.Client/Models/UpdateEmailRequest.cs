﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class UpdateEmailRequest
    {
        [Required, EmailAddress]
        public string PrimaryEmail { get; set; }
        [EmailAddress]
        public string AlternateEmail { get; set; }
    }
}
