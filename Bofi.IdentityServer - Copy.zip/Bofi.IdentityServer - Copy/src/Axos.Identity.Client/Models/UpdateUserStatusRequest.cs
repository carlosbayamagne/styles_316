﻿using Axos.Identity.Client.Enums;
using Axos.Integration.Contracts.DTOs.Validations;

namespace Axos.Identity.Client.Models
{
    public class UpdateUserStatusRequest
    {
        [EnumTypeDescriptionValidation(typeof(UserStatus))]
        public string Status { get; set; }
        public int[] UserIds { get; set; }
    }
}
