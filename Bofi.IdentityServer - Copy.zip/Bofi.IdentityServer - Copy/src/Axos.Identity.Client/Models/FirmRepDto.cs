﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class FirmRepDto
    {
        public int FirmId { get; set; }
        public string CommonName { get; set; }
        public string Logo { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public IEnumerable<ManagedAccounts> ManagedAccounts { get; set; }
        public IEnumerable<Representatives> Representatives { get; set; }
    }

    public class Representatives
    {
        public int RepId { get; set; }
        public bool IsPrimary { get; set; }
        public string CommonName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public IEnumerable<ManagedAccounts> ManagedAccounts { get; set; }
    }

    public class ManagedAccounts
    {
        public string Number { get; set; }
        public string Type { get; set; }
    }
}
