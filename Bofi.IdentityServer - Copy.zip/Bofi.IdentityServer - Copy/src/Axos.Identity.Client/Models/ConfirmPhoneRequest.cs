﻿namespace Axos.Identity.Client.Models
{
    public class ConfirmPhoneRequest
    {       
        public string Number { get; set; }
    }
}
