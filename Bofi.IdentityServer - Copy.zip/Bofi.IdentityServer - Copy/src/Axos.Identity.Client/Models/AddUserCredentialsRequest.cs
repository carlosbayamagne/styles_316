﻿using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class AddUserCredentialsRequest
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
