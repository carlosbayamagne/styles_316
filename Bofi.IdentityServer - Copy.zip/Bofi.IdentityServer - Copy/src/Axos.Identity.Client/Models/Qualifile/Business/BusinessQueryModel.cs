﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Qualifile.Business
{
    public class BusinessQueryModel
    {
        public string accountnbr { get; set; }
        public string addressmonthsnbr { get; set; }
        public string addressyearsnbr { get; set; }
        public string bankcd { get; set; }
        public string businessfederalidentificationnbr { get; set; }
        public string businessnm { get; set; }
        public string businesstypecd { get; set; }
        public string businessCityNm { get; set; }
        public string businessCompositePhoneNbr { get; set; }
        public string businessCountryCd { get; set; }
        public string consumer1 { get; set; }
        public string consumer2 { get; set; }
        public string depositamt { get; set; }
        public string businessPostalPlusFourCd { get; set; }
        public string prevaddressmonthsnbr { get; set; }
        public string prevaddressyearsnbr { get; set; }
        public string prevcitynm { get; set; }
        public string prevcountrycd { get; set; }
        public string prevpostalplusfourcd { get; set; }
        public string prevstatecd { get; set; }
        public string prevstreetaddresstxt { get; set; }
        public string businessStateCd { get; set; }
        public string businessStreetAddressTxt { get; set; }
        public string userdefinedrecordtxt { get; set; }

        public BusinessQueryModel() { }

        public BusinessQueryModel(string businessfederalidentificationnbr, string businessnm, string businessStreetAddressTxt, string businessCityNm, string businessStateCd, string businessPostalPlusFourCd)
        {
            this.businessfederalidentificationnbr = businessfederalidentificationnbr;
            this.businessnm = businessnm;
            this.businessStreetAddressTxt = businessStreetAddressTxt;
            this.businessCityNm = businessCityNm;
            this.businessStateCd = businessStateCd;
            this.businessPostalPlusFourCd = businessPostalPlusFourCd;
        }
    }
}
