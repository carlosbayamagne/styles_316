﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.Qualifile
{
    public class ServiceResult<T> : Result<T>
    {
        public string Request { get; private set; }
        public string Response { get; private set; }
        public new bool IsSuccess => base.IsSuccess;
        public new bool IsFailure => base.IsFailure;

        public ServiceResult(T value, string request, string response, bool isSuccess, string error)
            : base(value, isSuccess, error)
        {
            Request = request;
            Response = response;
        }

        public static ServiceResult<T> Ok(T value, string request, string response)
        {
            return new ServiceResult<T>(value, request, response, true, string.Empty);
        }

        public new static ServiceResult<T> Fail(string message)
        {
            return new ServiceResult<T>(default(T), string.Empty, string.Empty, false, message);
        }

        public static ServiceResult<T> Fail(string message, string request, string response)
        {
            return new ServiceResult<T>(default(T), string.Empty, string.Empty, false, message);
        }
    }

    public class Result
    {
        public bool IsSuccess { get; }

        public string Error { get; }

        public bool IsFailure => !this.IsSuccess;

        protected Result(bool isSuccess, string error)
        {
            if (isSuccess && !string.IsNullOrWhiteSpace(error))
                throw new InvalidOperationException("error message should be empty on success");
            this.IsSuccess = isSuccess || !string.IsNullOrWhiteSpace(error) ? isSuccess : throw new InvalidOperationException("error message is required in failure");
            this.Error = error;
        }

        public static Result Fail(string message) => new Result(false, message);

        public static Result Ok() => new Result(true, string.Empty);

        public static Result<T> Fail<T>(string message) => new Result<T>(default(T), false, message);

        public static Result<T> Ok<T>(T value) => new Result<T>(value, true, string.Empty);
    }

    public class Result<T> : Result
    {
        private readonly T _value;

        public T Value
        {
            get
            {
                if (!this.IsSuccess)
                    throw new InvalidOperationException();
                return this._value;
            }
        }

        protected internal Result(T value, bool isSuccess, string error)
          : base(isSuccess, error)
        {
            this._value = value;
        }
    }
}
