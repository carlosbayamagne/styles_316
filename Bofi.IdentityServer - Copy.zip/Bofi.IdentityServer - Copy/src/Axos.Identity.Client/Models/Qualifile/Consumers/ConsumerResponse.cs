﻿using System.Xml.Serialization;

namespace Axos.Identity.Client.Models.Qualifile.Consumers
{
    [XmlRoot(ElementName = "accountActionInfo")]
    public class AccountActionInfo
    {
        [XmlElement(ElementName = "accountAcceptanceTxt")]
        public string AccountAcceptanceTxt { get; set; }
        [XmlElement(ElementName = "accountActionTxt1")]
        public string AccountActionTxt1 { get; set; }
        [XmlElement(ElementName = "accountActionTxt10")]
        public string AccountActionTxt10 { get; set; }
        [XmlElement(ElementName = "accountActionTxt2")]
        public string AccountActionTxt2 { get; set; }
        [XmlElement(ElementName = "accountActionTxt3")]
        public string AccountActionTxt3 { get; set; }
        [XmlElement(ElementName = "accountActionTxt4")]
        public string AccountActionTxt4 { get; set; }
        [XmlElement(ElementName = "accountActionTxt5")]
        public string AccountActionTxt5 { get; set; }
        [XmlElement(ElementName = "accountActionTxt6")]
        public string AccountActionTxt6 { get; set; }
        [XmlElement(ElementName = "accountActionTxt7")]
        public string AccountActionTxt7 { get; set; }
        [XmlElement(ElementName = "accountActionTxt8")]
        public string AccountActionTxt8 { get; set; }
        [XmlElement(ElementName = "accountActionTxt9")]
        public string AccountActionTxt9 { get; set; }
    }

    [XmlRoot(ElementName = "qualifileInformation")]
    public class QualifileInformation
    {
        [XmlElement(ElementName = "scoreNbr")]
        public string ScoreNbr { get; set; }
    }

    [XmlRoot(ElementName = "qualifileResponse")]
    public class QualifileResponse
    {
        [XmlElement(ElementName = "accountActionInfo")]
        public AccountActionInfo AccountActionInfo { get; set; }
        [XmlElement(ElementName = "qualifileInformation")]
        public QualifileInformation QualifileInformation { get; set; }
        [XmlElement(ElementName = "errorTxt")]
        public string ErrorTxt { get; set; }
    }

    [XmlRoot(ElementName = "debitBureauComplianceInfo")]
    public class DebitBureauComplianceInfo
    {
        [XmlElement(ElementName = "debitFreezeMessage")]
        public string DebitFreezeMessage { get; set; }
    }

    [XmlRoot(ElementName = "creditBureauComplianceInfo")]
    public class CreditBureauComplianceInfo
    {
        [XmlElement(ElementName = "creditFreezeMessageTxt")]
        public string CreditFreezeMessageTxt { get; set; }
    }

    [XmlRoot(ElementName = "complianceInfo")]
    public class ComplianceInfo
    {
        [XmlElement(ElementName = "debitBureauComplianceInfo")]
        public DebitBureauComplianceInfo DebitBureauComplianceInfo { get; set; }
        [XmlElement(ElementName = "creditBureauComplianceInfo")]
        public CreditBureauComplianceInfo CreditBureauComplianceInfo { get; set; }
    }

    [XmlRoot(ElementName = "consumer")]
    public class ConsumerResponse
    {
        [XmlElement(ElementName = "qualifileResponse")]
        public QualifileResponse QualifileResponse { get; set; }
        [XmlElement(ElementName = "complianceInfo")]
        public ComplianceInfo ComplianceInfo { get; set; }
    }

    [XmlRoot("chexAuthenticateResponse")]
    public class TokenResponse
    {
        [XmlElement("chexAuthenticateReturn")]
        public string TokenValue { get; set; }
    }
}
