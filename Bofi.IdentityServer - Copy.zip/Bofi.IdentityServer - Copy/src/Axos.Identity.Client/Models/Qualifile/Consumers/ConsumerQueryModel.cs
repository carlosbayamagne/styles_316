﻿namespace Axos.Identity.Client.Models.Qualifile.Consumers
{
    public class ConsumerQueryModel
    {
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string FirstName { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string SSN { get; set; }
        public int BrandId { get; set; }
        public int SourceTypeId { get; set; }
        public string IdNumber { get; set; }
        public string IdStateCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Birthdate { get; set; }

        public ConsumerQueryModel() { }

        public ConsumerQueryModel(
            string firstName,
            string middleName,
            string lastName,
            string ssn,
            string streetAddress,
            string city,
            string state,
            string postalCode,
            int brandId,
            int sourceTypeId,
            string idNumber,
            string idStateCode,
            string phoneNumber,
            string birthdate)
        {
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            SSN = ssn;
            StreetAddress = streetAddress;
            City = city;
            State = state;
            PostalCode = postalCode;
            BrandId = brandId;
            SourceTypeId = sourceTypeId;
            IdNumber = idNumber;
            IdStateCode = idStateCode;
            PhoneNumber = phoneNumber;
            Birthdate = birthdate;
        }
    }
}
