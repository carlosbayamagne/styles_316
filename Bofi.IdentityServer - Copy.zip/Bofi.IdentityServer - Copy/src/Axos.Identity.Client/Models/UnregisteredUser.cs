﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models
{
    public class UnregisteredUser
    {
        public string CIF { get; set; }

        public string UserName { get; set; }

        public string Status { get; set; }
    }

    public class UnregisterUserPack
    {
        public IEnumerable<UnregisteredUser> UserList { get; set; }

        public bool IsSave { get; set; }
    }
}
