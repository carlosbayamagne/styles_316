﻿namespace Axos.Identity.Client.Models
{
    public class EditionResponse : IdentityResponse
    {
        public EditionResponse(bool applied)
        {
            ChangesApplied = applied;
        }

        public bool ChangesApplied { get; set; }
    }
}
