﻿namespace Axos.Identity.Client.Models
{
    public class PrivacySettings
    {
        public string userid { get; set; }
        public bool PrivacyDoNotShareCreditPersonalInfo { get; set; }
        public bool PrivacyDoNotMarketPersonalInfo { get; set; }
        public bool PrivacyDoNotSharePersonalInfoNonAffiliates { get; set; }
    }
}
