﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models
{
    public class HealthCheckResponse : HealthCheckModel
    {
        
        public string ServerName { get; set; }

        public HealthCheckModel[] Databases { get; set;}

        public HealthCheckModel[] Dependencies { get; set; }
    }
}
