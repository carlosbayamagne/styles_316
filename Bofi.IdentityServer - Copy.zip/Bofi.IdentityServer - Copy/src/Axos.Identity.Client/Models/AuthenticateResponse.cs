﻿using Axos.Identity.Client.Enums;
using System;

namespace Axos.Identity.Client.Models
{
    public class AuthenticateResponse
    {
        public AuthenticationStatus Status { get; set; }
        public User UserInfo { get; set; }
        public Guid ChallengeToken { get; set; }
        public DeviceInfo DeviceInfo { get; set; }
        public int? LoginFails { get; set; }
    }
}
