﻿namespace Axos.Identity.Client.Models
{
    public class PrivacySettingsRequest
    {
        public string Cif { get; set; }
        public bool ShareCreditWorthinessOptOut { get; set; }
        public bool ShareWithAffiliatesOptOut { get; set; }
        public bool ShareWithNonAffiliatesOptOut { get; set; }
    }
}
