﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class LogOutRequest
    {
        public int UserId { get; set; }
        public LogoutEventLogoutReason Reason { get; set; }
    }
}