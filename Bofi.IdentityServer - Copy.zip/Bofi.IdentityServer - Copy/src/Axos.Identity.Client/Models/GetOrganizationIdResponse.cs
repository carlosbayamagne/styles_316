﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class GetOrganizationIdResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public int Data { get; set; }
    }
}
