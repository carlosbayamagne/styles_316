﻿namespace Axos.Identity.Client.Models
{
    public class ZipcodeInformation
    {
        public string Country { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string StateName { get; set; }
        public string StateCode { get; set; }
        public string County { get; set; }
        public string CountyCode { get; set; }
        public string Community { get; set; }
        public string CommunityCode { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
    }
}