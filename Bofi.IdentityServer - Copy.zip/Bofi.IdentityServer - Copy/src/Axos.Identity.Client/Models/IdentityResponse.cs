﻿namespace Axos.Identity.Client.Models
{
    public class IdentityResponse
    {
        public IdentityResponse()
        {

        }
        public IdentityResponse(string transantionId)
        {
            TransactionId = transantionId;
        }

        public bool Success { get; set; }
        public string Message { get; set; }
        public string TransactionId { get; set; }
    }
}
