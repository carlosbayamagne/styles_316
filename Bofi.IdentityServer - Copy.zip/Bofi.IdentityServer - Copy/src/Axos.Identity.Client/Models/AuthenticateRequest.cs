﻿using Axos.Identity.Client.Models.Biometrics;
using System;

namespace Axos.Identity.Client.Models
{
    public class AuthenticateRequest 
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int BrandId { get; set; }
        public Guid ResetPasswordToken { get; set; }
        public IdentityDevice Device { get; set; }
        public BiometricIdentityRequest BiometricIdentity { get; set; }
        public bool UpdateLastContactDate { get; set; } = true;
        public string LoginOrigin { get; set; }
    }
}
