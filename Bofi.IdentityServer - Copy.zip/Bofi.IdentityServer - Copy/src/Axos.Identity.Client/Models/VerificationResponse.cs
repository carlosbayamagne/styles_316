﻿namespace Axos.Identity.Client.Models
{
    public class VerificationResponse : IdentityResponse
    {
        public VerificationResponse()
        {

        }

        public VerificationResponse(bool ok)
        {
            Ok = ok;
        }

        public bool Ok { get; set; }
    }
}
