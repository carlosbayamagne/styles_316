﻿using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class Brand
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Url { get; set; }

        public bool IsWhiteLabel { get; set; }

        public int UserId { get; set; }

        public IEnumerable<BrandSetting> Settings { get; set; }

    }
}
