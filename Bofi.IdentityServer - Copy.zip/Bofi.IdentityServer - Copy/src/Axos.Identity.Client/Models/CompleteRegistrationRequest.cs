﻿namespace Axos.Identity.Client.Models
{
    public class CompleteRegistrationRequest
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
