﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class SalesForceServiceResponse
    {
        public string Message { get; set; }
        public bool Success { get; set; }
        public SalesForceIds Data { get; set; }
    }

    public class SalesForceIds
    {
        public string AccountId { get; set; }
        public string ContactId { get; set; }
    }
}
