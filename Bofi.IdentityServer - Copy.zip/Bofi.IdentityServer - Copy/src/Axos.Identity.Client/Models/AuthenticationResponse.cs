﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class AuthenticationResponse : IdentityResponse
    {
        public bool Authenticated { get; set; }

 //       [EnumTypeDescriptionValidation(typeof(AuthenticationStatus))]
        public AuthenticationStatus Status { get; set; }
        public bool Locked { get; set; }
        public bool IsTemporary { get; set; }
    }
}
