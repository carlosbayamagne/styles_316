﻿namespace Axos.Identity.Client.Models
{
    public class IdentityDevice
    {
        public IdentityDevice()
        {

        }

        public string DeviceId { get; set; }
        public string Signature { get; set; }
    }
}
