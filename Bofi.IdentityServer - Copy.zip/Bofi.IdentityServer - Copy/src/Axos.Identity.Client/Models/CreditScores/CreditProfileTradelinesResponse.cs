﻿using System;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class CreditProfileTradelinesResponse
    {
        public DateTime CreditProfileTimestamp { get; set; }
        public CreditProfileTradeLines[] CreditProfileTradeLines { get; set; }
    }
    public class CreditProfileTradeLines
    {
        public string Balance { get; set; }
        public string Classification { get; set; }
        public string Limit { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
    }
}
