﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class QuestionData
    {
        public string QuestionNumber { get; set; }

        public string AnswerNumber { get; set; }

        public string QuestionId { get; set; }

        public string AnswerChoiceId { get; set; }
    }
}
