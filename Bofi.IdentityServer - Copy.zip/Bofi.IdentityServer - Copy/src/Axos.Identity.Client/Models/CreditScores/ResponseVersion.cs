﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class ResponseVersion
    {
        public string Requested { get; set; }

        public string MinimumSupported { get; set; }

        public string MaximumSupported { get; set; }
    }
}
