﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class CreditProfileContainer
    {
        public string CreditProfileValue { get; set; }

        public DateTime? CreditProfileDate { get; set; }
    }
}
