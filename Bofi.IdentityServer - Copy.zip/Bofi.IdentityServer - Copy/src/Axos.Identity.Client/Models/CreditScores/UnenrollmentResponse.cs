﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class UnenrollmentResponse : BaseExperianResponse
    {
        public ResponseVersion Version { get; set; }
    }
}
