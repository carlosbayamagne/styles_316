﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class SubmitIDVerificationDataResponse : BaseExperianResponse
    {
        public string BillingID { get; set; }
        public ResponseVersion Version { get; set; }
    }
}
