﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class AnswerOption
    {
        public string AnswerNumber { get; set; }

        public string Answer { get; set; }

        public string AnswerChoiceId { get; set; }
    }
}
