﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class ThinLoadResponse : BaseExperianResponse
    {
        public string BureauErrorCode { get; set; }

        public string BureauErrorMessage { get; set; }
    }
}
