﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class CreditScoreNotificationPreferences
    {
        public bool SMSEnabled { get; set; }

        public bool EmailEnabled { get; set; }

        public bool PushEnabled { get; set; }
    }
}
