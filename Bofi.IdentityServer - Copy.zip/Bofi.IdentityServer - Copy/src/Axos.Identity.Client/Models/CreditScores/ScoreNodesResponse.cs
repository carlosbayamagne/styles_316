﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class ScoreNodesResponse
    {
        public ScoreNode Previous { get; set; }

        public ScoreNode Current { get; set; }
    }

    public class ScoreNode
    {
        public string Score { get; set; }

        public DateTime ScoreDate { get; set; }
    }
}
