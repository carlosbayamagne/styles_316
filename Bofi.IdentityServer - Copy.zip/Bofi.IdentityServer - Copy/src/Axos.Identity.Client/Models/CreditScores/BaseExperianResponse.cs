﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class BaseExperianResponse
    {
        public string EncryptedData { get; set; }

        public string TraceNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string Status { get; set; }

        public string ErrorText { get; set; }

        public string ErrorType { get; set; }
    }
}
