﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class VerificationDataRequest
    {
        public string ApplicantChallengeId { get; set; }

        public List<QuestionData> QuestionDataArray { get; set; }
    }
}
