﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Models.CreditScores
{
    public class UserCheckResponse : BaseExperianResponse
    {
        public SubscriberData SubscriberData { get; set; }
    }

    public class SubscriberData
    {
        public string Active { get; set; }

        public string Address1 { get; set; }

        public string CBStatus { get; set; }

        public string City { get; set; }

        public string CountryCode { get; set; }

        public string DOB { get; set; }

        public string EmailAddress { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string MiddleInitial { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        public string LatestsUnenrollmentDate { get; set; }

        public bool SMSEnabled { get; set; }

        public bool EmailEnabled { get; set; }

        public bool PushEnabled { get; set; }
    }
}
