﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models
{
    public class UpdateUserPhonesRequest
    {
        public UserPhoneDto HomePhone { get; set; }
        public UserPhoneDto CellPhone1 { get; set; }
        public UserPhoneDto CellPhone2 { get; set; }
        public UserPhoneDto WorkPhone { get; set; }
        public UserPhoneDto WorkFax { get; set; }
    }
}
