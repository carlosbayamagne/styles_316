﻿using System.Diagnostics.CodeAnalysis;

namespace Axos.Identity.Client.Models
{
    public class Relationship
    {
        public int RelationshipId { get; set; }
        public int UdbUserId { get; set; }
        public int ParentUserID { get; set; }
    }
}
