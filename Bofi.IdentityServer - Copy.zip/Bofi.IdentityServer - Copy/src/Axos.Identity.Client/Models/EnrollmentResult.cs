﻿using System;
using System.Collections.Generic;

namespace Axos.Identity.Client.Models
{
    public class EnrollmentResult
    {
        public bool IdentityCreated { get; set; }
        public int IdentityId { get; set; }
        public Guid ChallengeToken { get; set; }
       
        public EnrollmentResult(int userId)
        {
            IdentityCreated = true;
            IdentityId = userId;
        }
    }
}
