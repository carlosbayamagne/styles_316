﻿using System;

namespace Axos.Identity.Client.Models
{
    public class StopPaymentRequest
    {
        public string UserName { get; set; }
        public string Action { get; set; }
        public string CheckNumber { get; set; }
        public string Payee { get; set; }
        public string Account { get; set; }
        public decimal Amount { get; set; }
        public DateTime DatePlaced { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string Brand { get; set; }
        public string RemovedText { get; set; }
    }
}
