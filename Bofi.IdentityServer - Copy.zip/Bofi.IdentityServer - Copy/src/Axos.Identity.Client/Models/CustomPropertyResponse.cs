﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Axos.Identity.Client.Models
{
    public class CustomPropertyResponse
    {
        [Required]
        public int UdbUserID { get; set; }

        [Required]
        public string PropertyName { get; set; }

        [Required]
        public string PropertyValue { get; set; }

        [Required]
        public DateTime EffectiveDate { get; set; }

        [Required]
        public DateTime ExpirationDate { get; set; }

        public string PropertyImage { get; set; }
    }
}
