﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class ConfirmAddressRequest
    {       
        public AddressType AddressType { get; set; }
    }
}
