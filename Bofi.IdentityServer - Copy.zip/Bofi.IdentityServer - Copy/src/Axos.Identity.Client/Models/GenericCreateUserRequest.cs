﻿using Axos.Identity.Client.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace Axos.Identity.Client.Models
{
    public class GenericCreateUserRequest
    {
        public string CIF { get; set; }
        [Required(AllowEmptyStrings = true)]
        public string FirstName { get; set; }
        [Required(AllowEmptyStrings = true)]
        public string LastName { get; set; }
        [StringLength(30)]
        public string MiddleName { get; set; }
        [StringLength(20)]
        public string Suffix { get; set; }
        public string CommonName { get; set; }
        [Required, EmailAddress, StringLength(320)]
        public string Email { get; set; }
        public UserType? UserType { get; set; }
        public UserSubType? UserSubType { get; set; }
        public UserState? UserState { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string SSN { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime Birthdate { get; set; }
        public int BrandId { get; set; }
        public string SourceTypeCode { get; set; }
        public string AlternateEmail { get; set; }
        public PreloadUserStatus PreloadedUser { get; set; }

        #region IRA
        public string AnnualIncome { get; set; }
        public string TotalNetWorth { get; set; }
        public string LiquidNetWorth { get; set; }
        public int? Dependents { get; set; }
        public string TaxBracket { get; set; }
        public string EmploymentStatus { get; set; }
        public int? YearsEmployed { get; set; }
        public EmployerAddress EmployerAddress { get; set; }
        public string MaritalStatus { get; set; }
        public CountryCitizenship? CountryCitizenship { get; set; }
        #endregion

        public string RegistrationOrigin { get; set; }
    }
}
