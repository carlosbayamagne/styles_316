﻿using Axos.Identity.Client.Enums;
using System;

namespace Axos.Identity.Client.Models
{
    public class Address
    {
        public AddressType AddressType { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string StreetAddress1 { get; set; }
        public string StreetAddress2 { get; set; }
        public string StreetAddress3 { get; set; }
        public string State { get; set; }
        public string StateCode { get; set; }
        public string Id { get; set; }
        public DateTime? SeasonalBeginDate { get; set; }
        public DateTime? SeasonalEndDate { get; set; }
        public bool? SeasonalRecurrence { get; set; }
        public bool Confirmed { get; set; }

        public override string ToString()
        {
            return $"{StreetAddress1}, {StreetAddress2}, {City}, {State} ({StateCode}), {PostalCode}";
        }
    }
}
