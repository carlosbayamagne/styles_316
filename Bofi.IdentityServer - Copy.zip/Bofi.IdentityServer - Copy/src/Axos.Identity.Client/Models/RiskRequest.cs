﻿namespace Axos.Identity.Client.Models
{
    public class RiskRequest
    {
        public IdentityUser IdentityUser { get; set; }
        public IdentityDevice IdentityDevice { get; set; }
        public RiskResponse RiskResponse { get; set; }
    }
}
