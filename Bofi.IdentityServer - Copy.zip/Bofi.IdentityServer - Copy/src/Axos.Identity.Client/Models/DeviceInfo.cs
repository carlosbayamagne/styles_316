﻿using Axos.Identity.Client.Enums;

namespace Axos.Identity.Client.Models
{
    public class DeviceInfo
    {
        public IdentityAdvice Advice { get; set; }
        public string DeviceId { get; set; }
        public string DeviceSignature { get; set; }
        public string DeviceType { get; set; }
        public string MatchedRule { get; set; }
        public string RuleAnnotation { get; set; }
        public int Score { get; set; }
        public string TransactionId { get; set; }
    }
}
