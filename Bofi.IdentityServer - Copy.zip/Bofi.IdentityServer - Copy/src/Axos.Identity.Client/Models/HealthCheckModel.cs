﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Models
{
    public class HealthCheckModel
    {
        public string StatusCode { get; set; }

        public string ServiceName {get; set;}

        public string Version {get; set;}

        public string Message {get; set;}
    }
}
