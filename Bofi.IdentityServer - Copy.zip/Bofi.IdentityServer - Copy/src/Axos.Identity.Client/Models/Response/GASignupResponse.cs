﻿namespace Axos.Identity.Client.Models.Response
{
    public class GASignupResponse : IdentityResponse
    {
        public string ManualCode { get; set; }
        public string BarCodeImage { get; set; }
    }
}
