﻿using System;

namespace IdentityClient.Models.Response
{
    public class AccessTokenResponse
    {
        public String AccessToken { get; set; }
        public long ExpiresIn { get; set; }
    }
}
