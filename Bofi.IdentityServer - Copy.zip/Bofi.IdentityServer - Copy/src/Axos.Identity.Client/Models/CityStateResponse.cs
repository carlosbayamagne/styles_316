﻿namespace Axos.Identity.Client.Models
{
    public class CityStateResponse
    { 
        public string Zip { get; set; }
        public string City { get; set; }
        public string State { get; set; }
    }
}