﻿using System.ComponentModel;

namespace Axos.Identity.Client.Enums
{
    public enum BofiBrands
    {
        [Description("Axos Bank")]
        Master = -1,

        [Description("Bank of Internet")]
        BankOfInternet = 1,

        [Description("BofI Federal Bank")]
        BofiFederalBank = 2,

        [Description("UFB Direct")]
        UFB = 3,

        [Description("BofI Advisor")]
        Advisor = 4,

        [Description("BofI Federal Bank BOA")]
        BofiFederalBankBOA = 5,

        [Description("NetBank")]
        NetBank = 6,

        [Description("Bank X")]
        BankX = 7,

        [Description("Bank Social")]
        BankSocial = 8,

        [Description("Specialty Deposits")]
        SpecialtyDeposits = 9,

        [Description("Virtus Bank")]
        VirtusBank = 10,

        [Description("Commercial LV")]
        CommercialLV = 17,

        [Description("Commercial LA")]
        CommercialLA = 18,

        [Description("Commercial NY")]
        CommercialLNY = 19,

        [Description("Nationwide Premiere")]
        NationwidePremiere = 30,

        [Description("Nationwide Standard")]
        NationwideStandard = 31,

        [Description("Nationwide Small Business")]
        NationwideSmallBusiness = 32,

        [Description("Nationwide Second Chance")]
        NationwideSecondChance = 36,

        [Description("Axos Trading")]
        AxosTrading = 149,

        [Description("Axos Invest")]
        AxosInvest = 150,

        [Description("Axos Digital Assets")]
        AxosDigitalAssets = 153,

        [Description("Axos Clearing")]
        AxosClearing = 154,

        [Description("RIA Investors")]
        RIAInvestors = 158
    }
}
