﻿using System;

namespace Axos.Identity.Client.Enums
{
    [Flags]
    public enum UserSubType
    {
        RealEstate = 0,
        Enrollment = 1,
        // Organization, Admin, User, APISubscriber belongs to User Type "LargeBusiness"
        Organization = 2,
        Admin = 3,
        User = 4,
        APISubscriber = 5,
        AxosBank = 8,
        AxosInvest = 16,
        AxosTrading = 32,
        AxosFiduciaryServices = 64,
        AxosCrypto = 128,
        AxosAdvisoryService = 256,
        AxosIBD = 512,
        Firm = 1024,
        Location = 2048,
        Advisor = 4096
    }
}
