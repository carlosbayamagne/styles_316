﻿using System.ComponentModel;

namespace Axos.Identity.Client.Enums
{
    public enum UserStatus
    {
        INITIAL,
        ACTIVE,
        INACTIVE,
        CLOSED
    }
}
