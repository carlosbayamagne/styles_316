﻿using System.ComponentModel;

namespace Axos.Identity.Client.Enums
{
    public enum DeliveryMethod
    {
        None,
        SMS,
        Email,
        Voice = 4,
        Push = 8
    }
}
