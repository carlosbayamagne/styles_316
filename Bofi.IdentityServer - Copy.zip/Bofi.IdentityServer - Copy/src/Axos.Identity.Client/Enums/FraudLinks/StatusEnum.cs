﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Axos.Identity.Client.Enums.FraudLinks
{
    public enum StatusEnum
    {
        [EnumMember(Value = "Pass")]
        Pass,
        [EnumMember(Value = "Fail")]
        Fail,
        [EnumMember(Value = "Error")]
        Error
    }
}
