﻿namespace Axos.Identity.Client.Enums
{
    public enum UserType
    {
        Advisor = 0,
        Consumer = 1,
        Business = 2,
        InternalService = 4,
        AdminPortal = 5
    }
}
