﻿
namespace Axos.Identity.Client.Enums
{
    public enum AuthenticationFactors
    {
        PinEnrolled = 1,
        DuressPinEnrolled = 2,
        FaceEnrolled = 3,
        VoiceEnrolled = 4,
        FingerEnrolled = 5,
        DeviceEnrolled = 6
    }
}
