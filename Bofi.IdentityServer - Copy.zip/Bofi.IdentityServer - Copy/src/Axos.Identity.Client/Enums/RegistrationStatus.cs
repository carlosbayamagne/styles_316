﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.Enums
{
    public enum RegistrationStatus
    {
        Complete,
        Incomplete
    }
}
