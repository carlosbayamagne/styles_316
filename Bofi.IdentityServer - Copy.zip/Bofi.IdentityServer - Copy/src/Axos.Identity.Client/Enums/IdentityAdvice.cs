﻿namespace Axos.Identity.Client.Enums
{
    public enum IdentityAdvice
    {
        Allow,
        Alert,
        IncreaseSecurity,
        Deny
    }
}
