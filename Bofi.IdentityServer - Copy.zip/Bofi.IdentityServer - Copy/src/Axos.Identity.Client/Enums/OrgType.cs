﻿namespace Axos.Identity.Client.Enums
{
    public enum OrgType
    {
        Axos = 1,
        IBD = 2,
        RIA = 3
    }
}
