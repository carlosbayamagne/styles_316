﻿using System.ComponentModel;

namespace Axos.Identity.Client.Enums
{
    public enum AdminUserStatus
    {
        Active,
        Suspended,
        Closed
    }
}
