﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Enums
{
    public enum UserState
    {
        Prospect = 0,
        Applicant = 1,
        Customer = 2
    }
}
