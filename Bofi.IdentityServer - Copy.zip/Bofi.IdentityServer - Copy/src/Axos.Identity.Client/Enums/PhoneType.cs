﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Enums
{
    public enum PhoneType
    {
        [Description("Home Phone")]
        HomePhone = 0,
        [Description("Home Cell Phone")]
        HomeCellPhone = 1,
        [Description("Business Phone")]
        BusinessPhone = 2,
        [Description("Business Cell Phone")]
        BusinessCellPhone = 3,
        [Description("Business Fax Number")]
        BusinessFax = 4
    }
}
