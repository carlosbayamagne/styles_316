﻿using System.ComponentModel;

namespace Axos.Identity.Client.Enums
{
    public enum AddressType
    {
        [Description("")]
        Mailing = 1,
        [Description("Phys")]
        Physical = 2,
        [Description("IRS")]
        IRS = 3,
        [Description("Seasonal")]
        Seasonal = 4,
        Employer = 5
    }
}
