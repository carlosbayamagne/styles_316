﻿namespace Axos.Identity.Client.Enums
{
    public enum LogoutEventLogoutReason
    {
        SystemTimedOut,
        UserInitiated,
        Unknown,
        Other
    }
}