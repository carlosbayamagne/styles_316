﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Client.Enums
{
    public enum UsersTypeFilter
    {
        All,
        OnlyCifUsers,
        OnlyNonCifUsers
    }
}
