﻿
namespace Axos.Identity.Client.Enums
{
    public enum PreloadUserStatus
    {
        NoPreload,
        AddInIdentity,
        AddInOlbFailed,
        AddAccountsFailed,
        Preload,
        AddInCAFailed,
        Complete,
    }
}
