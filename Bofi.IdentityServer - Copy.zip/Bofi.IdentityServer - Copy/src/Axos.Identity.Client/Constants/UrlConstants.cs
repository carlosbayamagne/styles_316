﻿using System;

namespace Axos.Identity.Client.Constants
{
	internal class UrlConstants
	{
		internal const string DeliveryMethodUrl = "api/deliverymethod";
		internal const string OrganizationUrl = "api/organizations";
		internal const string OrganizationSettingsUrl = "api/organizationsettings";
        internal const string BrandUrl = "api/brands";
        internal const string BrandSettingsUrl = "api/brandsettings";
        internal const string BrandingUrl = "api/brandings";
        internal const string BrandingSettingsUrl = "api/brandingsettings";
    }
}
