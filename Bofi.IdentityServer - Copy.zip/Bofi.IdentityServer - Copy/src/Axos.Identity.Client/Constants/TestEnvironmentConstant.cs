﻿namespace Axos.Identity.Client.Constants
{
    public static class TestEnvironmentConstant
    {
        public const string TestEnvironment = "Development";
    }
}