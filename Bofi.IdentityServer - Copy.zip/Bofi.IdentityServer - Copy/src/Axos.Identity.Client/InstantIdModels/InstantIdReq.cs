﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Axos.Integration.InstantId.Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdReq
    {
        public InstantIdRequestContent InstantIdRequest { get; set; } = new InstantIdRequestContent();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdRequestContent
    {
        public InstantIdUser User { get; set; } = new InstantIdUser();
        public int MaxWaitSeconds { get; set; } = 0;
        public string AccountNumber { get; set; }
        public string OutputType { get; set; } = "X";
        public InstantIdOptions Options { get; set; } = new InstantIdOptions();
        public InstantIdSearchBy SearchBy { get; set; } = new InstantIdSearchBy();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdUser
    {
        public string ReferenceCode { get; set; }
        public string BillingCode { get; set; }
        public string QueryId { get; set; }
        public string GLBPurpose { get; set; } = "5";
        public string DLPurpose { get; set; } = "0";
        public InstantIdEndUser EndUser { get; set; } = new InstantIdEndUser();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdEndUser
    {
        public string CompanyName { get; set; }
        public string StreetAddress1 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip5 { get; set; }
        public string Phone { get; set; }
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdOptions
    {
        public InstantIdRequestWatchLists WatchLists { get; set; } = null; // new InstantIdRequestWatchLists();
        public bool IncludeCLOverride { get; set; } = true;
        public bool IncludeMSOverride { get; set; } = true;
        public bool IncludeDLVerification { get; set; } = true;
        public bool PoBoxCompliance { get; set; } = true;
        public InstantIdIncludeModels IncludeModels { get; set; } = new InstantIdIncludeModels();
        public string RedFlagsReport { get; set; }
        public string GlobalWatchlistThreshold { get; set; }
        public InstantIdDOBMatch DOBMatch { get; set; } = new InstantIdDOBMatch();
        public bool IncludeAllRiskIndicators { get; set; } = true;
        public InstantIdRequireExactMatch RequireExactMatch { get; set; } = new InstantIdRequireExactMatch();
        public string CustomCVIModelName { get; set; }
        public string LastSeenThreshold { get; set; }
        public bool IncludeMIOverride { get; set; } = true;
        public InstantIdCVICalculationOptions CVICalculationOptions { get; set; } = new InstantIdCVICalculationOptions();
        public string InstantIDVersion { get; set; }
        public bool IncludeDeliveryPointBarcode { get; set; } = true;
        public string NameInputOrder { get; set; } = "FML";
        public bool IncludeEmailVerification { get; set; } = true;
        public bool DisableNonGovernmentDLData { get; set; } = true;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdRequestWatchLists
    {
        public List<string> WatchList { get; set; } = new List<string>();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdIncludeModels
    {
        public bool Thindex { get; set; } = true;
        public InstantIdStudentDefenderModel StudentDefenderModel { get; set; } = new InstantIdStudentDefenderModel();
        public InstantIdModelRequests ModelRequests { get; set; } = new InstantIdModelRequests();
        public InstantIdFraudPointModel FraudPointModel { get; set; } = new InstantIdFraudPointModel();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
#pragma warning disable S101 // Types should be named in PascalCase
    public class InstantIdDOBMatch
#pragma warning restore S101 // Types should be named in PascalCase
    {
        public string MatchType { get; set; } = "FuzzyCCYYMM";
        public int MatchYearRadius { get; set; } = 0;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdRequireExactMatch
    {
        public bool LastName { get; set; } = true;
        public bool FirstName { get; set; } = true;
        public bool FirstNameAllowNickname { get; set; } = true;
        public bool HomePhone { get; set; } = true;
        public bool SSN { get; set; } = true;
        public bool Address { get; set; } = true;
        public bool DriveLicense { get; set; } = true;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
#pragma warning disable S101 // Types should be named in PascalCase
    public class InstantIdCVICalculationOptions
    {
#pragma warning restore S101 // Types should be named in PascalCase
        public bool IncludeDOB { get; set; } = true;
        public bool IncludeDriverLicense { get; set; } = true;
        public bool DisableCustomerNetworkOption { get; set; } = true;
        public bool IncludeITIN { get; set; } = true;
        public bool IncludeComplianceCap { get; set; } = true;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdStudentDefenderModel
    {
        public bool StudentDefender { get; set; } = true;
        public bool IsStudentApplicant { get; set; } = true;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdModelRequests
    {
        List<InstantIdModelRequest> ModelRequest { get; set; } = new List<InstantIdModelRequest>();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdFraudPointModel
    {
        public string ModelName { get; set; }
        public bool IncludeRiskIndices { get; set; } = true;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdModelRequest
    {
        public string ModelName { get; set; }
        public InstantIdModelOptions ModelOptions { get; set; } = new InstantIdModelOptions();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdModelOptions
    {
        List<InstantIdModelOption> ModelOption { get; set; } = new List<InstantIdModelOption>();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdModelOption
    {
        public string OptionName { get; set; }
        public string OptionValue { get; set; }
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdSearchBy
    {
        public InstantIdName Name { get; set; } = new InstantIdName();
        public InstantIdAddress Address { get; set; } = new InstantIdAddress();
        public InstantIdDate DOB { get; set; } = new InstantIdDate();
        public int Age { get; set; } = 0;
        public string SSN { get; set; }
        public string SSNLast4 { get; set; }
        public string DriverLicenseNumber { get; set; }
        public string DriverLicenseState { get; set; }
        public string IPAddress { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public bool UseDOBFilter { get; set; } = true;
        public int DOBRadius { get; set; } = 0;
        public InstantIdPassport Passport { get; set; } = new InstantIdPassport();
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Channel { get; set; } = "Mail";
        public string Income { get; set; }
        public string OwnOrRent { get; set; } = "Own";
        public string LocationIdentifier { get; set; }
        public string OtherApplicationIdentifier1 { get; set; }
        public string OtherApplicationIdentifier2 { get; set; }
        public string OtherApplicationIdentifier3 { get; set; }
        public InstantIdApplicationDateTime ApplicationDateTime { get; set; } = new InstantIdApplicationDateTime();
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdName
    {
        public string Full { get; set; }
        public string First { get; set; }
        public string Middle { get; set; }
        public string Last { get; set; }
        public string Suffix { get; set; }
        public string Prefix { get; set; }
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdAddress
    {
        public string StreetNumber { get; set; }
        public string StreetPreDirection { get; set; }
        public string StreetName { get; set; }
        public string StreetSuffix { get; set; }
        public string StreetPostDirection { get; set; }
        public string UnitDesignation { get; set; }
        public string UnitNumber { get; set; }
        public string StreetAddress1 { get; set; }
        public string StreetAddress2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip5 { get; set; }
        public string Zip4 { get; set; }
        public string County { get; set; }
        public string PostalCode { get; set; }
        public string StateCityZip { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdDate
    {
        public int Year { get; set; } = 0;
        public int Month { get; set; } = 0;
        public int Day { get; set; } = 0;
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdPassport
    {
        public string Number { get; set; }
        public InstantIdDate ExpirationDate { get; set; } = new InstantIdDate();
        public string Country { get; set; }
        public string MachineReadableLine1 { get; set; }
        public string MachineReadableLine2 { get; set; }
    }

    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class InstantIdApplicationDateTime
    {
        public int Year { get; set; } = 0;
        public int Month { get; set; } = 0;
        public int Day { get; set; } = 0;
        public int Hour24 { get; set; } = 0;
        public int Minute { get; set; } = 0;
        public int Second { get; set; } = 0;
    }
}