﻿using System.ComponentModel;

namespace Axos.Integration.InstantId.Models
{
    /*
     *  0 I Have No Permissible Purpose
     *  1 Court, Law Enforcement, or Government Agencies—Use by a court, law enforcement agency or
     *  other government agency or entity, acting directly on behalf of a government agency.
     *  2 Motor Vehicle Safety or Theft—Use for any matter regarding motor vehicle or driver safety or theft
     *  (except by motor vehicle manufacturers).
     *  3 Use in the Normal Course of Business—For use in the normal course of business but only to
     *  verify the accuracy of personal information submitted by the individual to the business; and if the
     *  submitted information is incorrect, to obtain the correct information, but only for the purposes of
     *  preventing fraud by, pursuing legal remedies against, or recovering on a debt or security interest
     *  against, the individual.
     *  4 Civil, Criminal, Administrative, or Arbitral Proceedings—Use in connection with a civil, criminal,
     *  administrative, or arbitral proceeding, including the service of process, investigation in anticipation
     *  of litigation, the execution or enforcement of judgments, or compliance with the orders of any court.
     *  Value Description
     *  5 Commercial Driver's License—Use by an employer or its agents or insurer to obtain or verify
     *  information relating to a holder of a commercial driver's license that is required under chapter 313
     *  of title 49 of the United States Code.
     *  6 Insurance—Use by an insurer or insurance support organization, in connection with claims
     *  investigation activities or antifraud activities.
     *  7 Licensed Private Investigative or Security Services—Use by a licensed private investigative agency, or
     *  licensed security service, for a purpose permitted above.
     */

    public enum DLPurpose
    {
        [Description("I Have No Permissible Purpose")]
        NoPermissiblePurpose = 0,

        [Description("Court, Law Enforcement, or Government Agencies")]
        CourtLawEnforcmentOrGovernment = 1,

        [Description("Motor Vehicle Safety or Theft")]
        MotorVehicleSafetyOrTheft = 2,

        [Description("Use in the Normal Course of Business")]
        NormalCourseOfBusiness = 3,

        [Description("Civil, Criminal, Administrative, or Arbitral Proceedings")]
        CivilCriminalAdministrativeOrArbitratal = 4,

        [Description("Commercial Driver's License")]
        CommercialDriverLicense = 5,

        [Description("Insurance")]
        Insurance = 6,

        [Description("Licensed Private Investigative or Security Services")]
        LicensedPrivateInvestigativeOrSecurityServices = 7
    }
}
