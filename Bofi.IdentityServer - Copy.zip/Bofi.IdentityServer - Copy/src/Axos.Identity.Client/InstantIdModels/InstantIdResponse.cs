﻿
using System.Collections.Generic;

namespace Axos.Integration.InstantId.Models
{

    public class InstantIdResp
    {
        public InstantIdResponseEx InstantIDResponseEx { get; set; }
    }

    public class InstantIdResponseEx
    {
        public string xmlns { get; set; }
        public InstantIdResponse response { get; set; }
    }

    public class InstantIdResponse { 
        public InstantIdHeader Header { get; set; }
        public InstantIdResult Result { get; set; }
        public string Pdf { get; set; }
    }

    public class InstantIdHeader
    {
        public int Status { get; set; }
        public string Message { get; set; }
        public string QueryId { get; set; }
        public string TransactionId { get; set; }
        public InstantIdExceptions Exceptions { get; set; }
        public InstantIdDisclaimers Disclaimers { get; set; }
    }

    public class InstantIdExceptions
    {
        public List<InstantIdItem> Item { get; set; }
    }

    public class InstantIdItem
    {
        public string Source { get; set; }
        public int Code { get; set; }
        public string Location { get; set; }
        public string Message { get; set; }
    }

    public class InstantIdDisclaimers
    {
        public List<InstantIdDisclaimer> Disclaimer { get; set; }
    }

    public class InstantIdDisclaimer
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }

    public class InstantIdResult
    {
        public InstantIdReq InputEcho { get; set; }
        public string UniqueId { get; set; }
        public InstantIdVerifiedInput VerifiedInput { get; set; }
        public bool DOBVerified { get; set; }
        public int NameAddressSSNSummary { get; set; }
        public InstantIdNameAddressPhone NameAddressPhone { get; set; }
        public InstantIdComprehensiveVerification ComprehensiveVerification { get; set; }
        public InstantIdComprehensiveVerification CustomComprehensiveVerification { get; set; }
        public InstantIdInputCorrected InputCorrected { get; set; }
        public InstantIdNewAreaCode NewAreaCode { get; set; }
        public InstantIdReversePhone ReversePhone { get; set; }
        public string PhoneOfNameAddress { get; set; }
        public InstantIdSSNInfo SSNInfo { get; set; }
        public InstantIdChronologyHistories ChronologyHistories { get; set; }
        public InstantIdWatchLists WatchLists { get; set; }
        public string AdditionalScore1 { get; set; }
        public string AdditionalScore2 { get; set; }
        public InstantIdName CurrentName { get; set; }
        public InstantIdAdditionalLastNames AdditionalLastNames { get; set; }
        public InstantIdModels Models { get; set; }
        public InstantIdRedFlagsReport RedFlagsReport { get; set; }
        public bool PassportValidated { get; set; }
        public int FoundSSNCount { get; set; }
        public InstantIdDecedentInfo DecedentInfo { get; set; }
        public int DOBMatchLevel { get; set; }
        public bool SSNFoundForLexID { get; set; }
        public bool AddressPOBox { get; set; }
        public bool AddressCMRA { get; set; }
        public string InstantIDVersion { get; set; }
        public bool EmergingId { get; set; }
        public bool AddressStandardized { get; set; }
        public InstantIdAddress StandardizedInputAddress { get; set; }
        public string AddressSecondaryRangeMismatch { get; set; }
        public bool BureauDeleted { get; set; }
        public bool ITINExpired { get; set; }
        public bool IsPhoneCurrent { get; set; }
        public string PhoneLineType { get; set; }
        public string PhoneLineDescription { get; set; }
    }

    public class InstantIdVerifiedInput
    {
        public InstantIdName Name { get; set; }
        public InstantIdAddress Address { get; set; }
    }

    public class InstantIdNameAddressPhone
    {
        public string Summary { get; set; }
        public string Type { get; set; }
        public string Status { get; set; }
    }

    public class InstantIdComprehensiveVerification
    {
        public int ComprehensiveVerificationIndex { get; set; }
        public InstantIdRiskIndicators RiskIndicators { get; set; }
    }

    public class InstantIdInputCorrected
    {
        public InstantIdName Name { get; set; }
        public InstantIdAddress Address { get; set; }
        public string SSN { get; set; }
        public string HomePhone { get; set; }
        public InstantIdDate DOB { get; set; }
        public string DriverLicenseNumber { get; set; }
    }

    public class InstantIdNewAreaCode
    {
        public string AreaCode { get; set; }
        public InstantIdDate EffectiveDate { get; set; }
    }

    public class InstantIdReversePhone
    {
        public InstantIdFullName Name { get; set; }
        public InstantIdAddress Address { get; set; }
    }

#pragma warning disable S101 // Types should be named in PascalCase
    public class InstantIdSSNInfo
#pragma warning restore S101 // Types should be named in PascalCase
    {
        public string SSN { get; set; }
        public string Valid { get; set; }
        public string IssuedLocation { get; set; }
        public InstantIdDate IssuedStartDate { get; set; }
        public InstantIdDate IssuedEndDate { get; set; }
        public int FDNSsnInd { get; set; }
    }

    public class InstantIdChronologyHistories
    {
        public List<InstantIdChronologyHistory> ChronologyHistory { get; set; }
    }

    public class InstantIdWatchLists
    {
        public List<InstantIdWatchList> WatchList { get; set; }
    }

    public class InstantIdAdditionalLastNames
    {
        public List<InstantIdAdditionalLastName> AdditionalLastName { get; set; }
    }

    public class InstantIdModels
    {
        public List<InstantIdModel> Model { get; set; }
    }

    public class InstantIdRedFlagsReport
    {
        public int Version { get; set; }
        public List<InstantIdRedFlag> RedFlags { get; set; }
    }

    public class InstantIdDecedentInfo
    {
        public InstantIdFullName Name { get; set; }
        public InstantIdDate DOD { get; set; }
        public InstantIdDate DOB { get; set; }
    }

    public class InstantIdRiskIndicators
    {
        public List<InstantIdRiskIndicator> RiskIndicator { get; set; }
        public InstantIdPotentialFollowupActions PotentialFollowupActions { get; set; }
    }

    public class InstantIdFullName
    {
        public string Full { get; set; }
        public string First { get; set; }
        public string Middle { get; set; }
        public string Last { get; set; }
        public string Suffix { get; set; }
        public string Prefix { get; set; }
    }

    public class InstantIdChronologyHistory
    {
        public InstantIdAddress Address { get; set; }
        public string Phone { get; set; }
        public InstantIdDate DateFirstSeen { get; set; }
        public InstantIdDate DateLastSeen { get; set; }
        public bool IsBestAddress { get; set; }
    }

    public class InstantIdWatchList
    {
        public string Table { get; set; }
        public string RecordNumber { get; set; }
        public InstantIdFullName Name { get; set; }
        public InstantIdAddress Address { get; set; }
        public string Country { get; set; }
        public string EntityName { get; set; }
        public int Sequence { get; set; }
        public string Program { get; set; }
        public string RepWLNumWithName { get; set; }
    }

    public class InstantIdAdditionalLastName
    {
        public InstantIdDate DateLastSeen { get; set; }
        public string LastName { get; set; }
    }

    public class InstantIdModel
    {
        public string Name { get; set; }
        public InstantIdScores Scores { get; set; }
    }

    public class InstantIdScores { 
        public List<InstantIdScore> Score { get; set; }
    }

    public class InstantIdRedFlag
    {
        public string Name { get; set; }
        public List<InstantIdHighRiskIndicator> HighRiskIndicators { get; set; }
    }

    public class InstantIdRiskIndicator
    {
        public string RiskCode { get; set; }
        public string Description { get; set; }
        public int Sequence { get; set; }
    }

    public class InstantIdPotentialFollowupActions
    {
        public List<InstantIdFollowupAction> FollowupAction { get; set; }
    }

    public class InstantIdScore
    {
        public string Type { get; set; }
        public int Value { get; set; }
        public InstantIdRiskIndices RiskIndices { get; set; }
        public InstantIdRiskIndicators RiskIndicators { get; set; }
    }

    public class InstantIdHighRiskIndicator
    {
        public string RiskCode { get; set; }
        public string Description { get; set; }
        public int Sequence { get; set; }
    }

    public class InstantIdFollowupAction
    {
        public string RiskCode { get; set; }
        public string Description { get; set; }
    }

    public class InstantIdRiskIndices
    {
        public List<InstantIdRiskIndex> RiskIndex { get; set; }
    }

    public class InstantIdRiskIndex
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}