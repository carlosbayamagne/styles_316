﻿using System.ComponentModel;

namespace Axos.Integration.InstantId.Models
{
    /*
     *  0 (default) I Have No Permissible Purpose
     *  1 Transactions Authorized by Consumer—As necessary to effect, administer, or enforce a
     *  transaction requested or authorized by the consumer
     *  2 Law Enforcement Purpose—To the extent specifically permitted or required under other
     *  provisions of law and in accordance with the Right to Financial Privacy Act of 1978, to law
     *  enforcement agencies, self-regulatory organizations, or for an investigation on a matter related
     *  to public safety
     *  3 Use by Persons Holding a Legal or Beneficial Interest Relating to the Consumer—For use by
     *  persons holding a legal or beneficial interest relating to the consumer
     *  5 Fraud Prevention or Detection—For use to protect against or prevent actual or potential fraud,
     *  unauthorized transactions, claims, or other liability
     *  6 Required Institutional Risk Control—For required institutional risk control, or for resolving
     *  customer disputes or inquiries
     *  7 Legal Compliance—For use to comply with Federal, State, or local laws, rules, and other
     *  applicable legal requirements
     */

    public enum GLBPurpose
    {
        [Description("I Have No Permissible Purpose")]
        NoPermissiblePurpose = 0,

        [Description("Transactions Authorized by Consumer")]
        AuthorizedByCustomer = 1,

        [Description("Law Enforcement Purpose")]
        LawEnforcement = 2,

        [Description("Use by Persons Holding a Legal or Beneficial Interest Relating to the Consumer")]
        LegalOrBeneficialInterest = 3,

        [Description("Fraud Prevention or Detection")]
        FraudPrevention = 5,

        [Description("Required Institutional Risk Control")]
        InstitutionalRiskControl = 6,

        [Description("Legal Compliance")]
        LegalCompliance = 7
    }
}
