﻿using Axos.Identity.Client.Enums.FraudLinks;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Client.DTOs.FraudLinks
{
    public class OverAllVerificationResultDto
    {
        public bool MatchesFound { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public StatusEnum Veredict { get; set; }
    }
}
