﻿using Axos.Identity.Client.Models;
using System;

namespace Axos.Identity.Client.DTOs
{
    public class UserDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Status { get; set; }
        public string CIF { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string SSN { get; set; }
        public string Address { get; set; }
        public DateTime Birthdate { get; set; }
        public int? BrandId { get; set; }
        public DateTime RegistrationDate { get; set; }
		public bool InsightsEnabled { get; set; }
    }
}
