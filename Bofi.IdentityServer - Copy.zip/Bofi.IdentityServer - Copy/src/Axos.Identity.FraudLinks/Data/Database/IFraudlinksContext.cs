﻿using Axos.Identity.FraudLinks.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Database
{
    public interface IFraudlinksContext
    {
        DbSet<AddressData> AddressData { get; set; }
        DbSet<AddressType> AddressType { get; set; }
        DbSet<EmailData> EmailData { get; set; }
        DbSet<EmailType> EmailType { get; set; }
        DbSet<NameData> NameData { get; set; }
        DbSet<PhoneData> PhoneData { get; set; }
        DbSet<PhoneType> PhoneType { get; set; }
        DbSet<SourceType> SourceType { get; set; }
        DbSet<TaxpayerNumberData> TaxpayerNumberData { get; set; }
        DbSet<TaxpayerNumberType> TaxpayerNumberType { get; set; }
        DbSet<WhiteListItem> WhiteListItem { get; set; }
        DbSet<WhiteListItemType> WhiteListItemType { get; set; }
    }
}
