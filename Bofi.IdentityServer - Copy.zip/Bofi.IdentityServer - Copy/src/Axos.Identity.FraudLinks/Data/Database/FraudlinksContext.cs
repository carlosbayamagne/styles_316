﻿using Axos.Identity.FraudLinks.Data.Models;
using Axos.Integration.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Database
{
    public partial class FraudlinksContext : DbContext, IFraudlinksContext
    {
        public FraudlinksContext(IHostEnvironment env)
        {
            dbString = new ServiceConfig(env.EnvironmentName, "Fraudlinks").Settings["DbConnectionString"];
        }

        private string dbString;

        public FraudlinksContext(DbContextOptions<FraudlinksContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AddressData> AddressData { get; set; }
        public virtual DbSet<AddressType> AddressType { get; set; }
        public virtual DbSet<EmailData> EmailData { get; set; }
        public virtual DbSet<EmailType> EmailType { get; set; }
        public virtual DbSet<NameData> NameData { get; set; }
        public virtual DbSet<PhoneData> PhoneData { get; set; }
        public virtual DbSet<PhoneType> PhoneType { get; set; }
        public virtual DbSet<SourceType> SourceType { get; set; }
        public virtual DbSet<TaxpayerNumberData> TaxpayerNumberData { get; set; }
        public virtual DbSet<TaxpayerNumberType> TaxpayerNumberType { get; set; }
        public virtual DbSet<WhiteListItem> WhiteListItem { get; set; }
        public virtual DbSet<WhiteListItemType> WhiteListItemType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(dbString);
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<AddressData>(entity =>
            {
                entity.ToTable("AddressData", "V2");

                entity.HasIndex(e => new { e.Street, e.Unit, e.City, e.State, e.Zip, e.Country, e.AddressTypeId, e.SourceTypeId })
                    .HasName("UC_AddressData")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Removed).HasColumnType("datetime");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Street)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Unit)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Zip)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.AddressType)
                    .WithMany(p => p.AddressData)
                    .HasForeignKey(d => d.AddressTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AddressDa__Addre__6A85CC04");

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.AddressData)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AddressDa__Sourc__6B79F03D");
            });

            modelBuilder.Entity<AddressType>(entity =>
            {
                entity.ToTable("AddressType", "V2");

                entity.HasIndex(e => e.Name)
                    .HasName("UC_AddressType")
                    .IsUnique();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<EmailData>(entity =>
            {
                entity.ToTable("EmailData", "V2");

                entity.HasIndex(e => new { e.Email, e.EmailTypeId, e.SourceTypeId })
                    .HasName("UC_EmailData")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Removed).HasColumnType("datetime");

                entity.HasOne(d => d.EmailType)
                    .WithMany(p => p.EmailData)
                    .HasForeignKey(d => d.EmailTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__EmailData__Email__37FA4C37");

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.EmailData)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__EmailData__Sourc__38EE7070");
            });

            modelBuilder.Entity<EmailType>(entity =>
            {
                entity.ToTable("EmailType", "V2");

                entity.HasIndex(e => e.Name)
                    .HasName("UC_EmailType")
                    .IsUnique();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NameData>(entity =>
            {
                entity.ToTable("NameData", "V2");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.MiddleName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Removed).HasColumnType("datetime");

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.NameData)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__NameData__Source__147C05D0");
            });


            modelBuilder.Entity<PhoneData>(entity =>
            {
                entity.ToTable("PhoneData", "V2");

                entity.HasIndex(e => new { e.Phone, e.PhoneTypeId, e.SourceTypeId })
                    .HasName("UC_PhoneData")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Removed).HasColumnType("datetime");

                entity.HasOne(d => d.PhoneType)
                    .WithMany(p => p.PhoneData)
                    .HasForeignKey(d => d.PhoneTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PhoneData__Phone__3DB3258D");

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.PhoneData)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PhoneData__Sourc__3EA749C6");
            });

            modelBuilder.Entity<PhoneType>(entity =>
            {
                entity.ToTable("PhoneType", "V2");

                entity.HasIndex(e => e.Name)
                    .HasName("UC_PhoneType")
                    .IsUnique();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SourceType>(entity =>
            {
                entity.ToTable("SourceType", "V2");

                entity.HasIndex(e => e.Name)
                    .HasName("UC_SourceType")
                    .IsUnique();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TaxpayerNumberData>(entity =>
            {
                entity.ToTable("TaxpayerNumberData", "V2");

                entity.HasIndex(e => new { e.TaxPayerNumber, e.TaxPayerNumberTypeId, e.SourceTypeId })
                    .HasName("UC_SsnData")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Removed).HasColumnType("datetime");

                entity.Property(e => e.TaxPayerNumber)
                    .IsRequired()
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.HasOne(d => d.SourceType)
                    .WithMany(p => p.TaxpayerNumberData)
                    .HasForeignKey(d => d.SourceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SsnData__SourceT__220B0B18");

                entity.HasOne(d => d.TaxPayerNumberType)
                    .WithMany(p => p.TaxpayerNumberData)
                    .HasForeignKey(d => d.TaxPayerNumberTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SsnData__SsnType__2116E6DF");
            });

            modelBuilder.Entity<TaxpayerNumberType>(entity =>
            {
                entity.ToTable("TaxpayerNumberType", "V2");

                entity.HasIndex(e => e.Name)
                    .HasName("UC_SsnType")
                    .IsUnique();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<WhiteListItem>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AddedBy)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.HasOne(d => d.ValueTypeNavigation)
                    .WithMany(p => p.WhiteListItem)
                    .HasForeignKey(d => d.ValueType)
                    .HasConstraintName("FK_WhiteListItem_WhiteListItemType");
            });

            modelBuilder.Entity<WhiteListItemType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.TypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }
    }
}
