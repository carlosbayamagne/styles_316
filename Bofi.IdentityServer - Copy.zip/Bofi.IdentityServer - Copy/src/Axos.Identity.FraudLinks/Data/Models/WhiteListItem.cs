﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class WhiteListItem
    {
        public int Id { get; set; }
        public string Value { get; set; }
        public int? ValueType { get; set; }
        public string AddedBy { get; set; }
        public DateTime? DateAdded { get; set; }

        public virtual WhiteListItemType ValueTypeNavigation { get; set; }
    }
}
