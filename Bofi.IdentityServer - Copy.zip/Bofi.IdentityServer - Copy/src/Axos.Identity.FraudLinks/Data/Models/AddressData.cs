﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class AddressData
    {
        public int Id { get; set; }
        public string Street { get; set; }
        public string Unit { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
        public int AddressTypeId { get; set; }
        public int SourceTypeId { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? Removed { get; set; }

        public virtual AddressType AddressType { get; set; }
        public virtual SourceType SourceType { get; set; }
    }
}
