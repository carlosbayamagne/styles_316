﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class WhiteListItemType
    {
        public WhiteListItemType()
        {
            WhiteListItem = new HashSet<WhiteListItem>();
        }

        public int Id { get; set; }
        public string TypeName { get; set; }

        public virtual ICollection<WhiteListItem> WhiteListItem { get; set; }
    }
}
