﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class SourceType
    {
        public SourceType()
        {
            AddressData = new HashSet<AddressData>();
            EmailData = new HashSet<EmailData>();
            PhoneData = new HashSet<PhoneData>();
            TaxpayerNumberData = new HashSet<TaxpayerNumberData>();
            NameData = new HashSet<NameData>();
        }

        public int SourceTypeId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<AddressData> AddressData { get; set; }
        public virtual ICollection<EmailData> EmailData { get; set; }
        public virtual ICollection<PhoneData> PhoneData { get; set; }
        public virtual ICollection<TaxpayerNumberData> TaxpayerNumberData { get; set; }
        public virtual ICollection<NameData> NameData { get; set; }
    }
}
