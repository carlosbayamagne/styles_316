﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class PhoneData
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public int PhoneTypeId { get; set; }
        public int SourceTypeId { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? Removed { get; set; }

        public virtual PhoneType PhoneType { get; set; }
        public virtual SourceType SourceType { get; set; }
    }
}
