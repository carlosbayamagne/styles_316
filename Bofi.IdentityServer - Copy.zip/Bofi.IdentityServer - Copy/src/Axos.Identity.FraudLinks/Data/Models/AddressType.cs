﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class AddressType
    {
        public AddressType()
        {
            AddressData = new HashSet<AddressData>();
        }

        public int AddressTypeId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<AddressData> AddressData { get; set; }
    }
}
