﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class PhoneType
    {
        public PhoneType()
        {
            PhoneData = new HashSet<PhoneData>();
        }

        public int PhoneTypeId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<PhoneData> PhoneData { get; set; }
    }
}
