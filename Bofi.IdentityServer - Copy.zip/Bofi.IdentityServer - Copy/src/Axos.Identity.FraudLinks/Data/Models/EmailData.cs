﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Data.Models
{
    public partial class EmailData
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public int EmailTypeId { get; set; }
        public int SourceTypeId { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime? Removed { get; set; }

        public virtual EmailType EmailType { get; set; }
        public virtual SourceType SourceType { get; set; }
    }
}
