﻿using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.FraudLinks.Domain.Contracts
{
    public interface IVerificationService
    {
        VerificationTypeEnum VerificationType { get; }
        
        Task<VerificationDto> Verify(string Value);
    }
}
