﻿using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.FraudLinks.Domain.Contracts
{
    public interface IFraudlinksService
    {
        Task<FraudlinksResult<IList<VerificationDto>, OverAllVerificationResultDto>> Verify(FraudlinksVerificationRequestDto fraudlinksVerificationRequest);
    }
}
