﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Enums
{
    public enum SourceEnum
    {
        [EnumMember(Value = "Axos Bank")]
        [Description("Axos Bank")]
        AxosBank,
        [EnumMember(Value = "Axos Clearing")]
        [Description("Axos Clearing")]
        AxosClearing,
        [EnumMember(Value = "Axos Invest")]
        [Description("Axos Invest")]
        AxosInvest
    }
}
