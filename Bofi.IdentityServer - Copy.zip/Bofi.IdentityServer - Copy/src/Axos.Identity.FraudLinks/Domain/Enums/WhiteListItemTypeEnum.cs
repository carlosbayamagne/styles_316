﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Enums
{
    public enum WhiteListItemTypeEnum
    {
        [EnumMember(Value = "SSN/TIN")]
        [Description("SSN/TIN")]
        SSNTIN,
        [EnumMember(Value = "Email")]
        [Description("Email")]
        Email,
        [EnumMember(Value = "Phone")]
        [Description("Phone")]
        Phone,
        [EnumMember(Value = "IP Address")]
        [Description("IP Address")]
        IPAddress,
        [EnumMember(Value = "JhaKeyCustomer")]
        [Description("JhaKeyCustomer")]
        JhaKeyCustomer,
        [EnumMember(Value = "JhaKeyAccount")]
        [Description("JhaKeyAccount")]
        JhaKeyAccount,
        [EnumMember(Value = "Domain")]
        [Description("Domain")]
        Domain,
        [EnumMember(Value = "Name")]
        [Description("Name")]
        Name
    }
}
