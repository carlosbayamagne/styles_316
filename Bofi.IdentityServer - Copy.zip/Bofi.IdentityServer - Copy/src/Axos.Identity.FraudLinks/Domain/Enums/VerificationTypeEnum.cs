﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Enums
{
    public enum VerificationTypeEnum
    {
        [EnumMember(Value = "Email")]
        Email,
        [EnumMember(Value = "PhoneNumber")]
        PhoneNumber,
        [EnumMember(Value = "TaxPayerId")]
        TaxPayerId,
        [EnumMember(Value = "Name")]
        Name
    }
}
