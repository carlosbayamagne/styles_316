﻿using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Models
{
    public class FraudlinksResult<TData, TResult>
    {
        public FraudlinksMetadataDto<TResult> Metadata { get; }
        public TData Data { get; }
        private FraudlinksResult(TData data, TResult result, StatusEnum statusEnum, Assembly assembly, string errorMessage = null)
        {
            Metadata = new FraudlinksMetadataDto<TResult>()
            {
                FraudlinksVersion = GetFraudlinksVersion(assembly),
                Status = statusEnum,
                Result = result,
                ErrorMessage = errorMessage
            };

            Data = data;
        }

        public static FraudlinksResult<TData, TResult> Pass(TData data, TResult result, Assembly assembly)
        {
            return new FraudlinksResult<TData, TResult>(data, result, StatusEnum.Pass, assembly);
        }

        public static FraudlinksResult<TData, TResult> Fail(TData data, TResult result, Assembly assembly)
        {
            return new FraudlinksResult<TData, TResult>(data, result, StatusEnum.Fail, assembly);
        }

        public static FraudlinksResult<TData, TResult> Error(string errorMessage, Assembly assembly)
        {
            return new FraudlinksResult<TData, TResult>(default, default, StatusEnum.Error, assembly, errorMessage);
        }

        private string GetFraudlinksVersion(Assembly assembly)
        {
            return assembly.GetName().Version.ToString();
        }
    }
}
