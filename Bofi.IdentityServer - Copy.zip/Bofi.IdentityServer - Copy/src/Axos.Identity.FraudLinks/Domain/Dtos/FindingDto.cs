﻿using Axos.Identity.FraudLinks.Domain.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class FindingDto
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public StatusEnum Judgement { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public SourceEnum Source { get; set; }
        public bool MatchFound { get; set; }
        public bool? WhiteListed { get; set; }
        public bool? Removed { get; set; }
    }
}
