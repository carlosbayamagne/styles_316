﻿using Axos.Identity.FraudLinks.Domain.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class OverAllVerificationResultDto
    {
        public bool MatchesFound { get; set; }
        
        [JsonConverter(typeof(StringEnumConverter))]
        public StatusEnum Veredict { get; set; }
    }
}
