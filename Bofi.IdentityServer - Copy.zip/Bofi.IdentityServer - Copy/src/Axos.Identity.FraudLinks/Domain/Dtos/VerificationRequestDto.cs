﻿using Axos.Identity.FraudLinks.Domain.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class VerificationRequestDto
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public VerificationTypeEnum VerificationType { get; set; }
        public string Value { get; set; }
    }
}
