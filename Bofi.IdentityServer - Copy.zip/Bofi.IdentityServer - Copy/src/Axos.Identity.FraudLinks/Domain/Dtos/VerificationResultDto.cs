﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class VerificationResultDto
    {
        public VerificationDto[] Verifications { get; set; }
    }
}
