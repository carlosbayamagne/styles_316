﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class FraudlinksVerificationRequestDto
    {
        public IEnumerable<VerificationRequestDto> verificationRequests { get; set; }
    }
}
