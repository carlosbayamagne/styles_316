﻿using Axos.Identity.FraudLinks.Domain.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class FraudlinksMetadataDto<TResult> : FraudlinksMetadataDto
    {
        public TResult Result { get; set; }
        public FraudlinksMetadataDto() { }
    }

    public class FraudlinksMetadataDto
    {
        public string FraudlinksVersion { get; set; }
        
        [JsonConverter(typeof(StringEnumConverter))]
        public StatusEnum Status { get; set; }
        
        public string ErrorMessage { get; set; }
    }
}
