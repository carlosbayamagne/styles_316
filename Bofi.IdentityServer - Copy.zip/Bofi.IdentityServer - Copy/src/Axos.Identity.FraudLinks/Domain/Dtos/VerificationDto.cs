﻿using Axos.Identity.FraudLinks.Domain.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.FraudLinks.Domain.Dtos
{
    public class VerificationDto
    {
        [JsonConverter(typeof(StringEnumConverter))]
        public VerificationTypeEnum VerificationType { get; set; }
        public bool MatchesFound { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public StatusEnum Judgement { get; set; }
        public IEnumerable<FindingDto> Findings { get; set; }
    }
}
