﻿using Axos.Identity.FraudLinks.Domain.Contracts;
using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Enums;
using Axos.Identity.FraudLinks.Domain.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Fraudlinks.Services
{
    public class FraudlinksService : IFraudlinksService
    {
        private IEnumerable<IVerificationService> _verificationServices { get; set; }
        private ILogger<FraudlinksService> logger;

        public FraudlinksService(IEnumerable<IVerificationService> verificationServices, ILogger<FraudlinksService> logger)
        {
            _verificationServices = verificationServices;
            this.logger = logger;
        }

        public async Task<FraudlinksResult<IList<VerificationDto>, OverAllVerificationResultDto>> Verify(FraudlinksVerificationRequestDto fraudlinksVerificationRequest)
        {
            try
            {
                var verificationResults = new List<VerificationDto>();

                foreach (var verification in fraudlinksVerificationRequest.verificationRequests)
                {
                    if (String.IsNullOrWhiteSpace(verification.Value))
                        continue;

                    var verificationService = _verificationServices
                        .FirstOrDefault(x => x.VerificationType == verification.VerificationType);

                    verificationResults.Add(await verificationService.Verify(verification.Value));
                }

                var overAllResult = new OverAllVerificationResultDto()
                {
                    MatchesFound = verificationResults.Select(x => x.MatchesFound).Any(x => x),
                    Veredict = verificationResults.Any(x => x.Judgement == StatusEnum.Fail) ? StatusEnum.Fail : StatusEnum.Pass
                };
                if (verificationResults.Any(x => x.Judgement == StatusEnum.Fail))
                {
                    return FraudlinksResult<IList<VerificationDto>, OverAllVerificationResultDto>.Fail(verificationResults, overAllResult, Assembly.GetAssembly(typeof(FraudlinksService)));
                }

                return FraudlinksResult<IList<VerificationDto>, OverAllVerificationResultDto>.Pass(verificationResults, overAllResult, Assembly.GetAssembly(typeof(FraudlinksService)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "FraudLinks Error");
                return FraudlinksResult<IList<VerificationDto>, OverAllVerificationResultDto>.Error(ex.Message, Assembly.GetAssembly(typeof(FraudlinksService)));
            }
        }
    }
}
