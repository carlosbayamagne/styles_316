﻿using Axos.Extensions;
using Axos.Identity.FraudLinks.Data.Database;
using Axos.Identity.FraudLinks.Domain.Contracts;
using Axos.Identity.FraudLinks.Domain.Enums;
using Axos.Identity.Fraudlinks.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Fraudlinks.Services.Verification
{
    public class TaxPayerIdVerificationService : BaseVerificationService, IVerificationService
    {
        private IFraudlinksContext _dbContext { get; set; }

        public TaxPayerIdVerificationService(IFraudlinksContext dbContext) : base(VerificationTypeEnum.TaxPayerId)
        {
            _dbContext = dbContext;
        }

        protected override async Task<bool?> IsWhiteListed(string value)
        {
            return await _dbContext.WhiteListItem
                .Include(x => x.ValueTypeNavigation)
                .AnyAsync(x => x.ValueTypeNavigation.TypeName == WhiteListItemTypeEnum.SSNTIN.GetDescription()
                && x.Value == value);
        }

        protected override async Task<IEnumerable<VerificationMatchModel>> GetMatches(string value)
        {
            var matches = await _dbContext.TaxpayerNumberData
                .Include(x => x.SourceType)
                .Where(x => x.TaxPayerNumber == value).Distinct().ToListAsync();

            return from match in matches
                   select new VerificationMatchModel()
                   {
                       Source = match.SourceType.Name,
                       IsRemoved = match.Removed != null,
                       Value = match.TaxPayerNumber
                   };
        }
    }
}
