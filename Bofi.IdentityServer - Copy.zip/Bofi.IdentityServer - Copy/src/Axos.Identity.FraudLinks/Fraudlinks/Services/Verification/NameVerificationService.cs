﻿using Axos.Extensions;
using Axos.Identity.FraudLinks.Data.Database;
using Axos.Identity.FraudLinks.Domain.Contracts;
using Axos.Identity.FraudLinks.Domain.Enums;
using Axos.Identity.Fraudlinks.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Fraudlinks.Services.Verification
{
    public class NameVerificationService : BaseVerificationService, IVerificationService
    {
        private IFraudlinksContext _dbContext { get; set; }

        public NameVerificationService(IFraudlinksContext dbContext) : base(VerificationTypeEnum.Name)
        {
            _dbContext = dbContext;
        }

        protected override async Task<bool?> IsWhiteListed(string value)
        {
            return await _dbContext.WhiteListItem
                .Include(x => x.ValueTypeNavigation)
                .AnyAsync(x => x.ValueTypeNavigation.TypeName == WhiteListItemTypeEnum.Name.GetDescription()
                && x.Value == value);
        }

        protected override async Task<IEnumerable<VerificationMatchModel>> GetMatches(string value)
        {
            var names = value.Split(',');

            var firstName = names.Length > 0 ? names[0].Trim() : string.Empty;
            var lastName = names.Length > 1 ? names[1].Trim() : string.Empty;

            var matches = await _dbContext.NameData
                .Include(x => x.SourceType)
                .Where(x => x.FirstName == firstName
                && x.LastName == lastName).Distinct().ToListAsync();

            return from match in matches
                   select new VerificationMatchModel()
                   {
                       Source = match.SourceType.Name,
                       IsRemoved = match.Removed != null,
                       Value = $"First name: { match.FirstName }, Last name: { match.LastName }"
                   };
        }
    }
}
