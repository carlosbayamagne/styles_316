﻿using Axos.Extensions;
using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Enums;
using Axos.Identity.Fraudlinks.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Fraudlinks.Services.Verification
{
    public abstract class BaseVerificationService
    {
        public VerificationTypeEnum VerificationType { get; }
        public BaseVerificationService(VerificationTypeEnum verificationTypeEnum) => VerificationType = verificationTypeEnum;

        protected abstract Task<bool?> IsWhiteListed(string value);

        protected abstract Task<IEnumerable<VerificationMatchModel>> GetMatches(string value);

        public async Task<VerificationDto> Verify(string value)
        {
            value = value.Trim().ToLowerInvariant();
            var matches = await GetMatches(value);
            var sources = (SourceEnum[])Enum.GetValues(typeof(SourceEnum));
            var findings = new List<FindingDto>();
            foreach (var source in sources)
            {
                bool? isWhitelisted = null;

                var match = matches.FirstOrDefault(x => x.Source.Equals(source.GetDescription(), StringComparison.InvariantCultureIgnoreCase));

                if (match != null && match.Source.Equals(SourceEnum.AxosBank.GetDescription(), StringComparison.InvariantCultureIgnoreCase))
                {
                    isWhitelisted = await IsWhiteListed(match.Value);
                }

                findings.Add(GetFinding(match != null, source, isWhitelisted, match?.IsRemoved));
            }

            return GetVerification(findings);
        }

        private FindingDto GetFinding(bool matchFound, SourceEnum sourceEnum, bool? isWhitelisted, bool? isRemoved)
        {
            isRemoved = matchFound ? isRemoved ?? null : null;

            return new FindingDto()
            {
                Judgement = (matchFound ? (((isWhitelisted ?? false) || (isRemoved ?? false)) ? StatusEnum.Pass : StatusEnum.Fail) : StatusEnum.Pass),
                Source = sourceEnum,
                MatchFound = matchFound,
                WhiteListed = isWhitelisted,
                Removed = isRemoved
            };
        }

        private VerificationDto GetVerification(IEnumerable<FindingDto> findings)
        {
            return new VerificationDto()
            {
                VerificationType = VerificationType,
                MatchesFound = findings.Any(x => x.MatchFound),
                Judgement = findings.Any(x => x.Judgement == StatusEnum.Fail) ? StatusEnum.Fail : StatusEnum.Pass,
                Findings = findings
            };
        }
    }
}
