﻿using Axos.Extensions;
using Axos.Identity.FraudLinks.Data.Database;
using Axos.Identity.FraudLinks.Domain.Contracts;
using Axos.Identity.FraudLinks.Domain.Enums;
using Axos.Identity.Fraudlinks.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Axos.Identity.Fraudlinks.Services.Verification;

namespace Axos.Identity.Fraudlinks.Services.Verification
{
    public class EmailVerificationService : BaseVerificationService, IVerificationService
    {
        private IFraudlinksContext _dbContext { get; set; }

        public EmailVerificationService(IFraudlinksContext dbContext) : base(VerificationTypeEnum.Email)
        {
            _dbContext = dbContext;
        }

        protected override async Task<bool?> IsWhiteListed(string value)
        {
            return await _dbContext.WhiteListItem
                .Include(x => x.ValueTypeNavigation)
                .AnyAsync(x => x.ValueTypeNavigation.TypeName == WhiteListItemTypeEnum.Email.GetDescription()
                && x.Value == value);
        }

        protected override async Task<IEnumerable<VerificationMatchModel>> GetMatches(string value)
        {
            var matches = await _dbContext.EmailData
                .Include(x => x.SourceType)
                .Where(x => x.Email == value).Distinct().ToListAsync();

            return from match in matches
                   select new VerificationMatchModel()
                   {
                       Source = match.SourceType.Name,
                       IsRemoved = match.Removed != null,
                       Value = match.Email
                   };
        }
    }
}
