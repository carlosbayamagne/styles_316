﻿using Axos.Integration.Core;
using Axos.Identity.FraudLinks.Data.Database;
using Axos.Identity.FraudLinks.Domain.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Axos.Identity.Fraudlinks.Services.Verification;
using Axos.Identity.Fraudlinks.Services;

namespace Axos.Identity.FraudLinks.DependencyResolution
{
    public static partial class FraudlinksDependencies
    {
        //public static void RegisterClientDependencies(this IServiceCollection services, IConfiguration configuration, string environment)
        //{
        //    services.AddDbContext<FraudlinksContext>();

        //    var connectionString = new ServiceConfig(environment, "Fraudlinks").Settings["DbConnectionString"];

        //    services.AddScoped<FraudlinksContext>(ctx =>
        //    {
        //        var options = new DbContextOptionsBuilder<FraudlinksContext>();
        //        options.UseSqlServer(connectionString);
        //        return new FraudlinksContext(options.Options);
        //    });

        //    services.AddScoped<IFraudlinksContext, FraudlinksContext>(ctx =>
        //        ctx.GetRequiredService<FraudlinksContext>());

        //    services.AddScoped<IVerificationService, EmailVerificationService>();
        //    services.AddScoped<IVerificationService, PhoneNumberVerificationService>();
        //    services.AddScoped<IVerificationService, TaxPayerIdVerificationService>();
        //    services.AddScoped<IVerificationService, NameVerificationService>();
        //    services.AddScoped<IFraudlinksService, FraudlinksService>();
        //}
        
        public static void RegisterClientDependencies(this IServiceCollection services, string connectionString)
        {
            services.AddDbContext<FraudlinksContext>();

            services.AddScoped<FraudlinksContext>(ctx =>
            {
                var options = new DbContextOptionsBuilder<FraudlinksContext>();
                options.UseSqlServer(connectionString);
                return new FraudlinksContext(options.Options);
            });

            services.AddScoped<IFraudlinksContext, FraudlinksContext>(ctx =>
                ctx.GetRequiredService<FraudlinksContext>());

            services.AddScoped<IVerificationService, EmailVerificationService>();
            services.AddScoped<IVerificationService, PhoneNumberVerificationService>();
            services.AddScoped<IVerificationService, TaxPayerIdVerificationService>();
            services.AddScoped<IVerificationService, NameVerificationService>();
            services.AddScoped<IFraudlinksService, FraudlinksService>();
        }
    }
}
