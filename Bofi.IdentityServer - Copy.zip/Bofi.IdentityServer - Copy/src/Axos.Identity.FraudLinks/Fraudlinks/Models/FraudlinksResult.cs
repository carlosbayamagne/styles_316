﻿using Axos.Identity.FraudLinks.Domain.Dtos;
using Axos.Identity.FraudLinks.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Axos.Identity.Fraudlinks.Models
{
    public class FraudlinksResult<TData, TResult>
    {
        public FraudlinksMetadataDto<TResult> Metadata { get; }
        public TData Data { get; }
        private FraudlinksResult(TData data, TResult result, StatusEnum statusEnum, string errorMessage = null)
        {
            Metadata = new FraudlinksMetadataDto<TResult>()
            {
                FraudlinksVersion = GetFraudlinksVersion(),
                Status = statusEnum,
                Result = result,
                ErrorMessage = errorMessage
            };

            Data = data;
        }

        public static FraudlinksResult<TData, TResult> Pass(TData data, TResult result)
        {
            return new FraudlinksResult<TData, TResult>(data, result, StatusEnum.Pass);
        }

        public static FraudlinksResult<TData, TResult> Fail(TData data, TResult result)
        {
            return new FraudlinksResult<TData, TResult>(data, result, StatusEnum.Fail);
        }

        public static FraudlinksResult<TData, TResult> Error(string errorMessage)
        {
            return new FraudlinksResult<TData, TResult>(default, default, StatusEnum.Fail, errorMessage);
        }

        private string GetFraudlinksVersion()
        {
            return Assembly.GetEntryAssembly().GetName().Version.ToString();
        }
    }
}
