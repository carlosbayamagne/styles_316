﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Fraudlinks.Models
{
    public class VerificationMatchModel
    {
        public string Source { get; set; }
        public bool? IsRemoved { get; set; }
        public string Value { get; set; }

        public VerificationMatchModel() { }
    }
}
