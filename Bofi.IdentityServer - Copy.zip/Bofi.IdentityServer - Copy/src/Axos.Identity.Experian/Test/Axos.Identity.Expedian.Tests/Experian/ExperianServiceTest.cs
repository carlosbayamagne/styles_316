﻿using Axos.Identity.Experian.Models;
using Axos.Identity.Experian.Models.PreciseId;
using Axos.Identity.Experian.Services;
using Axos.Identity.Experian.UnitTests.Common;
using Axos.Integration.Common.Models;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace Axos.Identity.Experian.Tests
{
    [Trait("Experian Service", "UnitTest")]
    public class ExperianServiceTest : BaseRuleSet
    {
        private IExperianService _service;
        private IPropertyService _propertyService;

        public ExperianServiceTest() : base()
        {
            _propertyService = new PropertyService("Development", "Experian");
            _service = new ExperianService("Development");

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        }

        [Fact]
        public void PropertyService_CheckExtension()
        {
            // wrong key, return DefaultValue.
            Assert.Equal(1, _propertyService.Setting("UNKNOW_KEY", 1));
            Assert.Equal("Y", _propertyService.Setting("UNKNOW_KEY", "Y"));

            // real Key, return Property Value.
            Assert.Equal("TCA1", _propertyService.Setting("Preamble", "T_C_A_1"));
            Assert.Equal(2452100, _propertyService.Setting("SubCodeOption20", 1234));
        }


        [Fact]
        public async Task CanGetIDAQuestions()
        {
            //arrange
            var model = new PersonalInformation
            {
                FirstName = "RUTH",
                LastName = "SIMPSON",
                MiddleName = "A",
                SSN = "666-64-7983",
                Street = "3119 FOOTHILL BLVD APT 5",
                City = "LA CRESCENTA",
                State = "CA",
                PostalCode = "91214",
                PhoneNumber = "8183523798",
                PhoneType = "C",
                DriverLicenseNumber = "234235",
                DriverLicenseState = "CA",
                DateOfBirth = new DateTime(1980, 1, 1),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            _service = new ExperianService("Development");

            //act
            var result = await _service.GetIdaQuestions(model);


            //assert
            Assert.True(result.Value.Products.PreciseIDServer.HasQuestions());
        }

        [Fact]
        public async Task RequestIDVCanGetReviewCode()
        {
            //arrange
            var model = new PersonalInformation
            {
                FirstName = "Christoph",
                LastName = "Liloia",
                SSN = "666647655",
                Street = "2400 Feather sound dr",
                City = "Clearwater",
                State = "FL",
                PostalCode = "337623084",
                PhoneNumber = "4128317053",
                PhoneType = "R",
                DateOfBirth = new DateTime(1967, 3, 16),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            //act
            var result = await _service.RequestIdv(model);

            //assert
            Assert.True(result.IsSuccess);
            Assert.Equal("REF", result.Value.Products.PreciseIDServer.Summary.InitialResults.FinalDecision);
        }

        [Fact]
        public async Task RequestIDVCanGetAcceptedCode()
        {
            //arrange
            var model = new PersonalInformation
            {
                FirstName = "Pamela",
                LastName = "Parks",
                SSN = "666429028",
                Street = "204 S Humphrey Ave",
                City = "Oak Park",
                State = "IL",
                PostalCode = "603023327",
                DriverLicenseState = "PA",
                DriverLicenseNumber = "21312603",
                PhoneNumber = "7083865377",
                PhoneType = "R",
                DateOfBirth = new DateTime(1967, 3, 16),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            //act
            var result = await _service.RequestIdv(model);

            //assert
            Assert.True(result.IsSuccess);
            Assert.Equal("ACC", result.Value.Products.PreciseIDServer.Summary.InitialResults.FinalDecision);
        }

        [Fact]
        public async Task RequestIDV_PropertyServiceException_ShouldReturnException()
        {
            //arrange
            var propertyService = new Mock<IPropertyService>();           
            var service = new ExperianService(propertyService.Object);
            var model = new PersonalInformation
            {
                FirstName = "Pamela",
                LastName = "Parks",
                SSN = "666429028",
                Street = "204 S Humphrey Ave",
                City = "Oak Park",
                State = "IL",
                PostalCode = "603023327",
                DriverLicenseState = "PA",
                DriverLicenseNumber = "21312603",
                PhoneNumber = "7083865377",
                PhoneType = "R",
                DateOfBirth = new DateTime(1967, 3, 16),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            //act assert
            await Assert.ThrowsAsync<Integration.Common.Exceptions.RulesEngineException>(() => service.RequestIdv(model));            
        } 
        
        [Fact]
        public async Task GetIdaQuestions_PropertyServiceException_ShouldReturnException()
        {
            //arrange
            var propertyService = new Mock<IPropertyService>();           
            var service = new ExperianService(propertyService.Object);
            var model = new PersonalInformation
            {
                FirstName = "Pamela",
                LastName = "Parks",
                SSN = "666429028",
                Street = "204 S Humphrey Ave",
                City = "Oak Park",
                State = "IL",
                PostalCode = "603023327",
                DriverLicenseState = "PA",
                DriverLicenseNumber = "21312603",
                PhoneNumber = "7083865377",
                PhoneType = "R",
                DateOfBirth = new DateTime(1967, 3, 16),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            //act assert
            await Assert.ThrowsAsync<Integration.Common.Exceptions.RulesEngineException>(() => service.GetIdaQuestions(model));            
        }
        
        [Fact]
        public async Task SendIdaAnswers_PropertyServiceException_ShouldReturnException()
        {
            //arrange
            var propertyService = new Mock<IPropertyService>();           
            var service = new ExperianService(propertyService.Object);
            var model = new SendIdaAnswersRequest();           

            //act assert
            await Assert.ThrowsAsync<Integration.Common.Exceptions.RulesEngineException>(() => service.SendIdaAnswers(model));            
        }

        [Fact]
        public async Task CanSendIDAAnswers()
        {
            //arrange
            var pip = new PersonalInformation
            {
                FirstName = "RUTH",
                LastName = "SIMPSON",
                MiddleName = "A",
                SSN = "666-64-7983",
                Street = "3119 FOOTHILL BLVD APT 5",
                City = "LA CRESCENTA",
                State = "CA",
                PostalCode = "91214",
                PhoneNumber = "8183523798",
                PhoneType = "C",
                DriverLicenseNumber = "234235",
                DriverLicenseState = "CA",
                DateOfBirth = new DateTime(1980, 1, 1),
                Reference = _propertyService.Setting("ConsumerReference", "Consumer Identity")
            };

            var answers = new List<Answer>
                {
                    new Answer(0,1),
                    new Answer(1,2),
                    new Answer(2,3),
                    new Answer(3,4),
                    new Answer(4,5)
                };

            //act
            var questionResult = await _service.GetIdaQuestions(pip);
            var sessionId = questionResult.Value.Products.PreciseIDServer.SessionId;
            var reference = _propertyService.Setting("ConsumerReference", "Consumer Identity");
            var request = new SendIdaAnswersRequest { Answers = answers, Reference = reference, SessionId = sessionId };

            var answerResult = await _service.SendIdaAnswers(request);

            //assert
            Assert.True(answerResult.IsSuccess);
        }
    }
}