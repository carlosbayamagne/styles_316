﻿using Axos.Integration.Common.Models;
using Axos.Integration.Common.Services;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Axos.Integration.Common.Enums;
using Axos.Identity.Experian.Models.Response;
using Axos.Identity.Experian.Models.Request;
using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;
using System.Xml;
using System.IO;
using System;
using System.Linq;
using Axos.Identity.Experian.Models.Response.Details;
using System.Net;

namespace Axos.Identity.Experian
{
    public class ExperianCreditScoresService : HttpService, IExperianCreditScoresService
    {
        public ExperianCreditScoresService(string environment) : base(new DummyPayloadSerializer()) {}

        #region Tool methods
        private Dictionary<string, string> GetHeaders(string token)
        {
            return new Dictionary<string, string>
            {
                { "AuthorizationType", "eps-authorizer" },
                { "Authorization", "Bearer "+token }
            };
        }

        private async Task<string> GetCredentials(string client_id, string client_secret)
        {
            var pairValue = new Dictionary<string, string>
            {
                { "client_id", client_id },
                { "client_secret", client_secret },
                { "grant_type", "client_credentials" }
            };

            var formUrlEncodedContent = new FormUrlEncodedContent(pairValue);
            return await formUrlEncodedContent.ReadAsStringAsync();
        }

        private async Task<T> GenericRequest<T>(string xml, string url, string token, XmlExperianSerializer XmlSerializer)
        {
            ServiceResult<string> result = await Post<string, string>(url, xml, ContentType.BasicXml, GetHeaders(token));

            var rsxResult = XmlSerializer.DeSerializeResponse<T>(result.Value);

            return rsxResult;
        }


        private string SerializeToString<T>(T value)
        {
            var emptyNamespaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamespaces);
                return stream.ToString();
            }
        }
        #endregion

        #region Endpoint methods
        public async Task<string> GetToken(CreditScoresPropertiesSet propertiesSet, bool switchRTN)
        {
            JsonPayloadSerializer jsonPayloadSerializer = new JsonPayloadSerializer();

            //string tokenURL = "https://gateway-staging.csid.co/oauth2/token"; //PropertyService Replace
            //string client_id = "53950019_4b21f601-f8ac-4660-adc0-787993791788"; //PropertyService Replace
            //string client_secret = ")g$H9Tlwz2H082l"; //PropertyService Replace

            var urlFormEncoded = await GetCredentials(switchRTN ? propertiesSet.SRTN_client_id : propertiesSet.client_id, switchRTN ? propertiesSet.SRTN_client_secret : propertiesSet.client_secret);
            ServiceResult<string> serviceResult = await Post<string, string>(propertiesSet.TokenURL, urlFormEncoded, ContentType.UrlEncoded);

            var deserialization = jsonPayloadSerializer.DeSerializeResponse<TokenModel>(serviceResult.Value);

            return deserialization.access_token;
        }

        public async Task<ThinLoadResponse> ThinLoad(CreditScoresPropertiesSet propertiesSet, string token, ThinLoadRequest request)
        {
            //string url = "https://itm.csidentity.com/SubscriberLoad_API/ThinSubscriberAPIServlet"; //PropertyService Replace
            //string url = "https://gateway-staging.csid.co/SubscriberLoad_API/ThinSubscriberAPIServlet"; //PropertyService Replace

            ThinLoadRequestWrapper requestModel = new ThinLoadRequestWrapper
            {
                Subscriber = request,
                OfficeData = new OfficeData
                {
                    Service = "ThinLoad",
                    Version = "2.7",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<ThinLoadResponseWrapper>(SerializeToString<ThinLoadRequestWrapper>(requestModel), propertiesSet.EnrollmentURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<GetIDVerificationResponse> GetIDVerification(CreditScoresPropertiesSet propertiesSet, string token, GetIDVerificationRequest request, string JavascriptCollectorPayload = null, Headers headers = null, Cookies cookies = null, string RemoteIpAddress = null, string ServerTimeStamp = null)
        {
            request.DisclosureDateTime = DateTime.Now.ToString("yyyyMMddhhmmss");
            GetIDVerificationRequestWrapper requestModel = new GetIDVerificationRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "GetIDVerification",
                    Version = "2.3",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                },
                JavascriptCollectorPayload = JavascriptCollectorPayload,
                Headers = headers,
                Cookies = cookies,
                RemoteIpAddress = RemoteIpAddress,
                ServerTimeStamp = ServerTimeStamp
            };
            var XmlSerializer = new XmlExperianSerializer();

            var preResult = await Post<string, string>(propertiesSet.EndpointsURL, SerializeToString<GetIDVerificationRequestWrapper>(requestModel), ContentType.BasicXml, GetHeaders(token));
            GetIDVerificationWrapper result;
            if (!preResult.Value.Contains("<ErrorText>Subscriber is already authenticated in ITM.</ErrorText>"))
            {
                result = XmlSerializer.DeSerializeResponse<GetIDVerificationWrapper>(preResult.Value);
            }
            else
            {
                return null;
            }

            return result.Response;

        }

        public async Task<SubmitIDVerificationDataResponse> SubmitIDVerificationData(CreditScoresPropertiesSet propertiesSet, string token, SubmitIDVerificationDataRequest request)
        {
            SubmitIDVerificationDataRequestWrapper requestModel = new SubmitIDVerificationDataRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "SubmitIDVerificationData",
                    Version = "2.1",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<SubmitIDVerificationDataWrapper>(SerializeToString<SubmitIDVerificationDataRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<OrderCreditReportDataResponse> OrderCreditReportData(CreditScoresPropertiesSet propertiesSet, string token, OrderCreditReportDataRequest request)
        {
            OrderCreditReportDataRequestWrapper requestModel = new OrderCreditReportDataRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "OrderCreditReportData",
                    Version = " 2.2",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<OrderCreditReportDataWrapper>(SerializeToString<OrderCreditReportDataRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<CreditReportDataResponse> GetCreditReportData(CreditScoresPropertiesSet propertiesSet, string token, CreditReportDataRequest request)
        {
            CreditReportDataRequestWrapper requestModel = new CreditReportDataRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "GetCreditReportData",
                    Version = "2.1",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<CreditReportDataWrapper>(SerializeToString<CreditReportDataRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<GetCreditScoreDataResponse> GetCreditScoreData(CreditScoresPropertiesSet propertiesSet, string token, ScorePlotterDataRequest request)
        {
            //string url = "https://gateway-staging.csid.co/itm_web/CSIWebServiceAPIServlet"; //PropertyService Replace

            ScorePlotterDataRequestWrapper requestModel = new ScorePlotterDataRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "GetCreditScoreData",
                    Version = "2.0",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<GetCreditScoreDataWrapper>(SerializeToString<ScorePlotterDataRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<GenericResult<string>> ScorePlotterData(CreditScoresPropertiesSet propertiesSet, string token, ScorePlotterDataRequest request)
        {
            var returnValue = new GenericResult<string>();
            ScorePlotterDataRequestWrapper requestModel = new ScorePlotterDataRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "ScorePlotterData",
                    Version = "2.1",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<ScorePlotterDataWrapper>(SerializeToString<ScorePlotterDataRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);
            if (result.Response.Status != "Success")
            {

                returnValue.Message = "Can't get credit scores: " + result.Response.ErrorText;
                returnValue.State = "Fail";
                return returnValue;
            }
            HttpWebRequest pageRequest = (HttpWebRequest)WebRequest.Create(result.Response.DisplayUrl.Url);
            pageRequest.Method = "GET";
            string contents;
            using (var pageResponse = pageRequest.GetResponse())
            using (var stream = pageResponse.GetResponseStream())
            using (var reader = new StreamReader(stream))
            {
                HttpStatusCode statusCode = ((HttpWebResponse)pageResponse).StatusCode;
                contents = reader.ReadToEnd();
            }

            returnValue.Data = contents;
            returnValue.State = "Success";

            return returnValue;
        }

        public async Task<SOADeleteResponse> SOADeactivate(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request)
        {
            SOADeleteRequestWrapper requestModel = new SOADeleteRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "SOADeactivate",
                    Version = "2.3",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<SOADeleteResponseWrapper>(SerializeToString<SOADeleteRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<SOADeleteResponse> SOADelete(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request)
        {
            SOADeleteRequestWrapper requestModel = new SOADeleteRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "SOADelete",
                    Version = "2.0",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<SOADeleteResponseWrapper>(SerializeToString<SOADeleteRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<ThinLoadResponse> ExternalSubscriberLoad(CreditScoresPropertiesSet propertiesSet, string token, ExternalSubscriberLoadRequest request)
        {
            ExternalSubscriberLoadRequestWrapper requestModel = new ExternalSubscriberLoadRequestWrapper
            {
                Subscriber = request,
                OfficeData = new OfficeData
                {
                    Service = "ExternalSubscriberLoad",
                    Version = "2.7",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<ThinLoadResponseWrapper>(SerializeToString<ExternalSubscriberLoadRequestWrapper>(requestModel), propertiesSet.DirectEnrollmentURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<SOASearchResponse> SOASearch(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request)
        {
            SOADeleteRequestWrapper requestModel = new SOADeleteRequestWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "SOASearch",
                    Version = "2.0",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<SOASearchResponseWrapper>(SerializeToString<SOADeleteRequestWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }

        public async Task<OrderCreditScoreDataResponse> OrderCreditScore(CreditScoresPropertiesSet propertiesSet, string token, OrderCreditScoreDataRequest request)
        {
            OrderCreditScoreDataWrapper requestModel = new OrderCreditScoreDataWrapper
            {
                SubscriberData = request,
                OfficeData = new OfficeData
                {
                    Service = "OrderCreditScore",
                    Version = "1.0",
                    OfficeUserID = propertiesSet.OfficeUserID,
                    OfficePassword = propertiesSet.OfficePassword
                }
            };
            var XmlSerializer = new XmlExperianSerializer();

            var result = await GenericRequest<OrderCreditScoreDataResponseWrapper>(SerializeToString<OrderCreditScoreDataWrapper>(requestModel), propertiesSet.EndpointsURL, token, XmlSerializer);

            return result.Response;
        }
        #endregion
    }
}
