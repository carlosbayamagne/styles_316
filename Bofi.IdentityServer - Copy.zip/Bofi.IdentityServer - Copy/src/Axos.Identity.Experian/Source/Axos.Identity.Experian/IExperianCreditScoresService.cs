﻿using Axos.Identity.Experian.Models.Request;
using Axos.Identity.Experian.Models.Request.Details;
using Axos.Identity.Experian.Models.Response;
using Axos.Integration.Common.Models;
using Axos.Integration.Common.Services;
using System.Threading.Tasks;

namespace Axos.Identity.Experian
{
    public interface IExperianCreditScoresService
    {
        Task<string> GetToken(CreditScoresPropertiesSet propertiesSet, bool switchRTN);

        Task<ThinLoadResponse> ThinLoad(CreditScoresPropertiesSet propertiesSet, string token, ThinLoadRequest request);

        Task<GetIDVerificationResponse> GetIDVerification(CreditScoresPropertiesSet propertiesSet, string token, GetIDVerificationRequest request, string JavascriptCollectorPayload = null, Headers headers = null, Cookies cookies = null, string RemoteIpAddress = null, string ServerTimeStamp = null);

        Task<SubmitIDVerificationDataResponse> SubmitIDVerificationData(CreditScoresPropertiesSet propertiesSet, string token, SubmitIDVerificationDataRequest request);

        Task<OrderCreditReportDataResponse> OrderCreditReportData(CreditScoresPropertiesSet propertiesSet, string token, OrderCreditReportDataRequest request);

        Task<CreditReportDataResponse> GetCreditReportData(CreditScoresPropertiesSet propertiesSet, string token, CreditReportDataRequest request);

        Task<GetCreditScoreDataResponse> GetCreditScoreData(CreditScoresPropertiesSet propertiesSet, string token, ScorePlotterDataRequest request);

        Task<GenericResult<string>> ScorePlotterData(CreditScoresPropertiesSet propertiesSet, string token, ScorePlotterDataRequest request);

        Task<SOADeleteResponse> SOADeactivate(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request);

        Task<SOADeleteResponse> SOADelete(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request);

        Task<ThinLoadResponse> ExternalSubscriberLoad(CreditScoresPropertiesSet propertiesSet, string token, ExternalSubscriberLoadRequest request);

        Task<SOASearchResponse> SOASearch(CreditScoresPropertiesSet propertiesSet, string token, SOADeleteRequest request);

        Task<OrderCreditScoreDataResponse> OrderCreditScore(CreditScoresPropertiesSet propertiesSet, string token, OrderCreditScoreDataRequest request);
    }
}
