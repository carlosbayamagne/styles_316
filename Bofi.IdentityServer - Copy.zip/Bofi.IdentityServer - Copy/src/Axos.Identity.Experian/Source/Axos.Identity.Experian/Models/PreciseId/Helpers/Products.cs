﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class Products
    {
        public PreciseIdServer PreciseIDServer { get; set; }

        public Products()
        {
            PreciseIDServer = new PreciseIdServer();
        }
    }

    [XmlRoot("PreciseIDServer")]
    public class PreciseIdServer
    {
        public string ReferenceNumber { get; set; }
        [XmlElement("XMLVersion")]
        public int XmlVersion { get; set; }
        [XmlElement("SessionID")]
        public string SessionId { get; set; }
        [XmlElement("Messages"), DefaultValue("")]
        public Messages Messages { get; set; }
        public Header Header { get; set; }
        public Summary Summary { get; set; }
        [XmlElement("GLBDetail")]
        public GLBDetail GLBDetail  { get; set; }
        public Subscriber Subscriber { get; set; }
        public Applicant PrimaryApplicant { get; set; }
        public string Verbose { get; set; }
        public Vendor Vendor { get; set; }
        public Options Options { get; set; }
        public CheckPointOptions CheckPointOptions { get; set; }
        [XmlElement("KBAScore")]
        public KbaScore KbaScore { get; set; }
        [XmlElement("KBA")]
        public Kba Kba { get; set; }
        [XmlElement("KBAAnswers")]
        public KbaAnswers KbaAnswers { get; set; }

        public Error Error { get; set; }

        public PreciseIdServer()
        {
            ReferenceNumber = Guid.NewGuid().ToString();
            Header = new Header();
            Summary = new Summary();
            GLBDetail = new GLBDetail();
            Subscriber = new Subscriber();
            PrimaryApplicant = new Applicant();
            Vendor = new Vendor();
            Options = new Options();
            CheckPointOptions = new CheckPointOptions();
            Error = new Error();
        }

        public bool HasQuestions()
        {
            if (Kba == null || Kba.Questions == null)
                return false;
            return Kba.Questions.Any();
        }
    }

    [XmlRoot("Message")]
    public class Message
    {
        [XmlElement("Text")]
        public string Text { get; set; }
    }

    [XmlRoot("Messages")]
    public class Messages
    {
        [XmlElement("Message")]
        public List<Message> Message { get; set; }
    }

    public class Header
    {
        public string ReportDate { get; set; }
        public string ReportTime { get; set; }
        public string Preamble { get; set; }
        public string ReferenceNumber { get; set; }
    }

    public class Subscriber
    {
        public string Preamble { get; set; }
        public string OpInitials { get; set; }
        public int SubCode { get; set; }
    }

    public class Applicant
    {
        public Name Name { get; set; }
        public string SSN { get; set; }

        public Address CurrentAddress { get; set; }
        public DriverLicense DriverLicense { get; set; }
        public Phone Phone { get; set; }
        [XmlElement("DOB")]
        public string DateOfBirth { get; set; }

        public Applicant()
        {
            Name = new Name();
            CurrentAddress = new Address();
            DriverLicense = new DriverLicense();
            Phone = new Phone();
        }
    }

    public class Name
    {
        public string Surname { get; set; }
        public string First { get; set; }
        public string Middle { get; set; }
    }

    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
    }

    public class DriverLicense
    {
        public string State { get; set; }
        public string Number { get; set; }
    }

    public class Phone
    {
        public string Number { get; set; }
        public string Type { get; set; }
    }

    public class Vendor
    {
        [XmlElement("VendorNumber")]
        public string Number { get; set; }
        [XmlElement("VendorVersion")]
        public string Version { get; set; }
    }

    public class Options
    {
        public string ReferenceNumber { get; set; }
        [XmlElement("PreciseIDType")]
        public int PreciseIdType { get; set; }
        public string DetailRequest { get; set; }
        public string InquiryChannel { get; set; }
        [XmlElement("OFAC")]
        public string Ofac { get; set; }
        [XmlElement("OFACMSG")]
        public string OfacMsg { get; set; }

        public Options()
        {
            ReferenceNumber = Guid.NewGuid().ToString();
        }
    }

    public class CheckPointOptions
    {
        public string LevelOfDetail { get; set; }
        public string EchoInput { get; set; }
        public string EDAFallThru { get; set; }
        public string EDABestPickCutoff { get; set; }
        public string NoOfEDAListings { get; set; }
        public string Validation { get; set; }
        public string PrevAddrSegment { get; set; }
    }

    public class Summary
    {
        public InitialResuts InitialResults { get; set; }
        public string PreciseIDScore { get; set; }
        public string DateOfBirthMatch { get; set; }

        public Summary()
        {
            InitialResults = new InitialResuts();
        }
    }

    [XmlRoot("GLBDetail")]
    public class GLBDetail
    {
        [XmlElement("CheckpointSummary")]
        public CheckpointSummary CheckpointSummary { get; set; }

        public GLBDetail()
        {
            CheckpointSummary = new CheckpointSummary();
        }
    }

    [XmlRoot("CheckpointSummary")]
    public class CheckpointSummary
    {
        public string OFACValidationResult { get; set; }
        public CheckpointSummary()
        {
            OFACValidationResult = string.Empty;
        }        
    }

    public class InitialResuts
    {
        public string InitialDecision { get; set; }
        public string FinalDecision { get; set; }
        public string AuthenticationIndex { get; set; }
        public string MostLikelyFraudType { get; set; }
    }

    public class Error
    {
        [XmlElement("HostID")]
        public string HostId { get; set; }
        [XmlElement("ApplicationID")]
        public string ApplicationId { get; set; }
        public string ReportDate { get; set; }
        public string ReportTime { get; set; }
        public string ReportType { get; set; }
        public string Preamble { get; set; }
        public string RegionCode { get; set; }
        [XmlElement("ARFVersion")]
        public string ArfVersion { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string ActionIndicator { get; set; }
        [XmlElement("ModuleID")]
        public string ModuleId { get; set; }
        public string ReferenceNumber { get; set; }
    }
}
