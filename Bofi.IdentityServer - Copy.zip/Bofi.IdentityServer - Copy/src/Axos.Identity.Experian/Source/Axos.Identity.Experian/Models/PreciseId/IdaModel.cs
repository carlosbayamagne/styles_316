﻿using System.Collections.Generic;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class IdaModel
    {
        public string SessionId { get; private set; }
        public string ExclusionCode { get; private set; }
        public bool HasExclusionCode { get; private set; }
        public IEnumerable<Question> Questions { get; private set; }

        public IdaModel(string sessionId, string exlusionCode, bool hasExclusionCode,  IEnumerable<Question> questions = null)
        {
            SessionId = sessionId;
            Questions = questions ?? new List<Question>();
            ExclusionCode = exlusionCode;
            HasExclusionCode = hasExclusionCode;
        }

        public static IdaModel Create(string sessionId, string exlusionCode, IEnumerable<Question> questions)
        {
            return new IdaModel(sessionId, exlusionCode, false, questions);
        }

        public static IdaModel Exclusion(string sessionId, string exclusionCode)
        {
            return new IdaModel(sessionId, exclusionCode, true);
        }
    }
}
