﻿using System;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.PreciseId
{
    [XmlRoot("NetConnectRequest", Namespace = "http://www.experian.com/NetConnect")]
    public class RequestModel
    {
        public string EAI { get; set; }
        public string DBHost { get; set; }
        public string ReferenceId { get; set; }
        public RequestBody Request { get; set; }

        public RequestModel()
        {            
            Request = new RequestBody();
        }

        public void SetReference(string reference)
        {
            reference = string.IsNullOrWhiteSpace(reference) ? Guid.NewGuid().ToString() : reference;
            ReferenceId = reference;
            Request.Products.PreciseIDServer.ReferenceNumber = reference;
            Request.Products.PreciseIDServer.Options.ReferenceNumber = reference;            
        }
    }

    [XmlRoot("Request", Namespace = "http://www.experian.com/WebDelivery")]
    public class RequestBody
    {
        [XmlAttribute("version")]
        public int Version { get; set; }
        public Products Products { get; set; }

        public RequestBody()
        {
            Products = new Products();
            Products.PreciseIDServer.Header = null;
            Products.PreciseIDServer.Summary = null;
            Products.PreciseIDServer.GLBDetail = null;
            Products.PreciseIDServer.Error = null;
        }
    }
}
