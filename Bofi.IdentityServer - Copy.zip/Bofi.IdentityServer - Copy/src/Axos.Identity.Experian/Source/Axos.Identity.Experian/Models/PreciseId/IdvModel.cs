﻿using Newtonsoft.Json;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class IdvModel
    {
        public string SessionId { get; protected set; }
        public string ResponseCode { get; set; }
        public bool IsAccepted { get; private set; }
        public bool IsDeclined { get; private set; }
        public bool IsReview { get; private set; }
        public bool OFACHit { get; private set; }

        [JsonConstructor]
        private IdvModel(string sessionId, string responseCode, bool isAccepted, bool isDeclined, bool isReview, bool ofacHit)
        {
            SessionId = sessionId;
            ResponseCode = responseCode;
            IsAccepted = isAccepted;
            IsDeclined = isDeclined;
            IsReview = isReview;
            OFACHit = ofacHit;
        }

        public static IdvModel Create(string sessionId, string responseCode, bool ofacHit)
        {
            return new IdvModel(sessionId, responseCode, false, false, false, ofacHit);
        }

        public static IdvModel Accepted(string sessionId, string responseCode, bool ofacHit)
        {
            return new IdvModel(sessionId, responseCode, true, false, false, ofacHit);
        }

        public static IdvModel Declined(string sessionId, string responseCode, bool ofacHit)
        {
            return new IdvModel(sessionId, responseCode, false, true, false, ofacHit);
        }

        public static IdvModel Review(string sessionId, string responseCode, bool ofacHit)
        {
            return new IdvModel(sessionId, responseCode, false, false, true, ofacHit);
        }
    }
}
