﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.PreciseId
{
    [XmlRoot("KBA")]
    public class Kba
    {
        //[XmlElement("XMLVersion")]
        //public int? XmlVersion { get; set; }
        public string LanguageCode { get; set; }
        public General General { get; set; }

        [XmlElement("QuestionSet", typeof(Question))]
        public List<Question> Questions { get; set; }
    }

    public class General
    {
        [XmlElement("SessionID")]
        public string SessionId { get; set; }
    }

    public class Question
    {
        [XmlElement("QuestionType", DataType = "positiveInteger")]
        public string Type { get; set; }

        [XmlElement("QuestionText")]
        public string Text { get; set; }

        [XmlArray("QuestionSelect"), XmlArrayItem("QuestionChoice")]
        public string[] Option { get; set; }
    }

    [XmlRoot("KBAAnswers")]
    public class KbaAnswers
    {
        public OutWalletAnswerData OutWalletAnswerData { get; set; }

        public KbaAnswers()
        {
            OutWalletAnswerData = new OutWalletAnswerData();
        }
    }

    public class OutWalletAnswerData
    {
        [XmlElement("SessionID")]
        public string SessionId { get; set; }

        public OutWalletAnswerData()
        {
            OutWalletAnswers = new int[0];
        }

        [XmlArray("OutWalletAnswers")]
        [XmlArrayItem("OutWalletAnswerItem")]
        public int[] OutWalletAnswers { get; set; }
    }
}
