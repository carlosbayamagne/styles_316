﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.PreciseId
{
    [XmlRoot("KBAScore")]
    public class KbaScore
    {
        [XmlElement("ScoreSummary")]
        public ScoreSummary ScoreSummary { get; set; }
    }

    [XmlRoot("ScoreSummary")]
    public class ScoreSummary
    {
        [XmlElement("AcceptReferCode")]
        public string AcceptReferCode { get; set; }
    }
}
