﻿using Axos.Integration.Common.Models;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class ExperianArguments : RuleArguments
    {
        public PersonalInformation Model { get; private set;}

        private ExperianArguments(PersonalInformation model)
        {
            Model = model;
        }

        public override Result Validate()
        {
            if (Model == null)
                return Result.Fail("The ExperianRequestModel is required.");

            var ssnValidationResult = Ssn.Create(Model.SSN);

            return ssnValidationResult.IsFailure
                ? Result.Fail(ssnValidationResult.Error)
                : Result.Ok();
        }

        public static ExperianArguments Create(PersonalInformation model)
        {
            return new ExperianArguments(model);            
        }
    }
}
