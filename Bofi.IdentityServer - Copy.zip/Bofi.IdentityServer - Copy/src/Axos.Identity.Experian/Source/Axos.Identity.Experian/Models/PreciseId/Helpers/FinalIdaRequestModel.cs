﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class FinalIdaRequestModel
    {
        public IEnumerable<Answer> Answers { get; set; }
        public string SessionId { get; set; }
    }
}
