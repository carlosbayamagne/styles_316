﻿using Axos.Integration.Common.Models;

namespace Axos.Identity.Experian.Models.PreciseId
{
    public class FinalIdaArguments : RuleArguments
    {
        public FinalIdaRequestModel Model { get; private set; }

        private FinalIdaArguments(FinalIdaRequestModel model)
        {
            Model = model;
        }

        public override Result Validate()
        {
            if (Model == null)
                return Result.Fail("The FinalIdaRequestModel is required.");

            return Result.Ok();
        }

        public static FinalIdaArguments Create(FinalIdaRequestModel model)
        {
            return new FinalIdaArguments(model);
        }
    }
}
