﻿using Axos.Integration.Common.Models;
using Axos.Identity.Experian.Models.NetConnect;
using Axos.Identity.Experian.Models.PreciseId;
using System.Collections.Generic;
using System.Linq;
using NetConnectRequest = Axos.Identity.Experian.Models.NetConnect.RequestModel;
using PreciseIdRequest = Axos.Identity.Experian.Models.PreciseId.RequestModel;

namespace Axos.Identity.Experian.Models
{
    public static class ModelExtensions
    {
        public static PreciseIdRequest CreateRequestModel(this PersonalInformation pip)
        {
            var result = new PreciseIdRequest();
            result.SetReference(pip.Reference);
            var server = result.Request.Products.PreciseIDServer;
            server.PrimaryApplicant.DateOfBirth = pip.DateOfBirth.ToString("MMddyyyy");
            server.PrimaryApplicant.Name.First = pip.FirstName;
            server.PrimaryApplicant.Name.Middle = pip.MiddleName;
            server.PrimaryApplicant.Name.Surname = pip.LastName;
            server.PrimaryApplicant.SSN = pip.SSN;
            server.PrimaryApplicant.CurrentAddress.Street = pip.Street;
            server.PrimaryApplicant.CurrentAddress.City = pip.City;
            server.PrimaryApplicant.CurrentAddress.State = pip.State;
            server.PrimaryApplicant.CurrentAddress.Zip = pip.PostalCode;
            server.PrimaryApplicant.DriverLicense.State = pip.DriverLicenseState;
            server.PrimaryApplicant.DriverLicense.Number = pip.DriverLicenseNumber;
            server.PrimaryApplicant.Phone.Number = pip.PhoneNumber;
            server.PrimaryApplicant.Phone.Type = pip.PhoneType;

            return result;
        }

        public static NetConnectRequest CreateNetConnectRequestModel(this PersonalInformation pip)
        {
            var result = new NetConnectRequest();
            var server = result.Request.Products.CreditProfile;
            server.PrimaryApplicant.YOB = pip.DateOfBirth.Year;
            server.PrimaryApplicant.Name.First = pip.FirstName;
            server.PrimaryApplicant.Name.Middle = pip.MiddleName;
            server.PrimaryApplicant.Name.Surname = pip.LastName;
            server.PrimaryApplicant.SSN = pip.SSN;
            server.PrimaryApplicant.CurrentAddress.Street = pip.Street;
            server.PrimaryApplicant.CurrentAddress.City = pip.City;
            server.PrimaryApplicant.CurrentAddress.State = pip.State;
            server.PrimaryApplicant.CurrentAddress.Zip = pip.PostalCode;
            server.PrimaryApplicant.Phone.Number = pip.PhoneNumber;

            return result;
        }

        /// <summary>
        /// Sets the common configuration settings to be use in the Experian service for IDV and IDA
        /// </summary>
        public static void SetCommonSettings(this PreciseIdRequest request, IPropertyService propertyService)
        {

            request.EAI = propertyService.Setting("ExternalApplicationId", "11111111");
            request.DBHost = propertyService.Setting("DatabaseHostName", "PRECISE_ID_TEST");

            request.Request.Version = propertyService.Setting("Version", 1);

            request.Request.Products.PreciseIDServer.XmlVersion = propertyService.Setting("PreciseID_ServerXmlVersion", 5); 
            request.Request.Products.PreciseIDServer.Verbose = propertyService.Setting("PreciseID_ServerVerbose", "Y"); 

            request.Request.Products.PreciseIDServer.Subscriber.Preamble = propertyService.Setting("Preamble", "TCA1");
            request.Request.Products.PreciseIDServer.Subscriber.OpInitials = propertyService.Setting("PreciseID_ServerSubscriberOpInitials", "AC"); 

            request.Request.Products.PreciseIDServer.Vendor.Number = propertyService.Setting("VendorNumber", "ABC");
            request.Request.Products.PreciseIDServer.Vendor.Version = propertyService.Setting("VendorVersion", "123456");

            request.Request.Products.PreciseIDServer.Options.DetailRequest = propertyService.Setting("PreciseID_ServerOptionsDetailRequest", "D");
            request.Request.Products.PreciseIDServer.Options.InquiryChannel = propertyService.Setting("PreciseID_ServerOptionsInquiryChannel", "INTE");

            request.Request.Products.PreciseIDServer.CheckPointOptions.LevelOfDetail = propertyService.Setting("PreciseID_ServerCheckpointOptionsLevelOfDetail", "F"); 
            request.Request.Products.PreciseIDServer.CheckPointOptions.EchoInput = propertyService.Setting("PreciseID_ServerCheckpointOptionsEchoInput", "N"); 
            request.Request.Products.PreciseIDServer.CheckPointOptions.EDAFallThru = propertyService.Setting("PreciseID_ServerCheckpointOptionsEdaFallThru", "N"); 
            request.Request.Products.PreciseIDServer.CheckPointOptions.EDABestPickCutoff = propertyService.Setting("PreciseID_ServerCheckpointOptionsEdaBestPickCutoff", "00"); 
            request.Request.Products.PreciseIDServer.CheckPointOptions.NoOfEDAListings = propertyService.Setting("PreciseID_ServerCheckpointOptionsNoOfEdaListings", "00");
            request.Request.Products.PreciseIDServer.CheckPointOptions.Validation = propertyService.Setting("PreciseID_ServerCheckpointOptionsValidation", "Y"); 
            request.Request.Products.PreciseIDServer.CheckPointOptions.PrevAddrSegment = propertyService.Setting("PreciseID_ServerCheckpointOptionsPrevAddrSegment", "Y"); 
        }

        public static void SetNetConnectCommonSettings(this NetConnectRequest request, IPropertyService propertyService)
        {

            request.EAI = propertyService.Setting("ExternalApplicationId", "11111111");
            request.DBHost = propertyService.Setting("DatabaseHostName", "PRECISE_ID_TEST");

            request.Request.Version = 1.0m;
            
            request.Request.Products.CreditProfile.Subscriber.Preamble = propertyService.Setting("Preamble", "TCA1");
            request.Request.Products.CreditProfile.Subscriber.OpInitials = propertyService.Setting("PreciseID_ServerSubscriberOpInitials", "AC");

            request.Request.Products.CreditProfile.Vendor.Number = propertyService.Setting("VendorNumber", "ABC");
            request.Request.Products.CreditProfile.Vendor.Version = propertyService.Setting("VendorVersion", "123456");

            request.Request.Products.CreditProfile.OutputType.XML.ARFVersion = "07";
            request.Request.Products.CreditProfile.OutputType.XML.Verbose = "N";

            request.Request.Products.CreditProfile.AddOns.MLA = "Y";
            request.Request.Products.CreditProfile.AddOns.RiskModels.Bankruptcy = "Y";
            request.Request.Products.CreditProfile.AddOns.RiskModels.FICO = "Y";
            request.Request.Products.CreditProfile.AddOns.RiskModels.TotalDebtToIncome = "Y";
        }

        public static void SetIDVSettings(this PreciseIdRequest request, IPropertyService propertyService)
        {
            request.SetCommonSettings(propertyService);
            request.Request.Products.PreciseIDServer.Options.PreciseIdType = propertyService.Setting("PreciseID_ServerOptionsIdvPreciseIdType", 20); 
            request.Request.Products.PreciseIDServer.Subscriber.SubCode = propertyService.Setting("SubCodeOption20", 2452100); 
        }

        public static void SetIDASettings(this PreciseIdRequest request, IPropertyService propertyService)
        {
            request.Request.Products.PreciseIDServer.Options.PreciseIdType = propertyService.Setting("PreciseID_ServerOptionsIdaPreciseIdType", 11);
            request.Request.Products.PreciseIDServer.Subscriber.SubCode = propertyService.Setting("SubCodeOption11", 2452070); 
            request.Request.Products.PreciseIDServer.Options.Ofac = propertyService.Setting("PreciseID_ServerOptionsOfac", "Y"); 
            request.Request.Products.PreciseIDServer.Options.OfacMsg = propertyService.Setting("PreciseID_ServerOptionsOfacmsg", "Y"); 

            request.Request.Products.PreciseIDServer.Kba = new Kba
            {
                LanguageCode = "en"
            };
        }

        public static PreciseIdRequest CreateIdaQuestionsModel(this PersonalInformation pip, IPropertyService propertyService)
        {
            var model = pip.CreateRequestModel();
            model.SetCommonSettings(propertyService);
            model.SetIDASettings(propertyService);

            return model;
        }

        public static void SetScoresSettings(this NetConnectRequest model, IPropertyService propertyService)
        {
            model.SetNetConnectCommonSettings(propertyService);
            model.Request.Products.CreditProfile.Subscriber.SubCode = propertyService.Setting("SubCodeOption", 2800397); 
        }

        public static PreciseIdRequest CreateIdaAnswersModel(string sessionId, string reference, IEnumerable<Answer> answers, IPropertyService propertyService)
        {
            var request = new PreciseIdRequest();
            request.SetReference(reference);
            request.SetCommonSettings(propertyService);
            request.Request.Products.PreciseIDServer.ReferenceNumber = null;
            request.Request.Products.PreciseIDServer.Verbose = null;
            request.Request.Products.PreciseIDServer.KbaAnswers = new KbaAnswers();
            request.Request.Products.PreciseIDServer.Subscriber = null;
            request.Request.Products.PreciseIDServer.PrimaryApplicant = null;
            request.Request.Products.PreciseIDServer.Vendor = null;
            request.Request.Products.PreciseIDServer.Options = null;
            request.Request.Products.PreciseIDServer.CheckPointOptions = null;
            request.Request.Products.PreciseIDServer.KbaAnswers.OutWalletAnswerData.SessionId = sessionId;           
            request.Request.Products.PreciseIDServer.KbaAnswers.OutWalletAnswerData.OutWalletAnswers = answers.Select(x => x.AnswerId).ToArray();

            return request;
        }

        public static PreciseIdRequest CreateIDVRequestModel(this PersonalInformation pip, IPropertyService propertyService)
        {
            var model = pip.CreateRequestModel();
            model.SetCommonSettings(propertyService);
            model.SetIDVSettings(propertyService);

            return model;
        }

        public static NetConnectRequest CreateScoresRequestModel(this PersonalInformation pip, IPropertyService propertyService)
        {
            var model = pip.CreateNetConnectRequestModel();
            
            model.SetScoresSettings(propertyService);

            return model;
        }

        public static IdaModel CreateIDAQuestions(this PreciseId.ResponseModel model)
        {
            var sessionId = model.Products.PreciseIDServer.SessionId;
            var preciseIdScore = model.Products.PreciseIDServer.Summary.PreciseIDScore;
            IEnumerable<Question> questions;
            if(model.Products.PreciseIDServer.Kba == null)
            {
                questions = new List<Question>();
            }
            else
            {
                questions = model.Products.PreciseIDServer.Kba.Questions;
            }

            return IdaModel.Create(sessionId, preciseIdScore, questions);
        }

        public static ScoreModel CreateScoreResponse(this NetConnect.ResponseModel model)
        {
            var score =  ScoreModel.Create(model.TransactionId, model.CompletionCode);
            var creditProfile = model.Products?.CreditProfile;
            var riskModels = creditProfile?.RiskModels;

            score.FICO = int.Parse(riskModels.FirstOrDefault(r => r.ModelIndicator.Code == "AF")?.Score ?? "0");
            score.Bankrupcy = int.Parse(riskModels.FirstOrDefault(r => r.ModelIndicator.Code == "B ")?.Score ?? "999");
            score.DTI = int.Parse(riskModels.FirstOrDefault(r => r.ModelIndicator.Code == "D1")?.Score ?? "99");

            score.MLA = creditProfile?.InformationalMessages?.Any(m => m.MessageText.Contains("1203 MLA")) ?? false;

            return score;
        }
    }
}
