﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;

namespace Axos.Identity.Experian.Models
{
    public class CreditProfileValue
    {
        [JsonProperty("data")]
        public List<Data> Data { get; set; }
    }
   
    public class Account
    {
        [JsonProperty("number")]
        public string Number { get; set; }

        [JsonProperty("balance")]
        public string Balance { get; set; }

        [JsonProperty("classification")]
        public string Classification { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("limit")]
        public string Limit { get; set; }
    }

    public class Data
    {
        [JsonProperty("accounts")]
        public List<Account> Accounts { get; set; }
    }
}
