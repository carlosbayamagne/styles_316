﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Response
{
    public class ScoreDetails
    {
        public string score { get; set; }

        public CreditScoresFactor credit_score_factor { get; set; }

        public string score_model { get; set; }

        public string score_rating { get; set; }

        public string bureau { get; set; }

        public string score_date { get; set; }
    }

    public class CreditScoresFactor
    {
        public Factors[] Factors { get; set; }
    }

    public class Factors
    {
        public string sequence { get; set; }

        public string code { get; set; }

        public string is_positive { get; set; }

        public string value { get; set; }
    }
}
