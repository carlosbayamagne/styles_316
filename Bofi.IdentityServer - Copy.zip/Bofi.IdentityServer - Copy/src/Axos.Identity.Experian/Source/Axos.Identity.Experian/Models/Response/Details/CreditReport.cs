﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response.Details
{
    public class CreditReport
    {
        [XmlElement(ElementName = "CreditReportData")]
        public CreditReportData CreditReportData { get; set; }
    }
}
