﻿using Axos.Identity.Experian.Models.Response.Details;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class GetIDVerificationWrapper
    {
        [XmlElement(ElementName = "Response")]
        public GetIDVerificationResponse Response { get; set; }
    }

    public class GetIDVerificationResponse : BaseExperianResponse
    {
        public string ApplicantChallengeId { get; set; }

        public string BillingID { get; set; }

        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }

        [XmlElement("QuestionData")]
        public List<QuestionDataGetIDVerification> QuestionDataArray { get; set; }

        public string PassiveAuthSuccess { get; set; }
    }

    public class QuestionDataGetIDVerification
    {
        public string QuestionType { get; set; }

        public string QuestionNumber { get; set; }

        public string Question { get; set; }

        public string QuestionId { get; set; }

        [XmlElement("AnswerOption")]
        public List<AnswerOption> AnswerOptionArray { get; set; }
    }
}
