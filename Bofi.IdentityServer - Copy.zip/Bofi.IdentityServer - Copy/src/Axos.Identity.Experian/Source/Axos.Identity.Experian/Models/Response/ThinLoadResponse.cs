﻿using Axos.Identity.Experian.Models.Response.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class ThinLoadResponseWrapper
    {
        [XmlElement(ElementName = "Response")]
        public ThinLoadResponse Response { get; set; }
    }

    public class ThinLoadResponse : BaseExperianResponse
    {
        public string BureauErrorCode { get; set; }

        public string BureauErrorMessage { get; set; }
    }
}
