﻿using Axos.Identity.Experian.Models.Response.Details;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class SubmitIDVerificationDataWrapper
    {
        [XmlElement(ElementName = "Response")]
        public SubmitIDVerificationDataResponse Response { get; set; }
    }
    public class SubmitIDVerificationDataResponse : BaseExperianResponse
    {
        public string BillingID { get; set; }

        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }
    }
}
