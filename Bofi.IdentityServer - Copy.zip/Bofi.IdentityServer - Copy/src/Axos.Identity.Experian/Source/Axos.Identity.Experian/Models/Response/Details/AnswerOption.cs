﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Response.Details
{
    public class AnswerOption
    {
        public string AnswerNumber { get; set; }

        public string Answer { get; set; }

        public string AnswerChoiceId { get; set; }
    }
}
