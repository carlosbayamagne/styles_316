﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Response.Details
{
    public class Verification
    {
    }
}
