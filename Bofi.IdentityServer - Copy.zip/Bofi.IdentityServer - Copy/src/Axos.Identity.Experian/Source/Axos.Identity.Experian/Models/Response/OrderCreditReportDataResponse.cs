﻿using Axos.Identity.Experian.Models.Response.Details;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class OrderCreditReportDataWrapper
    {
        [XmlElement(ElementName = "Response")]
        public OrderCreditReportDataResponse Response { get; set; }
    }

    public class OrderCreditReportDataResponse : BaseExperianResponse
    {
        public string BillingID { get; set; }

        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }

        [XmlElement(ElementName = "CreditReport")]
        public CreditReport CreditReport { get; set; }

        public string BureauErrorCode { get; set; }

        public string BureauErrorMessage { get; set; }

        public string ProductId { get; set; }

        public string OutputType { get; set; }
    }
}
