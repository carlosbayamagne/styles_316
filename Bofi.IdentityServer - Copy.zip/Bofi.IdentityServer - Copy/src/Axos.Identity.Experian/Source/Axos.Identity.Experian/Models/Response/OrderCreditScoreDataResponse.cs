﻿using Axos.Identity.Experian.Models.Response.Details;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class OrderCreditScoreDataResponseWrapper
    {
        [XmlElement(ElementName = "Response")]
        public OrderCreditScoreDataResponse Response { get; set; }
    }

    public class OrderCreditScoreDataResponse : BaseExperianResponse
    {
        [XmlElement("CreditScore")]
        public CreditScore CreditScore { get; set; }
    }

    public class CreditScore
    {
        public string Score { get; set; }

        public string Date { get; set; }

        public string PopulationRank { get; set; }

        [XmlElement("ScoreFactor")]
        public ScoreFactor ScoreFactor { get; set; }

    }
    public class ScoreFactor
    {
        [XmlElement("Factor")]
        public List<string> Factor { get; set; }
    }
}
