﻿using Axos.Identity.Experian.Models.Response.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class CreditReportDataWrapper
    {
        [XmlElement(ElementName = "Response")]
        public CreditReportDataResponse Response { get; set; }
    }

    public class CreditReportDataResponse : BaseExperianResponse
    {
        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }

        [XmlElement(ElementName = "CreditReport")]
        public CreditReport CreditReport { get; set; }
    }
}
