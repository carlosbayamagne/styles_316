﻿using Axos.Identity.Experian.Models.Response.Details;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class GetCreditScoreDataWrapper
    {
        [XmlElement(ElementName = "Response")]
        public GetCreditScoreDataResponse Response { get; set; }
    }
    public class GetCreditScoreDataResponse : BaseExperianResponse
    {
        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }

        public string ScoreDetails { get; set; }
    }
}
