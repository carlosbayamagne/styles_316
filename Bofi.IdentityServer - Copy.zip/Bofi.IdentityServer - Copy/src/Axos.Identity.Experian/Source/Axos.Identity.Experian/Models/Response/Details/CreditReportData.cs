﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Response.Details
{
    public class CreditReportData
    {
        public string Type { get; set; }

        public string ReportDetails { get; set; }
    }
}
