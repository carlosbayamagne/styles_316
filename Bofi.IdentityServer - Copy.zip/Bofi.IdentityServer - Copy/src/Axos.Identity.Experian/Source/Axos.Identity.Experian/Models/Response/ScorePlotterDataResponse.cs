﻿using Axos.Identity.Experian.Models.Response.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response
{
    [XmlRoot("CSIAPIResponse")]
    public class ScorePlotterDataWrapper
    {
        [XmlElement(ElementName = "Response")]
        public ScorePlotterDataResponse Response { get; set; }
    }

    public class ScorePlotterDataResponse : BaseExperianResponse
    {

        [XmlElement(ElementName = "Version")]
        public ResponseVersion Version { get; set; }

        [XmlElement(ElementName = "DisplayUrl")]
        public DisplayUrl DisplayUrl { get; set; }
    }

    public class DisplayUrl
    {
        public string Url { get; set; }
    }
}
