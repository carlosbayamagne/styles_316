﻿using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Response.Details
{
    public class BaseExperianResponse
    {
        [XmlElement(ElementName = "EncryptedData")]
        public string EncryptedData { get; set; }

        [XmlElement(ElementName = "TraceNumber")]
        public string TraceNumber { get; set; }

        [XmlElement(ElementName = "SubscriberNumber")]
        public string SubscriberNumber { get; set; }

        [XmlElement(ElementName = "Status")]
        public string Status { get; set; }

        [XmlElement(ElementName = "ErrorText")]
        public string ErrorText { get; set; }

        [XmlElement(ElementName = "ErrorType")]
        public string ErrorType { get; set; }
    }
}
