﻿using Axos.Identity.Experian.Models.Request.Details;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class OrderCreditScoreDataWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public OrderCreditScoreDataRequest SubscriberData { get; set; }
    }

    public class OrderCreditScoreDataRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string CreditScoreTypeNumber { get; set; }

    }
}
