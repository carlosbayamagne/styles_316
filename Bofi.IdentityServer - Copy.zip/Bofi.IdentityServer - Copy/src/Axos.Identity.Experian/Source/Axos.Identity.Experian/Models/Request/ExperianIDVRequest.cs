﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    public static class ExperianIDVRequest
    {
        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/NetConnect")]
        [XmlRoot(Namespace = "http://www.experian.com/NetConnect", IsNullable = false)]
        public class NetConnectRequest
        {
            /// <remarks />
            public string EAI { get; set; }

            /// <remarks />
            public string DBHost { get; set; }

            /// <remarks />
            public string ReferenceId { get; set; }

            /// <remarks />
            [XmlElement(Namespace = "http://www.experian.com/WebDelivery")]
            public Request Request { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        [XmlRoot(Namespace = "http://www.experian.com/WebDelivery", IsNullable = false)]
        public class Request
        {
            /// <remarks />
            public RequestProducts Products { get; set; }

            /// <remarks />
            [XmlAttribute]
            public decimal version { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProducts
        {
            /// <remarks />
            public RequestProductsPreciseIDServer PreciseIDServer { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServer
        {
            /// <remarks />
            public decimal XMLVersion { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerSubscriber Subscriber { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerPrimaryApplicant PrimaryApplicant { get; set; }

            /// <remarks />
            public string Verbose { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerVendor Vendor { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerOptions Options { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerCheckPointOptions CheckPointOptions { get; set; }

            /// <remarks />
            public string ReferenceNumber { get; set; }

            /// <remarks />
            public object IPAddress { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerSubscriber
        {
            /// <remarks />
            public string Preamble { get; set; }

            /// <remarks />
            public string OpInitials { get; set; }

            /// <remarks />
            public string SubCode { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerPrimaryApplicant
        {
            /// <remarks />
            public RequestProductsPreciseIDServerPrimaryApplicantName Name { get; set; }

            /// <remarks />
            public string SSN { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerPrimaryApplicantCurrentAddress CurrentAddress { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerPrimaryApplicantDriverLicense DriverLicense { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerPrimaryApplicantPhone Phone { get; set; }

            /// <remarks />
            public string DOB { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerPrimaryApplicantName
        {
            /// <remarks />
            public string Surname { get; set; }

            /// <remarks />
            public string First { get; set; }

            /// <remarks />
            public object Middle { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerPrimaryApplicantCurrentAddress
        {
            /// <remarks />
            public string Street { get; set; }

            /// <remarks />
            public string City { get; set; }

            /// <remarks />
            public string State { get; set; }

            /// <remarks />
            public string Zip { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerPrimaryApplicantDriverLicense
        {
            /// <remarks />
            public string State { get; set; }

            /// <remarks />
            public string Number { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerPrimaryApplicantPhone
        {
            /// <remarks />
            public string Number { get; set; }

            /// <remarks />
            public string Type { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerVendor
        {
            /// <remarks />
            public string VendorNumber { get; set; }

            /// <remarks />
            public string VendorVersion { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerOptions
        {
            /// <remarks />
            public string ReferenceNumber { get; set; }

            /// <remarks />
            public string OFAC { get; set; }

            /// <remarks />
            public string OFACMSG { get; set; }

            /// <remarks />
            public byte PreciseIDType { get; set; }

            /// <remarks />
            public string DetailRequest { get; set; }

            /// <remarks />
            public string InquiryChannel { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerCheckPointOptions
        {
            /// <remarks />
            public string LevelOfDetail { get; set; }

            /// <remarks />
            public string EchoInput { get; set; }

            /// <remarks />
            public string EDAFallThru { get; set; }

            /// <remarks />
            public string EDABestPickCutoff { get; set; }

            /// <remarks />
            public string NoOfEDAListings { get; set; }

            /// <remarks />
            public string Validation { get; set; }

            /// <remarks />
            public string PrevAddrSegment { get; set; }
        }
    }
}
