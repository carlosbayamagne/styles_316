﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class ScorePlotterDataRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public ScorePlotterDataRequest SubscriberData { get; set; }
    }

    public class ScorePlotterDataRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string XslID { get; set; }

        [XmlElement("Filter")]
        public Filter Filter { get; set; }
    }

    public class Filter
    {
        public string Value { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }
    }
}
