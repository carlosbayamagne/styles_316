﻿using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request.Details
{
    public class OfficeData
    {
        [XmlElement("Service")]
        public string Service { get; set; }

        [XmlElement("Version")]
        public string Version { get; set; }

        [XmlElement("OfficeUserID")]
        public string OfficeUserID { get; set; }

        [XmlElement("OfficePassword")]
        public string OfficePassword { get; set; }
    }
}
