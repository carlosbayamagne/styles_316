﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class ExternalSubscriberLoadRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("Subscriber")]
        public ExternalSubscriberLoadRequest Subscriber { get; set; }
    }
    public class ExternalSubscriberLoadRequest
    {
        public string PartnerNumber { get; set; }

        public string Type { get; set; }

        public string ProductType { get; set; }

        public string SSN { get; set; }

        public string DOB { get; set; }

        public string FirstName { get; set; }

        public string MiddleInitial { get; set; }

        public string LastName { get; set; }

        public string Address1 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        public string EmailAddress { get; set; }

        public string DisclosureDateTime { get; set; }

        [XmlElement("NotificationPreference")]
        public NotificationPreferenceExternal NotificationPreference { get; set; }
    }

    public class NotificationPreferenceExternal
    {

        [XmlElement("Offline")]
        public string Offline { get; set; }

        [XmlElement("Email")]
        public string Email { get; set; }

        [XmlElement("SVA")]
        public string SVA { get; set; }

        [XmlElement("Text")]
        public string Text { get; set; }
    }
}
