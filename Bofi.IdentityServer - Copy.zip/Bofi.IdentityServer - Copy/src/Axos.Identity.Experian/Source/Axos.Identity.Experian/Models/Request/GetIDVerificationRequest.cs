﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class GetIDVerificationRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public GetIDVerificationRequest SubscriberData { get; set; }

        public string JavascriptCollectorPayload { get; set; }

        [XmlElement("Headers")]
        public Headers Headers { get; set; }

        [XmlElement("Cookies")]
        public Cookies Cookies { get; set; }

        public string RemoteIpAddress { get; set; }

        public string ServerTimeStamp { get; set; }
    }

    public class GetIDVerificationRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string SSN { get; set; }

        public string FirstName { get; set; }

        public string MiddleInitial { get; set; }

        public string LastName { get; set; }

        public string Generation { get; set; }

        public string EmailAddress { get; set; }

        public string Address1 { get; set; }

        public string DOB { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        [XmlElement("CreditCard")]
        public CreditCard CreditCard { get; set; }

        public string DisclosureDateTime { get; set; }
    }

    public class Headers
    {
        [XmlArray("Headers")]
        [XmlArrayItem("Header")]
        public CookieHeaderElement[] HeadersArray { get; set; }
    }

    public class Cookies
    {
        [XmlArray("Cookies")]
        [XmlArrayItem("Cookie")]
        public CookieHeaderElement[] CookiesArray { get; set; }
    }

    public class CookieHeaderElement
    {
        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("Value")]
        public string Value { get; set; }
    }
}
