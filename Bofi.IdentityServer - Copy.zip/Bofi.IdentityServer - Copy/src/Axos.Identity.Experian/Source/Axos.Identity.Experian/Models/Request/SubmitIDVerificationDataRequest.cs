﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class SubmitIDVerificationDataRequestWrapper
    {
        [XmlElement(ElementName = "OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement(ElementName = "SubscriberData")]
        public SubmitIDVerificationDataRequest SubscriberData { get; set; }
    }

    public class SubmitIDVerificationDataRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string ApplicantChallengeId { get; set; }

        [XmlElement("QuestionData")]
        public List<QuestionData> QuestionDataArray { get; set; }

        public string NewSubThankYouEmailRequired { get; set; }
    }

    public class QuestionData
    {
        [Required]
        public string QuestionNumber { get; set; }
        
        [Required]
        public string AnswerNumber { get; set; }

        [Required]
        public string QuestionId { get; set; }

        [Required]
        public string AnswerChoiceId { get; set; }
    }
}
