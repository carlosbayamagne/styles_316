﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Request.Details
{
    public class CreditCard
    {
        public string CardType { get; set; }

        public string AccountNumber { get; set; }

        public string CardExpiration { get; set; }

        public string SecurityCode { get; set; }

        public string BillAddrSame { get; set; }

        public string BillFirstName { get; set; }

        public string BillLastName { get; set; }

        public string BillAddr { get; set; }

        public string BillCity { get; set; }

        public string BillState { get; set; }

        public string BillZipCode { get; set; }
    }
}
