﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Experian.Models.Request.Details
{
    public class CreditScoresPropertiesSet
    {
        public string PartnerNumber { get; set; }

        public string OfficeUserID { get; set; }

        public string OfficePassword { get; set; }

        public string EndpointsURL { get; set; }

        public string EnrollmentURL { get; set; }

        public string DirectEnrollmentURL { get; set; }

        public string TokenURL { get; set; }

        public string client_id { get; set; }

        public string client_secret { get; set; }

        public string SRTN_client_id { get; set; }

        public string SRTN_client_secret { get; set; }

        public string SRTN_PartnerNumber { get; set; }
    }
}
