﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Axos.Identity.Experian.Models.Request
{
    public class VerificationData
    {
        [Required]
        public string ApplicantChallengeId { get; set; }


        [Required]
        public List<QuestionData> QuestionDataArray { get; set; }
    }
}
