﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class SOADeleteRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public SOADeleteRequest SubscriberData { get; set; }
    }

    public class SOADeleteRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }
    }
}
