﻿using Axos.Identity.Experian.Models.Request.Details;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class OrderCreditReportDataRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public OrderCreditReportDataRequest SubscriberData { get; set; }
    }

    public class OrderCreditReportDataRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string CreditReportTypeNumber { get; set; }

        public string CouponCode { get; set; }

        [XmlElement("CreditCard")]
        public CreditCard CreditCard { get; set; }

        public string DisclosureDateTime { get; set; }

        public string OutputType { get; set; }
    }

}
