﻿using Axos.Identity.Experian.Models.Request.Details;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    [XmlRoot("CSIAPIRequest")]
    public class CreditReportDataRequestWrapper
    {
        [XmlElement("OfficeData")]
        public OfficeData OfficeData { get; set; }

        [XmlElement("SubscriberData")]
        public CreditReportDataRequest SubscriberData { get; set; }
    }

    public class CreditReportDataRequest
    {
        public string PartnerNumber { get; set; }

        public string SubscriberNumber { get; set; }

        public string ProductID { get; set; }

        public string OutputType { get; set; }
    }
}
