﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.Request
{
    public static class ExperianFinalRequest
    {
        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/NetConnect")]
        [XmlRoot(Namespace = "http://www.experian.com/NetConnect", IsNullable = false)]
        public class NetConnectRequest
        {
            /// <remarks />
            public string EAI { get; set; }

            /// <remarks />
            public string DBHost { get; set; }

            /// <remarks />
            public string ReferenceId { get; set; }

            /// <remarks />
            [XmlElement(Namespace = "http://www.experian.com/WebDelivery")]
            public Request Request { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        [XmlRoot(Namespace = "http://www.experian.com/WebDelivery", IsNullable = false)]
        public class Request
        {
            /// <remarks />
            public RequestProducts Products { get; set; }

            /// <remarks />
            [XmlAttribute]
            public decimal version { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProducts
        {
            /// <remarks />
            public RequestProductsPreciseIDServer PreciseIDServer { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServer
        {
            /// <remarks />
            public decimal XMLVersion { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerKBAAnswers KBAAnswers { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerKBAAnswers
        {
            /// <remarks />
            public RequestProductsPreciseIDServerKBAAnswersOutWalletAnswerData OutWalletAnswerData { get; set; }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerKBAAnswersOutWalletAnswerData
        {
            /// <remarks />
            public string SessionID { get; set; }

            /// <remarks />
            public RequestProductsPreciseIDServerKBAAnswersOutWalletAnswerDataOutWalletAnswers OutWalletAnswers
            {
                get;
                set;
            }
        }

        /// <remarks />
        [XmlType(AnonymousType = true, Namespace = "http://www.experian.com/WebDelivery")]
        public class RequestProductsPreciseIDServerKBAAnswersOutWalletAnswerDataOutWalletAnswers
        {
            /// <remarks />
            public byte OutWalletAnswer1 { get; set; }

            /// <remarks />
            public byte OutWalletAnswer2 { get; set; }

            /// <remarks />
            public byte OutWalletAnswer3 { get; set; }

            /// <remarks />
            public byte OutWalletAnswer4 { get; set; }

            /// <remarks />
            public byte OutWalletAnswer5 { get; set; }
        }
    }
}
