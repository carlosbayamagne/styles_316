﻿using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.NetConnect
{
    [XmlRoot("NetConnectResponse", Namespace = "http://www.experian.com/NetConnectResponse")]
    public class ResponseModel
    {
        public string CompletionCode { get; set; }
        public string ErrorMessage { get; set; }
        [XmlElement("Products", Namespace = "http://www.experian.com/ARFResponse")]
        public ProductsResponse Products { get; set; }
        public string ReferenceId { get; set; }
        public string TransactionId { get; set; }

        public bool IsServiceError()
        {
            return !string.IsNullOrWhiteSpace(Products.CreditProfile.Error?.ErrorDescription);
        }

        public string GetErrorMessage()
        {
            if (!string.IsNullOrWhiteSpace(Products.CreditProfile.Error.ErrorDescription))
                return Products.CreditProfile.Error.ErrorDescription;
            return ErrorMessage;
        }

        public ResponseModel()
        {
            Products = new ProductsResponse();
        }
    }
}
