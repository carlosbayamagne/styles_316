﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Axos.Identity.Experian.Models.NetConnect
{
    public class ProductsResponse
    {
        [XmlElement("CreditProfile")]
        public ResponseCreditProfile CreditProfile { get; set; }

        public ProductsResponse()
        {
            CreditProfile = new ResponseCreditProfile();
        }
    }

    public class ResponseCreditProfile : CreditProfile
    {
        [XmlElement("RiskModel")]
        public List<RiskModel> RiskModels { get; set; }

        [XmlElement("InformationalMessage")]
        public List<InformationalMessage> InformationalMessages { get; set; }

        public ResponseCreditProfile() : base()
        {
            RiskModels = new List<RiskModel>();
            InformationalMessages = new List<InformationalMessage>();
        }
    }


    public class RiskModel
    {
        public string Score { get; set; }
        public string ScoreFactorCodeOne { get; set; }
        public string ScoreFactorCodeTwo { get; set; }
        public string ScoreFactorCodeThree { get; set; }
        public string ScoreFactorCodeFour { get; set; }
        public ModelIndicator ModelIndicator { get; set; }
        public Evaluation Evaluation { get; set; }

        public RiskModel()
        {
            ModelIndicator = new ModelIndicator();
            Evaluation = new Evaluation();
        }

    }

    public class ModelIndicator
    {
        [XmlAttribute("code")]
        public string Code { get; set; }
    }

    public class Evaluation
    {
        [XmlAttribute("code")]
        public string Code { get; set; }
    }

    public class InformationalMessage
    {
        public string MessageNumber { get; set; }
        public string MessageText { get; set; }
    }
}
