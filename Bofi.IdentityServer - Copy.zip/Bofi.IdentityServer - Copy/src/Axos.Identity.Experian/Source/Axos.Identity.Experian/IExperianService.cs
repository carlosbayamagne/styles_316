﻿using Axos.Identity.Experian.Models;
using System.Threading.Tasks;
using ExperianResponse = Axos.Integration.Common.Models.ServiceResult<Axos.Identity.Experian.Models.PreciseId.ResponseModel>;

namespace Axos.Identity.Experian.Services
{
    public interface IExperianService
    {
        Task<ExperianResponse> RequestIdv(PersonalInformation pip);       

        Task<ExperianResponse> GetIdaQuestions(PersonalInformation pip);

        Task<ExperianResponse> SendIdaAnswers(SendIdaAnswersRequest request);
    }
}
