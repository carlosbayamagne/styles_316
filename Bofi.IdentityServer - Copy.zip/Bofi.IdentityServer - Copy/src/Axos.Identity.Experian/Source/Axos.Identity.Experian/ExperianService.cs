﻿using Axos.Identity.Experian.Models;
using Axos.Identity.Experian.Models.PreciseId;
using Axos.Integration.Common.Enums;
using Axos.Integration.Common.Exceptions;
using Axos.Integration.Common.Models;
using Axos.Integration.Common.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ExperianResponse = Axos.Integration.Common.Models.ServiceResult<Axos.Identity.Experian.Models.PreciseId.ResponseModel>;
using PreciseIdRequest = Axos.Identity.Experian.Models.PreciseId.RequestModel;

namespace Axos.Identity.Experian.Services
{
    public class ExperianService : HttpService, IExperianService
    {
        private readonly IPropertyService _propertyService;

        public ExperianService(IPropertyService propertyService): base(new XmlExperianSerializer())
        {
            _propertyService = propertyService;
        }

        public ExperianService(string environment)
            : base(new XmlExperianSerializer())
        {            
            _propertyService = new PropertyService(environment, "Experian");
        }

        #region Private Methods
        private CredentialsInfo GetCredentialsInfo()
        {
            var username = _propertyService.UserName;
            var password = _propertyService.Password;
            return new CredentialsInfo(username, password, CredentialsType.Basic);
        }

        private Dictionary<string, string> GetEncodedCredentials(CredentialsInfo credentials)
        {
            string userIdFormatted = $"{credentials.UserName}:{credentials.Password}";
            var pairValue = new Dictionary<string, string>();
            pairValue.Add("Authorization", "Basic " + ConvertToBase64String(userIdFormatted));
            return pairValue;
        }        

        private string ConvertToBase64String(string input)
        {
            //Encoding is in the System.Text Namespace
            byte[] info = Encoding.ASCII.GetBytes(input);
            //Convert the binary input into base 64 UUEncode output.
            //Each 3 byte sequence in the source data becomes a 4 byte
            //sequence in the character array.
            long dataLength = (long)((4.0d / 3.0d) * info.Length);
            //if length is not divisible by 4, go up to the next multiple of 4.
            if (dataLength % 4 != 0)
                dataLength += 4 - dataLength % 4;
            //Allocate the output buffer
            char[] base64CharArray = new char[dataLength];
            //converting.... (Convert is in the system namespace)
            Convert.ToBase64CharArray(info, 0, info.Length, base64CharArray, 0);
            //display the converted data
            return new string(base64CharArray);
        }
        #endregion

        #region Public Methods        

        public async Task<ExperianResponse> RequestIdv(PersonalInformation pip)
        {
            ExperianResponse serviceResult = null;
            try
            {
                var credentialsInfo = GetCredentialsInfo();
                var requestModel = pip.CreateIDVRequestModel(_propertyService);
                var headers = GetEncodedCredentials(credentialsInfo);
                serviceResult = await Post<PreciseIdRequest, ResponseModel>(_propertyService.Uri, requestModel, ContentType.Xml, headers);

                return ExperianResponse.Ok(serviceResult.Value, serviceResult.Request, serviceResult.Response);
            }
            catch (RulesEngineException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw RulesEngineException.UnhandledError(ex, serviceResult?.Request, serviceResult?.Response);
            }
        }

        public async Task<ExperianResponse> GetIdaQuestions(PersonalInformation pip)
        {
            ExperianResponse serviceResult = null;

            try
            {
                var credentialsInfo = GetCredentialsInfo();
                var requestModel = pip.CreateIdaQuestionsModel(_propertyService);
                var headers = GetEncodedCredentials(credentialsInfo);
                serviceResult = await Post<PreciseIdRequest, ResponseModel>(_propertyService.Uri, requestModel, ContentType.Xml, headers);

                return ExperianResponse.Ok(serviceResult.Value, serviceResult.Request, serviceResult.Response);
            }
            catch (RulesEngineException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw RulesEngineException.UnhandledError(ex, serviceResult?.Request, serviceResult?.Response);
            }

        }

        public async Task<ExperianResponse> SendIdaAnswers(SendIdaAnswersRequest request)
        {
            ExperianResponse serviceResult = null;
            try
            {
                var credentialsInfo = GetCredentialsInfo();
                var idaRequestModel = ModelExtensions.CreateIdaAnswersModel(request.SessionId, request.Reference, request.Answers, _propertyService);
                var headers = GetEncodedCredentials(credentialsInfo);

                serviceResult = await Post<PreciseIdRequest, ResponseModel>(_propertyService.Uri, idaRequestModel, ContentType.Xml, headers);

                return ExperianResponse.Ok(serviceResult.Value, serviceResult.Request, serviceResult.Response);
            }
            catch (RulesEngineException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw RulesEngineException.UnhandledError(ex, serviceResult?.Request, serviceResult?.Response);
            }
        }

        #endregion
    }
}
