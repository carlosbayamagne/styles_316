﻿
namespace Axos.Identity.Models.Enums
{
    public enum PreloadUserStatus
    {
        NoPreload,
        AddInIdentity,
        AddInOlbFailed,
        AddAccountsFailed,
        Preload,
        AddInCAFailed,
        Complete,
    }
}
