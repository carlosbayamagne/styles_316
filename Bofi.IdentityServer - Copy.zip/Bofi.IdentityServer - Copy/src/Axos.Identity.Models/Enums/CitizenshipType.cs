﻿namespace Axos.Identity.Models.Enums
{
    public enum CitizenshipType
    {
        USCitizen = 1,
        ResidentAlien = 2
    }
}