﻿namespace Axos.Identity.Models.Enums
{
    public enum AdminUserStatus
    {
        Active,
        Suspended,
        Closed
    }
}