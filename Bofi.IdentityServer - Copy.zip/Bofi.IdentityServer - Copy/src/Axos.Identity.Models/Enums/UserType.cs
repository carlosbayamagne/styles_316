﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Models.Enums
{
    public enum UserType
    {
        Advisor = 0,
        Consumer = 1,
        Business = 2,
        InternalService = 4
    }
}
