﻿using System.ComponentModel;

namespace Axos.Identity.Models.Enums
{
    public enum UserStatus
    {
        INITIAL,
        ACTIVE,
        INACTIVE,
        CLOSED
    }
}
