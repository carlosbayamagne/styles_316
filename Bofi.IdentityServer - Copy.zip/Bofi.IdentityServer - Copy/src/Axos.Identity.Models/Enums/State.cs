﻿using System.ComponentModel;

namespace Axos.Identity.Models.Enums
{
    public enum State
    {
        /// <summary>
        /// AMERICAN FORCES AMERICAS
        /// </summary>
        [Description("AMERICAN FORCES AMERICAS")]
        AA = 1,
        /// <summary>
        /// AMERICAN FORCES EUROPE
        /// </summary>
        [Description("AMERICAN FORCES EUROPE")]
        AE,
        /// <summary>
        /// ALASKA
        /// </summary>
        [Description("ALASKA")]
        AK,
        /// <summary>
        /// ALABAMA
        /// </summary>
        [Description("ALABAMA")]
        AL,
        /// <summary>
        /// AMERICAN FORCES PACIFIC
        /// </summary>
        [Description("AMERICAN FORCES PACIFIC")]
        AP,
        /// <summary>
        /// ARKANSAS
        /// </summary>
        [Description("ARKANSAS")]
        AR,
        /// <summary>
        /// AMERICAN SAMOA
        /// </summary>
        [Description("AMERICAN SAMOA")]
        AS,
        /// <summary>
        /// ARIZONA
        /// </summary>
        [Description("ARIZONA")]
        AZ,
        /// <summary>
        /// CALIFORNIA
        /// </summary>
        [Description("CALIFORNIA")]
        CA,
        /// <summary>
        /// COLORADO
        /// </summary>
        [Description("COLORADO")]
        CO,
        /// <summary>
        /// CONNECTICUT
        /// </summary>
        [Description("CONNECTICUT")]
        CT,
        /// <summary>
        /// DISTRICT OF COLUMBIA
        /// </summary>
        [Description("DISTRICT OF COLUMBIA")]
        DC,
        /// <summary>
        /// DELAWARE
        /// </summary>
        [Description("DELAWARE")]
        DE,
        /// <summary>
        /// FLORIDA
        /// </summary>
        [Description("FLORIDA")]
        FL,
        /// <summary>
        /// FEDERATED STATES OF MICRONESIA
        /// </summary>
        [Description("FEDERATED STATES OF MICRONESIA")]
        FM,
        /// <summary>
        /// GEORGIA
        /// </summary>
        [Description("GEORGIA")]
        GA,
        /// <summary>
        /// GUAM GU
        /// </summary>
        [Description("GUAM GU")]
        GU,
        /// <summary>
        /// HAWAII
        /// </summary>
        [Description("HAWAII")]
        HI,
        /// <summary>
        /// IOWA
        /// </summary>
        [Description("IOWA")]
        IA,
        /// <summary>
        /// IDAHO
        /// </summary>
        [Description("IDAHO")]
        ID,
        /// <summary>
        /// ILLINOIS
        /// </summary>
        [Description("ILLINOIS")]
        IL,
        /// <summary>
        /// INDIANA
        /// </summary>
        [Description("INDIANA")]
        IN,
        /// <summary>
        /// KANSAS
        /// </summary>
        [Description("KANSAS")]
        KS,
        /// <summary>
        /// KENTUCKY
        /// </summary>
        [Description("KENTUCKY")]
        KY,
        /// <summary>
        /// LOUISIANA
        /// </summary>
        [Description("LOUISIANA")]
        LA,
        /// <summary>
        /// MASSACHUSETTS
        /// </summary>
        [Description("MASSACHUSETTS")]
        MA,
        /// <summary>
        /// MARYLAND
        /// </summary>
        [Description("MARYLAND")]
        MD,
        /// <summary>
        /// MAINE
        /// </summary>
        [Description("MAINE")]
        ME,
        /// <summary>
        /// MARSHALL ISLANDS
        /// </summary>
        [Description("MARSHALL ISLANDS")]
        MH,
        /// <summary>
        /// MICHIGAN
        /// </summary>
        [Description("MICHIGAN")]
        MI,
        /// <summary>
        /// MINNESOTA
        /// </summary>
        [Description("MINNESOTA")]
        MN,
        /// <summary>
        /// MISSOURI
        /// </summary>
        [Description("MISSOURI")]
        MO,
        /// <summary>
        /// NORTHERN MARIANA ISLANDS
        /// </summary>
        [Description("NORTHERN MARIANA ISLANDS")]
        MP,
        /// <summary>
        /// MISSISSIPPI
        /// </summary>
        [Description("MISSISSIPPI")]
        MS,
        /// <summary>
        /// MONTANA
        /// </summary>
        [Description("MONTANA")]
        MT,
        /// <summary>
        /// NORTH CAROLINA
        /// </summary>
        [Description("NORTH CAROLINA")]
        NC,
        /// <summary>
        /// NORTH DAKOTA
        /// </summary>
        [Description("NORTH DAKOTA")]
        ND,
        /// <summary>
        /// NEBRASKA
        /// </summary>
        [Description("NEBRASKA")]
        NE,
        /// <summary>
        /// NEW HAMPSHIRE
        /// </summary>
        [Description("NEW HAMPSHIRE")]
        NH,
        /// <summary>
        /// NEW JERSEY
        /// </summary>
        [Description("NEW JERSEY")]
        NJ,
        /// <summary>
        /// NEW MEXICO
        /// </summary>
        [Description("NEW MEXICO")]
        NM,
        /// <summary>
        /// NEVADA
        /// </summary>
        [Description("NEVADA")]
        NV,
        /// <summary>
        /// NEW YORK
        /// </summary>
        [Description("NEW YORK")]
        NY,
        /// <summary>
        /// OHIO
        /// </summary>
        [Description("OHIO")]
        OH,
        /// <summary>
        /// OKLAHOMA
        /// </summary>
        [Description("OKLAHOMA")]
        OK,
        /// <summary>
        /// OREGON
        /// </summary>
        [Description("OREGON")]
        OR,
        /// <summary>
        /// PENNSYLVANIA
        /// </summary>
        [Description("PENNSYLVANIA")]
        PA,
        /// <summary>
        /// PUERTO RICO
        /// </summary>
        [Description("PUERTO RICO")]
        PR,
        /// <summary>
        /// PALAU
        /// </summary>
        [Description("PALAU")]
        PW,
        /// <summary>
        /// RHODE ISLAND
        /// </summary>
        [Description("RHODE ISLAND")]
        RI,
        /// <summary>
        /// SOUTH CAROLINA
        /// </summary>
        [Description("SOUTH CAROLINA")]
        SC,
        /// <summary>
        /// SOUTH DAKOTA
        /// </summary>
        [Description("SOUTH DAKOTA")]
        SD,
        /// <summary>
        /// TENNESSEE
        /// </summary>
        [Description("TENNESSEE")]
        TN,
        /// <summary>
        /// TEXAS
        /// </summary>
        [Description("TEXAS")]
        TX,
        /// <summary>
        /// UTAH
        /// </summary>
        [Description("UTAH")]
        UT,
        /// <summary>
        /// VIRGINIA
        /// </summary>
        [Description("VIRGINIA")]
        VA,
        /// <summary>
        /// VIRGIN ISLANDS
        /// </summary>
        [Description("VIRGIN ISLANDS")]
        VI,
        /// <summary>
        /// VERMONT
        /// </summary>
        [Description("VERMONT")]
        VT,
        /// <summary>
        /// WASHINGTON
        /// </summary>
        [Description("WASHINGTON")]
        WA,
        /// <summary>
        /// WISCONSIN
        /// </summary>
        [Description("WISCONSIN")]
        WI,
        /// <summary>
        /// WEST VIRGINIA
        /// </summary>
        [Description("WEST VIRGINIA")]
        WV,
        /// <summary>
        /// WYOMING
        /// </summary>
        [Description("WYOMING")]
        WY
    }
}
