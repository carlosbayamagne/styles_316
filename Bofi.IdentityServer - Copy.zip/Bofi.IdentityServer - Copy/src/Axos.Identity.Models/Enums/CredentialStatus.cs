﻿namespace Axos.Identity.Models.Enums
{
    public enum CredentialStatus
    {
        /// <summary>
        /// Value not found as valid Status
        /// </summary>
        Undefined = 0,

        /// <summary>
        /// The credential is active and can be used for authentication
        /// </summary>
        Active = 1,

        /// <summary>
        /// The credential is locked when the user consecutively fails to
        ///authenticate for the maximum number of negative attempts
        ///configured. For example if the maximum attempts configured
        ///is 3, then the third attempt with wrong credential will lock
        ///the credential.
        /// </summary>
        Locked = 2,

        /// <summary>
        /// The credential is disabled by the administrator
        /// </summary>
        Disabled = 3,

        /// <summary>
        /// The credential of the user is deleted from the database.
        /// </summary>
        Deleted = 4,

        /// <summary>
        /// The credential of the user has expired.
        /// </summary>
        Expired = 5,

        /// <summary>
        /// The credential is verified when the OTP submitted by the
        ///user is authenticated by AuthMinder Server successfully.
        /// </summary>
        Verified = 50
    }
}