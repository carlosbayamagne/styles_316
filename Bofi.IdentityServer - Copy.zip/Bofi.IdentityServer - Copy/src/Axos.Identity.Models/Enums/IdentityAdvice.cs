﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Models.Enums
{
    public enum IdentityAdvice
    {
        Allow,
        Alert,
        IncreaseSecurity,
        Deny
    }
}
