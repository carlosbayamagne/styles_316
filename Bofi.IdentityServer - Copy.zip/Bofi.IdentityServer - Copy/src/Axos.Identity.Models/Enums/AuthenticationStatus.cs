﻿using System;

namespace Axos.Identity.Models.Enums
{
    public enum AuthenticationStatus
    {
        [Obsolete("Use equivalent status (Active)")]
        Success = 0,

        UserNotFound = 1,

        [Obsolete("Use equivalent status (Inactive)")]
        Suspended = 2,

        Closed = 3,
        InvalidCredentials = 4,
        LockedAccount = 5,
        Inactive = 6,
        NotAllowed = 7,
        ResetPassword = 8,
        Allow = 9,
        Challenge = 10
    }
}