﻿namespace Axos.Identity.Models.Enums
{
    public enum GenderType
    {
        Male = 1,
        Female = 2
    }
}