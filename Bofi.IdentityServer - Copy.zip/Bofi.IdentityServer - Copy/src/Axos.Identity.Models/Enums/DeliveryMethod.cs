﻿namespace Axos.Identity.Models.Enums
{
    public enum DeliveryMethod
    {
        None = 0,
        SMS = 1,
        Email = 2,
        Voice = 4,
        Push = 8
    }
}