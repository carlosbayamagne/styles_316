﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Models.Enums
{
    public enum ServiceName
    {
        BankingCore = 1,
        CA = 2,
        Daon = 3,
        Experian = 4,
        Guardian = 5,
        Marketo = 6,
        MiTek = 7,
        JxChange = 8,
        IntegrationCore = 9,
        Notification = 10,
        Salesforce = 11
    }
}
