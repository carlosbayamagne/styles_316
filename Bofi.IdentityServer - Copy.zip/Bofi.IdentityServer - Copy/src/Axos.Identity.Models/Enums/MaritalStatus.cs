﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Models.Enums
{
    public enum MaritalStatusType
    {
        [Description("Married")]
        M = 1,

        [Description("Reg Domestic Partner")]
        R = 2,

        [Description("Single")]
        S = 3,

        [Description("Unknown")]
        U = 4,

        [Description("Divorced")]
        D = 5,

        [Description("Unmarried")]
        N = 6,

        [Description("Separated")]
        P = 7,

        [Description("Widower")]
        W = 8
    }
}
