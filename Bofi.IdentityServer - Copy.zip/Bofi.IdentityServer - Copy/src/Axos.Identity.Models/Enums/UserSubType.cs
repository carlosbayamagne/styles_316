﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Axos.Identity.Models.Enums
{
    [Flags]
    public enum UserSubType
    {
        RealEstate = 0,
        Enrollment = 1,
        // Organization, Admin, User, APISubscriber belongs to User Type "LargeBusiness"
        Organization = 2,
        Admin = 3,
        User = 4,
        APISubscriber = 5,
        AxosBank = 8,
        AxosInvest = 16,
        AxosTrading = 32,
        AxosFiduciaryServices = 64
    }
}
