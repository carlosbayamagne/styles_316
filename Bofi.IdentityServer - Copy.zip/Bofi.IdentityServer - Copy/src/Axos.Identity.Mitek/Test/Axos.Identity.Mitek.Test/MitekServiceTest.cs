﻿using Axos.Identity.Mitek.Models;
using Axos.Identity.Mitek.Services;
using Axos.Integration.MiTek.Models;
using Newtonsoft.Json;
using System.IO;
using System.Threading.Tasks;
using Xunit;

namespace Axos.Identity.Tests.Mitek
{
    [Trait("Mitek Service", "UnitTest")]
    public class MitekServiceTest 
    {
        [Fact]        
        public async Task MitekService_AuthenticateDocumentsAsync_PassIfIdIsValidated()
        {
            //arrange          
            MitekService mitekService = new MitekService("Development", null);

            string json = File.ReadAllText("MitekPictures.json");
            dynamic pictures = JsonConvert.DeserializeObject<dynamic>(json);                        
           
            var args = new MitekModel();
            args.AddIdDocument(pictures.front.Value, pictures.back.Value);

            //act            
            MiTekServiceResponse validationResult = await mitekService.AuthenticateDocuments(args);

            //assert            
            Assert.True(validationResult.IdIsAuthenticated);            
        }       
    }
}