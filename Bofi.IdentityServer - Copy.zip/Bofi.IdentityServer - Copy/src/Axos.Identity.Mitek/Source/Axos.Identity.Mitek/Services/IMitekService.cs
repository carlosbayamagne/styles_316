﻿
using Axos.Identity.Mitek.Models;
using Axos.Integration.MiTek.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Mitek.Services
{
    public interface IMitekService
    {
        Task<MiTekServiceResponse> ValidateIdAsync(MiTekIdDocument idDocument);
        Task<MiTekServiceResponse> ValidateIdAndSelfieAsync(List<MiTekIdDocument> idDocuments);

        MiTekServiceResponse ValidateId(MiTekIdDocument idDocument);
        MiTekServiceResponse ValidateIdAndSelfie(List<MiTekIdDocument> idDocuments);

        Task<MiTekServiceResponse> AuthenticateDocuments(IMitekModel mitekModel);
    }
}
