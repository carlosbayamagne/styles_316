﻿using Axos.Identity.Mitek.Models;
using Axos.Integration.MiTek.Models;
using Axos.Integration.MiTek.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Axos.Identity.Mitek.Services
{
    public class MitekService : IMitekService
    {
        private readonly MiTekService _service;

        public MitekService(string environment, string callingServiceName, string cwd = null)
        {
            _service = new MiTekService(environment, callingServiceName, cwd);
        }

        #region Async
        public async Task<MiTekServiceResponse> ValidateIdAsync(MiTekIdDocument idDocument)
        {
            string front = idDocument.Front;
            string back = idDocument.Back;
            return await _service.ValidateIdAsync(front, back);
        }

        public async Task<MiTekServiceResponse> ValidateIdAndSelfieAsync(List<MiTekIdDocument> idDocuments)
        {
            string front = null;
            string back = null;
            string selfie = null;
            foreach (MiTekIdDocument mid in idDocuments)
            {
                if (mid.DocumentType == "IdDocument")
                {
                    front = mid.Front;
                    back = mid.Back;
                }
                else if (mid.DocumentType == "Selfie")
                {
                    selfie = mid.Front;
                }
            }
            return await _service.ValidateIdAndSelfieAsync(front, back, selfie);
        }

        public async Task<MiTekServiceResponse> AuthenticateDocuments(IMitekModel mitekModel)
        {
            string front = null;
            string back = null;
            string selfie = null;

            foreach (IdDocument mid in mitekModel.IdDocuments)
            {
                if (mid.DocumentType.Equals("IdDocument", StringComparison.CurrentCultureIgnoreCase))
                {
                    front = mid.Front;
                    back = mid.Back;
                }
                else if (mid.DocumentType.Equals("Selfie", StringComparison.CurrentCultureIgnoreCase))
                {
                    selfie = mid.Front;
                }
            }

            MiTekServiceResponse mitekIntegrationResponse = new MiTekServiceResponse();

            if (selfie is null)
            {
                mitekIntegrationResponse = await _service.ValidateIdAsync(front, back);
            }
            else
            {
                mitekIntegrationResponse = await _service.ValidateIdAndSelfieAsync(front, back, selfie);
            }

            return mitekIntegrationResponse;
        }
        #endregion

        #region Sync
        public MiTekServiceResponse ValidateId(MiTekIdDocument idDocument) => this.ValidateIdAsync(idDocument).Result;

        public MiTekServiceResponse ValidateIdAndSelfie(List<MiTekIdDocument> idDocuments) => this.ValidateIdAndSelfieAsync(idDocuments).Result;
        #endregion
    }
}
