﻿using System.Collections.Generic;

namespace Axos.Identity.Mitek.Models
{
    public class MitekModel : IMitekModel
    {
        public List<IdDocument> IdDocuments { get; }

        public MitekModel()
        {
            IdDocuments = new List<IdDocument>();
        }

        public void AddIdDocument(string front, string back)
        {
            var idDocument = new IdDocument() { Front = front, Back = back, DocumentType = "IdDocument" };
            IdDocuments.Add(idDocument);
        }

        public void AddSelfieDocument(string selfie)
        {
            this.IdDocuments.Add(new IdDocument()
            {
                Front = selfie,
                Back = (string)null,
                DocumentType = "Selfie"
            });
        }
    }
}
