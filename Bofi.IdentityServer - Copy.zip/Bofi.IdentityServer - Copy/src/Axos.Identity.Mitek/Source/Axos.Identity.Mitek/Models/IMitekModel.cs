﻿using System.Collections.Generic;

namespace Axos.Identity.Mitek.Models
{
    public interface IMitekModel
    {
        List<IdDocument> IdDocuments { get; }
        void AddIdDocument(string front, string back);
        void AddSelfieDocument(string selfie);
    }
}
