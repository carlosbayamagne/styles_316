﻿using Axos.Identity.Ekata.Models.Abstractions;
using Newtonsoft.Json;

namespace Axos.Identity.Ekata.Models
{
    public class SecondaryApplicantInformationModel :
    IApplicantInformation,
    IBasicPersonInformation,
    IAddress,
    IPhoneInformation
    {
        [JsonProperty("secondary.name")]
        private string FullName1 { set { FullName = value; } }
        public string FullName { get; set; }
        
        [JsonProperty("secondary.firstname")]
        private string FirstName1 { set{ FirstName = value; } }
        public string FirstName { get; set; }
        
        [JsonProperty("secondary.lastname")]
        private string LastName1 { set{ LastName = value; } }
        public string LastName { get; set; }
        
        [JsonProperty("secondary.address.street_line_1")]
        private string StreetLine11 { set{ StreetLine1 = value; } }
        public string StreetLine1 { get; set; }
        
        [JsonProperty("secondary.address.street_line_2")]
        private string StreetLine21 { set{ StreetLine2 = value; } }
        public string StreetLine2 { get; set; }
        
        [JsonProperty("secondary.address.city")]
        private string City1 { set{ City = value; } }
        public string City { get; set; }
        
        [JsonProperty("secondary.address.postal_code")]
        private string PostalCode1 { set{ PostalCode = value; } }
        public string PostalCode { get; set; }
        
        [JsonProperty("secondary.address.state_code")]
        private string StateCode1 { set{ StateCode = value; } }
        public string StateCode { get; set; }
        
        [JsonProperty("secondary.address.country_code")]
        private Enums.CountryCode? CountryCode1 { set{ CountryCode = value; } }
        public Enums.CountryCode? CountryCode { get; set; } = new Enums.CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        
        [JsonProperty("secondary.phone")]
        private string Phone1 { set{ Phone = value; } }
        public string Phone { get; set; }
        
        [JsonProperty("secondary.phone.country_hint")]
        private Enums.CountryCode? CountryHint1 { set{ CountryHint = value; } }
        public Enums.CountryCode? CountryHint { get; set; } = new Enums.CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        
        [JsonProperty("secondary.email_address")]
        private string EmailAddress1 { set{ EmailAddress = value; } }
        public string EmailAddress { get; set; }
    }
}
