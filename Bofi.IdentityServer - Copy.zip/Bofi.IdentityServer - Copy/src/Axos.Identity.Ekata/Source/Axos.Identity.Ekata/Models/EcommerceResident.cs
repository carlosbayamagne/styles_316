﻿using Newtonsoft.Json;

namespace Axos.Identity.Ekata.Models
{
    public class EcommerceResident
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("age_range")]
        public AgeRange AgeRange { get; set; }
    }
}
