﻿using Axos.Identity.Ekata.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace Axos.Identity.Ekata.Models
{
    public class IpAddressChecksV33
    {
        [JsonProperty("error")]
        public IpAddressCheckErrorV33Enum? Error { get; set; }

        public bool HasError => this.Error.HasValue;

        [JsonProperty("warnings")]
        public IList<string> Warnings { get; set; }

        [JsonProperty("is_valid")]
        public bool? IsValid { get; set; }

        [JsonProperty("proxy_risk")]
        public bool? ProxyRisk { get; set; }

        [JsonProperty("geolocation")]
        public IPGeolocation Geolocation { get; set; }

        [JsonProperty("match_to_primary_name")]
        [JsonConverter(typeof(StringEnumConverter))]
        public NameMappingStatusEnum? AddressMatchToPrimaryName { get; set; }

        [JsonProperty("match_to_secondary_name")]
        [JsonConverter(typeof(StringEnumConverter))]
        public NameMappingStatusEnum? AddressMatchToSecondaryName { get; set; }

        [JsonProperty("distance_from_primary_address")]
        public int? DistancePrimaryAddress { get; set; }

        [JsonProperty("distance_from_secondary_address")]
        public int? DistanceSecondaryAddress { get; set; }

        [JsonProperty("distance_from_primary_phone")]
        public int? DistancePrimaryPhone { get; set; }

        [JsonProperty("distance_from_secondary_phone")]
        public int? DistanceSecondaryPhone { get; set; }
    }
}
