﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Axos.Identity.Ekata.Models.Abstractions
{
    public interface IBasicPersonInformation
    {
        string FullName { get; set; }

        string FirstName { get; set; }

        string LastName { get; set; }

        string EmailAddress { get; set; }
    }
}
