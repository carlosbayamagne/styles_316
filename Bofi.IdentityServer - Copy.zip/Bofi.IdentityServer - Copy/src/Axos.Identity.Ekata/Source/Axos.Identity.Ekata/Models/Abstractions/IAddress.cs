﻿using Axos.Identity.Ekata.Enums;

namespace Axos.Identity.Ekata.Models.Abstractions
{
    public interface IAddress
    {
        string StreetLine1 { get; set; }

        string StreetLine2 { get; set; }

        string City { get; set; }

        string PostalCode { get; set; }

        string StateCode { get; set; }

        CountryCode? CountryCode { get; set; }
    }
}
