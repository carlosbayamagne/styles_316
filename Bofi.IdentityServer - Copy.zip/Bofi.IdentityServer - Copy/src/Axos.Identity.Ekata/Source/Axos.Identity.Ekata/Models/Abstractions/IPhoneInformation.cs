﻿using Axos.Identity.Ekata.Enums;

namespace Axos.Identity.Ekata.Models.Abstractions
{
    public interface IPhoneInformation
    {
        string Phone { get; set; }
        CountryCode? CountryHint { get; set; }
    }
}
