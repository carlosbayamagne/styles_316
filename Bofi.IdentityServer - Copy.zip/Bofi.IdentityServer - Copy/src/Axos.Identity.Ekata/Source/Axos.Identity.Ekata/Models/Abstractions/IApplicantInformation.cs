﻿namespace Axos.Identity.Ekata.Models.Abstractions
{
    public interface IApplicantInformation : IBasicPersonInformation, IAddress, IPhoneInformation
    {
    }
}
