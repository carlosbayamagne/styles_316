﻿using Axos.Identity.Ekata.Enums;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace Axos.Identity.Ekata.Models.Response
{
    public class PhoneChecksV33
    {
        [JsonProperty("error")]
        public PhoneCheckErrorV33Enum? Error { get; set; }

        public bool HasError => this.Error.HasValue;

        [JsonProperty("warnings")]
        public IList<string> Warnings { get; set; }

        [JsonProperty("is_valid")]
        public bool? IsValid { get; set; }

        [JsonProperty("country_code")]
        public string CountryCode { get; set; }

        [JsonProperty("is_commercial")]
        public bool? IsCommercial { get; set; }

        [JsonProperty("line_type")]
        public LineTypeEnum? LineTypeDescription { get; set; }

        [JsonProperty("carrier")]
        public string Carrier { get; set; }

        [JsonProperty("is_prepaid")]
        public bool? IsPrepaid { get; set; }

        [JsonProperty("match_to_name")]
        [JsonConverter(typeof(StringEnumConverter))]
        public NameMappingStatusEnum? PhoneMatchToName { get; set; }

        [JsonProperty("match_to_address")]
        public AddressMatchEnum? PhoneMatchToAddressResult { get; set; }

        [JsonProperty("subscriber")]
        public EcommerceSubscriber Subscriber { get; set; }
    }
}
