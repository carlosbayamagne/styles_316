﻿using Axos.Identity.Ekata.Models.Requests;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace Axos.Identity.Ekata.Models.Response
{
    public class IdentityCheckResponseV33
    {
        [JsonProperty("request")]
        public IdentityCheckRequestV33 Request { get; set; }

        [JsonProperty("primary_phone_checks")]
        public PhoneChecksV33 PrimaryApplicantPhoneChecks { get; set; }

        [JsonProperty("secondary_phone_checks")]
        public PhoneChecksV33 SecondaryApplicantPhoneChecks { get; set; }

        [JsonProperty("primary_address_checks")]
        public AddressChecksV33Primary PrimaryApplicantAddressChecks { get; set; }

        [JsonProperty("secondary_address_checks")]
        public AddressChecksV33Secondary SecondaryApplicantAddressChecks { get; set; }

        [JsonProperty("primary_email_address_checks")]
        public EmailAddressChecksV33 PrimaryApplicantEmailAddressChecks { get; set; }

        [JsonProperty("secondary_email_address_checks")]
        public EmailAddressChecksV33 SecondaryApplicantEmailAddressChecks { get; set; }

        [JsonProperty("ip_address_checks")]
        public IpAddressChecksV33 IpAddressChecks { get; set; }

        [JsonProperty("identity_check_score")]
        public int? IdentityCheckScore { get; set; }

        [JsonProperty("identity_network_score")]
        public double? IdentityNetworkScore { get; set; }

        [OnDeserialized]
        internal void OnDeserializedMethod(StreamingContext context)
        {
            if (this.Request == null || this.Request.AdditionalData == null)
                return;
            this.Request.ApiKey = (string)null;
            string str = JsonConvert.SerializeObject((object)this.Request.AdditionalData);
            this.Request.PrimaryApplicant = JsonConvert.DeserializeObject<PrimaryApplicantInformationModel>(str);
            this.Request.SecondaryApplicant = JsonConvert.DeserializeObject<SecondaryApplicantInformationModel>(str);
        }
    }
}
