﻿using Axos.Identity.Ekata.Converters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;

namespace Axos.Identity.Ekata.Models.Requests
{
    public class IdentityCheckRequestV33
    {
        public string ApiKey { get; set; }

        public string TransactionId { get; set; } = Guid.NewGuid().ToString();
        [JsonProperty("transaction_id")]
        private string TransactionId1 { set { TransactionId = value; } }

        [JsonProperty("transaction_time")]
        private DateTime TransactionTime1 { set { TransactionTime = value; } }
        public DateTime TransactionTime { get; private set; } = DateTime.Now;

        public DateTime TransactionDate
        {
            get => this.TransactionTime.Date;
            set => this.TransactionTime = value;
        }

        [JsonProperty("ip_address")]
        [JsonConverter(typeof(IpConverter))]
        private IPAddress IpAddress1 { set { IpAddress = value; } }
        [JsonConverter(typeof(IpConverter))]
        public IPAddress IpAddress { get; set; }
        public PrimaryApplicantInformationModel PrimaryApplicant { get; set; }
        public SecondaryApplicantInformationModel SecondaryApplicant { get; set; }

        [JsonExtensionData]
        internal IDictionary<string, JToken> AdditionalData { get; set; }
    }
}
