﻿using Axos.Identity.Ekata.Enums;
using Axos.Identity.Ekata.Models.Abstractions;
using Newtonsoft.Json;

namespace Axos.Identity.Ekata.Models
{
    public class PrimaryApplicantInformationModel :
    IApplicantInformation,
    IBasicPersonInformation,
    IAddress,
    IPhoneInformation
    {
        [JsonProperty("primary.name")]
        private string FullName1 { set { FullName = value; } }
        public string FullName { get; set; }

        [JsonProperty("primary.firstname")]
        private string FirstName1 { set { FirstName = value; } }
        public string FirstName { get; set; }

        [JsonProperty("primary.lastname")]
        private string LastName1 { set{ LastName = value; } }
        public string LastName { get; set; }

        [JsonProperty("primary.address.street_line_1")]
        private string StreetLine11 { set{ StreetLine1 = value; } }
        public string StreetLine1 { get; set; }

        [JsonProperty("primary.address.street_line_2")]
        private string StreetLine21 { set{ StreetLine2 = value; } }
        public string StreetLine2 { get; set; }
        
        [JsonProperty("primary.address.city")]
        private string City1 { set{ City = value; } }
        public string City { get; set; }
        
        [JsonProperty("primary.address.postal_code")]
        private string PostalCode1 { set{ PostalCode = value; } }
        public string PostalCode { get; set; }
        
        [JsonProperty("primary.address.state_code")]
        private string StateCode1 { set{ StateCode = value; } }
        public string StateCode { get; set; }
        
        [JsonProperty("primary.address.country_code")]
        private CountryCode? CountryCode1 { set { CountryCode = value; } }
        public CountryCode? CountryCode { get; set; } = new CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        
        [JsonProperty("primary.phone")]
        private string Phone1 { set{ Phone = value; } }
        public string Phone { get; set; }
        
        [JsonProperty("primary.phone.country_hint")]
        private CountryCode? CountryHint1 { set { CountryHint = value; } }
        public CountryCode? CountryHint { get; set; } = new CountryCode?(Enums.CountryCode.UnitedStatesofAmerica);
        
        [JsonProperty("primary.email_address")]
        private string EmailAddress1 { set{ EmailAddress = value; } }
        public string EmailAddress { get; set; }
    }
}
