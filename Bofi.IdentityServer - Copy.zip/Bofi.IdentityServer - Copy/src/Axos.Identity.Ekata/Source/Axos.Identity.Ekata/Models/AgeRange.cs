﻿using Newtonsoft.Json;

namespace Axos.Identity.Ekata.Models
{
    public class AgeRange
    {
        [JsonProperty("from")]
        public int From { get; set; }

        [JsonProperty("to")]
        public int? To { get; set; }
    }
}
