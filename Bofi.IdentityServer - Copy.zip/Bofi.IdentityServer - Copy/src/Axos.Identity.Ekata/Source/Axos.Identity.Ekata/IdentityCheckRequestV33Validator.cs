﻿using Axos.Identity.Ekata.Models.Requests;
using FluentValidation;

namespace Axos.Identity.Ekata
{
    public class IdentityCheckRequestV33Validator : AbstractValidator<IdentityCheckRequestV33>
    {
        public IdentityCheckRequestV33Validator()
        {

            RuleFor(request => request)
                .Must(request =>
                {
                    var validInputsCount = 0;

                    if (request.IpAddress != null)
                    {
                        validInputsCount++;
                    }

                    if (request.PrimaryApplicant != null)
                    {
                        var currentValidInputs = validInputsCount;
                        foreach (var item in request.PrimaryApplicant.GetType().GetProperties())
                        {
                            if (item != null && item.GetValue(request.PrimaryApplicant, null) != null)
                            {
                                currentValidInputs++;
                            }
                            if (currentValidInputs > 1)
                            {
                                return true;
                            }
                        }
                    }

                    if (request.SecondaryApplicant != null)
                    {
                        var currentValidInputs = validInputsCount;

                        foreach (var item in request.SecondaryApplicant.GetType().GetProperties())
                        {
                            if (item != null && item.GetValue(request.SecondaryApplicant, null) != null)
                            {
                                currentValidInputs++;
                            }
                            if (currentValidInputs > 1)
                            {
                                return true;
                            }
                        }
                    }

                    return false;
                })
                .WithErrorCode("To perform an Identity Check, we need at least two inputs from the following: " +
                "Name(primary or secondary)." +
                "Phone(primary or secondary)." +
                "Address(primary or secondary)." +
                "Email Address(primary or secondary)." +
                "IP Address.");
            RuleFor(x => x.TransactionId).NotNull();
            RuleFor(x => x.TransactionTime).NotNull();
            RuleFor(app => app.PrimaryApplicant.EmailAddress)
                .EmailAddress()
                .When(app => app.PrimaryApplicant != null);
            RuleFor(app => app.SecondaryApplicant.EmailAddress)
                .EmailAddress()
                .When(app => app.SecondaryApplicant != null);
            RuleFor(app => app.PrimaryApplicant.Phone)
                .Matches("^\\+?[\\d-]*(x\\d*)?")
                .When(app => app.PrimaryApplicant != null);
        }
    }
}
