﻿using Axos.Identity.Client.Http;
using Axos.Identity.Ekata.Models.Requests;
using Axos.Identity.Ekata.Models.Response;
using Axos.Integration.Core;
using Axos.Integration.Core.Extensions;

using FluentValidation;

using Microsoft.AspNetCore.WebUtilities;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Axos.Identity.Ekata
{
    public class EkataService : IEkataService
    {

        private readonly HttpClient _httpClient;
        private readonly IValidator<IdentityCheckRequestV33> _validator;
        private readonly string _environment;
        private readonly IServiceConfig _serviceConfig;
        readonly ApiClientHttpTools serviceHttpTools = null;
        private readonly string _apiKey;

        public EkataService(string environment)
        {
            _validator = new IdentityCheckRequestV33Validator();
            _environment = environment;

            _serviceConfig = new ServiceConfig(_environment, "Ekata");

            serviceHttpTools = new ApiClientHttpTools(_serviceConfig.Settings["baseUrl"]);

            _httpClient = serviceHttpTools.Client;

            _apiKey = _serviceConfig.Settings["apiKey"];
        }


        public async Task<IdentityCheckResponseV33> PerformIdentityCheckAsync(IdentityCheckRequestV33 identityCheckRequest, bool useTestConfig = false)
        {
            var validationResult = (await _validator.ValidateAsync(identityCheckRequest));
            if (!validationResult.IsValid)
            {
                throw new InvalidOperationException(string.Join("\n",
                    validationResult.Errors.Select(error => error.ErrorMessage)));
            }

            if (_environment == "Production" && !Guid.TryParse(identityCheckRequest.TransactionId, out _))
            {
                throw new InvalidOperationException("TransactionId it's not a valid GUID");
            }

            var url = CreateIdentityCheckUrl(identityCheckRequest,useTestConfig);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",
                (useTestConfig && _environment != "Production") ? identityCheckRequest.ApiKey : _apiKey);

            var response = (await _httpClient.GetAsync(url)).EnsureSuccessStatusCode();

            return await response.Content.ReadAsAsync<IdentityCheckResponseV33>();
        }
        public IdentityCheckResponseV33 PerformIdentityCheck(IdentityCheckRequestV33 identityCheckRequest, bool useTestConfig = false)
        {
            var validationResult = (_validator.Validate(identityCheckRequest));
            if (!validationResult.IsValid)
            {
                throw new InvalidOperationException(string.Join("\n",
                    validationResult.Errors.Select(error => error.ErrorMessage)));
            }

            if (_environment == "Production" && !Guid.TryParse(identityCheckRequest.TransactionId, out _))
            {
                throw new InvalidOperationException("TransactionId it's not a valid GUID");
            }

            var url = CreateIdentityCheckUrl(identityCheckRequest,useTestConfig);

            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",
                (useTestConfig && _environment != "Production") ? identityCheckRequest.ApiKey : _apiKey);

            var response = _httpClient.GetAsync(url).Result.EnsureSuccessStatusCode();

            return response.Content.ReadAsAsync<IdentityCheckResponseV33>().Result;
        }

        static string FormatIPAddress(IPAddress ipAddress)
        {
            var segments = ipAddress.ToString().Split('.');
            return string.Join(".", Array.ConvertAll(segments, s => int.Parse(s).ToString("D3")));
        }

        private string CreateIdentityCheckUrl(IdentityCheckRequestV33 identityCheckRequest, bool useTestConfig)
        {

            var url = QueryHelpers.AddQueryString(_serviceConfig.Settings["identityCheckUrl"],
                    new Dictionary<string, string>
                    {
                        { "transaction_id", identityCheckRequest.TransactionId.ToString() },
                        { "transaction_time", identityCheckRequest.TransactionTime.ToString("yyyy-MM-dd HH:mm") },
                        { "transaction_date", identityCheckRequest.TransactionDate.ToString("yyyy-MM-dd") },
                    }
                );

            if (identityCheckRequest.IpAddress != null)
            {
                url = QueryHelpers.AddQueryString(url, "ip_address",useTestConfig? FormatIPAddress(identityCheckRequest.IpAddress) : identityCheckRequest.IpAddress.ToString());
            }

            if (identityCheckRequest.PrimaryApplicant != null)
            {
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.FullName))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.name", identityCheckRequest.PrimaryApplicant.FullName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.FirstName))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.firstname", identityCheckRequest.PrimaryApplicant.FirstName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.LastName))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.lastname", identityCheckRequest.PrimaryApplicant.LastName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.StreetLine1))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.street_line_1", identityCheckRequest.PrimaryApplicant.StreetLine1);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.StreetLine2))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.street_line_2", identityCheckRequest.PrimaryApplicant.StreetLine2);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.City))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.city", identityCheckRequest.PrimaryApplicant.City);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.PostalCode))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.postal_code", identityCheckRequest.PrimaryApplicant.PostalCode);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.StateCode))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.state_code", identityCheckRequest.PrimaryApplicant.StateCode);
                }
                if (identityCheckRequest.PrimaryApplicant.CountryCode.HasValue)
                {
                    url = QueryHelpers.AddQueryString(url, "primary.address.country_code", identityCheckRequest.PrimaryApplicant.CountryCode.Value.GetDescription());
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.Phone))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.phone", identityCheckRequest.PrimaryApplicant.Phone);
                }
                if (identityCheckRequest.PrimaryApplicant.CountryHint.HasValue)
                {
                    url = QueryHelpers.AddQueryString(url, "primary.phone.country_hint", identityCheckRequest.PrimaryApplicant.CountryHint.Value.GetDescription());
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.PrimaryApplicant.EmailAddress))
                {
                    url = QueryHelpers.AddQueryString(url, "primary.email_address", identityCheckRequest.PrimaryApplicant.EmailAddress);
                }
            }

            if (identityCheckRequest.SecondaryApplicant != null)
            {
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.FullName))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.name", identityCheckRequest.SecondaryApplicant.FullName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.FirstName))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.firstname", identityCheckRequest.SecondaryApplicant.FirstName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.LastName))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.lastname", identityCheckRequest.SecondaryApplicant.LastName);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.StreetLine1))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.street_line_1", identityCheckRequest.SecondaryApplicant.StreetLine1);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.StreetLine2))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.street_line_2", identityCheckRequest.SecondaryApplicant.StreetLine2);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.City))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.city", identityCheckRequest.SecondaryApplicant.City);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.PostalCode))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.postal_code", identityCheckRequest.SecondaryApplicant.PostalCode);
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.StateCode))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.state_code", identityCheckRequest.SecondaryApplicant.StateCode);
                }
                if (identityCheckRequest.SecondaryApplicant.CountryCode.HasValue)
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.address.country_code", identityCheckRequest.SecondaryApplicant.CountryCode.Value.GetDescription());
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.Phone))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.phone", identityCheckRequest.SecondaryApplicant.Phone);
                }
                if (identityCheckRequest.SecondaryApplicant.CountryHint.HasValue)
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.phone.country_hint", identityCheckRequest.SecondaryApplicant.CountryHint.Value.GetDescription());
                }
                if (!string.IsNullOrEmpty(identityCheckRequest.SecondaryApplicant.EmailAddress))
                {
                    url = QueryHelpers.AddQueryString(url, "secondary.email_address", identityCheckRequest.SecondaryApplicant.EmailAddress);
                }
            }
            return url;
        }
    }
}
