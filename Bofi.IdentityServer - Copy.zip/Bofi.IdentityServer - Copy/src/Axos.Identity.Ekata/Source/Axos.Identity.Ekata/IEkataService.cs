﻿using Axos.Identity.Ekata.Models.Requests;
using Axos.Identity.Ekata.Models.Response;
using System.Threading.Tasks;

namespace Axos.Identity.Ekata
{
    public interface IEkataService
    {
        Task<IdentityCheckResponseV33> PerformIdentityCheckAsync(IdentityCheckRequestV33 identityCheckRequest, bool useTestConfig = false);
        IdentityCheckResponseV33 PerformIdentityCheck(IdentityCheckRequestV33 identityCheckRequest, bool useTestConfig = false);
    }
}
