﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Ekata.Enums
{
    public enum NameMappingStatusEnum
    {
        [Description("No name found"), EnumMember(Value = "No name found")] NotNameFound,
        [Description("Match"), EnumMember(Value = "Match")] Match,
        [Description("No match"), EnumMember(Value = "No match")] NoMatch,
    }
}
