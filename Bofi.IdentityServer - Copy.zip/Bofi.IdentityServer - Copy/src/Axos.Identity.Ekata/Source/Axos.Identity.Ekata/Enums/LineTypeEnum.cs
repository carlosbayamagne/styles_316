﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum LineTypeEnum
    {
        [Description("Other"), EnumMember(Value = "Other")] Other,
        [Description("Landline"), EnumMember(Value = "Landline")] Landline,
        [Description("Fixed VOIP"), EnumMember(Value = "Fixed VOIP")] FixedVoIp,
        [Description("Mobile"), EnumMember(Value = "Mobile")] Mobile,
        [Description("Voicemail"), EnumMember(Value = "Voicemail")] Voicemail,
        [Description("Tollfree"), EnumMember(Value = "Tollfree")] Tollfree,
        [Description("Premium"), EnumMember(Value = "Premium")] Premium,
        [Description("Non-fixed VOIP"), EnumMember(Value = "Non-fixed VOIP")] NonFixedVoIp,
    }
}
