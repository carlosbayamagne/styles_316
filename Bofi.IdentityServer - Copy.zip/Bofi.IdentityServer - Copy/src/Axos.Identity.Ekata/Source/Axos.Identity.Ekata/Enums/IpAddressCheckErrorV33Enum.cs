﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace Axos.Identity.Ekata.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum IpAddressCheckErrorV33Enum
    {
        [Description("Partial"), EnumMember(Value = "Partial")] Partial,
    }
}
