﻿using Axos.Identity.Ekata.Enums;
using Axos.Identity.Ekata.Models.Requests;
using FluentValidation;
using Moq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Axos.Identity.Ekata.Test
{
    public class EkataServiceTests
    {
        [Fact]
        public async Task TestIdentityCheck()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                }
            };


            var response = await ekataService.PerformIdentityCheckAsync(request);

            Assert.NotNull(response);
        }

        [Fact(Skip = "Prevent going to Production, only for debug")]
        public void PerformIdentityCheck_ProductionGuidCheck()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Production");

            var request = new IdentityCheckRequestV33
            {
                                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                },
                TransactionId = "low_confidence_score"
            };

            Assert.Throws<InvalidOperationException>(() => ekataService.PerformIdentityCheck(request));
        }

        [Fact]
        public void PerformIdentityCheck_UseRequestApiKey()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = ekataService.PerformIdentityCheck(request,true);

            Assert.NotNull(response);
        }

        [Fact(Skip = "Prevent going to Production, only for debug")]
        public async Task PerformIdentityCheckAsync_ProductionGuidCheck()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Production");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Waidong L Syrws",
                    FirstName = "Waidong",
                    LastName = "Syrws",
                    StreetLine1 = "100 Syrws St",
                    StreetLine2 = "Ste 1",
                    City = "Lynden",
                    PostalCode = "98264",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "2069735100",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "waidong@gmail.com"
                },
                TransactionId = "low_confidence_score"
            };

            await Assert.ThrowsAsync<InvalidOperationException>(() => ekataService.PerformIdentityCheckAsync(request));
        }

        [Fact]
        public async Task PerformIdentityCheckAsync_UseRequestApiKey()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = await ekataService.PerformIdentityCheckAsync(request, true);

            Assert.NotNull(response);
        }

        [Fact]
        public async Task PerformIdentityCheckAsync_MapsRequest()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel{
                    FullName = "Test Match2",
                    FirstName = "Test2",
                    LastName = "Match2",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = await ekataService.PerformIdentityCheckAsync(request, true);

            Assert.NotNull(response);
            Assert.Equal(request.TransactionId, response.Request.TransactionId);
            Assert.Equal(request.PrimaryApplicant.FullName, response.Request.PrimaryApplicant.FullName);
            Assert.Equal(request.SecondaryApplicant.FullName, response.Request.SecondaryApplicant.FullName);
        }

        [Fact]
        public void PerformIdentityCheck_UseTestConfig_SendsIPFormated()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Test Match2",
                    FirstName = "Test2",
                    LastName = "Match2",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = ekataService.PerformIdentityCheck(request, true);

            Assert.NotNull(response);
            Assert.Equal(request.TransactionId, response.Request.TransactionId);
            Assert.Equal(request.PrimaryApplicant.FullName, response.Request.PrimaryApplicant.FullName);
            Assert.Equal(request.SecondaryApplicant.FullName, response.Request.SecondaryApplicant.FullName);
            Assert.Null(response.IpAddressChecks?.Geolocation);
        }

        [Fact]
        public void PerformIdentityCheck_DontUseTestConfig_SendsIPUnformatted()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Test Match2",
                    FirstName = "Test2",
                    LastName = "Match2",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = ekataService.PerformIdentityCheck(request);

            Assert.NotNull(response);
            Assert.Equal(request.TransactionId, response.Request.TransactionId);
            Assert.Equal(request.PrimaryApplicant.FullName, response.Request.PrimaryApplicant.FullName);
            Assert.Equal(request.SecondaryApplicant.FullName, response.Request.SecondaryApplicant.FullName);
            Assert.NotNull(response.IpAddressChecks?.Geolocation);
        }

        [Fact]
        public async Task PerformIdentityCheckAsync_UseTestConfig_SendsIPFormated()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Test Match2",
                    FirstName = "Test2",
                    LastName = "Match2",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = await ekataService.PerformIdentityCheckAsync(request, true);

            Assert.NotNull(response);
            Assert.Equal(request.TransactionId, response.Request.TransactionId);
            Assert.Equal(request.PrimaryApplicant.FullName, response.Request.PrimaryApplicant.FullName);
            Assert.Equal(request.SecondaryApplicant.FullName, response.Request.SecondaryApplicant.FullName);
            Assert.Null(response.IpAddressChecks?.Geolocation);
        }

        [Fact]
        public async Task PerformIdentityCheckAsync_DontUseTestConfig_SendsIPUnformatted()
        {
            var validatorMock = new Mock<IValidator<IdentityCheckRequestV33>>();
            validatorMock.Setup(validator =>
                validator.ValidateAsync(It.IsAny<IdentityCheckRequestV33>(), default(CancellationToken)))
                .ReturnsAsync(new FluentValidation.Results.ValidationResult
                {
                }
                );

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var ekataService = new EkataService("Development");

            var request = new IdentityCheckRequestV33
            {
                IpAddress = System.Net.IPAddress.Parse("54.190.251.42"),
                PrimaryApplicant = new Ekata.Models.PrimaryApplicantInformationModel
                {
                    FullName = "Test Match",
                    FirstName = "Test",
                    LastName = "Match",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                SecondaryApplicant = new Ekata.Models.SecondaryApplicantInformationModel
                {
                    FullName = "Test Match2",
                    FirstName = "Test2",
                    LastName = "Match2",
                    StreetLine1 = "101 Test St",
                    StreetLine2 = "Ste 1",
                    City = "Seattle",
                    PostalCode = "98101",
                    StateCode = "WA",
                    CountryCode = CountryCode.UnitedStatesofAmerica,
                    Phone = "1000000002",
                    CountryHint = CountryCode.UnitedStatesofAmerica,
                    EmailAddress = "test2@ekata.com"
                },
                ApiKey = "_fixture",
                TransactionId = "low_confidence_score"
            };

            var response = await ekataService.PerformIdentityCheckAsync(request);

            Assert.NotNull(response);
            Assert.Equal(request.TransactionId, response.Request.TransactionId);
            Assert.Equal(request.PrimaryApplicant.FullName, response.Request.PrimaryApplicant.FullName);
            Assert.Equal(request.SecondaryApplicant.FullName, response.Request.SecondaryApplicant.FullName);
            Assert.NotNull(response.IpAddressChecks?.Geolocation);
        }
    }
}
